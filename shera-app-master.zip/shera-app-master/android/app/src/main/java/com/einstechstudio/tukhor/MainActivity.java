package com.einstechstudio.tukhor;

import android.os.Bundle;

import com.jakewharton.threetenabp.AndroidThreeTen;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //GeneratedPluginRegistrant.registerWith(getFlutterEngine());
        AndroidThreeTen.init(this);

    }

}
