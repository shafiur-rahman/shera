package bd.com.quizgiri.quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
