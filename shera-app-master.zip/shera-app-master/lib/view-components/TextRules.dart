import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RulesText extends StatelessWidget {
  String text = "";
  var room;
  RulesText({
    Key key,this.text, room
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
          top: 4),
      child: Row(
        crossAxisAlignment:
        CrossAxisAlignment
            .start,
        children: [
          Container(
            margin:
            EdgeInsets.only(
                right: 16,
                top: 8),
            height: 4,
            width: 4,
            decoration:
            BoxDecoration(
              color:
              Colors.white,
              shape: BoxShape
                  .circle,
            ),
          ),
          Expanded(
            child: Container(
              child: Text(
                text,
                style:
                TextStyle(
                  fontFamily:
                  "Poppins",
                  fontSize: 14,
                  color: Colors
                      .white,
                  fontWeight:
                  FontWeight
                      .w500,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}