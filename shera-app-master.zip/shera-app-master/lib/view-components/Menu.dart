/*
* Created by Ahammed Hossain Shanto
* on 7/5/20
*/

import 'dart:math';

import 'package:app_review/app_review.dart';
import 'package:badges/badges.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:launch_review/launch_review.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Pop_Ups/DownloadApp.dart';

class Menu {
  static YYDialog yyDialog = new YYDialog();

  static Future<void> init() {
//    if(Platform.isIOS) {
//      inAppReview.openStoreListing(appStoreId: APP_STORE_ID);
//    }
  }

  static show(BuildContext context, {var noti}) {
    double availableHeight = MediaQuery.of(context).size.height - 80;
    double requiredHeight = 610;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 60
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.7)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Stack(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(0, 0, 0, 28),
            height: calculatedHeight,
            child: Container(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white,
                ),
                padding: EdgeInsets.fromLTRB(24, 0, 12, 52),
                child: Scrollbar(
                  child: SingleChildScrollView(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 12, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          InkWell(
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 24, 0, 16),
                              padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[100],
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    child: Icon(
                                      Icons.search,
                                      size: 12,
                                      color: Colors.grey[500],
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      margin: EdgeInsets.fromLTRB(16, 0, 0, 0),
                                      child: Text(
                                        '${LocaleValues.instance.getText(LocaleKey.SEARCH_TOPICS)}',
                                        style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 12,
                                          color: Colors.grey[500],
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.pushNamed(context, SearchTopicsRoute);
                            },
                          ),
                          Material(
                            color: Colors.transparent,
                            child: Column(
                              children: [
                                InkWell(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Image.asset(
                                                "assets/images/ic_avatar.png",
                                                height: 40,
                                                width: 40,
                                              ),
                                            ),
                                            Expanded(
                                              child: Container(
                                                margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                                                child: Text(
                                                  '${LocaleValues.instance.getText(LocaleKey.PROFILE)}',
                                                  style: TextStyle(fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                                ),
                                              ),
                                            ),
                                            Container(
                                                child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 16,
                                              color: Colors.grey[400],
                                            ))
                                          ],
                                        ),
                                        Container(
                                          height: 0.5,
                                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                          color: Colors.grey[300],
                                        )
                                      ],
                                    ),
                                  ),
                                  onTap: () {
                                    if (ModalRoute.of(context).settings.name != ProfileRoute) {
                                      Navigator.of(context).pop();
                                      Navigator.pushNamed(context, ProfileRoute);
                                    } else {
                                      Navigator.of(context).pop();
                                    }
                                  },
                                ),
                                InkWell(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Icon(
                                                Icons.category,
                                                color: Colors.white,
                                                size: 24,
                                              ),
                                              padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.green[300],
                                              ),
                                            ),
                                            Expanded(
                                              child: Container(
                                                margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                                                child: Text(
                                                  '${LocaleValues.instance.getText(LocaleKey.CATEGORIES)}',
                                                  style: TextStyle(fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                                ),
                                              ),
                                            ),
                                            Container(
                                                child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 16,
                                              color: Colors.grey[400],
                                            ))
                                          ],
                                        ),
                                        Container(
                                          height: 0.5,
                                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                          color: Colors.grey[300],
                                        )
                                      ],
                                    ),
                                  ),
                                  onTap: () {
                                    if (ModalRoute.of(context).settings.name != CategoryListRoute) {
                                      Navigator.of(context).pop();
                                      Navigator.pushNamed(context, CategoryListRoute);
                                    } else {
                                      Navigator.of(context).pop();
                                    }
                                  },
                                ),
                                InkWell(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Icon(
                                                Icons.notifications,
                                                color: Colors.white,
                                                size: 24,
                                              ),
                                              padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                                              decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.button_color_pink),
                                            ),
                                            Expanded(
                                              child: Row(
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                                                    child: Badge(
                                                      badgeColor: Colors.white,
                                                      showBadge: noti != null && noti['promotion'],
                                                      padding: EdgeInsets.all(0),
                                                      position: BadgePosition(top: 0, end: -20),
                                                      elevation: 1,
                                                      badgeContent: Container(
                                                        margin: EdgeInsets.all(2),
                                                        decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.button_color_pink),
                                                        height: 10,
                                                        width: 10,
                                                      ),
                                                      child: Text(
                                                        '${LocaleValues.instance.getText(LocaleKey.NOTIFICATIONS)}',
                                                        style: TextStyle(fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                                      ),
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Container(),
                                                  )
                                                ],
                                              ),
                                            ),
                                            Container(
                                                child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 16,
                                              color: Colors.grey[400],
                                            ))
                                          ],
                                        ),
                                        Container(
                                          height: 0.5,
                                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                          color: Colors.grey[300],
                                        )
                                      ],
                                    ),
                                  ),
                                  onTap: () {
                                    if (ModalRoute.of(context).settings.name != NotificationsRoute) {
                                      Navigator.of(context).pop();
                                      Navigator.pushNamed(context, NotificationsRoute);
                                    } else {
                                      Navigator.of(context).pop();
                                    }
                                  },
                                ),
                                InkWell(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Image.asset(
                                                "assets/images/ic_settings_rounded.png",
                                                height: 40,
                                                width: 40,
                                              ),
                                            ),
                                            Expanded(
                                              child: Container(
                                                margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                                                child: Text(
                                                  '${LocaleValues.instance.getText(LocaleKey.SETTINGS)}',
                                                  style: TextStyle(fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                                ),
                                              ),
                                            ),
                                            Container(
                                                child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 16,
                                              color: Colors.grey[400],
                                            ))
                                          ],
                                        ),
                                        Container(
                                          height: 0.5,
                                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                          color: Colors.grey[300],
                                        )
                                      ],
                                    ),
                                  ),
                                  onTap: () {
                                    if (ModalRoute.of(context).settings.name != SettingsRoute) {
                                      Navigator.of(context).pop();
                                      Navigator.pushNamed(context, SettingsRoute);
                                    } else {
                                      Navigator.of(context).pop();
                                    }
                                  },
                                ),
                                InkWell(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Icon(
                                                Icons.people,
                                                color: Colors.white,
                                                size: 24,
                                              ),
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: ColorsLocal.button_color_purple,
                                              ),
                                              padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                                            ),
                                            Expanded(
                                              child: Row(
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                                                    child: Badge(
                                                      badgeColor: Colors.white,
                                                      showBadge: noti != null && noti['challenge'],
                                                      padding: EdgeInsets.all(0),
                                                      position: BadgePosition(top: 0, end: -20),
                                                      elevation: 1,
                                                      badgeContent: Container(
                                                        margin: EdgeInsets.all(2),
                                                        decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.button_color_pink),
                                                        height: 10,
                                                        width: 10,
                                                      ),
                                                      child: Text(
                                                        '${LocaleValues.instance.getText(LocaleKey.CHALLENGES)}',
                                                        style: TextStyle(fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                                        textAlign: TextAlign.start,
                                                      ),
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Container(),
                                                  )
                                                ],
                                              ),
                                            ),
                                            Container(
                                                child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 16,
                                              color: Colors.grey[400],
                                            ))
                                          ],
                                        ),
                                        Container(
                                          height: 0.5,
                                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                          color: Colors.grey[300],
                                        )
                                      ],
                                    ),
                                  ),
                                  onTap: () {
                                    if (ModalRoute.of(context).settings.name != ChallengesRoute) {
                                      Navigator.of(context).pop();
                                      Navigator.pushNamed(context, ChallengesRoute);
                                    } else {
                                      Navigator.of(context).pop();
                                    }
                                  },
                                ),
                                InkWell(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Image.asset(
                                                "assets/images/ic_purchase.png",
                                                height: 40,
                                                width: 40,
                                              ),
                                            ),
                                            Expanded(
                                              child: Container(
                                                margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                                                child: Text(
                                                  '${LocaleValues.instance.getText(LocaleKey.PURCHASE_HISTORY)}',
                                                  style: TextStyle(fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                                ),
                                              ),
                                            ),
                                            Container(
                                                child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 16,
                                              color: Colors.grey[400],
                                            ))
                                          ],
                                        ),
                                        Container(
                                          height: 0.5,
                                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                          color: Colors.grey[300],
                                        )
                                      ],
                                    ),
                                  ),
                                  onTap: () {
                                    if (ModalRoute.of(context).settings.name != PurchaseHistoryRoute) {
                                      Navigator.of(context).pop();
                                      Navigator.pushNamed(context, PurchaseHistoryRoute);
                                    } else {
                                      Navigator.of(context).pop();
                                    }
                                  },
                                ),
                                InkWell(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Icon(
                                                Icons.mail,
                                                color: Colors.white,
                                                size: 24,
                                              ),
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.blue,
                                              ),
                                              padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                                            ),
                                            Expanded(
                                              child: Container(
                                                margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                                                child: Text(
                                                  '${LocaleValues.instance.getText(LocaleKey.INVITE_FRIENDS)}',
                                                  style: TextStyle(fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                              ),
                                            ),
                                            Container(
                                                child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 16,
                                              color: Colors.grey[400],
                                            ))
                                          ],
                                        ),
                                        Container(
                                          height: 0.5,
                                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                          color: Colors.grey[300],
                                        )
                                      ],
                                    ),
                                  ),
                                  onTap: () {
                                    if (PackageSupport.instance.isMobile()) {
                                      if (ModalRoute.of(context).settings.name != InviteFriendsRoute) {
                                        Navigator.of(context).pop();
                                        Navigator.pushNamed(context, InviteFriendsRoute);
                                      } else {
                                        Navigator.of(context).pop();
                                      }
                                    } else {
                                      DownloadApp.showDialog(context);
                                    }
                                  },
                                ),
                                InkWell(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    padding: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              child: Icon(
                                                Icons.rate_review,
                                                color: Colors.orange,
                                                size: 24,
                                              ),
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.orange.withOpacity(0.2),
                                              ),
                                              padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                                            ),
                                            Expanded(
                                              child: Container(
                                                margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                                                child: Text(
                                                  '${LocaleValues.instance.getText(LocaleKey.RATE_QUIZGIRI)}',
                                                  style: TextStyle(fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                              ),
                                            ),
                                            Container(
                                                child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 16,
                                              color: Colors.grey[400],
                                            ))
                                          ],
                                        ),
                                        Container(
                                          height: 0.5,
                                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                          //color: Colors.grey[300],
                                        )
                                      ],
                                    ),
                                  ),
                                  onTap: () async {
                                    if (PackageSupport.instance.isMobile()) {
                                      try {
                                        AppReview.requestReview.then((onValue) {
                                          Navigator.pop(context);
                                          //Logger.printWrapped(onValue.toString());
                                        });
                                      } catch (_) {
                                        //Logger.printWrapped("Catch called");
                                        LaunchReview.launch(androidAppId: PACKAGE_NAME_ANDROID, iOSAppId: APP_STORE_ID);
                                      }
                                    } else {
                                      DownloadApp.showDialog(context);
                                    }
                                  },
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.button_color_pink),
              child: IconButton(
                icon: Icon(
                  Icons.clear,
                  size: 24,
                  color: Colors.white,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
          )
        ],
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
