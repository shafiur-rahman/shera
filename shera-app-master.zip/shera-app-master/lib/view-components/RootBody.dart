/*
* Created by Ahammed Hossain Shanto
* on 2/16/21
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/RedirectToBrowser.dart';
import 'package:quiz/models/RootSize.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../constants/ProjectConstants.dart';

class RootBody extends StatefulWidget {
  // Widget _getChild({BuildContext context, Widget child}) {
  //   double margin = 0;
  //   if(MediaQuery.of(context).size.width > SCREEN_BREAK) {
  //     margin = MediaQuery.of(context).size.width - SCREEN_BREAK;
  //   }
  //   return Container(
  //     margin: EdgeInsets.symmetric(horizontal: margin/2),
  //     child: child,
  //   );
  // }

  final Widget child;
  bool needLogin;

  RootBody({this.child, this.needLogin = true});

  @override
  _RootBodyState createState() => _RootBodyState();
}

class _RootBodyState extends State<RootBody> {

  bool isLoggedIn = true;

  checkLogin() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String accessToken = sharedPreferences.getString(ACCESS_TOKEN);
    if(!(accessToken != null && accessToken.toString().isNotEmpty)) {
      setState(() {
        isLoggedIn = false;
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    if(widget.needLogin) {
      checkLogin();
    }
    new RootSize(context).init();
    double margin = 0;
    double width = MediaQuery.of(context).size.width;
    if (width > SCREEN_BREAK && !AppSessionSettings.isFullScreen) {
      margin = MediaQuery.of(context).size.width - SCREEN_BREAK;
      width = SCREEN_BREAK;
    }
    return Container(
      color: Colors.grey[800],
      child: Align(
        alignment: Alignment.center,
        child: Container(
          //padding: EdgeInsets.symmetric(horizontal: margin/2),
          width: width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                height: isLoggedIn ? 0 : MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                    color: Colors.white
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(32, 0, 32, 0),
                        child: Text(
                          "You are not logged in. You must login to access this page",
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 22,
                              color: ColorsLocal.text_color,
                              fontWeight: FontWeight.w600,
                              decoration: TextDecoration.none
                          ),
                          textAlign: TextAlign.center,

                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
                        child: RaisedButton(
                            elevation: 0,
                            highlightElevation: 0,
                            child: Text(
                              "Login Now",
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                            ),
                            color: ColorsLocal.button_color_pink,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
                            onPressed: () async {
                              SharedPreferences sharedPreference = await SharedPreferences.getInstance();
                              var route = {
                                'route': ModalRoute.of(context).settings.name,
                                'arguments': ModalRoute.of(context).settings.arguments
                              };
                              sharedPreference.setString(PENDING_ROUTE, json.encode(route));
                              RedirectToBrowser.instance.launch(WEB_APP_URL, newTab: false);
                            }
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                  child: widget.child
              ),
            ],
          ),
        ),
      ),
    );
  }
}

