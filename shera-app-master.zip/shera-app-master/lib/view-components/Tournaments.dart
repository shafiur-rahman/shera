/*
* Created by Ahammed Hossain Shanto
* on 7/2/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/ImageLoader.dart';

class Tournaments {
  static Color oddColor = ColorsLocal.hexToColor("843BE2");
  static Color oddColor_dark = ColorsLocal.hexToColor("771ced");
  static Color evenColor = ColorsLocal.hexToColor("3B6AE2");
  static Color evenColor_dark = ColorsLocal.hexToColor("3734d6");

  static Widget tile(
    double height,
    double width,
    int index,
    List tournaments, {
    double radius = 8,
    double initialGap = 16,
    double gapBetween = 16,
    GestureTapCallback onTap,
  }) {
    return Container(
      margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 16, 0),
      child: PhysicalModel(
        color: Colors.transparent,
        clipBehavior: Clip.antiAlias,
        borderRadius: BorderRadius.circular(radius),
        child: Container(
          height: height,
          width: width,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            color: index % 2 == 0 ? evenColor : oddColor,
          ),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                child: Container(
                  height: height,
                  width: height,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage("https://i.ibb.co/ch7sF1K/live-quiz-bg-banner.png"),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                top: 0,
                child: InkWell(
                  child: Container(
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                    child: Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 10.0),
                                      child: Text(
                                        'পুরস্কার ১২০০০ টাকা',
                                        style: TextStyle(fontSize: 12, fontFamily: "Poppins", color: Colors.white, fontWeight: FontWeight.w500),
                                        textAlign: TextAlign.start,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Text(
                                        '${tournaments[index]['name'].toString()}',
                                        style: TextStyle(fontSize: 24, fontFamily: "Poppins", color: Colors.white, fontWeight: FontWeight.w700),
                                        textAlign: TextAlign.start,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
                            margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Text(
                                      '২ দিন ১২ ঘণ্টা ৩০ মিনিট',
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        color: index % 2 == 0 ? evenColor_dark : oddColor_dark,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  onTap: onTap,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  static Widget tileShimmer(double height, double width, int index, {double radius = 15, double initialGap = 16, double gapBetween = 16}) {
    return Container(
      child: MyShimmer.fromColors(
          child: Container(
            margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 16, 0),
            height: height,
            width: width,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(radius),
              color: Colors.grey[300],
            ),
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white),
    );
  }
}
