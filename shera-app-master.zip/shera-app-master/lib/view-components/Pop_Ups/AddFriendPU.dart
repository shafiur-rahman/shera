import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/ChallengeInfo.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/UserPopupVM.dart';
import 'package:shimmer/shimmer.dart';

class AddFriendPU {
  static YYDialog yyDialog = new YYDialog();

  static show(BuildContext context, var user) {
    double availableHeight = MediaQuery.of(context).size.height - 250;
    double requiredHeight = 420;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 60
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (_) {
              return UserPopupVm(user);
            },
          ),
        ],
        child: Consumer<UserPopupVm>(
          builder: (context, snapshot, _) {
            return Stack(
              // overflow: Overflow.visible,
              children: [
                Container(
                  //padding: EdgeInsets.fromLTRB(0, 28, 0, 0),
                  margin: EdgeInsets.only(top: 40),
                  height: snapshot.user['self'] ? calculatedHeight - 40 : calculatedHeight,
                  child: Container(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Material(
                              clipBehavior: Clip.antiAlias,
                              borderRadius: BorderRadius.only(
                                topRight: Radius.circular(20),
                                topLeft: Radius.circular(20),
                              ),
                              color: ColorsLocal.hexToColor("5C13BA"),
                              child: Container(
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0, 50, 0, 0),
                                  child: Column(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(left: 24, right: 24),
                                        child: Text(
                                          snapshot.user['name'].toString(),
                                          style: TextStyle(color: ColorsLocal.hexToColor("FFFFFF"), fontFamily: "Poppins", fontWeight: FontWeight.bold, fontSize: 20),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(top: 8, bottom: 16),
                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), border: Border.all(color: ColorsLocal.hexToColor("EADAFF"), width: 1)),
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(20, 6, 20, 6),
                                          child: Text(
                                            '${LocaleKey.LEVEL.toLocaleText()} ${snapshot.user['level'].toString().toLocaleNumber()}',
                                            style: TextStyle(color: ColorsLocal.hexToColor("FFFFFF"), fontFamily: "Poppins", fontWeight: FontWeight.bold, fontSize: 12),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(30, 16, 30, 8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      child: Container(
                                        child: Text(
                                          LocaleKey.TOTAL_POINTS.toLocaleText(),
                                          style: TextStyle(color: ColorsLocal.hexToColor("4D4D4D"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      child: Text(
                                        snapshot.user['total_point'].toString().toLocaleNumber(),
                                        //'${snapshot.userDetails['wallet']['gems'].toString()}',
                                        style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.hexToColor("F63677"), fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(24, 0, 24, 0),
                              child: Divider(
                                color: ColorsLocal.hexToColor("F1F1F1"),
                                thickness: 2,
                              ),
                            ),
                            Container(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(30, 8, 30, 8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      LocaleKey.HIGH_SCORE_IN_ANY_TOPIC.toLocaleText(),
                                      style: TextStyle(color: ColorsLocal.hexToColor("4D4D4D"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14),
                                    ),
                                    Container(
                                      child: Text(
                                        snapshot.user['topic_high_score'].toString().toLocaleNumber(),
                                        style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.hexToColor("F63677"), fontWeight: FontWeight.bold),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(24, 0, 24, 0),
                              child: Divider(
                                color: ColorsLocal.hexToColor("F1F1F1"),
                                thickness: 2,
                              ),
                            ),
                            Container(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(30, 8, 30, 8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      LocaleKey.TOURNAMENT_WIN.toLocaleText(),
                                      style: TextStyle(color: ColorsLocal.hexToColor("4D4D4D"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14),
                                    ),
                                    Container(
                                      child: Text(
                                        '${snapshot.user['tournament_win'].toString().toLocaleNumber()}/${snapshot.user['tournament_played'].toString().toLocaleNumber()}',
                                        //'${snapshot.userDetails['wallet']['gems'].toString()}',
                                        style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.hexToColor("F63677"), fontWeight: FontWeight.bold),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(24, 0, 24, 0),
                              child: Divider(
                                color: ColorsLocal.hexToColor("F1F1F1"),
                                thickness: 2,
                              ),
                            ),
                            !snapshot.user['self']
                                ? Padding(
                                    padding: const EdgeInsets.fromLTRB(30, 24, 30, 5),
                                    child: MaterialButton(
                                      elevation: 0,
                                      highlightElevation: 0,
                                      shape: RoundedRectangleBorder(side: snapshot.user['friendship_status'] == "pending" || snapshot.user['friendship_status'] == "requested" ? BorderSide(color: ColorsLocal.hexToColor("27AE60")) : BorderSide(color: ColorsLocal.hexToColor("FFFFFF"), width: 0), borderRadius: BorderRadius.all(Radius.circular(5.0))),
                                      color: snapshot.user['friendship_status'] != "friend" && snapshot.user['friendship_status'] != "not_friend" ? Colors.white : ColorsLocal.button_color_pink,
                                      onPressed: () {
                                        if (snapshot.user['friendship_status'] == "not_friend") {
                                          snapshot.sendRequest(snapshot.user["user_id"]);
                                        } else if (snapshot.user['friendship_status'] == "pending") {
                                          snapshot.friendRequestAccept();
                                        } else if (snapshot.user['friendship_status'] == "friend") {
                                          ChallengeInfo.friendUserId = int.parse(snapshot.user['user_id'].toString());
                                          Navigator.pop(context);
                                          Navigator.pushNamed(context, ChallengeFriendRoute);
                                        }
                                      },
                                      child: Padding(
                                        padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                                        child: Center(
                                            child: snapshot.processing
                                                ? Container(
                                                    height: 24,
                                                    width: 24,
                                                    child: CircularProgressIndicator(
                                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.grey[200]),
                                                      strokeWidth: 2,
                                                    ))
                                                : snapshot.user['friendship_status'] == "pending"
                                                    ? Text(
                                                        LocaleKey.ACCEPT_REQUEST.toLocaleText(),
                                                        style: TextStyle(color: ColorsLocal.hexToColor("27AE60"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16),
                                                      )
                                                    : snapshot.user['friendship_status'] == "requested"
                                                        ? Text(
                                                            LocaleKey.REQUEST_SENT.toLocaleText(),
                                                            style: TextStyle(color: ColorsLocal.hexToColor("27AE60"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16),
                                                          )
                                                        : snapshot.user['friendship_status'] == "not_friend"
                                                            ? Text(
                                                                LocaleKey.ADD_FRIEND.toLocaleText(),
                                                                style: TextStyle(color: ColorsLocal.hexToColor("FFFFFF"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16),
                                                              )
                                                            : snapshot.user['friendship_status'] == "friend"
                                                                ? Text(
                                                                    LocaleKey.CHALLENGE.toLocaleText(),
                                                                    style: TextStyle(color: ColorsLocal.hexToColor("FFFFFF"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16),
                                                                  )
                                                                : Text(
                                                                    LocaleKey.UNAVAILABLE.toLocaleText(),
                                                                    style: TextStyle(color: Colors.grey[500], fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16),
                                                                  )),
                                      ),
                                    ),
                                  )
                                : Container()
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  top: 0,
                  child: Center(
                    child: Container(
                        //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                          border: Border.all(width: 4, color: Colors.white),
                        ),
                        constraints: BoxConstraints.tightFor(height: 80, width: 80),
                        child: CachedNetworkImage(
                          imageUrl: snapshot.user['image_url'].toString(),
                          //imageUrl: snapshot.userDetails['image_url'].toString(),
                          imageBuilder: (context, imageProvider) => Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              //borderRadius: BorderRadius.circular(4),
                              image: DecorationImage(
                                image: imageProvider,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          placeholder: (context, url) => Shimmer.fromColors(
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                //borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[300],
                              ),
                            ),
                            baseColor: Colors.grey[300],
                            highlightColor: Colors.white,
                          ),
                          errorWidget: (context, url, error) => Icon(Icons.error),
                        )),
                  ),
                )
              ],
            );
          },
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
