/*
* Created by Shanto on 28/07/2020
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';

class BCSModelResult {
  static showDialog(
    BuildContext context,
    dynamic result, {
    GestureTapCallback onTap,
  }) {
    YYDialog yyDialog = new YYDialog();

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 64
      //..height = 110
      ..backgroundColor = Colors.white
      ..borderRadius = 10.0
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..barrierDismissible = false
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(24, 24, 24, 24),
              child: Text(
                result['title'].toString(),
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 18,
                  color: ColorsLocal.text_color,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              height: 0.5,
              color: Colors.grey[300],
            ),
            Container(
              padding: EdgeInsets.fromLTRB(32, 0, 32, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.TOTAL_QUESTION.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  '${result['total_question'].toString().toLocaleNumber()}',
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.CORRECT_ANS.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  result['total_correct'].toString().toLocaleNumber(),
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.WRONG_ANSWER.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  result['total_incorrect'].toString().toLocaleNumber(),
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.SKIPPED.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  result['total_skipped'].toString().toLocaleNumber(),
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.MARK.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  result['mark_obtain'].toString().toLocaleNumber(),
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
                    child: RaisedButton(
                      elevation: 0,
                      highlightElevation: 0,
                      child: Text(
                        LocaleKey.DONE.toLocaleText(),
                        style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                      color: ColorsLocal.button_color_pink,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      onPressed: onTap,
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
