/*
* Created by Shafiur Rahman
* on 14/5/20
*/

import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/GamePlayVM.dart';

class WatchVideoPU {
  static YYDialog yyDialog = new YYDialog();

  static show(
    BuildContext context,
    GamePlayVM snapshot,
    var wallet, {
    GestureTapCallback onWatchVideoTap,
    GestureTapCallback onCoinUseTap,
    int retryCoinAmount = 100,
  }) {
    TextStyle style = TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Muli", fontWeight: FontWeight.w600, fontSize: 14);

    double availableHeight = MediaQuery.of(context).size.height;
    double requiredHeight = 350;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 50
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Stack(
        // overflow: Overflow.visible,
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 28),
            height: calculatedHeight,
            //width: double.infinity,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              child: SingleChildScrollView(
                child: Container(
                  margin: EdgeInsets.fromLTRB(35, 53, 35, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            boxShadow: [BoxShadow(color: ColorsLocal.hexToColor("C1C1C1").withOpacity(0.13), spreadRadius: 8, blurRadius: 8)],
                            border: Border.all(
                              width: 1,
                              color: ColorsLocal.hexToColor("F2F2F2"),
                            )),
                        child: InkWell(
                          onTap: onWatchVideoTap,
                          child: Container(
                            height: 60,
                            width: double.infinity,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset(
                                  "assets/images/ic_youtube.png",
                                  height: 24,
                                  width: 24,
                                ),
                                SizedBox(
                                  width: 7,
                                ),
                                Text(LocaleKey.WATCH_VIDEO.toLocaleText(), style: TextStyle(color: ColorsLocal.hexToColor("FF2E75"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18)),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 19),
                        decoration: BoxDecoration(color: ColorsLocal.button_color_purple, borderRadius: BorderRadius.circular(15), boxShadow: [BoxShadow(color: ColorsLocal.hexToColor("C1C1C1").withOpacity(0.13), spreadRadius: 8, blurRadius: 8)]),
                        child: InkWell(
                          onTap: onCoinUseTap,
                          child: Container(
                            height: 60,
                            width: double.infinity,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset(
                                  "assets/images/ic_coinbox.png",
                                  height: 24,
                                  width: 24,
                                ),
                                SizedBox(
                                  width: 7,
                                ),
                                Text('${retryCoinAmount.toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}', style: TextStyle(color: ColorsLocal.hexToColor("FFFFFF"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18)),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 19),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(LocaleKey.YOUR_BALANCE.toLocaleText(), style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w400, fontSize: 14)),
                            Image.asset(
                              "assets/images/ic_taka.png",
                              height: 17,
                              width: 17,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(wallet['coins'].toString().toLocaleNumber() ?? "0".toLocaleNumber(), style: TextStyle(color: ColorsLocal.hexToColor("FF4081"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14)),
                          ],
                        ),
                      ),
                      ChangeNotifierProvider.value(
                        value: snapshot,
                        child: Consumer<GamePlayVM>(builder: (context, snapshot, _) {
                          return Container(
                            margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                            child: snapshot.popupWorking ? CupertinoActivityIndicator() : Container(height: 20, width: 20),
                          );
                        }),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: ColorsLocal.button_color_pink,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.25),
                    spreadRadius: 1,
                    blurRadius: 15,
                    offset: Offset(0, -5), // changes position of shadow
                  ),
                ],
              ),
              child: IconButton(
                icon: Icon(
                  Icons.clear,
                  size: 24,
                  color: Colors.white,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
          )
        ],
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
