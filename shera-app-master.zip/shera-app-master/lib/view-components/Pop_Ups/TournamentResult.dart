/*
* Created by Ahammed Hossain Shanto on 8/4/20
*/

import 'dart:convert';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';

class TournamentResult {
  static YYDialog yyDialog = new YYDialog();

  static show(BuildContext context, int totalQuestion, int totalCorrect, {String redirectionUrl}) {
    TextStyle style = TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14);

    double availableHeight = MediaQuery.of(context).size.height;
    double requiredHeight = 450;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 50
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Stack(
        // overflow: Overflow.visible,
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 28),
            height: calculatedHeight,
            width: MediaQuery.of(context).size.width.toCustomWidth() - 50,
            //width: double.infinity,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              child: SingleChildScrollView(
                child: Container(
                  //margin: EdgeInsets.fromLTRB(35, 53, 35, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: ColorsLocal.button_color_purple,
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(40),
                            bottomLeft: Radius.circular(40),
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(16, 32, 16, 0),
                              child: Text(
                                LocaleKey.YOU_HAVE_GIVEN.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                              child: Text(
                                '${totalCorrect.toString().toLocaleNumber()} ${LocaleKey.CORRECT_ANS.toLocaleText()}',
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  color: Colors.white,
                                  fontSize: 30,
                                  fontWeight: FontWeight.w600,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(16, 16, 16, 32),
                              child: Text(
                                '${LocaleKey.TOTAL_QUESTION.toLocaleText()} ${totalQuestion.toString().toLocaleNumber()}',
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(16, 32, 16, 0),
                        child: Text(
                          LocaleKey.THANKS_FOR_PLAYING.toLocaleText(),
                          style: TextStyle(
                            fontFamily: "Poppins",
                            color: ColorsLocal.text_color_pink,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(16, 8, 16, 32),
                        child: Text(
                          LocaleKey.WILL_PUBLISH_RESULT_SOON.toLocaleText(),
                          style: TextStyle(
                            fontFamily: "Poppins",
                            color: ColorsLocal.text_color.withOpacity(0.6),
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        child: Align(
                          alignment: Alignment.center,
                          child: RaisedButton(
                            color: ColorsLocal.button_color_purple,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Padding(
                              padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                              child: Text(
                                LocaleKey.GO_HOME.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 14,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            onPressed: () {
                              while (Navigator.canPop(context)) {
                                Navigator.pop(context);
                              }
                              Navigator.pushReplacementNamed(context, HomeRoute);
                              if (redirectionUrl != null && redirectionUrl.isNotEmpty) {
                                Navigator.pushNamed(context, RedirectionWebViewRoute,
                                    arguments: {
                                      'launch_url': redirectionUrl,
                                    });
                              }
                            },
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: ColorsLocal.button_color_pink,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.25),
                    spreadRadius: 1,
                    blurRadius: 15,
                    offset: Offset(0, -5), // changes position of shadow
                  ),
                ],
              ),
              child: IconButton(
                icon: Icon(
                  Icons.clear,
                  size: 24,
                  color: Colors.white,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
          )
        ],
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
