/*
* Created by Shanto on 28/07/2020
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';

class TournamentPaymentOption {
  static showDialog(BuildContext context, {GestureTapCallback onCoinPay, GestureTapCallback onBDTPay, String coin_fee = "", String bdt_fee = "", String type}) {
    YYDialog yyDialog = new YYDialog();

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 64
      //..height = 110
      ..backgroundColor = Colors.white
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
              child: Text(
                LocaleKey.PAY_TO_PLAY.toLocaleText(),
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 24,
                  color: ColorsLocal.text_color_pink,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            type == "coin" || type == "optional"
                ? Container(
                    margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
                    child: RaisedButton(
                      elevation: 0,
                      highlightElevation: 0,
                      child: Text(
                        '${LocaleKey.PLAY.toLocaleText()} ${coin_fee.toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}',
                        style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                      color: ColorsLocal.button_color_pink,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      onPressed: onCoinPay,
                    ),
                  )
                : Container(),
            type == "money" || type == "optional"
                ? Container(
                    margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                    child: RaisedButton(
                      elevation: 0,
                      highlightElevation: 0,
                      child: Text(
                        '${LocaleKey.PLAY.toLocaleText()} ${bdt_fee.toString().toLocaleNumber()} ${LocaleKey.BDT.toLocaleText()}',
                        style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                      color: ColorsLocal.button_color_purple,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      onPressed: onBDTPay,
                    ),
                  )
                : Container(),
          ],
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
