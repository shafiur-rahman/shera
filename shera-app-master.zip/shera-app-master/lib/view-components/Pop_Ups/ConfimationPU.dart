/*
* Created by Shanto on 28/07/2020
*/

import 'package:facebook_app_events/facebook_app_events.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/PaymentViaMobileOperatorVM.dart';
import 'package:toast/toast.dart';

class ConfirmationPU {
  static showDialog(BuildContext context, var price, var caption, var bundleId, var tournamentId, var subscription_fee, PaymentViaMobileOperatorVM paymentViaMobileOperatorVM) {
    YYDialog yyDialog = new YYDialog();

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 100
      //..height = 110
      ..backgroundColor = Colors.white
      ..borderRadius = 10.0
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(ChangeNotifierProvider.value(
        value: paymentViaMobileOperatorVM,
        child: Consumer<PaymentViaMobileOperatorVM>(builder: (context, snapshot, _) {
          return Container(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                  child: Image.asset(
                    "assets/images/ic_purchase.png",
                    height: 40,
                    width: 40,
                  ),
                ),
                Container(
                    margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                    child: bundleId != null
                        ? Text(
                            "You are buying $caption for $price taka ",
                            style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 16,
                              color: ColorsLocal.text_color,
                              fontWeight: FontWeight.w500,
                            ),
                            textAlign: TextAlign.center,
                          )
                        : tournamentId != null
                            ? Text(
                                "Play this tournament for $subscription_fee taka",
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 16,
                                  color: ColorsLocal.text_color,
                                  fontWeight: FontWeight.w500,
                                ),
                                textAlign: TextAlign.center,
                              )
                            : null),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                          child: RaisedButton(
                            elevation: 0,
                            highlightElevation: 0,
                            child: Text(
                              "No",
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                            ),
                            color: ColorsLocal.button_color_pink,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                            onPressed: () {
                              try {
                                yyDialog?.dismiss();
                              } catch (_) {}
                              yyDialog = new YYDialog();
                            },
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                          child: RaisedButton(
                            elevation: 0,
                            highlightElevation: 0,
                            child: snapshot.processingPayment
                                ? Container(
                                    height: 27,
                                    width: 27,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Text(
                                    "Yes",
                                    style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                                  ),
                            color: ColorsLocal.button_color_pink,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                            onPressed: () {
                              if (!snapshot.processingPayment) {
                                try {
                                  if (bundleId != null) {
                                    snapshot.payment(bundleId).then((value) {
                                      if (value) {
//                                            while (Navigator.canPop(context)) {
//                                              Navigator.of(context).pop();
//                                            }

                                        //log facebook event here ***
                                        if (BUILD_TYPE == "production") {
                                          FacebookAppEvents facebookAppEvents = new FacebookAppEvents();
                                          double amount = 0;
                                          if (price != null) {
                                            amount = price;
                                          } else if (subscription_fee != null) {
                                            amount = double.parse(subscription_fee.toString());
                                          }
                                          facebookAppEvents.logPurchase(amount: amount, currency: "BDT");
                                        }
                                        Navigator.of(context).pop();
                                        var arguments = {};
                                        arguments["caption"] = caption.toString();
                                        arguments["store"] = true;
                                        Navigator.pushReplacementNamed(context, ConfirmationRoute, arguments: arguments);
                                      } else {
                                        Toast.show("Please check mobile balance", context);
                                      }
                                    });
                                  } else if (tournamentId != null) {
                                    snapshot.getTournamentPass(tournamentId).then((value) {
                                      if (value) {
//                                            while (Navigator.canPop(context)) {
//                                              Navigator.of(context).pop();
//                                              yyDialog?.dismiss();
//                                              SystemNavigator.pop();
//                                            }
                                        Navigator.of(context).pop();
                                        Navigator.pushReplacementNamed(context, ConfirmationRoute, arguments: {"tournament": true});
                                      } else {
                                        Toast.show("Please check mobile balance", context);
                                      }
                                      ;
                                    });
                                  }
                                } catch (_) {}
                                yyDialog = new YYDialog();
                              }
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          );
        }),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
