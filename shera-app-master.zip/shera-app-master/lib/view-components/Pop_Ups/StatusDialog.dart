/*
* Created by Shanto on 28/07/2020
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/values/ColorsLocal.dart';

class StatusDialog {
  static showDialog(BuildContext context, {String status = "none", String title = "", String caption = ""}) {
    Color success = ColorsLocal.hexToColor("00B960");
    Color failed = ColorsLocal.hexToColor("F6891F");

    YYDialog yyDialog = new YYDialog();

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 64
      //..height = 110
      ..backgroundColor = Colors.white
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Center(
              child: Container(
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: status == "success"
                      ? success.withOpacity(0.1)
                      : status == "failed"
                          ? failed.withOpacity(0.1)
                          : ColorsLocal.text_color.withOpacity(0.1),
                ),
                child: Center(
                  child: Icon(
                    status == "success"
                        ? Icons.check
                        : status == "failed"
                            ? Icons.error_outline
                            : Icons.email,
                    color: status == "success"
                        ? success
                        : status == "failed"
                            ? failed
                            : ColorsLocal.text_color,
                    size: 40,
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
              child: Text(
                title,
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 24,
                  color: status == "success"
                      ? success
                      : status == "failed"
                          ? failed
                          : ColorsLocal.text_color,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
              child: Text(
                caption,
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 14,
                  color: ColorsLocal.text_color,
                  fontWeight: FontWeight.w400,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
              child: RaisedButton(
                elevation: 0,
                highlightElevation: 0,
                child: Text(
                  "Okay",
                  style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                ),
                color: ColorsLocal.button_color_purple,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                onPressed: () {
                  yyDialog?.dismiss();
                  yyDialog = new YYDialog();
                },
              ),
            )
          ],
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
