/*
* Created by Ahammed Hossain Shanto
* on 7/5/20
*/

import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/ChallengeResultVM.dart';

class InviteFriendPU {
  static YYDialog yyDialog = new YYDialog();

  static show(BuildContext context) {
    TextStyle style = TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Muli", fontWeight: FontWeight.w600, fontSize: 14);

    double availableHeight = MediaQuery.of(context).size.height;
    double requiredHeight = 450;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 50
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (_) {
              return ChallengeResultVM(context);
            },
          ),
        ],
        child: Consumer<ChallengeResultVM>(
          builder: (context, snapshot, _) {
            return Stack(
              // overflow: Overflow.visible,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(10, 0, 10, 28),
                  height: calculatedHeight,
                  width: double.infinity,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    child: SingleChildScrollView(
                      child: Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              margin: EdgeInsets.only(top: 19),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text("Tanjil invited ", style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 22)),
                                  Text("you to play bangla quiz",
                                      style: TextStyle(
                                          color: ColorsLocal.hexToColor("414141"),
                                          fontFamily: "Muli",
                                          // fontWeight: FontWeight.w600,
                                          fontSize: 14)),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(28, 55, 28, 0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    children: [
                                      Container(
                                        height: 87, width: 87,
//                                   color: Colors.blue,
                                        child: CachedNetworkImage(
                                          imageUrl: 'https://www.beautycastnetwork.com/images/banner-profile_pic.jpg',
                                          imageBuilder: (context, imageProvider) => Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              //borderRadius: BorderRadius.circular(4),
                                              image: DecorationImage(
                                                image: imageProvider,
                                                fit: BoxFit.fill,
                                              ),
                                            ),
                                          ),
                                          placeholder: (context, url) => MyShimmer.fromColors(
                                            child: Container(
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                //borderRadius: BorderRadius.circular(8),
                                                color: Colors.grey[300],
                                              ),
                                            ),
                                            baseColor: Colors.grey[300],
                                            highlightColor: Colors.white,
                                          ),
                                          errorWidget: (context, url, error) => Icon(Icons.error),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 15,
                                      ),
                                    ],
                                  ),
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Text(
                                            "VS",
                                            style: TextStyle(color: ColorsLocal.hexToColor("FF4081"), fontFamily: "Poppins", fontWeight: FontWeight.bold, fontSize: 30),
                                          ),
                                        ],
                                      ),
                                      color: Colors.white,
                                    ),
                                  ),
                                  Column(
                                    children: [
                                      Container(
                                        height: 87, width: 87,
//                                   color: Colors.blue,
                                        child: CachedNetworkImage(
                                          imageUrl: 'https://www.fairtravel4u.org/wp-content/uploads/2018/06/sample-profile-pic.png',
                                          imageBuilder: (context, imageProvider) => Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              //border: Border.all(color: ColorsLocal.hexToColor("FF2E75")),
                                              //borderRadius: BorderRadius.circular(4),
                                              image: DecorationImage(
                                                image: imageProvider,
                                                fit: BoxFit.fill,
                                              ),
                                            ),
                                          ),
                                          placeholder: (context, url) => MyShimmer.fromColors(
                                            child: Container(
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                //borderRadius: BorderRadius.circular(8),
                                                color: Colors.grey[300],
                                              ),
                                            ),
                                            baseColor: Colors.grey[300],
                                            highlightColor: Colors.white,
                                          ),
                                          errorWidget: (context, url, error) => Icon(Icons.error),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 15,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              //  color: Colors.green,
                              margin: EdgeInsets.fromLTRB(50, 0, 50, 0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Tanzil",
                                    style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 14),
                                  ),
                                  Text(
                                    "Asharaf",
                                    style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 14),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 35),
                              // color: Colors.orange,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Material(
                                    shape: RoundedRectangleBorder(side: BorderSide(color: ColorsLocal.hexToColor("E5E5E5")), borderRadius: BorderRadius.all(Radius.circular(20))),
                                    color: ColorsLocal.hexToColor("8435E8"),
                                    child: InkWell(
                                      onTap: () {},
                                      child: Padding(
                                        padding: EdgeInsets.fromLTRB(25, 10, 24, 9),
                                        child: Text("Accept", style: TextStyle(color: ColorsLocal.hexToColor("FFFFFF"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18)),
                                      ),
                                    ),
                                    clipBehavior: Clip.antiAlias,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Material(
                                    shape: RoundedRectangleBorder(side: BorderSide(color: ColorsLocal.hexToColor("E5E5E5")), borderRadius: BorderRadius.all(Radius.circular(20))),
                                    color: ColorsLocal.hexToColor("FF2E75"),
                                    child: InkWell(
                                      onTap: () {},
                                      child: Padding(
                                        padding: EdgeInsets.fromLTRB(25, 10, 24, 9),
                                        child: Text("Decline", style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18)),
                                      ),
                                    ),
                                    clipBehavior: Clip.antiAlias,
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: ColorsLocal.button_color_pink,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 1,
                          blurRadius: 15,
                          offset: Offset(0, -5), // changes position of shadow
                        ),
                      ],
                    ),
                    child: IconButton(
                      icon: Icon(
                        Icons.clear,
                        size: 24,
                        color: Colors.white,
                      ),
                      padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ),
                )
              ],
            );
          },
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
