/*
* Created by Shanto on 28/07/2020
*/

import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';

class ReferralPU {
  static showDialog(BuildContext context, String imageUrl, {var data}) {
    YYDialog yyDialog = new YYDialog();

    _getWidth() {
      double w = MediaQuery.of(context).size.width.toCustomWidth() - 64;
      double width = min(w, 300);
      return width;
    }

    _getHeight() {
      double w = MediaQuery.of(context).size.width.toCustomWidth() - 64;
      double h = MediaQuery.of(context).size.height - w;
      double height = min(w, 300);
      return height;
    }

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 64
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..borderRadius = 10.0
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(GestureDetector(
        onTap: () {
          //  yyDialog?.dismiss();
          Navigator.pop(context);
          if (data != null) {
            if (data['type'] != null && data['type'] == 'topic') {
              Navigator.pushNamed(context, TopicDetailsRoute, arguments: {'topic_id': data['id'].toString(), 'type': "Suggested", 'category_name': "Topic"});
            } else if (data['type'] != null && data['type'] == 'category') {
              var arguments = {};
              arguments['type'] = "category";
              arguments['page_title'] = "Suggested Topic".toString();
              arguments['category_id'] = data['id'];

              Navigator.pushNamed(context, TopicListRoute, arguments: arguments);
            } else if (data['type'] != null && data['type'] == 'tournament') {
              Navigator.pushNamed(context, TournamentDetailsRoute, arguments: {
                'tournament_id': data['id'],
              });
            } else if (data['type'] != null && data['type'] == 'refer') {
              Navigator.pushNamed(context, InviteFriendsRoute);
            }
          }
        },
        child: Container(
          width: _getWidth(),
          height: _getHeight(),
          child: CachedNetworkImage(
            imageUrl: imageUrl,
            imageBuilder: (context, imageProvider) => Container(
              decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                //borderRadius: BorderRadius.circular(4),
                image: DecorationImage(
                  image: imageProvider,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            placeholder: (context, url) => Container(
              child: Center(
                child: SizedBox(
                  height: 40,
                  width: 40,
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    strokeWidth: 3,
                  ),
                ),
              ),
            ),
            errorWidget: (context, url, error) => Icon(Icons.error),
          ),
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
