/*
* Created by Ahammed Hossain Shanto
* on 7/5/20
*/

import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/ChallengeResultVM.dart';

class CongratulationsPU {
  static YYDialog yyDialog = new YYDialog();

  static show(BuildContext context) {
    TextStyle style = TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Muli", fontWeight: FontWeight.w600, fontSize: 14);

    double availableHeight = MediaQuery.of(context).size.height;
    double requiredHeight = 430;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 60
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (_) {
              return ChallengeResultVM(context);
            },
          ),
        ],
        child: Consumer<ChallengeResultVM>(
          builder: (context, snapshot, _) {
            return Stack(
              overflow: Overflow.visible,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(10, 0, 10, 28),
                  height: calculatedHeight,
                  width: double.infinity,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    child: SingleChildScrollView(
                      child: Container(
                        margin: EdgeInsets.fromLTRB(36, 221, 24, 64),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("Congratulations!", style: TextStyle(color: ColorsLocal.hexToColor("FF2E75"), fontFamily: "Muli", fontWeight: FontWeight.w900, fontSize: 22)),
                            Container(
                              margin: EdgeInsets.only(top: 4),
                              child: Text("You got 100 coins", style: TextStyle(color: ColorsLocal.hexToColor("F6891F"), fontFamily: "Poppins", fontWeight: FontWeight.w900, fontSize: 14)),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 5),
                              child: Text("You are now level player II", style: TextStyle(color: ColorsLocal.hexToColor("8435E8"), fontFamily: "Muli", fontWeight: FontWeight.w900, fontSize: 13)),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 19),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    height: 28,
                                    margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        color: Colors.white,
                                        border: Border.all(
                                          width: 1,
                                          color: ColorsLocal.hexToColor("E4CFFF"),
                                        )),
                                    child: Wrap(
                                      crossAxisAlignment: WrapCrossAlignment.center,
                                      children: [
                                        Container(
                                          child: Image.asset(
                                            "assets/images/ic_coin.png",
                                            height: 20,
                                            width: 20,
                                          ),
                                          padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                                          child: Text(
                                            "900",
                                            //'${snapshot.userDetails['wallet']['gems'].toString()}',
                                            style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  Container(
                                    height: 28,
                                    margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        color: Colors.white,
                                        border: Border.all(
                                          width: 1,
                                          color: ColorsLocal.hexToColor("E4CFFF"),
                                        )),
                                    child: Wrap(
                                      crossAxisAlignment: WrapCrossAlignment.center,
                                      children: [
                                        Container(
                                          child: Image.asset(
                                            "assets/images/ic_gem.png",
                                            height: 20,
                                            width: 20,
                                          ),
                                          padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                                          child: Text(
                                            "900",
                                            //'${snapshot.userDetails['wallet']['gems'].toString()}',
                                            style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: ColorsLocal.button_color_pink,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 1,
                          blurRadius: 15,
                          offset: Offset(0, -5), // changes position of shadow
                        ),
                      ],
                    ),
                    child: IconButton(
                      icon: Icon(
                        Icons.clear,
                        size: 24,
                        color: Colors.white,
                      ),
                      padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ),
                ),
                Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: Image.asset(
                      "assets/images/congratulations_background.png",
                      height: calculatedHeight - 100,
                      width: double.infinity,
                    )),
                Positioned(
                    top: 25,
                    left: 0,
                    right: 0,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                      child: Image.asset(
                        "assets/images/gifts.png",
                        height: calculatedHeight / 2.5,
                      ),
                    )),
              ],
            );
          },
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
