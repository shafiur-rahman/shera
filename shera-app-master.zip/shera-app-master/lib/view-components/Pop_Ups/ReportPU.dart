/*
* Created by Shanto on 28/07/2020
*/

import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/ReportVM.dart';

class ReportPU {
  static showDialog(BuildContext context, int questionId) {
    YYDialog yyDialog = new YYDialog();

    _getWidth() {
      double w = MediaQuery.of(context).size.width.toCustomWidth() - 64;
      double width = min(w, 300);
      return width;
    }

    _getHeight() {
      double w = MediaQuery.of(context).size.width.toCustomWidth() - 64;
      double h = MediaQuery.of(context).size.height - w;
      double height = min(w, 300);
      return height;
    }

    double availableHeight = MediaQuery.of(context).size.height - 160;
    double requiredHeight = 400;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 64
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..borderRadius = 10.0
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) {
            return ReportVM(context);
          })
        ],
        child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.white,
            ),
            width: _getWidth(),
            height: calculatedHeight,
            child: SingleChildScrollView(
              child: Stack(
                children: [
                  Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 20),
                        child: Text(
                          LocaleKey.REPORT.toLocaleText(),
                          style: TextStyle(fontFamily: "Poppins", color: ColorsLocal.hexToColor("414141"), fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Divider(),
                      Consumer<ReportVM>(builder: (context, snapshot, _) {
                        return Container(
                          padding: EdgeInsets.fromLTRB(32, 12, 32, 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: List.generate(snapshot.options.length, (index) {
                              return Material(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0, 8, 0, 8),
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(8),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(12, 10, 12, 10),
                                      decoration: BoxDecoration(
                                        //color: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index ? Colors.transparent : Colors.white.withOpacity(0.33),
                                        gradient: snapshot.toggoleReport(index)
                                            ? LinearGradient(colors: [ColorsLocal.hexToColor("FF4081"), ColorsLocal.hexToColor("FF4081")], stops: [0.0, 1.0], begin: Alignment.bottomCenter, end: Alignment.topCenter)
                                            : LinearGradient(
                                                colors: [Colors.white.withOpacity(0.5), Colors.white.withOpacity(0.33)],
                                                stops: [0.0, 1.0],
                                              ),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          width: snapshot.toggoleReport(index) ? 0 : 2,
                                          color: snapshot.toggoleReport(index)
                                              ? ColorsLocal.text_color_pink_2
                                              : snapshot.toggoleReport(index)
                                                  ? Colors.transparent
                                                  : ColorsLocal.hexToColor("E6E6E6"),
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: Container(
                                              child: Text(
                                                snapshot.options[index].toString(),
                                                style: TextStyle(fontFamily: "Poppins", color: snapshot.toggoleReport(index) ? Colors.white : ColorsLocal.hexToColor("747474"), fontSize: 18, fontWeight: FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    onTap: () {
                                      snapshot.isSelected(index);
                                    },
                                  ),
                                ),
                              );
                            }),
                          ),
                        );
                      }),
                      Consumer<ReportVM>(builder: (context, snapshot, _) {
                        return Container(
                          margin: EdgeInsets.fromLTRB(24, 20, 24, 0),
                          child: Material(
                            color: ColorsLocal.hexToColor("8435E8"),
                            clipBehavior: Clip.antiAlias,
                            borderRadius: BorderRadius.circular(10),
                            child: snapshot.reportedSubmitted
                                ? InkWell(
                                    onTap: () {
                                      // var type;
                                      // type = snapshot.options[snapshot.optionsIndex];
                                      // snapshot.onReportSubmit(questionId, type);
                                      // if(snapshot.reportedSubmitted){
                                      //   Navigator.of(context).pop();
                                      // }
                                    },
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(0, 8, 0, 8),
                                      decoration: BoxDecoration(
                                          //color: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index ? Colors.transparent : Colors.white.withOpacity(0.33),
                                          ),
                                      child: Center(
                                        child: Text(
                                          snapshot.reportedSubmitted ? LocaleKey.REPORTED.toLocaleText() : LocaleKey.SUBMIT.toLocaleText(),
                                          style: TextStyle(fontFamily: "Poppins", color: Colors.white, fontSize: 18, fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                  )
                                : InkWell(
                                    onTap: () {
                                      var type;
                                      type = snapshot.options[snapshot.optionsIndex];
                                      snapshot.onReportSubmit(questionId, type);
                                      // if(snapshot.reportedSubmitted){
                                      //   Navigator.of(context).pop();
                                      // }
                                    },
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(0, 8, 0, 8),
                                      decoration: BoxDecoration(
                                          //color: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index ? Colors.transparent : Colors.white.withOpacity(0.33),
                                          ),
                                      child: Center(
                                        child: Text(
                                          snapshot.reportedSubmitted ? LocaleKey.SUBMITTED.toLocaleText() : LocaleKey.SUBMIT.toLocaleText(),
                                          style: TextStyle(fontFamily: "Poppins", color: Colors.white, fontSize: 18, fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                    ),
                                  ),
                          ),
                        );
                      })
                    ],
                  ),
                  Positioned(
                    right: 0,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        child: Image.asset(
                          "assets/images/qr_close.png",
                          height: 20,
                          width: 20,
                        ),
                        padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                      ),
                    ),
                    top: 0,
                  )
                ],
              ),
            )),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
