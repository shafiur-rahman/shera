/*
* Created by Shanto on 28/07/2020
*/

import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/RedirectToBrowser.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/extensions/string_extensions.dart';

class SignInToPlay {
  static showDialog(BuildContext context) {
    YYDialog yyDialog = new YYDialog();

    yyDialog.build(context)
      ..width = max(MediaQuery.of(context).size.width.toCustomWidth() -100, 300)
      //..height = 110
      ..backgroundColor = Colors.white
      ..borderRadius = 10.0
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
              child: Text(
                LocaleKey.ALREADY_PURCHASED_BUNDLE.toLocaleText(),
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 22,
                  color: ColorsLocal.text_color_purple,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
              child: Text(
                LocaleKey.SIGN_IN_TO_PLAY.toLocaleText(),
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 16,
                  color: ColorsLocal.text_color,
                  fontWeight: FontWeight.w400,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
              child: RaisedButton(
                child: Text(
                  LocaleKey.SIGN_IN_NOW.toLocaleText(),
                  style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                ),
                color: ColorsLocal.button_color_pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
                onPressed: () {
                  try {
                    yyDialog?.dismiss();
                    RedirectToBrowser.instance.launch("/", newTab: false);
                  } catch (_) {}
                  yyDialog = new YYDialog();
                },
              ),
            )
          ],
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
