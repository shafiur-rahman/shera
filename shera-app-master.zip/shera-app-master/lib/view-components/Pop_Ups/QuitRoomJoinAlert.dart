/*
* Created by Shafiur Rahman
* on 14/5/20
*/

import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:get/get.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/ChallengeResultVM.dart';
import 'package:quiz/view-models/GamePlayVM.dart';
import 'package:shimmer/shimmer.dart';

class QuitRoomJoinAlert {
  static YYDialog yyDialog = new YYDialog();

  static show(BuildContext context) async {
    TextStyle style = TextStyle(
      color: ColorsLocal.hexToColor("414141"),
      fontFamily: "Muli",
      fontWeight: FontWeight.w600,
      fontSize: 14,
    );

    double availableHeight = MediaQuery.of(context).size.height;
    double requiredHeight = 280;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width - 50
    //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        padding: EdgeInsets.fromLTRB(10, 0, 10, 28),
        height: calculatedHeight, width: double.infinity,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
          ),
          child: SingleChildScrollView(
            child: Container(
              margin: EdgeInsets.fromLTRB(35, 36, 35, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Text(
                      "Your will be considered as looser by quiting the challenge",
                      style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 18,
                        color: ColorsLocal.text_color,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 8),
                    child: Text(
                      "Are you sure to quit the challenge?",
                      style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 14,
                        color: ColorsLocal.text_color.withOpacity(0.7),
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                  Material(
                    type: MaterialType.transparency,
                    child: Container(
                      margin: EdgeInsets.only(top: 32),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          InkWell(
                            child: Container(
                              height: 40,
                              width: 80,
                              child: Center(
                                child: Text(
                                  "No",
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16,
                                    color: ColorsLocal.text_color_pink,
                                  ),
                                ),
                              ),
                            ),
                            onTap: () {
                              yyDialog.dismiss();
                            },
                          ),
                          InkWell(
                            child: Container(
                              height: 40,
                              width: 80,
                              child: Center(
                                child: Text(
                                  "Yes",
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16,
                                    color: ColorsLocal.text_color_pink,
                                  ),
                                ),
                              ),
                            ),
                            onTap: () {
                              yyDialog.dismiss();
                              Navigator.pop(context);
                              AppSessionSettings.socket.dispose();
                            },
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
