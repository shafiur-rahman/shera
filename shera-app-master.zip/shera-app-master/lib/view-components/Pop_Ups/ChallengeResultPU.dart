/*
* Created by Ahammed Hossain Shanto
* on 7/5/20
*/

import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:shimmer/shimmer.dart';

class ChallengeResultPU {
  static YYDialog yyDialog = new YYDialog();

  static show(BuildContext context, var result, {GestureTapCallback onTapRematch, GestureTapCallback onTapCancel}) {
    TextStyle style = TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Muli", fontWeight: FontWeight.w600, fontSize: 14);

    double availableHeight = MediaQuery.of(context).size.height - 120;
    double requiredHeight = 600;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 60
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
          child: Stack(
        // overflow: Overflow.visible,
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 28),
            height: calculatedHeight,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              child: SingleChildScrollView(
                child: Container(
                  margin: EdgeInsets.fromLTRB(36, 28, 24, 64),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        // color: Colors.orange,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Stack(
                              children: [
                                Column(
                                  children: [
                                    Container(
                                      height: 12,
                                      color: Colors.indigo,
                                    ),
                                    Container(
                                      height: 60, width: 60,
//                                   color: Colors.blue,
                                      child: CachedNetworkImage(
                                        imageUrl: result['self']['avatar'].toString(),
                                        imageBuilder: (context, imageProvider) => Container(
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            border: result['self']['played'] && result['opponent']['played'] && result['self']['winner'] ? Border.all(color: ColorsLocal.hexToColor("FF2E75")) : Border.all(width: 0),
                                            image: DecorationImage(
                                              image: imageProvider,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        placeholder: (context, url) => Shimmer.fromColors(
                                          child: Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              //borderRadius: BorderRadius.circular(8),
                                              color: Colors.grey[300],
                                            ),
                                          ),
                                          baseColor: Colors.grey[300],
                                          highlightColor: Colors.white,
                                        ),
                                        errorWidget: (context, url, error) => Icon(Icons.error),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 8),
                                      child: Text(
                                        result["self"]["name"].toString(),
                                        style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 12),
                                      ),
                                    ),
                                  ],
                                ),
                                result['self']['played'] && result['opponent']['played'] && result['self']['winner']
                                    ? Positioned(
                                        top: -10,
                                        child: Image.asset(
                                          "assets/images/winner.png",
                                          width: 60,
                                        ),
                                      )
                                    : Container()
                              ],
                            ),
                            Expanded(
                              child: Container(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Text(
                                      result['self']['played'] ? result['self']['correct_answer'].toString().toLocaleNumber() : "-",
                                      style: TextStyle(color: ColorsLocal.hexToColor("FF4081"), fontFamily: "Poppins", fontWeight: FontWeight.bold, fontSize: 24),
                                    ),
                                    Text(
                                      "-",
                                      style: TextStyle(color: ColorsLocal.hexToColor("8435E8"), fontFamily: "Poppins", fontWeight: FontWeight.bold, fontSize: 24),
                                    ),
                                    Text(
                                      result['opponent']['played'] ? result['opponent']['correct_answer'].toString().toLocaleNumber() : "-",
                                      style: TextStyle(color: ColorsLocal.hexToColor("8435E8"), fontFamily: "Poppins", fontWeight: FontWeight.bold, fontSize: 24),
                                    ),
                                  ],
                                ),
                                color: Colors.white,
                              ),
                            ),
                            Stack(
                              children: [
                                Column(
                                  children: [
                                    Container(height: 12),
                                    Container(
                                      height: 60, width: 60,
//                                   color: Colors.blue,
                                      child: CachedNetworkImage(
                                        imageUrl: result['opponent']['avatar'].toString(),
                                        imageBuilder: (context, imageProvider) => Container(
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            border: result['self']['played'] && result['opponent']['played'] && result['opponent']['winner'] ? Border.all(color: ColorsLocal.hexToColor("FF2E75")) : Border.all(width: 0),
                                            //borderRadius: BorderRadius.circular(4),
                                            image: DecorationImage(
                                              image: imageProvider,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        placeholder: (context, url) => Shimmer.fromColors(
                                          child: Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              //borderRadius: BorderRadius.circular(8),
                                              color: Colors.grey[300],
                                            ),
                                          ),
                                          baseColor: Colors.grey[300],
                                          highlightColor: Colors.white,
                                        ),
                                        errorWidget: (context, url, error) => Icon(Icons.error),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 8),
                                      child: Text(
                                        result['opponent']['name'].toString(),
                                        style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 12),
                                      ),
                                    ),
                                  ],
                                ),
                                result['self']['played'] && result['opponent']['played'] && result['opponent']['winner']
                                    ? Positioned(
                                        top: -10,
                                        child: Image.asset(
                                          "assets/images/winner.png",
                                          width: 60,
                                        ),
                                      )
                                    : Container()
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(50, 5, 50, 20),
                        decoration: BoxDecoration(
                          // color: Colors.green,
                          border: Border.all(color: ColorsLocal.hexToColor("E5E5E5"), width: 2),
                          borderRadius: BorderRadius.circular(9),
                        ),
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(10, 8, 10, 8),
                          child: Container(
                            child: Wrap(
                              alignment: WrapAlignment.spaceEvenly,
                              children: [
                                Text(
                                  result['self']['played'] ? result['self']['win_count'].toString().toLocaleNumber() : "-",
                                  style: TextStyle(color: ColorsLocal.hexToColor("FF4081"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  LocaleKey.WIN.toLocaleText(),
                                  style: TextStyle(color: ColorsLocal.hexToColor("000000"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  result['opponent']['played'] ? result['opponent']['win_count'].toString().toLocaleNumber() : "-",
                                  style: TextStyle(color: ColorsLocal.hexToColor("8435E8"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Divider(
                        thickness: 1,
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                        // color: Colors.orange,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(LocaleKey.CORRECT.toLocaleText(), style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Muli", fontWeight: FontWeight.w600, fontSize: 14)),
                            Expanded(
                              child: Container(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Text(result['self']['played'] ? result['self']['correct_answer'].toString().toLocaleNumber() : "-", style: TextStyle(color: ColorsLocal.hexToColor("8435E8"), fontFamily: "Muli", fontWeight: FontWeight.bold, fontSize: 16)),
                                    Text("-", style: TextStyle(color: ColorsLocal.hexToColor("8435E8"), fontFamily: "Muli", fontWeight: FontWeight.bold, fontSize: 16)),
                                    Text(result['opponent']['played'] ? result['opponent']['correct_answer'].toString().toLocaleNumber() : "-", style: TextStyle(color: ColorsLocal.hexToColor("8435E8"), fontFamily: "Muli", fontWeight: FontWeight.bold, fontSize: 16)),
                                  ],
                                ),
                                color: Colors.white,
                              ),
                            ),
                            Text(LocaleKey.CORRECT.toLocaleText(), style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Muli", fontWeight: FontWeight.w600, fontSize: 14)),
                          ],
                        ),
                      ),
                      Divider(
                        thickness: 1,
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 20, 0, 20),
                        // color: Colors.orange,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(LocaleKey.WRONG.toLocaleText(), style: style),
                            Expanded(
                              child: Container(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Text(result['self']['played'] ? result['self']['wrong_answer'].toString().toLocaleNumber() : "-", style: TextStyle(color: ColorsLocal.hexToColor("FF2E75"), fontFamily: "Muli", fontWeight: FontWeight.bold, fontSize: 16)),
                                    Text("-", style: TextStyle(color: ColorsLocal.hexToColor("FF2E75"), fontFamily: "Muli", fontWeight: FontWeight.bold, fontSize: 16)),
                                    Text(result['opponent']['played'] ? result['opponent']['wrong_answer'].toString().toLocaleNumber() : "-", style: TextStyle(color: ColorsLocal.hexToColor("FF2E75"), fontFamily: "Muli", fontWeight: FontWeight.bold, fontSize: 16)),
                                  ],
                                ),
                                color: Colors.white,
                              ),
                            ),
                            Text(LocaleKey.WRONG.toLocaleText(), style: style),
                          ],
                        ),
                      ),
                      Divider(
                        thickness: 1,
                      ),
                      Container(
                        width: double.infinity,
                        margin: EdgeInsets.only(top: 25),
                        // color: Colors.orange,
                        child: Material(
                          shape: RoundedRectangleBorder(side: BorderSide(color: ColorsLocal.hexToColor("E5E5E5")), borderRadius: BorderRadius.all(Radius.circular(15))),
                          color: ColorsLocal.hexToColor("FF2E75"),
                          child: InkWell(
                            onTap: onTapRematch,
                            child: Padding(
                              padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                              child: Center(
                                child: Text(LocaleKey.REMATCH.toLocaleText(), style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18)),
                              ),
                            ),
                          ),
                          clipBehavior: Clip.antiAlias,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: ColorsLocal.button_color_pink,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 1,
                    blurRadius: 15,
                    offset: Offset(0, -5), // changes position of shadow
                  ),
                ],
              ),
              child: IconButton(
                icon: Icon(
                  Icons.clear,
                  size: 24,
                  color: Colors.white,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: onTapCancel,
              ),
            ),
          )
        ],
      )))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
