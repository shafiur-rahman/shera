/*
* Created by Shanto on 28/07/2020
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';

class BCSModelQuestionInfo {
  static showDialog(
    BuildContext context,
    dynamic model, {
    GestureTapCallback onTap,
        bool isBcsSubscribed = false,
  }) {
    YYDialog yyDialog = new YYDialog();

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 64
      //..height = 110
      ..backgroundColor = Colors.white
      ..borderRadius = 10.0
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(24, 24, 24, 24),
              child: Text(
                model['title'].toString(),
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 18,
                  color: ColorsLocal.text_color,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              height: 0.5,
              color: Colors.grey[300],
            ),
            Container(
              padding: EdgeInsets.fromLTRB(32, 0, 32, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.TIME.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  '${Duration(seconds: model['duration']).inMinutes.toString().toLocaleNumber()} ${LocaleKey.MINUTES.toLocaleText()}',
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.TOTAL_QUESTION.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  '${model['question_count'].toString().toLocaleNumber()}',
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.MARK.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  model['full_mark'].toString().toLocaleNumber(),
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.PENALTY.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 14,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Text(
                                  '${double.parse((model['penalty'] * 100).toString()).toStringAsFixed(0).toLocaleNumber()}%',
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color.withOpacity(0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 0.5,
                          color: Colors.grey[300],
                        )
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
                    child: RaisedButton(
                      elevation: 0,
                      highlightElevation: 0,
                      child: Text(
                        //model['is_free'] ? LocaleKey.PLAY_FREE.toLocaleText() : '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_coin'].toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}',
                        getBcsModelPricing(model, isBcsSubscribed),
                        style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                      color: ColorsLocal.button_color_pink,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      onPressed: onTap,
                    ),
                  ),
                  SizedBox(
                    height: 0,
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                    child: RaisedButton(
                      elevation: 0,
                      highlightElevation: 0,
                      child: Text(
                        //model['is_free'] ? LocaleKey.PLAY_FREE.toLocaleText() : '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_coin'].toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}',
                        LocaleKey.PURCHASE_PACK.toLocaleText(),
                        style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                      color: ColorsLocal.button_color_purple,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, BCSPackagesRoute);
                      },
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }

  static String getBcsModelPricing(var model, bool isBcsSubscribed) {
    String value = "";
    if(model['is_free'] || isBcsSubscribed) {
      value = LocaleKey.PLAY_FREE.toLocaleText();
    }
    else {
      if (model['fee_type'] != null && model['fee_type'] == 'money') {
        if(model['is_paid'] != null && model['is_paid'] == true) {
          value = LocaleKey.PLAY_NOW.toLocaleText();
        }
        else {
          value =
          '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_money'].toString().toLocaleNumber()} ${LocaleKey.BDT
              .toLocaleText()}';
        }
      }
      else {
        value =
        '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_coin'].toString().toLocaleNumber()} ${LocaleKey
            .USING_COINS.toLocaleText()}';
      }
    }
    return value;
  }
}
