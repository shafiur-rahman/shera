/*
* Created by Shanto on 28/07/2020
*/

import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';

class CoinsGemsUsage {
  static showDialog(BuildContext context) {
    double availableHeight = MediaQuery.of(context).size.height - 60;
    double requiredHeight = 540;

    double calculatedHeight = min(availableHeight, requiredHeight);

    YYDialog yyDialog = new YYDialog();

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 64
      //..height = 110
      ..backgroundColor = Colors.white
      ..borderRadius = 10.0
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        height: calculatedHeight,
        padding: EdgeInsets.fromLTRB(24, 24, 24, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.only(right: 8),
                    child: Image.asset(
                      "assets/images/ic_coin.png",
                      height: 20,
                      width: 20,
                    ),
                  ),
                  Expanded(
                    child: Container(
                      child: Text(
                        LocaleKey.USE_OF_COIN.toLocaleText(),
                        style: TextStyle(
                          fontFamily: "Poppins",
                          fontSize: 18,
                          color: ColorsLocal.text_color,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                margin: EdgeInsets.only(top: 16, bottom: 16),
                height: 0.5,
                color: Colors.grey[400],
              ),
              Container(
                margin: EdgeInsets.only(bottom: 8),
                child: Text(
                  LocaleKey.USE_OF_COIN_1.toLocaleText(),
                  style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 14,
                    color: ColorsLocal.text_color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 8),
                child: Text(
                  LocaleKey.USE_OF_COIN_2.toLocaleText(),
                  style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 14,
                    color: ColorsLocal.text_color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 8),
                child: Text(
                  LocaleKey.USE_OF_COIN_3.toLocaleText(),
                  style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 14,
                    color: ColorsLocal.text_color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(right: 8),
                      child: Image.asset(
                        "assets/images/ic_gem.png",
                        height: 20,
                        width: 20,
                      ),
                    ),
                    Expanded(
                      child: Container(
                        child: Text(
                          LocaleKey.USE_OF_GEM.toLocaleText(),
                          style: TextStyle(
                            fontFamily: "Poppins",
                            fontSize: 18,
                            color: ColorsLocal.text_color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 16, bottom: 16),
                height: 0.5,
                color: Colors.grey[400],
              ),
              Container(
                margin: EdgeInsets.only(bottom: 8),
                child: Text(
                  LocaleKey.USE_OF_GEM_1.toLocaleText(),
                  style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 14,
                    color: ColorsLocal.text_color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
                child: RaisedButton(
                  elevation: 0,
                  highlightElevation: 0,
                  child: Text(
                    LocaleKey.OKAY.toLocaleText(),
                    style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                  color: ColorsLocal.button_color_pink,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
            ],
          ),
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
