/*
* Created by Shanto on 28/07/2020
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';

class ExitPopup {
  static showDialog(BuildContext context) {
    YYDialog yyDialog = new YYDialog();

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 100
      //..height = 110
      ..backgroundColor = Colors.white
      ..borderRadius = 10.0
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
        child: Column(
          children: [
            Container(
                margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                child: Icon(
                  Icons.exit_to_app,
                )),
            Container(
              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
              child: Text(
                LocaleKey.SURE_TO_EXIT.toLocaleText(),
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 16,
                  color: ColorsLocal.text_color,
                  fontWeight: FontWeight.w400,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                      child: RaisedButton(
                        elevation: 0,
                        highlightElevation: 0,
                        child: Text(
                          LocaleKey.NO.toLocaleText(),
                          style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                        ),
                        color: ColorsLocal.button_color_pink,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                        onPressed: () {
                          try {
                            yyDialog?.dismiss();
                          } catch (_) {}
                          yyDialog = new YYDialog();
                        },
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                      child: RaisedButton(
                        elevation: 0,
                        highlightElevation: 0,
                        child: Text(
                          LocaleKey.YES.toLocaleText(),
                          style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                        ),
                        color: ColorsLocal.button_color_pink,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                        onPressed: () {
                          try {
                            yyDialog?.dismiss();
                            SystemNavigator.pop();
                          } catch (_) {}
                          yyDialog = new YYDialog();
                        },
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
