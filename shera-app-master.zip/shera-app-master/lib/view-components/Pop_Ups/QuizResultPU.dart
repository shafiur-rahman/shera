import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/QuizResultVM.dart';

class QuizResultPU {
  static YYDialog yyDialog = new YYDialog();

  static show(
    BuildContext context,
    double topicProgress,
    int totalQuestion,
    int totalCorrect,
    String currentLevel,
    int nextTopicId, {
    GestureTapCallback onNextTopicTap,
    GestureTapCallback onTryAgainTap,
    GestureTapCallback onCancel,
    GestureTapCallback onChallenge,
  }) {
    double availableHeight = MediaQuery.of(context).size.height - 160;
    double requiredHeight = 620;
    double calculatedHeight = min(availableHeight, requiredHeight);

    double accuracy = totalCorrect / totalQuestion.toDouble();
    //Logger.printWrapped(accuracy.toString());

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 60
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (_) {
              return QuizResultVM(context);
            },
          ),
        ],
        child: Consumer<QuizResultVM>(
          builder: (context, snapshot, _) {
            return Stack(
              // overflow: Overflow.visible,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(10, 28, 10, 0),
                  height: calculatedHeight,
                  child: Container(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      padding: EdgeInsets.fromLTRB(0, 25, 0, 10),
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Material(
                                    clipBehavior: Clip.antiAlias,
                                    borderRadius: BorderRadius.circular(20),
                                    child: Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 16, 0),
                                      child: InkWell(
                                          onTap: onCancel ??
                                              () {
                                                Navigator.of(context).pop();
                                                Navigator.of(context).pop();
                                              },
                                          child: Image.asset(
                                            "assets/images/qr_close.png",
                                            width: 28,
                                            height: 28,
                                          )),
                                    )),
                              ],
                            ),
                            Container(
                              //  color: Colors.green,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      child: Image.asset(
                                        accuracy >= .66
                                            ? "assets/images/qr_happy.png"
                                            : accuracy >= .33
                                                ? "assets/images/qr_emo_draw.png"
                                                : "assets/images/qr_emo_loss.png",
                                        width: 50,
                                        height: 50,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 20, 0, 0),
                              child: Center(
                                  child: Text(
                                accuracy >= .66
                                    ? LocaleKey.CONGRATULATION.toLocaleText()
                                    : accuracy >= .33
                                        ? LocaleKey.NOT_BAD.toLocaleText()
                                        : LocaleKey.BETTER_LUCK_NEXT_TIME.toLocaleText(),
                                style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.bold, fontSize: 22),
                              )),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 10),
                              child: Center(
                                  child: Text(
                                accuracy >= .66
                                    ? LocaleKey.YOU_HAVE_PASSED.toLocaleText()
                                    : accuracy >= .33
                                        ? LocaleKey.NO_IMPROVEMENT.toLocaleText()
                                        : LocaleKey.YOU_HAVE_FAILED.toLocaleText(),
                                style: TextStyle(color: ColorsLocal.hexToColor("6D6D6D"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                              )),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 10),
                              child: Center(
                                  child: Text(
                                '${totalCorrect.toString().toLocaleNumber()}/${totalQuestion.toString().toLocaleNumber()}',
                                style: TextStyle(color: ColorsLocal.getProgressColor(accuracy * 100), fontFamily: "Poppins", fontWeight: FontWeight.bold, fontSize: 29),
                              )),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 15),
                              //color: Colors.green,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        LocaleKey.YOU_HAVE_COMPLETED.toLocaleText(),
                                        style: TextStyle(color: ColorsLocal.hexToColor("A5A5A5"), fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 16),
                                      ),
                                      Text(
                                        ' ${(topicProgress * 100).toStringAsFixed(0).toLocaleNumber()}%',
                                        style: TextStyle(color: ColorsLocal.getProgressColor(topicProgress), fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 16),
                                      )
                                    ],
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(40, 10, 0, 10),
                                    child: LinearPercentIndicator(
                                      width: MediaQuery.of(context).size.width.toCustomWidth() - 150,
                                      lineHeight: 5.0,
                                      backgroundColor: Colors.grey[200],
                                      percent: (topicProgress * 100) / 100,
                                      //progressColor: Colors.green,
                                      padding: EdgeInsets.fromLTRB(2, 0, 2, 0),
                                      linearGradient: LinearGradient(
                                        colors: [ColorsLocal.getProgressColor(topicProgress), ColorsLocal.getProgressColor(topicProgress).withOpacity(0.1)],
                                        stops: [0.7, 1.0],
                                      ),
                                      animation: true,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 10),
                              child: Text(
                                '${LocaleKey.LEVEL.toLocaleText()} ${currentLevel.toLocaleNumber()}',
                                style: TextStyle(color: ColorsLocal.hexToColor("6D6D6D"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 10),
                              child: Column(
                                children: [
                                  Text(LocaleKey.EXPLORE.toLocaleText(), style: TextStyle(color: ColorsLocal.hexToColor("9B9B9B"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 12)),
                                  // Text(
                                  //     "for upgrading your level",
                                  //     style: TextStyle(
                                  //         color:
                                  //             ColorsLocal.hexToColor("9B9B9B"),
                                  //         fontFamily: "Poppins",
                                  //         fontWeight: FontWeight.w600,
                                  //         fontSize: 12))
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 25),
                              // color: Colors.orange,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Material(
                                    shape: RoundedRectangleBorder(side: BorderSide(color: ColorsLocal.hexToColor("E5E5E5")), borderRadius: BorderRadius.all(Radius.circular(5.0))),
                                    color: Colors.white,
                                    child: InkWell(
                                      onTap: onNextTopicTap,
                                      child: Padding(
                                        padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                                        child: Text(LocaleKey.NEXT_TOPIC.toLocaleText(), style: TextStyle(color: ColorsLocal.hexToColor("8435E8"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18)),
                                      ),
                                    ),
                                    clipBehavior: Clip.antiAlias,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Material(
                                    shape: RoundedRectangleBorder(side: BorderSide(color: ColorsLocal.hexToColor("E5E5E5")), borderRadius: BorderRadius.all(Radius.circular(5.0))),
                                    color: Colors.white,
                                    child: InkWell(
                                      onTap: onTryAgainTap,
                                      child: Padding(
                                        padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                                        child: Text(LocaleKey.TRY_AGAIN.toLocaleText(), style: TextStyle(color: ColorsLocal.hexToColor("FF2E75"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18)),
                                      ),
                                    ),
                                    clipBehavior: Clip.antiAlias,
                                  )
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 16),
                              child: RaisedButton(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                elevation: 0,
                                highlightElevation: 0,
                                color: ColorsLocal.button_color_pink,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(12, 12, 12, 12),
                                  child: Text(
                                    LocaleKey.CHALLENGE_NOW.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                onPressed: onChallenge,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
