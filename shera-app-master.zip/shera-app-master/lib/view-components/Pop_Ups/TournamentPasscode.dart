/*
* Created by Shafiur Rahman
* on 14/5/20
*/

import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-models/TournamentDetailsVM.dart';

class TournamentPasscode {
  static YYDialog yyDialog = new YYDialog();

  static show(
    BuildContext context,
    TournamentDetailsVM snapshot, {
    GestureTapCallback onButtonPressed,
  }) {
    TextStyle style = TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Muli", fontWeight: FontWeight.w600, fontSize: 14);

    TextEditingController _passcodeController = new TextEditingController();

    double availableHeight = MediaQuery.of(context).size.height - MediaQuery.of(context).viewInsets.bottom;
    double requiredHeight = 320;
    double calculatedHeight = min(availableHeight, requiredHeight);

    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width.toCustomWidth() - 50
      //..height = 110
      ..backgroundColor = Colors.transparent
      ..barrierColor = Colors.black.withOpacity(0.8)
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(ChangeNotifierProvider.value(
        value: snapshot,
        child: Consumer<TournamentDetailsVM>(builder: (context, snapshot, _) {
          return Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 28),
            height: calculatedHeight,
            //width: double.infinity,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              child: SingleChildScrollView(
                child: Container(
                  margin: EdgeInsets.fromLTRB(24, 24, 24, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        child: Text(
                          LocaleKey.ENTER_PASSCODE.toLocaleText(),
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            color: ColorsLocal.text_color,
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 16),
                        child: TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 2,
                                color: ColorsLocal.button_color_pink,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            hintStyle: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 16,
                              color: Colors.grey[300],
                              fontWeight: FontWeight.w500,
                            ),
                            hintText: "123456",
                          ),
                          onChanged: (value) {
                            snapshot.passcode = value.toString();
                          },
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 8),
                        child: Text(
                          snapshot.passcodeMessage,
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            color: ColorsLocal.text_color_pink,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 16),
                        child: RaisedButton(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          color: ColorsLocal.button_color_purple,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                            child: Text(
                              LocaleKey.VERIFY.toLocaleText(),
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          onPressed: onButtonPressed,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        }),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }
}
