/*
* Created by Ahammed Hossain Shanto
* on 7/2/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/ImageLoader.dart';

class LiveQuiz {
  static Color oddColor = ColorsLocal.hexToColor("843BE2");
  static Color oddColor_dark = ColorsLocal.hexToColor("771ced");
  static Color evenColor = ColorsLocal.hexToColor("3B6AE2");
  static Color evenColor_dark = ColorsLocal.hexToColor("3734d6");

  static Widget tile(
      double height,
      double width,
      int index,
      List tournaments, {
        double radius = 8,
        double initialGap = 16,
        double gapBetween = 16,
        GestureTapCallback onTap,
      }) {
    return Container(
      margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 16, 0),
      child: PhysicalModel(
        color: Colors.transparent,
        clipBehavior: Clip.antiAlias,
        borderRadius: BorderRadius.circular(radius),
        child: Container(
          height: height,
          width: width,
          decoration: BoxDecoration(
            image: new DecorationImage(image: new AssetImage('images/live_quiz_bg_banner.png'), fit: BoxFit.cover),
            borderRadius: BorderRadius.circular(radius),
            color: index % 2 == 0 ? evenColor : oddColor,
          ),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                child: Transform.translate(
                  offset: Offset(-25, -25),
                  child: Container(
                    height: height,
                    width: height,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: index % 2 == 0 ? [evenColor, evenColor_dark] : [oddColor, oddColor_dark],
                          stops: [0.0, 1.0],
                        )),
                  ),
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                top: 0,
                child: InkWell(
                  child: Container(
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                    child: Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                      child: Text(
                                        'পুরস্কার ২০০০ টাকা',
                                        style: TextStyle(fontSize: 12, fontFamily: "Poppins", color: Colors.white, fontWeight: FontWeight.w500),
                                        textAlign: TextAlign.start,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                          decoration: BoxDecoration(
                                            color: index % 2 == 0 ? evenColor_dark.withOpacity(0.5) : oddColor_dark.withOpacity(0.5),
                                            borderRadius: BorderRadius.circular(50),
                                          ),
                                          padding: EdgeInsets.fromLTRB(10, 4, 10, 4),
                                          margin: EdgeInsets.fromLTRB(16, 0, 0, 0),
                                          child: Wrap(
                                            crossAxisAlignment: WrapCrossAlignment.center,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                child: Text(
                                                  'যোগ দিন',
                                                  style: TextStyle(
                                                    fontSize: 10,
                                                    color: Colors.white.withOpacity(0.6),
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily: "poppins",
                                                  ),
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                              )
                                            ],
                                          )),
                                      tournaments[index]['sponsor_icon'] != null && tournaments[index]['sponsor_icon'].toString().isNotEmpty
                                          ? Container(
                                        margin: EdgeInsets.only(top: 8),
                                        child: ImageLoader.loadRect(
                                          imageUrl: tournaments[index]['sponsor_icon'].toString(),
                                          width: width * 0.3,
                                          height: 40,
                                          fit: BoxFit.contain,
                                          showLoadingShimmer: false,
                                        ),
                                      )
                                          : Container(),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Text(
                                        '${tournaments[index]['name'].toString()}',
                                        style: TextStyle(fontSize: 24, fontFamily: "Poppins", color: Colors.white, fontWeight: FontWeight.w600),
                                        textAlign: TextAlign.start,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  // Column(
                                  //   crossAxisAlignment: CrossAxisAlignment.end,
                                  //   children: [
                                  //     Container(
                                  //         decoration: BoxDecoration(
                                  //           color: index % 2 == 0 ? evenColor_dark.withOpacity(0.5) : oddColor_dark.withOpacity(0.5),
                                  //           borderRadius: BorderRadius.circular(50),
                                  //         ),
                                  //         padding: EdgeInsets.fromLTRB(10, 4, 10, 4),
                                  //         margin: EdgeInsets.fromLTRB(16, 0, 0, 0),
                                  //         child: Wrap(
                                  //           crossAxisAlignment: WrapCrossAlignment.center,
                                  //           children: [
                                  //             Container(
                                  //               margin: EdgeInsets.fromLTRB(5, 0, 0, 0),
                                  //               child: Text(
                                  //                 'যোগ দিন',
                                  //                 style: TextStyle(
                                  //                   fontSize: 10,
                                  //                   color: Colors.white.withOpacity(0.6),
                                  //                   fontWeight: FontWeight.w500,
                                  //                   fontFamily: "poppins",
                                  //                 ),
                                  //                 maxLines: 1,
                                  //                 overflow: TextOverflow.ellipsis,
                                  //               ),
                                  //             )
                                  //           ],
                                  //         )),
                                  //     tournaments[index]['sponsor_icon'] != null && tournaments[index]['sponsor_icon'].toString().isNotEmpty
                                  //         ? Container(
                                  //       margin: EdgeInsets.only(top: 8),
                                  //       child: ImageLoader.loadRect(
                                  //         imageUrl: tournaments[index]['sponsor_icon'].toString(),
                                  //         width: width * 0.3,
                                  //         height: 40,
                                  //         fit: BoxFit.contain,
                                  //         showLoadingShimmer: false,
                                  //       ),
                                  //     )
                                  //         : Container(),
                                  //   ],
                                  // )
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              child: Text(
                                // '${tournaments[index]['time_left'].toString()}',
                                'সময়কাল: ০১ ঘন্টা',
                                style: TextStyle(fontSize: 16, fontFamily: "Poppins", color: Colors.white, fontWeight: FontWeight.w500),
                                textAlign: TextAlign.start,
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Color(0xFF65A4FB),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
                            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  child: Text(
                                    // '${tournaments[index]['time_left'].toString()}',
                                    'আরম্ভ',
                                    style: TextStyle(fontSize: 12, fontFamily: "Poppins", color: Colors.white, fontWeight: FontWeight.w500),
                                    textAlign: TextAlign.start,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Expanded(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                                    child: Text(
                                      '১০ : ৩০ পিএম',
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        color: Color(0xFFFFFFFF),
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  onTap: onTap,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  static Widget tileShimmer(double height, double width, int index, {double radius = 15, double initialGap = 16, double gapBetween = 16}) {
    return Container(
      child: MyShimmer.fromColors(
          child: Container(
            margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 16, 0),
            height: height,
            width: width,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(radius),
              color: Colors.grey[300],
            ),
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white),
    );
  }
}
