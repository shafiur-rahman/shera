/*
* Created by Shafiur
* on 7/2/20
*/

import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';

class TopDeals {
  static Color oddColor = ColorsLocal.hexToColor("843BE2");
  static Color oddColor_dark = ColorsLocal.hexToColor("771ced");
  static Color evenColor = ColorsLocal.hexToColor("FF4081");
  static Color evenColor_dark = ColorsLocal.hexToColor("3734d6");

  static Color linear_purple_start = ColorsLocal.hexToColor("7B3BE2");
  static Color linear_purple_end = ColorsLocal.hexToColor("9B61F9");
  static Color linear_blue_start = ColorsLocal.hexToColor("3B4CE2");
  static Color linear_blue_end = ColorsLocal.hexToColor("2980D0");
  static Color linear_bluePurple_start = ColorsLocal.hexToColor("4594FF");
  static Color linear_bluePurple_end = ColorsLocal.hexToColor("8657EB");

  static LinearGradient purplegradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment(0.8, 0.0), // 10% of the width, so there are ten blinds.
    colors: [linear_purple_end, linear_purple_start], // whitish to gray
//  tileMode: TileMode.repeated, // repeats the gradient over the canvas
  );

  static LinearGradient bluegradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment(0.8, 0.0), // 10% of the width, so there are ten blinds.
    colors: [linear_blue_end, linear_blue_start], // whitish to gray
//                    tileMode: TileMode.repeated, // repeats the gradient over the canvas
  );
  static LinearGradient bluePurplegradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment(0.8, 0.0), // 10% of the width, so there are ten blinds.
    colors: [linear_bluePurple_end, linear_bluePurple_start], // whitish to gray
//                    tileMode: TileMode.repeated, // repeats the gradient over the canvas
  );

  static List gradients = [bluegradient, purplegradient, bluePurplegradient];

  Random random = new Random();

  static Widget tile(
    double height,
    double width,
    int index,
    List topdeals, {
    double radius = 7,
    double initialGap = 16,
    double gapBetween = 16,
    GestureTapCallback onTapCard,
    GestureTapCallback onTapBuyNow,
  }) {
    return Container(
      margin: EdgeInsets.fromLTRB(12, 5, 0, 5),
      child: Material(
        clipBehavior: Clip.antiAlias,
        elevation: 2,
        child: InkWell(
          onTap: onTapCard,
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(7), gradient: index % 2 == 0 ? gradients[2] : gradients[1]),
            height: height,
            width: width,
            child: Wrap(
              alignment: WrapAlignment.spaceBetween,
              direction: Axis.vertical,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    height: 80,
                    width: 80,
                    child: CachedNetworkImage(
                      imageUrl: '${topdeals[index]['image_url'].toString()}',
                      imageBuilder: (context, imageProvider) => Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          //borderRadius: BorderRadius.circular(4),
                          image: DecorationImage(
                            image: imageProvider,
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                      placeholder: (context, url) => MyShimmer.fromColors(
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            //borderRadius: BorderRadius.circular(8),
                            color: Colors.grey[300],
                          ),
                        ),
                        baseColor: Colors.grey[300],
                        highlightColor: Colors.white,
                      ),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(0, 5, 10, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${topdeals[index]['caption'].toString()}',
                        style: TextStyle(
                          color: ColorsLocal.hexToColor("F5F5F5"),
                          fontFamily: "Poppins",
                          shadows: [
                            Shadow(
                                // bottomLeft
                                offset: Offset(1, 1),
                                color: Colors.white.withOpacity(.2)),
                          ],
                          fontWeight: FontWeight.w500,
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        '${topdeals[index]['bundle_name'].toString()}',
                        style: TextStyle(
                          color: ColorsLocal.hexToColor("FFEA00"),
                          fontFamily: "Poppins",
                          fontWeight: FontWeight.w500,
                          fontSize: 13,
                        ),
                      ),
                      Text(
                        AppSessionSettings.isNepaliUser() ? '${LocaleValues.instance.getNumber(topdeals[index]['price'].toString())}/= ${LocaleValues.instance.getText(LocaleKey.RS)}' : '${LocaleValues.instance.getNumber(topdeals[index]['price'].toString())}/= ${LocaleValues.instance.getText(LocaleKey.BDT)}',
                        style: TextStyle(
                          color: ColorsLocal.hexToColor("F5F5F5"),
                          fontFamily: "Poppins",
                          fontWeight: FontWeight.w500,
                          fontSize: 6,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        child: Material(
                          clipBehavior: Clip.antiAlias,
                          borderRadius: BorderRadius.circular(10),
                          child: InkWell(
                            onTap: onTapBuyNow,
                            child: Container(
                              width: 100,
                              child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Center(
                                  child: Text(
                                    '${LocaleValues.instance.getText(LocaleKey.BUY_NOW)}',
                                    style: TextStyle(
                                      color: ColorsLocal.hexToColor("843BE2"),
                                      fontFamily: "Poppins",
                                      fontWeight: FontWeight.w600,
                                      fontSize: 10,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }

  static Widget tileShimmer(double height, double width, int index, {double radius = 15, double initialGap = 16, double gapBetween = 16}) {
    return Container(
      child: MyShimmer.fromColors(
          child: Container(
            margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 16, 0),
            height: height,
            width: width,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(radius),
              color: Colors.grey[300],
            ),
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white),
    );
  }
}
