/*
* Created by Ahammed Hossain Shanto
* on 10/13/20
*/

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quiz/models/MyShimmer.dart';

class ImageLoader {
  static double height;
  static double width;
  static BoxShape boxShape;
  static String imageUrl;
  static double radius;
  BoxFit fit;

  static Widget loadRect({double height = 100.0, double width = 100.0, @required imageUrl, boxShape = BoxShape.rectangle, radius = 0.0, fit = BoxFit.cover, bool showLoadingShimmer = true}) {
    return Container(
      margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
      width: width,
      height: height,
      child: CachedNetworkImage(
        imageUrl: imageUrl,
        imageBuilder: (context, imageProvider) => Container(
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(radius),
            image: DecorationImage(
              image: imageProvider,
              fit: fit,
            ),
          ),
        ),
        placeholder: (context, url) => showLoadingShimmer
            ? MyShimmer.fromColors(
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(radius),
                  ),
                ),
                baseColor: Colors.grey[300],
                highlightColor: Colors.white,
              )
            : Container(
                height: height,
                width: width,
                child: Center(
                  child: Container(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  ),
                ),
              ),
        errorWidget: (context, url, error) => Icon(
          Icons.error,
          size: height / 2,
          color: Colors.grey,
        ),
      ),
    );
  }

  static Widget loadCircular({double height = 100.0, double width = 100.0, @required imageUrl, boxShape = BoxShape.circle, fit = BoxFit.cover}) {
    return Container(
      margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
      width: width,
      height: height,
      child: CachedNetworkImage(
        imageUrl: imageUrl,
        imageBuilder: (context, imageProvider) => Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            image: DecorationImage(
              image: imageProvider,
              fit: fit,
            ),
          ),
        ),
        placeholder: (context, url) => MyShimmer.fromColors(
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.grey[300],
            ),
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
        errorWidget: (context, url, error) => Icon(
          Icons.error,
          size: height / 2,
          color: Colors.grey,
        ),
      ),
    );
  }
}
