/*
* Created by Ahammed Hossain Shanto
* on 7/5/20
*/

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quiz/models/MyShimmer.dart';

class Categories {
  static Widget tile(
    double height,
    double width,
    int index,
    List categories, {
    GestureTapCallback onTap,
    double initialGap = 16,
    double gapBetween = 16,
    double radius = 7,
    bool implementFavButton = false,
    double iconSize = 66,
    double iconLabelGap = 8,
    double favButtonPosition = 12,
    double favIconSize = 16,
    EdgeInsetsGeometry padding = const EdgeInsets.all(0),
    TextStyle textStyle = const TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.w500,
      fontFamily: "Poppins",
    ),
    GestureTapCallback onFavTap,
  }) {
    bool updating = false;
    if (categories[index]['updating'] != null && categories[index]['updating'] == true) {
      updating = true;
    }

    return Stack(
      children: [
        Container(
          height: height,
          width: width,
          margin: EdgeInsets.fromLTRB(index == 0 ? initialGap : 0, 0, gapBetween, 0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            color: Colors.white,
          ),
          child: Material(
            color: Colors.white,
            borderRadius: BorderRadius.circular(radius),
            child: InkWell(
              borderRadius: BorderRadius.circular(radius),
              child: Container(
                child: Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                          padding: padding,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                          ),
                          constraints: BoxConstraints.tightFor(height: iconSize, width: iconSize),
                          child: CachedNetworkImage(
                            imageUrl: categories[index]['image_url'].toString(),
                            imageBuilder: (context, imageProvider) => Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                //borderRadius: BorderRadius.circular(4),
                                image: DecorationImage(
                                  image: imageProvider,
                                  fit: BoxFit.contain,
                                ),
                              ),
                            ),
                            placeholder: (context, url) => MyShimmer.fromColors(
                              child: Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  //borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                              baseColor: Colors.grey[300],
                              highlightColor: Colors.white,
                            ),
                            errorWidget: (context, url, error) => Icon(Icons.error),
                          )),
                      Container(
                        margin: EdgeInsets.fromLTRB(8, iconLabelGap, 8, 0),
                        child: Text(
                          categories[index]['name'].toString(),
                          style: textStyle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              onTap: onTap,
            ),
          ),
        ),
        Positioned(
          right: favButtonPosition,
          top: favButtonPosition,
          child: implementFavButton
              ? updating
                  ? Container(
                      height: favIconSize,
                      width: favIconSize,
                      margin: EdgeInsets.fromLTRB(4, 4, 4, 4),
                      child: CupertinoActivityIndicator(),
                    )
                  : InkWell(
                      child: Container(
                        margin: EdgeInsets.fromLTRB(4, 4, 4, 4),
                        child: Icon(
                          Icons.star,
                          size: favIconSize,
                          color: categories[index]['following'] ? Colors.amber : Colors.grey[300],
                        ),
                      ),
                      onTap: implementFavButton ? onFavTap : null,
                    )
              : Container(),
        ),
      ],
    );
  }
}
