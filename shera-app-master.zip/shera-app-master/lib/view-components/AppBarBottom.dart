/*
* Created by Ahammed Hossain Shanto on 7/9/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quiz/values/ColorsLocal.dart';

class AppBarBottom {
  static Widget shadow({double height = 20, Widget child, double width}) {
    return PreferredSize(
      preferredSize: Size.fromHeight(height),
      child: Container(
        height: height,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              offset: Offset(0, 12),
              color: ColorsLocal.hexToColor("E1E1E1").withOpacity(0.5),
              spreadRadius: 0.3,
              blurRadius: 16,
            )
          ],
        ),
        child: child,
      ),
    );
  }
}
