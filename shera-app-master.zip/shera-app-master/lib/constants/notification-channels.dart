/*
* Created by Ahammed Hossain Shanto
* on 3/18/21
*/

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:quiz/constants/ProjectConstants.dart';

const AndroidNotificationChannel NOTIFICATION_GLOBAL_CHANNEL = AndroidNotificationChannel(
  CHANNEL_GLOBAL_NOTIFICATION, // id
  'Global Notification', // title
  'Global Notification', // description
  importance: Importance.high,
);