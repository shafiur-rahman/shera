import 'package:http/http.dart';

class UrlHelper {
//  TODO: Uncomment the line below when building app in ***** LOCAL *****
//   static const String BaseUrl = "http://romonixyz-b05b8d83.localhost.run/api/v2.0";

  //  TODO: Uncomment the line below when building app in ***** STAGING *****
 // static const String BaseUrl = "https://staging.developer.quizgiri.xyz/api/v2.0";

  // base url for testing xd
  // static const String BaseUrl = "https://developer.quizgiri.xyz/api/v2.0";


  // TODO: Uncomment the line below when building app in ***** PRODUCTION *****
 // shera base url
   static const String BaseUrl = "http://143.244.135.142:82/api/v2.0";
   // static const String BaseUrl = "http://143.244.132.138:8000/api/v2.0";

 // TODO: Uncomment the line below when building app in ***** Local Environment Server *****
   //static const String BaseUrl = "https://04fc4d1deb6e.ngrok.io";


  // for testing xd
  // static const String ChallengeRoomDomain_Production = "https://developer.quizgiri.xyz:4430";
  //  static const String ChallengeRoomDomain_Production = "http://143.244.132.138:4430";
   static const String ChallengeRoomDomain_Production = "http://143.244.135.142:4430";
  //static const String ChallengeRoomDomain_Staging = "http://13.233.2.239:3001";

  static String checkUpdate() {
    return BaseUrl + "/check-update";
  }

  static String checkToken() {
    return BaseUrl + "/check-token";
  }

  static String sendOtp() {
    return BaseUrl + "/send-otp";
  }

  static String resendOtp() {
    return BaseUrl + "/retry-otp";
  }

  static String verifyOtp() {
    return BaseUrl + "/login";
  }

  static String registerUser() {
    return BaseUrl + "/register";
  }

  static String loginWithEmail() {
    return BaseUrl + "/email-login";
  }

  static String suggestedCategories() {
    return BaseUrl + "/suggested-categories";
  }

  static String followCategories() {
    return BaseUrl + "/follow-categories";
  }

  static String allCategories() {
    return BaseUrl + "/categories";
  }

  static String subcategories() {
    return BaseUrl + "/subcategories";
  }

  static String favouriteCategories() {
    return BaseUrl + "/favourite-categories";
  }

  static String addFavouriteCategory() {
    return BaseUrl + "/add-favourite-category";
  }

  static String removeFavouriteCategory() {
    return BaseUrl + "/remove-favourite-category";
  }

  static String topicsOfCategory() {
    return BaseUrl + "/topics";
  }

  static String followUnfollowTopic() {
    return BaseUrl + "/follow-unfollow-topic";
  }

  static String topicDetails() {
    return BaseUrl + "/topic";
  }

  static String startGame() {
    return BaseUrl + "/gameplay/start";
  }

  static String submitAnswerOfQuiz() {
    return BaseUrl + "/gameplay/submit";
  }

  static String startTournament() {
    return BaseUrl + "/tournament/start";
  }

  static String startDailyTask() {
    return BaseUrl + "/daily-task/start";
  }

  static String submitAnswerOfTournament() {
    return BaseUrl + "/tournament/submit";
  }

  static String submitAnswerOfDailyTask() {
    return BaseUrl + "/daily-task/submit";
  }

  static String tryAgainQuiz() {
    return BaseUrl + "/gameplay/try-again";
  }

  static String tryAgainDailyTask() {
    return BaseUrl + "/daily-task/try-again";
  }

  static String profile() {
    return BaseUrl + "/user";
  }

  static String updateProfile() {
    return BaseUrl + "/user";
  }

  static String updateProfileImage() {
    return BaseUrl + "/user/update-avatar";
  }

  static String categoriesPlayed() {
    return BaseUrl + "/user/categories-played";
  }

  static String dailyTask() {
    return BaseUrl + "/user/daily-task";
  }

  static String topTopics() {
    return BaseUrl + "/top-topics";
  }

  static String favouriteTopics() {
    return BaseUrl + "/favourite-topics";
  }


  static String latestTournamentsBkash() {
    return BaseUrl + "/tournament/running-bkash";
  }

  static String tournamentDetails() {
    return BaseUrl + "/tournament/details";
  }

  static String challengeRoomDetails() {
    return BaseUrl + "/challenge-room/details";
  }

  static String spinInfo() {
    return BaseUrl + "/spin-info";
  }

  static String submitSpin() {
    return BaseUrl + "/submit-spin";
  }

  static String resetSpin() {
    return BaseUrl + "/reset-spin";
  }

  static String getSettings() {
    return BaseUrl + "/settings";
  }

  static String setSettings() {
    return BaseUrl + "/settings";
  }

  static String getFriendList() {
    return BaseUrl + "/friends";
  }

  static String acceptFriendRequest() {
    return BaseUrl + "/friend-request-accept";
  }

  static String denyFriendRequest() {
    return BaseUrl + "/friend-request-deny";
  }

  static String reportQuestion() {
    return BaseUrl + "/question/report";
  }

  static String sendFriendRequest() {
    return BaseUrl + "/friend-request-send";
  }

  static String unFriend() {
    return BaseUrl + "/unfriend";
  }

  static String outgoingRequestDelete() {
    return BaseUrl + "/outgoing-request-delete";
  }

  static String refreshToken() {
    return BaseUrl + "/refresh-fcm";
  }

  static String recoverPassword() {
    return BaseUrl + "/recover-password";
  }

  static String friendList() {
    return BaseUrl + "/friends";
  }

  static String challengeFriend() {
    return BaseUrl + "/challenge/request";
  }

  static String challengeList() {
    return BaseUrl + "/challenge/list";
  }

  static String challengeAccept() {
    return BaseUrl + "/challenge/accept";
  }

  static String challengeDeny() {
    return BaseUrl + "/challenge/deny";
  }

  static String challengeStart() {
    return BaseUrl + "/challenge/start";
  }

  static String challengeSubmit() {
    return BaseUrl + "/challenge/submit";
  }

  static String challengeRetry() {
    return BaseUrl + "/challenge/try-again";
  }

  static String promotions() {
    return BaseUrl + "/promotions";
  }

  static String leaderboardList() {
    return BaseUrl + "/leaderboard";
  }

  static String ChallengeRoomLeaderBoardList() {
    return BaseUrl + "/challenge-room/leaderboard";
  }

  static String purchaseBundle() {
    return BaseUrl + "/bundles/purchase";
  }

  static String getTournamentPass() {
    return BaseUrl + "/tournament/entry";
  }

  static String allBundle() {
    return BaseUrl + "/bundles";
  }

  static String purchaseHistory() {
    return BaseUrl + "/bundles/purchase/history";
  }

  static String referralGet() {
    return BaseUrl + "/referral/get";
  }

  static String referralApply() {
    return BaseUrl + "/referral/apply";
  }

  static String searchTopics() {
    return BaseUrl + "/topics/search";
  }

  static String searchFriends() {
    return BaseUrl + "/friends/search";
  }

  static String lifeline5050() {
    return BaseUrl + "/tournament/lifeline-50-50";
  }

  static String lifelineGetAnswer() {
    return BaseUrl + "/tournament/lifeline-gems";
  }

  static String seeAllRecent() {
    return BaseUrl + "/topic/ranking";
  }

  static String dailyTaskRanking() {
    return BaseUrl + "/daily-task/ranking";
  }

  static String seeAllRecentTournament() {
    return BaseUrl + "/tournament/ranking";
  }

  static String logout() {
    return BaseUrl + "/logout";
  }

  static String checkNotificationStatus() {
    return BaseUrl + "/noti-track";
  }

  static String inAppPupup() {
    return BaseUrl + "/in-app-popup";
  }

  static String termsAndConditions() {
    return "https://quizgiri.xyz/terms-conditions";
  }

  static String privacyPolicy() {
    return "https://quizgiri.xyz/privacy-policy";
  }

  static String createPayment() {
    return BaseUrl + "/paysenz/create-payment";
  }

  static String searchFromContacts() {
    return BaseUrl + "/friends/search-contact";
  }

  static String verifyPasscode() {
    return BaseUrl + "/tournament/passcode-entry";
  }

  static String subscribeByCoin() {
    return BaseUrl + "/tournament/coin-entry";
  }

  static String unsubscribeTournamnet() {
    return BaseUrl + "/tournament/nepal-unsubscribe";
  }

  static String weeklyTaskDetails() {
    return BaseUrl + "/weekly-task/details";
  }

  static String bcsTestList() {
    return BaseUrl + "/bcs-test/list";
  }

  static String bcsTestStart() {
    return BaseUrl + "/bcs-test/start";
  }

  static String bcsModelPlaySubmit() {
    return BaseUrl + "/bcs-test/submit";
  }

  static String bcsHistory() {
    return BaseUrl + "/bcs-test/history";
  }

  static String nepalTournamentEntry() {
    return BaseUrl + "/tournament/nepal-entry";
  }

  static String bundlePurchaseNepal() {
    return BaseUrl + "/bundles/nepal-purchase";
  }

  static String onDemandPaymentNepal() {
    return BaseUrl + "/tournament/nepal-ondemand";
  }

  static String bcsPacks() {
    return BaseUrl + "/bcs-packs";
  }

  static String tournamentPacks() {
    return BaseUrl + "/tournament-packs";
  }

  static String purchaseBkashPacks() {
    return BaseUrl + "/subscribe-bkash-packs";
  }

  static String cancelBundleSubscriptionGhoori() {
    return BaseUrl + "/ghoori-subscription-cancel";
  }

  static String ncellPackages() {
    return "http://45.114.85.21:8080/api/v1/services/packages?serviceId=quizgiri";
  }

  //Live Quiz API
  static String liveQuizList() {
    return BaseUrl + "/live-quiz/running";
  }

   //Latest Tournament API
   static String latestTournaments() {
     return BaseUrl + "/tournament/running";
   }

   //Battle Room API
   static String battleRoomList() {
     return BaseUrl + "/challenge-room/rooms";
   }

  static String challengeRoomJoin() {
    return BaseUrl + "/challenge-room/join";
  }

  static String initialConnection() {
    return BaseUrl + "/challenge-room/connected";
  }

  static String requestPartner() {
    return BaseUrl + "/challenge-room/request-partner";
  }

  static String challengeRoomSubmit() {
    return BaseUrl + "/challenge-room/submit";
  }

  static String challengeRoomRequestNextQuestion() {
    return BaseUrl + "/challenge-room/timeout-next-question";
  }

  static String sendConnectionStatus() {
    return BaseUrl + "/challenge-room/check-connection";
  }

  static String requestFirstQuestion() {
    return BaseUrl + "/challenge-room/request-start";
  }


  static bool isSuccessful(Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return true;
    } else {
      return false;
    }
  }
}

//"Authorization": 'Bearer $access_token',
//"Content-type": "application/json",
//"X-Requested-With": "XMLHttpRequest",
//"x-api-key": API_KEY,
