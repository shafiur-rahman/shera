/*
* Created by Ahammed Hossain Shanto on 7/21/20
*/

import 'dart:io';

import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:quiz/constants/ProjectConstants.dart';

class AdmobHelper {
  static String AdMobAppId = "ca-app-pub-8459260005325677~3073264718";
  static String ResumeGameUnitId = "ca-app-pub-8459260005325677/9117188065";
  static String AdMobAppIdIos = "ca-app-pub-8459260005325677~5362157338";
  static String ResumeGameUnitIdIos = "ca-app-pub-8459260005325677/7598555399";
  ///interstitial ad unit
  static String gameResultAdUnitAndroid = "ca-app-pub-8459260005325677/3423057261";
  static String gameResultAdUnitIos = "ca-app-pub-8459260005325677/1918403901";
  /// banner ad unit
  static String bannerAdUnitAndroid = "ca-app-pub-8459260005325677/9147201550";
  static String bannerAdUnitIos = "ca-app-pub-8459260005325677/7988347607";

  static String getAppId() {
    if (Platform.isAndroid) {
      return AdMobAppId;
    } else if (Platform.isIOS) {
      return AdMobAppIdIos;
    } else {
      return "";
    }
  }

  static String getResumeGameUnitId() {
    if(BUILD_TYPE == "production") {
      if (Platform.isAndroid) {
        return ResumeGameUnitId;
      } else if (Platform.isIOS) {
        return ResumeGameUnitIdIos;
      } else {
        return "";
      }
    }
    else {
      return RewardedAd.testAdUnitId;
    }
  }

  static String getGameResultAdUnit() {
    if(BUILD_TYPE == "production") {
      if (Platform.isAndroid) {
        return gameResultAdUnitAndroid;
      } else if (Platform.isIOS) {
        return gameResultAdUnitIos;
      } else {
        return "";
      }
    }
    else {
      return InterstitialAd.testAdUnitId;
    }
  }

  static String getBannerAdUnit() {
    if(BUILD_TYPE == "production") {
      if (Platform.isAndroid) {
        return bannerAdUnitAndroid;
      } else if (Platform.isIOS) {
        return bannerAdUnitIos;
      } else {
        return "";
      }
    }
    else {
      return BannerAd.testAdUnitId;
    }
  }
}
