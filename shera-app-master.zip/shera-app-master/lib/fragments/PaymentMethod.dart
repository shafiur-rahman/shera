/*Created by Shafiur 09/07/2020*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/RedirectToBrowser.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Menu.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/PaymentMethodVM.dart';
import 'package:quiz/extensions/string_extensions.dart';

class PaymentMethod extends StatelessWidget {
  var arguments;
  int bundle_id;
  int bcsId;
  String caption;
  double price;
  int tournamentId;
  int subscription_fee;
  PaymentMethodVM paymentMethodVM;
  String userName, userId, email, phone;

  PaymentMethod(this.arguments) {
    bundle_id = arguments["bundle_id"];
    bcsId = arguments['bcs_id'];
    caption = arguments["caption"];
    try {
      price = double.parse(arguments["price"].toString());
    }
    catch (_) {
      price = 0;
    }
    tournamentId = arguments["tournament_id"];
    subscription_fee = arguments["subscription_fee"];
    userName = arguments['user_name'];
    userId = arguments['user_id'];
    email = arguments['email'];
    phone = arguments['phone'];
  }

  bool backArrowEnable = true;
  String title = LocaleKey.PAYMENT_METHOD.toLocaleText();

  bool allowMobileOperator() {
    if (bundle_id != null) {
      return true;
    } else {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final PaymentMethodVM paymentMethodVm = new PaymentMethodVM(context);
    return RootBody(
      child: MultiProvider(
        providers: [ChangeNotifierProvider.value(value: paymentMethodVm)],
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(75),
            child: AppBar(
              elevation: 0,
              leading: backArrowEnable
                  ? Container(
                      child: IconButton(
                        icon: Image.asset(
                          "assets/images/back_arrow.png",
                          height: 20,
                          width: 24,
                        ),
                        padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    )
                  : Container(),
              title: Text(
                title,
                style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          body: Padding(
              padding: EdgeInsets.fromLTRB(0, 50, 0, 0),
              child: SingleChildScrollView(child: Consumer<PaymentMethodVM>(
                builder: (context, snapshot, _) {
                  return buildPaymentOptions(context, snapshot, bundle_id, tournamentId);
                },
              ))),
        ),
      ),
    );
  }

  Widget buildPaymentOptions(BuildContext context, PaymentMethodVM snapshot, int bundle_id, int tournamentId) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
            margin: EdgeInsets.fromLTRB(30, 0, 0, 0),
            child: Text(
              LocaleKey.SELECT_PAYMENT_METHOD.toLocaleText(),
              style: TextStyle(
                fontFamily: "Poppins",
                color: ColorsLocal.hexToColor("414141"),
                fontSize: 14,
              ),
            )),
        !AppSessionSettings.isNepaliUser()
            ? Container(
                margin: EdgeInsets.fromLTRB(30, 10, 30, 0),
                child: Material(
                  elevation: .1,
                  borderRadius: BorderRadius.circular(7),
                  clipBehavior: Clip.antiAlias,
                  color: Colors.white,
                  child: InkWell(
                    onTap: () {
                      String type, bundleId;
                      if (bundle_id != null) {
                        type = "bundle";
                        bundleId = bundle_id.toString();
                      } else if(tournamentId != null) {
                        type = "tournament";
                        bundleId = tournamentId.toString();
                      } else if(bcsId != null) {
                        type = "bcs";
                        bundleId = bcsId.toString();
                      }

                      snapshot.createRequest(type, bundleId).then((value) {
                        if (value != null) {
                          if (PackageSupport.instance.isMobile()) {
                            Navigator.pushNamed(context, PaysenzPaymentRoute, arguments: value).then((value) {
                              Navigator.pop(context);
                            });
                          } else {
                            RedirectToBrowser.instance.launch(value.toString(), newTab: false);
                          }
                        }
                      });
                    },
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(20, 5, 20, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.grey[100],
                              ),
                              constraints: BoxConstraints.tightFor(height: 64, width: 64),
                              child: snapshot.creatingPayment || snapshot.checkingPaymentStatus
                                  ? Center(
                                      child: CupertinoActivityIndicator(),
                                    )
                                  : Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Image.asset(
                                        "assets/images/ic_mobile_banking.png",
                                      ),
                                    )),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.only(left: 16, right: 16),
                              child: Text(
                                LocaleKey.BKASH_AND_OTHERS.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  color: ColorsLocal.hexToColor("000000"),
                                  fontSize: 18,
                                ),
                              ),
                            ),
                          ),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 15,
                            color: ColorsLocal.hexToColor("686868"),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              )
            : Container(),
        // !AppSessionSettings.isNepaliUser() ? Opacity(
        //   opacity: allowMobileOperator() ? 1.0 : 0.3,
        //   child: Container(
        //     margin: EdgeInsets.fromLTRB(30, 10, 30, 0),
        //     child: Material(
        //       elevation: .1,
        //       borderRadius: BorderRadius.circular(7),
        //       clipBehavior: Clip.antiAlias,
        //       color: Colors.white,
        //       child: InkWell(
        //         onTap: () {
        //           if(allowMobileOperator()) {
        //             var arguments = {};
        //
        //             arguments["bundle_id"] = this.bundle_id;
        //             arguments["tournament_id"] = this.tournamentId;
        //             arguments["caption"] = this.caption;
        //             arguments["price"] = this.price;
        //             arguments["subscription_fee"] = this.subscription_fee;
        //
        //             Navigator.pushNamed(context, PaymentViaMobileOperatorRoute, arguments: arguments);
        //           }
        //         },
        //         child: Padding(
        //           padding: EdgeInsets.fromLTRB(20, 5, 20, 5),
        //           child: Row(
        //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //             children: [
        //               Container(
        //                   alignment: Alignment.center,
        //                   decoration: BoxDecoration(
        //                     shape: BoxShape.circle,
        //                     color: Colors.grey[100],
        //                   ),
        //                   constraints: BoxConstraints.tightFor(height: 64, width: 64),
        //                   child: Padding(
        //                     padding: const EdgeInsets.all(10.0),
        //                     child: Image.asset(
        //                       "assets/images/ic_sim.png",
        //                     ),
        //                   )),
        //               Expanded(
        //                 child: Container(
        //                   padding: EdgeInsets.only(left: 16, right: 16),
        //                   child: Text(
        //                     "Mobile Operators",
        //                     style: TextStyle(
        //                       fontFamily: "Poppins",
        //                       color: ColorsLocal.hexToColor("000000"),
        //                       fontSize: 18,
        //                     ),
        //                   ),
        //                 ),
        //               ),
        //               Icon(
        //                 Icons.arrow_forward_ios,
        //                 size: 15,
        //                 color: ColorsLocal.hexToColor("686868"),
        //               )
        //             ],
        //           ),
        //         ),
        //       ),
        //     ),
        //   ),
        // ) : Container(),
        AppSessionSettings.isNepaliUser()
            ? Container(
                margin: EdgeInsets.fromLTRB(30, 10, 30, 0),
                child: Material(
                  elevation: .1,
                  borderRadius: BorderRadius.circular(7),
                  clipBehavior: Clip.antiAlias,
                  color: Colors.white,
                  child: InkWell(
                    onTap: () {
                      String type, bundleId;
                      if (bundle_id != null) {
                        type = "bundle";
                        bundleId = bundle_id.toString();
                      } else {
                        type = "tournament";
                        bundleId = tournamentId.toString();
                      }
                      var arguments = {"type": type, "tournament_id": bundleId};
                      if (type == "tournament") {
                        Navigator.pushReplacementNamed(context, NcellPackagesRoute, arguments: arguments);
                      } else {
                        snapshot.purchaseBundleNepal(bundleId);
                      }
                    },
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(20, 5, 20, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.grey[100],
                              ),
                              constraints: BoxConstraints.tightFor(height: 64, width: 64),
                              child: snapshot.creatingPayment || snapshot.checkingPaymentStatus
                                  ? Center(
                                      child: CupertinoActivityIndicator(),
                                    )
                                  : Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Image.asset(
                                        "assets/images/ic_ncell.png",
                                      ),
                                    )),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.only(left: 16, right: 16),
                              child: Text(
                                "Ncell",
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  color: ColorsLocal.hexToColor("000000"),
                                  fontSize: 18,
                                ),
                              ),
                            ),
                          ),
                          snapshot.isProcessing
                              ? CupertinoActivityIndicator()
                              : Icon(
                                  Icons.arrow_forward_ios,
                                  size: 15,
                                  color: ColorsLocal.hexToColor("686868"),
                                )
                        ],
                      ),
                    ),
                  ),
                ),
              )
            : Container(),
      ],
    );
  }
}

class CustomContainer extends StatelessWidget {
  @override
  String text = 'demoText';
  String icon = 'assets/images/agrovet_icon.png';
  GestureTapCallback onTap;

  CustomContainer({Key key, this.text, this.icon, this.onTap})
      : assert(text != null),
        assert(icon != null),
        super(key: key);

  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(30, 10, 30, 0),
      child: Material(
        elevation: .1,
        borderRadius: BorderRadius.circular(7),
        clipBehavior: Clip.antiAlias,
        color: Colors.white,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: EdgeInsets.fromLTRB(20, 5, 20, 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.grey[100],
                    ),
                    constraints: BoxConstraints.tightFor(height: 64, width: 64),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Image.asset(
                        icon,
                      ),
                    )),
                Text(
                  text,
                  style: TextStyle(
                    fontFamily: "Poppins",
                    color: ColorsLocal.hexToColor("000000"),
                    fontSize: 18,
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  size: 15,
                  color: ColorsLocal.hexToColor("686868"),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class OtherPaymentMethod extends StatelessWidget {
  bool backArrowEnable = true;
  String title = "Payment Method";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(75),
        child: AppBar(
          elevation: 0,
          leading: backArrowEnable
              ? Container(
                  child: IconButton(
                    icon: Image.asset(
                      "assets/images/back_arrow.png",
                      height: 20,
                      width: 24,
                    ),
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                )
              : Container(),
          title: Text(
            title,
            style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
          ),
          actions: [
            IconButton(
              icon: Image.asset(
                "assets/images/ic_menu.png",
                height: 20,
                width: 20,
              ),
              onPressed: () {
                Menu.show(context);
              },
            )
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.fromLTRB(0, 60, 0, 0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                  margin: EdgeInsets.fromLTRB(30, 0, 0, 0),
                  child: Text(
                    "Select Your Payment Option",
                    style: TextStyle(
                      fontFamily: "Poppins",
                      color: ColorsLocal.hexToColor("414141"),
                      fontSize: 14,
                    ),
                  )),
              Container(
                margin: EdgeInsets.fromLTRB(0, 20, 0, 0),
                child: CustomContainer(
                  text: "Visa card",
                  icon: "assets/images/pm_visacard.png",
                  onTap: () {},
                ),
              ),
              CustomContainer(
                text: "Master card",
                icon: "assets/images/pm_mastercard2.png",
                onTap: () {},
              ),
              CustomContainer(
                text: "Nexus pay",
                icon: "assets/images/pm_nexuspay.png",
                onTap: () {},
              ),
              CustomContainer(
                text: "Rocket",
                icon: "assets/images/pm_rocket.png",
                onTap: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }
}
