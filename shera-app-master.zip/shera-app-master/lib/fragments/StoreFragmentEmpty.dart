/*
Created by Shafiur 07/07/2020
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Menu.dart';
import 'package:quiz/view-components/RootBody.dart';

class StoreFragmentEmpty extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(75),
          child: _buildAppBar(context),
        ),
        body: Center(
          child: Text(
            "Coming Soon",
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 18,
              fontWeight: FontWeight.w400,
              color: ColorsLocal.text_color.withOpacity(0.5),
            ),
          ),
        ));
  }

  Widget _buildAppBar(BuildContext context) {
    return AppBar(
      bottom: AppBarBottom.shadow(),
      title: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          "Store",
          style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 22),
        ),
      ),
      actions: [
        IconButton(
          icon: Image.asset(
            "assets/images/ic_menu.png",
            height: 20,
            width: 20,
          ),
          onPressed: () {
            Menu.show(context);
          },
        )
      ],
      iconTheme: new IconThemeData(color: Colors.black),
      backgroundColor: Colors.white,
    );
  }
}
