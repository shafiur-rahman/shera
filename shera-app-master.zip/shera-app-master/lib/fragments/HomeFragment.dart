/*
* Created by Ahammed Hossain Shanto
* on 7/1/20
*/

import 'dart:convert';
import 'dart:math';

import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:quiz/ViewModelFactory.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/helpers/banner-ad-loader.dart';
import 'package:quiz/helpers/interstitial-ad_loader.dart';
import 'package:quiz/helpers/video-ad-loader.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/models/RedirectToBrowser.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/ImageLoader.dart';
import 'package:quiz/view-components/LiveQuiz.dart';
import 'package:quiz/view-components/Menu.dart';
import 'package:quiz/view-components/MyLinearProgressBar.dart';
import 'package:quiz/view-components/Pop_Ups/BCSModelQuestionInfo.dart';
import 'package:quiz/view-components/Pop_Ups/CoinsGemsUsage.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-components/TextRules.dart';
import 'package:quiz/view-components/Topics.dart';
import 'package:quiz/view-components/Tournaments.dart';
import 'package:quiz/view-models/HomeChallengeRoomVM.dart';
import 'package:quiz/view-models/HomeFragmentVM.dart';
import 'package:quiz/view-models/UtilsVM.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'package:visibility_detector/visibility_detector.dart';

import '../constants/ProjectConstants.dart';

class HomeFragment extends StatelessWidget {
  final double minTileWidth = 120;

  @override
  Widget build(BuildContext context) {
    final HomeFragmentVM homeFragmentVM = ViewModelFactory.getHomeFragmentVM(context);
    final UtilsVM utilsVM = ViewModelFactory.getUtilsVM(context);

    //CHALLENGE ROOM LIVE
    final HomeChallengeRoomVM homeChallengeRoomVM = new HomeChallengeRoomVM(context);

    // utilsVM.checkRferral();
    utilsVM.checkNoti();

    return MultiProvider(
        providers: [
          ChangeNotifierProvider.value(
            value: homeFragmentVM,
          ),
          ChangeNotifierProvider.value(
            value: utilsVM,
          ),
          ChangeNotifierProvider.value(
            value: homeChallengeRoomVM,
          )

//        ChangeNotifierProvider(
//          create: (_) {
//            return HomeFragmentVM(context);
//          },
//        ),
//        ChangeNotifierProvider(
//          create: (_) {
//            return UtilsVM(context);
//          },
//        )
        ],
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(56),
            child: Consumer2<UtilsVM, HomeFragmentVM>(builder: (context, snapshot, snapshot2, _) {
              return AppBar(
                elevation: snapshot.getElevation(),
                title: _buildAppBar(context, snapshot2),
                automaticallyImplyLeading: false,
                centerTitle: false,
                actions: [
                  AppSessionSettings.showScreenToggleButton(context) ?
                  InkWell(
                    onTap: () async {
                      AppSessionSettings.isFullScreen = !AppSessionSettings.isFullScreen;
                      while(Navigator.canPop(context)) {
                        Navigator.pop(context);
                      }
                      Navigator.pushReplacementNamed(context, SplashScreenRoute);
                    },
                    child: Container(
                      padding: EdgeInsets.fromLTRB(16, 4, 16, 4),
                      child: Icon(
                        AppSessionSettings.isFullScreen ? Icons.fullscreen_exit : Icons.fullscreen,
                        size: 20,
                        color: ColorsLocal.button_color_pink,
                      ),
                    ),
                  ) : Container(height: 0, width: 0,),
                      Badge(
                          badgeColor: Colors.white,
                          showBadge: snapshot.noti != null && ((snapshot.noti['promotion'] != null && snapshot.noti['promotion']) || (snapshot.noti['challenge'] != null && snapshot.noti['challenge'])),
                          padding: EdgeInsets.all(0),
                          position: BadgePosition(top: 10, end: 0),
                          elevation: 1,
                          badgeContent: Container(
                            margin: EdgeInsets.all(2),
                            decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.button_color_pink),
                            height: 10,
                            width: 10,
                          ),
                          child: IconButton(
                            icon: Icon(
                              Icons.sort_outlined,
                              size: 26,
                            ),
                            onPressed: () {
                              //Navigator.pushNamed(context, InviteFriendsRoute);
                              Menu.show(context, noti: snapshot.noti);
                            },
                          ),
                        )
                ],
              );
            }),
          ),
          body: Consumer2<HomeFragmentVM, UtilsVM>(builder: (context, snapshot, utilsVm, _) {
            return RefreshIndicator(
              child: Stack(
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    top: 0,
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          //User wallet under the appbar **********
                          // _buildWallet(context, snapshot, utilsVm),
                          _buildDownloadApp(context, snapshot),
                          //ChallengeRoom

                          Visibility(
                            visible: false,
                            child: Container(
                              margin: EdgeInsets.fromLTRB(16, 12, 16, 0),
                              child: Image.asset(
                                "assets/images/promo_banner.png",
                              ),
                            ),
                          ),
                          // snapshot.getAd(
                          //   0,
                          //   //margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                          // ),
                          // first box
                          _buildLiveQuiz(context, snapshot),
                          // second box
                          _buildLatestTournaments(context, snapshot),
                          // _buildBattleRoom2(context, snapshot),
                          _buildTitle(context),
                          // _buildBattleRoom(context, snapshot),
                          // snapshot.getAd(
                          //   1,
                          //   //margin: EdgeInsets.fromLTRB(16, 16, 16, 8),
                          // ),
                          //Daily task ****** can be hidden
                          // third box
                          Consumer<HomeChallengeRoomVM>(
                              builder: (context, snapshot, _) {
                                return _buildBattleRoom2(context, snapshot);
                              }),
                          Container(
                            height: 64,
                          )
                        ],
                      ),
                    ),
                  ),
                  AppSessionSettings.isNepaliUser() || true
                      ? Container()
                      : Positioned(
                          top: 180,
                          right: 0,
                          child: Consumer<HomeFragmentVM>(builder: (context, snapshot, _) {
                            return InkWell(
                              borderRadius: BorderRadius.circular(100),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(100),
                                      bottomLeft: Radius.circular(100),
                                    ),
                                    boxShadow: [BoxShadow(offset: Offset(0, 0), color: Colors.grey[300], spreadRadius: 2, blurRadius: 16)]),
                                child: Wrap(
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  children: [
                                    Container(
                                      child: Image.asset(
                                        "assets/images/ic_wheel_small.png",
                                        height: 40,
                                        width: 40,
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(4, 0, 0, 0),
                                      child: Text(
                                        '${LocaleValues.instance.getText(LocaleKey.SPIN_NOW_2)}',
                                        style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.button_color_purple, fontWeight: FontWeight.w600),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              onTap: () {
                                Navigator.pushNamed(context, DailySpinRoute).then((value) {
                                  snapshot.loadProfile();
                                });
                              },
                            );
                          })),
                ],
              ),
              onRefresh: () async {
                await homeFragmentVM.refresh();
                homeFragmentVM.initAds();
                UtilsVM utilsVM = Provider.of<UtilsVM>(context, listen: false);
                utilsVM.checkNoti();
              },
            );
          }),
        ));
  }

  Widget _buildAppBar(BuildContext context, HomeFragmentVM snapshot) {
    if (snapshot.profileLoaded) {
      return Container(
        child: Container(
          child: Row(
            children: [
              InkWell(
                customBorder: CircleBorder(),
                onTap: () {
                  Navigator.pushNamed(context, ProfileRoute);
                },
                child: Container(
                    //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        border: Border.all(
                          width: 2,
                          color: Colors.grey[300],
                        ),
                        shape: BoxShape.circle),
                    constraints: BoxConstraints.tightFor(height: 40, width: 40),
                    child: CachedNetworkImage(
                      imageUrl: snapshot.userDetails['image_url'].toString(),
                      imageBuilder: (context, imageProvider) => Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          //borderRadius: BorderRadius.circular(4),
                          image: DecorationImage(
                            image: imageProvider,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      placeholder: (context, url) => Shimmer.fromColors(
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            //borderRadius: BorderRadius.circular(8),
                            color: Colors.grey[300],
                          ),
                        ),
                        baseColor: Colors.grey[300],
                        highlightColor: Colors.white,
                      ),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                    )),
              ),
            ],
          ),
        ),
      );
    } else {
      return Container(
        child: MyShimmer.fromColors(
            child: Container(
              child: Row(
                children: [
                  Container(
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.grey[300],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(16, 0, 16, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            height: 16,
                            margin: EdgeInsets.fromLTRB(0, 0, 100, 0),
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          Container(
                            height: 14,
                            margin: EdgeInsets.fromLTRB(0, 8, 50, 0),
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(8),
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    }
  }

  Widget _buildWallet(BuildContext context, HomeFragmentVM snapshot, UtilsVM utilsVM) {
    if (snapshot.profileLoaded) {
      return Container(
        padding: EdgeInsets.fromLTRB(0, 5, 0, 5),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(offset: Offset(0, 4), color: ColorsLocal.hexToColor("E1E1E1").withOpacity(0.5), spreadRadius: 0.4, blurRadius: 16)],
        ),
        child: VisibilityDetector(
          key: Key("wallet"),
          onVisibilityChanged: (VisibilityInfo info) {
            try {
              if (info.visibleFraction > 0) {
                utilsVM.setWalletVisibility(true);
              } else {
                utilsVM.setWalletVisibility(false);
              }
            } catch (_) {}
          },
          child: Container(
            margin: EdgeInsets.fromLTRB(72, 8, 16, 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
            ),
          ),
        ),
      );
    } else {
      return Container(
        padding: EdgeInsets.fromLTRB(0, 5, 0, 5),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(offset: Offset(0, 4), color: ColorsLocal.hexToColor("E1E1E1").withOpacity(0.5), spreadRadius: 0.4, blurRadius: 16)],
        ),
        child: VisibilityDetector(
          key: Key("wallet"),
          onVisibilityChanged: (VisibilityInfo info) {
            if (info.visibleFraction > 0) {
              utilsVM.setWalletVisibility(true);
            } else {
              utilsVM.setWalletVisibility(false);
            }
          },
          child: MyShimmer.fromColors(
              child: Container(
                margin: EdgeInsets.fromLTRB(72, 8, 16, 8),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      Container(
                        height: 28,
                        width: 60,
                        margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.grey[300],
                        ),
                      ),
                      Container(
                        height: 28,
                        width: 60,
                        margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.grey[300],
                        ),
                      ),
                      Container(
                        height: 28,
                        width: 60,
                        margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.grey[300],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              baseColor: Colors.grey[300],
              highlightColor: Colors.white),
        ),
      );
    }
  }

  Widget _buildDailyTask(BuildContext context, HomeFragmentVM snapshot) {
    if (snapshot.dailyTaskLoaded) {
      if (snapshot.dailyTask != null && !AppSessionSettings.isNepaliUser()) {
        return Container(
          margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
//          boxShadow: [
//            BoxShadow(
//              offset: Offset(0, -1),
//              color: Colors.grey[300],
//              spreadRadius: 1,
//              blurRadius: 6,
//            )
//          ]
          ),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            child: PhysicalModel(
              clipBehavior: Clip.antiAlias,
              color: Colors.white,
              borderRadius: BorderRadius.circular(10.0),
              child: Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 16),
                          child: Image.asset(
                            "assets/images/daily_task_background.png",
                            //color: Colors.grey[300],
                            width: 100,
                          ),
                        ),
                        Positioned(
                          left: 0,
                          top: 0,
                          right: 0,
                          bottom: 16,
                          child: Container(
                            margin: EdgeInsets.fromLTRB(24, 24, 24, 40),
                            child: Image.asset(
                              "assets/images/ic_calendar.png",
                              height: 50,
                              width: 50,
                              //color: Colors.grey[300],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Expanded(
                      child: Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  // Container(
                                  //   child: Text(
                                  //     "Daily Task",
                                  //     style: TextStyle(
                                  //         fontFamily: "Poppins",
                                  //         fontSize: 10,
                                  //         color: ColorsLocal.text_color_pink_2,
                                  //         fontWeight: FontWeight.w500),
                                  //   ),
                                  // ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: Text(
                                      snapshot.dailyTask['title'].toString(),
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color.withOpacity(0.9), fontWeight: FontWeight.w700),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Text(
                                      snapshot.dailyTask['caption'].toString(),
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: Colors.grey[500], fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                    child: Row(
                                      children: [
                                        Container(
                                          child: MyLinearProgressBar.progressBar(120, double.parse(snapshot.dailyTask['progress'].toString()),
                                              gradient: false,
                                              border: Border.all(
                                                width: 1,
                                                color: Colors.grey[300],
                                              ),
                                              backgroundColor: Colors.grey[200],
                                              height: 6),
                                        ),
                                        Expanded(
                                          child: Container(),
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            onTap: () {
              Navigator.pushNamed(context, DailyTaskDetailsRoute).then((value) {
                snapshot.loadDailyTask();
              });
            },
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
//          boxShadow: [
//            BoxShadow(
//              offset: Offset(0, -1),
//              color: Colors.grey[300],
//              spreadRadius: 1,
//              blurRadius: 6,
//            )
//          ]
        ),
        clipBehavior: Clip.antiAlias,
        child: PhysicalModel(
          clipBehavior: Clip.antiAlias,
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
          child: MyShimmer.fromColors(
              child: Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 16),
                      child: Image.asset(
                        "assets/images/daily_task_background.png",
                        color: Colors.grey[300],
                        width: 100,
                      ),
                    ),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              height: 12,
                              margin: EdgeInsets.fromLTRB(0, 0, 150, 0),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[300],
                              ),
                            ),
                            Container(
                              height: 20,
                              margin: EdgeInsets.fromLTRB(0, 12, 50, 0),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[300],
                              ),
                            ),
                            Container(
                              height: 20,
                              margin: EdgeInsets.fromLTRB(0, 8, 100, 0),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[300],
                              ),
                            ),
                            Container(
                              height: 12,
                              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[300],
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              baseColor: Colors.grey[300],
              highlightColor: Colors.white),
        ),
      );
    }
  }

  Widget _buildDownloadApp(BuildContext context, HomeFragmentVM snapshot) {
    if (PackageSupport.instance.isMobile()) {
      return Container();
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white, boxShadow: [BoxShadow(spreadRadius: 0.1, blurRadius: 4, color: Colors.grey[300])]),
        child: Wrap(
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 8,
          runSpacing: 8,
          children: [
            Container(
              child: Text(
            LocaleKey.WHY_DOWNLOAD_APP.toLocaleText(),
            style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            textAlign: TextAlign.start,
              ),
            ),
            //SizedBox(width: 16),
            InkWell(
              child: Image.asset(
                "assets/images/ic_playstore.png",
                height: 40,
                width: 120,
                fit: BoxFit.fill,
              ),
              onTap: () {
                RedirectToBrowser.instance.launch(ANDROID_APP_URL, newTab: false);
              },
            ),
            //SizedBox(width: 8),
            InkWell(
              child: Image.asset(
                "assets/images/ic_appstore.png",
                height: 40,
                width: 120,
                fit: BoxFit.fill,
              ),
              onTap: () {
                RedirectToBrowser.instance.launch(IOS_APP_URL, newTab: false);
              },
            ),
          ],
        ),
      );
    }
  }

  Widget _buildLatestTournaments(BuildContext context, HomeFragmentVM snapshot) {
    if (snapshot.latestTournamentsLoaded) {
      List tournaments = new List();
      if (snapshot.latestTournaments != null) {
        tournaments = snapshot.latestTournaments['tournaments'];
      }

      if (tournaments != null && tournaments.isNotEmpty) {
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'বর্তমান টুর্নামেন্ট',
                        style: TextStyle(fontFamily: "Poppins", fontSize: 24, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                      ),
                    ),
//                    Container(
//                      child: RichText(
//                        text: TextSpan(
//                          text: "See all",
//                          style: TextStyle(
//                            fontFamily: "Poppins",
//                            fontSize: 10,
//                            color: ColorsLocal.hexToColor("757575"),
//                            fontWeight: FontWeight.w500
//                          ),
//                          recognizer: TapGestureRecognizer()..onTap = () {
//                            //TODO navigate to all tournaments screen ***
//                          }
//                        ),
//                      ),
//                    )
                  ],
                ),
              ),
              Container(
                height: 160,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tile(150, 300, index, tournaments, onTap: () {
                      Navigator.pushNamed(context, TournamentDetailsRoute, arguments: {
                        'tournament_id': tournaments[index]['id'],
                      }).then((value) {
                        snapshot.loadProfile();
                      });
                    });
                  },
                  itemCount: tournaments.length,
                ),
              )
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(16, 20, 160, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 160,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tileShimmer(150, 250, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  Widget _buildBattleRoom2(BuildContext context, HomeChallengeRoomVM snapshot) {
    if (snapshot.challengeRoomsLoaded) {
      List battles = new List();
      if (snapshot.challengeRooms != null) {
        battles = snapshot.challengeRooms;
      }

      if (tournaments != null && tournaments.isNotEmpty) {
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'বর্তমান টুর্নামেন্ট',
                        style: TextStyle(fontFamily: "Poppins", fontSize: 24, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                      ),
                    ),
//                    Container(
//                      child: RichText(
//                        text: TextSpan(
//                          text: "See all",
//                          style: TextStyle(
//                            fontFamily: "Poppins",
//                            fontSize: 10,
//                            color: ColorsLocal.hexToColor("757575"),
//                            fontWeight: FontWeight.w500
//                          ),
//                          recognizer: TapGestureRecognizer()..onTap = () {
//                            //TODO navigate to all tournaments screen ***
//                          }
//                        ),
//                      ),
//                    )
                  ],
                ),
              ),
              Container(
                height: 160,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tile(150, 300, index, tournaments, onTap: () {
                      Navigator.pushNamed(context, TournamentDetailsRoute, arguments: {
                        'tournament_id': tournaments[index]['id'],
                      }).then((value) {
                        snapshot.loadProfile();
                      });
                    });
                  },
                  itemCount: tournaments.length,
                ),
              )
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(16, 20, 160, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 160,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tileShimmer(150, 250, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }
  Widget _buildTitle(BuildContext context) {
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        'ব্যাটেল রুম',
                        style: TextStyle(fontFamily: "Poppins", fontSize: 24, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
  }
  Widget _buildLiveQuiz(BuildContext context, HomeFragmentVM snapshot) {
    if (snapshot.latestLiveQuizLoaded) {
      List tournaments = new List();
      if (snapshot.latestLiveQuiz != null) {
        tournaments = snapshot.latestLiveQuiz['tournaments'];
      }

      if (tournaments != null && tournaments.isNotEmpty) {
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Container(
                    //   child: Text(
                    //     'লাইভ কুইজ',
                    //     style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                    //   ),
                    // ),
//                    Container(
//                      child: RichText(
//                        text: TextSpan(
//                          text: "See all",
//                          style: TextStyle(
//                            fontFamily: "Poppins",
//                            fontSize: 10,
//                            color: ColorsLocal.hexToColor("757575"),
//                            fontWeight: FontWeight.w500
//                          ),
//                          recognizer: TapGestureRecognizer()..onTap = () {
//                            //TODO navigate to all tournaments screen ***
//                          }
//                        ),
//                      ),
//                    )
                  ],
                ),
              ),
              Container(
                height: 160,
                margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return LiveQuiz.tile(150, 300, index, tournaments, onTap: () {
                      Navigator.pushNamed(context, TournamentDetailsRoute, arguments: {
                        'tournament_id': tournaments[index]['id'],
                      }).then((value) {
                        snapshot.loadProfile();
                      });
                    });
                  },
                  itemCount: tournaments.length,
                ),
              )
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(16, 20, 160, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 160,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tileShimmer(150, 250, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  Widget _buildBcsModelTests(BuildContext context, HomeFragmentVM snapshot) {
    if (!snapshot.bcsTestsLoaded) {
      //show loading****
      return Container(
        margin: EdgeInsets.fromLTRB(0, 24, 0, 8),
        child: CarouselSlider(
          options: CarouselOptions(
            height: 190.0,
            autoPlay: true,
            viewportFraction: getViewportFraction(190, 350, context),
            enlargeCenterPage: false,
            autoPlayAnimationDuration: Duration(seconds: 1),
            autoPlayInterval: Duration(seconds: 3),
          ),
          items: [1, 2, 3].map((model) {
            return Builder(
              builder: (BuildContext context) {
                return Container(
                    width: MediaQuery.of(context).size.width.toCustomWidth(),
                    margin: EdgeInsets.symmetric(horizontal: 8.0, vertical: 5.0),
                    //padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          width: 1,
                          color: Colors.grey[300],
                        )),
                    child: MyShimmer.fromColors(
                      child: Container(
                        height: 190,
                        width: 350,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.grey[300],
                        ),
                      ),
                      baseColor: Colors.grey[300],
                      highlightColor: Colors.white,
                    ));
              },
            );
          }).toList(),
        ),
      );
    } else if (false) {
      //show actual list items here *********
      return Container(
        margin: EdgeInsets.fromLTRB(0, 16, 0, 8),
        child: CarouselSlider(
          options: CarouselOptions(
            height: 190.0,
            autoPlay: snapshot.bcsModelStarting ? false : true,
            viewportFraction: getViewportFraction(190, 350, context),
            enlargeCenterPage: false,
            autoPlayAnimationDuration: Duration(seconds: 1),
            autoPlayInterval: Duration(seconds: 5),
          ),
          items: snapshot.bcsTests.map((model) {
            return Builder(
              builder: (BuildContext context) {
                return InkWell(
                  onTap: () {
                    BCSModelQuestionInfo.showDialog(
                      context,
                      model,
                      onTap: () {
                        //start game here
                        //call api to get the question
                        //check if response is false -> Maybe because of no having enough coins
                        Navigator.of(context).pop();
                        if(snapshot.needToPayForBcsTest(model)) {
                          Navigator.pushNamed(context, PaymentMethodRoute, arguments: {
                            'bcs_id': int.parse(model['id'].toString())
                          }).then((value) {
                            snapshot.loadBcsTests();
                          });
                        }
                        else {
                          snapshot.loadBCSModelQuestions(model['id'].toString());
                        }
                      },
                      isBcsSubscribed: snapshot.isBcsSubscribed
                    );
                  },
                  child: Container(
                      width: MediaQuery.of(context).size.width.toCustomWidth(),
                      margin: EdgeInsets.symmetric(horizontal: 8.0, vertical: 5.0),
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), boxShadow: [BoxShadow(color: Colors.grey[300], blurRadius: 8, spreadRadius: 0.1)]),
                      child: Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                              ],
                            ),
                          ],
                        ),
                      )),
                );
              },
            );
          }).toList(),
        ),
      );
    } else {
      //nothing to show *********
      return Container();
    }
  }

  Widget _buildTopicList(BuildContext context, HomeFragmentVM snapshot, {@required String type}) {
    if ((snapshot.topTopicsLoaded && type == "top") || (snapshot.favouriteTopicsLoaded && type == "favourite")) {
      List topics = [];
      String title = "";
      int shortListCount = 0;
      if (type == "top") {
        if (snapshot.topTopics != null) {
          topics = snapshot.topTopics['topics'];
          shortListCount = snapshot.topTopics['short_list_count'];
          title = snapshot.topTopics['title'].toString();
        }
      } else if (type == "favourite") {
        if (snapshot.favouriteTopics != null) {
          topics = snapshot.favouriteTopics['topics'];
          shortListCount = snapshot.favouriteTopics['short_list_count'];
          title = snapshot.favouriteTopics['title'].toString();
        }
      }
      if (topics != null && topics.isNotEmpty) {
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(22, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                  ],
                ),
              ),
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(16, 20, 160, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 150,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tileShimmer(150, 150, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  Widget _buildCategoryList(BuildContext context, HomeFragmentVM snapshot, {@required String type}) {
    if (snapshot.categoriesLoaded && type == "categories") {
      List category = new List();
      String title = "";
      int shortListCount = 0;
      if (type == "categories") {
        category = snapshot.categories["category_list"];
        shortListCount = snapshot.categories["short_list_count"];
        title = "Categories";
      }
      if (category != null && category.isNotEmpty) {
        // int rowCount = getRowCount(context);
        // double heightWidth = (MediaQuery.of(context).size.width.toCustomWidth() - 56 - (rowCount-1)*16)/rowCount;
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(22, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                  ],
                ),
              ),
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(16, 20, 160, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 150,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tileShimmer(150, 150, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  Widget _buildInterestedTopics(BuildContext context, HomeFragmentVM snapshot) {
    if (snapshot.interestedTopicsLoaded) {
      if (snapshot.interestedTopics['categories'] != null && snapshot.interestedTopics['categories'].length != 0) {
        List topics = snapshot.interestedTopics['categories'];
        return Container(
          margin: EdgeInsets.fromLTRB(24, 24, 24, 56),
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
              ],
            ),
          ),
        );
      } else {
        return Container(
          height: 56,
        );
      }
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(24, 24, 24, 56),
        child: MyShimmer.fromColors(
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 20,
                    margin: EdgeInsets.fromLTRB(0, 0, 150, 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey[300],
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: List.generate(2, (index) {
                        return Container(
                          height: 130,
                          margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: Colors.grey[300],
                          ),
                        );
                      }),
                    ),
                  )
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    }
  }

  int getRowCount(BuildContext context) {
    double availableWidth = MediaQuery.of(context).size.width.toCustomWidth() - 56;

    int i = availableWidth ~/ minTileWidth;
    return i;
  }

  double getViewportFraction(double height, double expectedWidth, BuildContext context) {
    double totalWidth = MediaQuery.of(context).size.width.toCustomWidth();
    return expectedWidth / totalWidth;
  }

  Widget _buildChallengeRooms(
      BuildContext context, HomeChallengeRoomVM snapshot) {
    if (!snapshot.challengeRoomsLoaded) {
      //show loading****
      return Container(
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
        child: Column(
          children: [
            CarouselSlider(
              options: CarouselOptions(
                height: snapshot.getRoomHeight(context),
                autoPlay: false,
                viewportFraction: 0.8,
                enlargeCenterPage: false,
                autoPlayAnimationDuration: Duration(seconds: 1),
                autoPlayInterval: Duration(seconds: 3),
              ),
              items: [1, 2, 3].map((model) {
                return Builder(
                  builder: (BuildContext context) {
                    return Shimmer.fromColors(
                      child: Container(
                          width: MediaQuery.of(context).size.width,
                          margin:
                          EdgeInsets.symmetric(horizontal: 8.0, vertical: 5.0),
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                width: 1,
                                color: Colors.grey[300],
                              )),
                          child: Container(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(right: 16),
                                      child: CircleAvatar(
                                        backgroundColor:
                                        ColorsLocal.button_color_purple,
                                        radius: 40,
                                        child: Text(
                                          "B",
                                          style: TextStyle(
                                              fontFamily: "Poppins",
                                              fontSize: 32,
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.stretch,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.only(top: 4),
                                              child: Wrap(
                                                children: [
                                                ],
                                              ),
                                            )
                                          ],
                                        ))
                                  ],
                                ),
                                Container(
                                  padding: EdgeInsets.fromLTRB(16, 16, 16, 0),
                                  child: Text(
                                    "Play",
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontSize: 14,
                                        color: ColorsLocal.text_color_pink,
                                        fontWeight: FontWeight.w600),
                                    maxLines: 1,
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          )),
                      highlightColor: Colors.white,
                      baseColor: Colors.grey[300],
                    );
                  },
                );
              }).toList(),
            ),
          ],
        ),
      );
    } else if (snapshot.challengeRooms != null &&
        snapshot.challengeRooms.isNotEmpty) {
      //show actual list items here *********
      return Container(
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(16, 20, 16, 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Container(
                  //   child: Text(
                  //     // '${LocaleValues.instance.getText(LocaleKey.LATEST_CHALLENGEROOM)}',
                  //     '',
                  //     style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  //   ),
                  // ),
//                    Container(
//                      child: RichText(
//                        text: TextSpan(
//                          text: "See all",
//                          style: TextStyle(
//                            fontFamily: "Poppins",
//                            fontSize: 10,
//                            color: ColorsLocal.hexToColor("757575"),
//                            fontWeight: FontWeight.w500
//                          ),
//                          recognizer: TapGestureRecognizer()..onTap = () {
//                            //TODO navigate to all tournaments screen ***
//                          }
//                        ),
//                      ),
//                    )
                ],
              ),
            ),
            CarouselSlider(
              options: CarouselOptions(
                  height: snapshot.getRoomHeight(context),
                  autoPlay: false /*snapshot.joiningRoom ? false : true*/,
                  viewportFraction: 0.85,
                  aspectRatio: snapshot.getRoomHeight(context) /
                      snapshot.getRoomWidth(context),
                  enlargeCenterPage: false,
                  autoPlayAnimationDuration: Duration(seconds: 1),
                  autoPlayInterval: Duration(seconds: 4),
                  onPageChanged: (index, reason) async {
                    //await Future.delayed(Duration(milliseconds: 600));
                    snapshot.setVisibleRoomIndex(index);
                  }),
              items: snapshot.challengeRooms.map((room) {
                return Builder(
                  builder: (BuildContext context) {
                    return Container(
                      margin: EdgeInsets.symmetric(horizontal: 8.0),
                      child: InkWell(
                        child: Material(
                          type: MaterialType.transparency,
                          clipBehavior: Clip.antiAlias,
                          borderRadius: BorderRadius.circular(24),
                          child: Container(
                            height: snapshot.getRoomHeight(context),
                            width: snapshot.getRoomWidth(context),
                            decoration: BoxDecoration(
                              color: ColorsLocal.hexToColor(
                                  room['primary_color'].toString()),
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Stack(
                              children: [
                                Transform.translate(
                                  offset: Offset(-50, -100),
                                  child: Container(
                                    height:
                                    snapshot.getRoomHeight(context) / 1.0,
                                    width:
                                    snapshot.getRoomHeight(context) / 1.0,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          colors: [
                                            ColorsLocal.hexToColor(
                                                room['primary_color_dark'])
                                                .withOpacity(0.3),
                                            Colors.transparent
                                          ],
                                          stops: [
                                            0.0,
                                            0.8
                                          ],
                                          begin: Alignment.bottomRight,
                                          end: Alignment.topLeft),
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ),
                                Positioned(
                                    left: 0,
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    child: Container(
                                      padding: EdgeInsets.all(16),
                                      child: Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        children: [
                                          Container(
                                            child: Row(
                                              children: [
                                                snapshot.joiningRoom &&
                                                    snapshot.joiningRoomId ==
                                                        room['id']
                                                            .toString()
                                                    ? Container(
                                                  height: 40,
                                                  width: 40,
                                                  margin: EdgeInsets.only(
                                                      left: 16, top: 8),
                                                  child: Center(
                                                    child: Container(
                                                      height: 30,
                                                      width: 30,
                                                      child:
                                                      SizedBox.shrink()
                                                    ),
                                                  ),
                                                )
                                                    : Container(
                                                  // child: ImageLoader
                                                  //     .loadRect(
                                                  //   imageUrl:
                                                  //   room['image']
                                                  //       .toString(),
                                                  //   height: 90,
                                                  //   width: 45,
                                                  //   showLoadingShimmer:
                                                  //   false,
                                                  // ),
                                                  margin: EdgeInsets.only(
                                                      left: 0, top: 8),
                                                ),
                                                Expanded(
                                                    child:
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(16, 24, 16, 0),
                                                      child: Text(
                                                        room['name'].toString(),
                                                        style: TextStyle(
                                                            fontFamily: "Poppins",
                                                            fontSize: 24,
                                                            color: Colors.white,
                                                            fontWeight:
                                                            FontWeight.w600,
                                                            height: 1.2
                                                        ),
                                                        maxLines: 2,
                                                        overflow:
                                                        TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            child: Row(
                                              children: [
                                                snapshot.joiningRoom &&
                                                    snapshot.joiningRoomId ==
                                                        room['id']
                                                            .toString()
                                                    ? Container(
                                                  height: 40,
                                                  width: 40,
                                                  margin: EdgeInsets.only(
                                                      left: 16, top: 8),
                                                  child: Center(
                                                    child: Container(
                                                        height: 30,
                                                        width: 30,
                                                        child:
                                                        SizedBox.shrink()
                                                    ),
                                                  ),
                                                )
                                                    : Container(
                                                  // child: ImageLoader
                                                  //     .loadRect(
                                                  //   imageUrl:
                                                  //   room['image']
                                                  //       .toString(),
                                                  //   height: 90,
                                                  //   width: 45,
                                                  //   showLoadingShimmer:
                                                  //   false,
                                                  // ),
                                                  margin: EdgeInsets.only(
                                                      left: 0, top: 8),
                                                ),
                                                Expanded(
                                                  child:
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        left: 16, right: 16),
                                                    child: Text(
                                                      'সময়কাল: ০১ ঘন্টা',
                                                      style: TextStyle(
                                                          fontFamily: "Poppins",
                                                          fontSize: 16,
                                                          color: Color(0xFFAFCFFB),
                                                          fontWeight:
                                                          FontWeight.w500,
                                                          height: 1.2
                                                      ),
                                                      maxLines: 2,
                                                      overflow:
                                                      TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    )),
                                Positioned(
                                    child: AnimatedContainer(
                                      duration: Duration(milliseconds: 300),
                                      height: snapshot.detailsVisibleId ==
                                          room['id'].toString()
                                          ? snapshot.getRoomHeight(context)
                                          : 0,
                                      width: snapshot.getRoomWidth(context),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: ColorsLocal.hexToColor(
                                              room['primary_color']),
                                        ),
                                        child: SingleChildScrollView(
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.stretch,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: [
                                              Align(
                                                alignment: Alignment.topRight,
                                                child: InkWell(
                                                  child: Container(
                                                    margin: EdgeInsets.only(
                                                        right: 12, top: 12),
                                                    height: 20,
                                                    width: 20,
                                                    decoration: BoxDecoration(
                                                        color: Colors.white,
                                                        shape: BoxShape.circle,
                                                        boxShadow: [
                                                          BoxShadow(
                                                              color: ColorsLocal
                                                                  .hexToColor(room[
                                                              'primary_color_dark']),
                                                              spreadRadius: 1,
                                                              blurRadius: 8)
                                                        ]),
                                                    child: Center(
                                                        child: Icon(
                                                          Icons.clear,
                                                          color: ColorsLocal.hexToColor(
                                                              room[
                                                              'primary_color_dark']),
                                                          size: 14,
                                                        )),
                                                  ),
                                                  onTap: () {
                                                    snapshot.setDetailsVisibility(
                                                        room['id'].toString());
                                                  },
                                                ),
                                              ),
                                              // Container(
                                              //   child: Text(
                                              //     "নিয়মাবলী",
                                              //     style: TextStyle(
                                              //         fontFamily: "Poppins",
                                              //         fontSize: 18,
                                              //         color: Colors.white,
                                              //         fontWeight: FontWeight.w700),
                                              //     textAlign: TextAlign.center,
                                              //   ),
                                              // ),
                                             // RulesText(text: "চ্যালেঞ্জটি শেষ হওয়ার পূর্বে, রুম থেকে বের হয়ে গেলে আপনার প্রতিদ্বন্দ্বী বিজয়ী হয়ে যাবে",),
                                             // RulesText(text: "আপনাকে সর্বমোট ১০টি প্রশ্ন খেলতে হবে"),
                                             // RulesText(text: "আপনার কমপক্ষে ১০০/৫০০/১০০০/২০০০ কয়েন থাকতে হবে"),
                                             // RulesText(text: "চ্যালেঞ্জ জিতে গেলে এন্ট্রি ফি সহ মোট ২০০/১০০০/২০০০/৪০০০ কয়েন পাবেন"),

                                            ],
                                          ),
                                        ),
                                      ),
                                    ))
                              ],
                            ),
                          ),
                        ),
                        onTap: () {
                              var arguments = {
                                "room_info": room,
                              };
                              Navigator.pushNamed(
                                  context, ChallengeRoomDetailsRoute,
                                  arguments: arguments);
                        },
                      ),
                    );
                  },
                );
              }).toList(),
            ),
            Container(
              margin: EdgeInsets.only(top: 8),
              child: Wrap(
                children:
                List.generate(snapshot.challengeRooms.length, (index) {
                  return Container(
                    height: 8,
                    width: 8,
                    margin: EdgeInsets.all(2),
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: index == snapshot.visibleRoomIndex
                            ? Colors.grey[500]
                            : Colors.grey[200],
                        border: Border.all(width: 1, color: Colors.grey[500])),
                  );
                }),
              ),
            )
          ],
        ),
      );
    } else {
      //nothing to show *********
      return Container();
    }
  }


}



