/*
Created by Shafiur 07/07/2020
*/

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/ViewModelFactory.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/utils/SizeConfig.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Menu.dart';
import 'package:quiz/view-components/Pop_Ups/CoinsGemsUsage.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-components/TopDeals.dart';
import 'package:quiz/view-models/StoreFragmentVM.dart';
import 'package:quiz/extensions/string_extensions.dart';

class StoreFragment extends StatelessWidget {
  double productsMinWidth = 100;

  @override
  Widget build(BuildContext context) {
    final StoreFragmentVM storeFragmentVM = ViewModelFactory.getStoreFragmentVM(context);

    Future<void> _onRefresh() async {
       storeFragmentVM.loadAllPurchase();
       storeFragmentVM.loadProfile();
       storeFragmentVM.loadTournamentPacks();
       storeFragmentVM.loadBcsPacks();
    }

    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: storeFragmentVM),
      ],
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(75),
          child: _buildAppBar(context),
        ),
        body: RefreshIndicator(
          onRefresh: _onRefresh,
          child: Column(
            children: [
              Consumer<StoreFragmentVM>(
                builder: (context, snapshot, _) {
                  return _buildBalance(context, snapshot);
                },
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Visibility(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(16, 12, 16, 0),
                          child: Image.asset(
                            "assets/images/promo_banner.png",
                          ),
                        ),
                        visible: false,
                      ),
                      Consumer<StoreFragmentVM>(
                        builder: (context, snapshot, _) {
                          return _buildTournamentPackageList(context, snapshot);
                        },
                      ),
                      Consumer<StoreFragmentVM>(
                        builder: (context, snapshot, _) {
                          return _buildTopDeals(context, snapshot);
                        },
                      ),
                      Consumer<StoreFragmentVM>(
                        builder: (context, snapshot, _) {
                          return _buildBCSPackageList(context, snapshot);
                        },
                      ),
                      Consumer<StoreFragmentVM>(
                        builder: (context, snapshot, _) {
                          return _buildPopularProducts(context, snapshot);
                        },
                      ),
                      Container(
                        height: 56,
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return AppBar(
      bottom: AppBarBottom.shadow(),
      title: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          LocaleValues.instance.getText(LocaleKey.STORE),
          style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 22),
        ),
      ),
      actions: [
        !AppSessionSettings.isNepaliUser()
            ? IconButton(
                icon: Image.asset(
                  "assets/images/ic_menu.png",
                  height: 20,
                  width: 20,
                ),
                onPressed: () {
                  Menu.show(context);
                },
              )
            : Container()
      ],
      iconTheme: new IconThemeData(color: Colors.black),
      backgroundColor: Colors.white,
    );
  }

  Widget _buildBalance(BuildContext context, StoreFragmentVM snapshot) {
    if (snapshot.allBundlesLoaded && snapshot.profileLoaded) {
      return Card(
        margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0),
        ),
        elevation: .5,
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${LocaleValues.instance.getText(LocaleKey.YOUR_BALANCE)}',
                style: TextStyle(color: ColorsLocal.text_color_purple_2, fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 15),
              ),
              Row(
                children: [
                  InkWell(
                    onTap: () {
                      CoinsGemsUsage.showDialog(context);
                    },
                    child: Container(
                      height: 28,
                      margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                          border: Border.all(
                            width: 1,
                            color: ColorsLocal.hexToColor("E4CFFF"),
                          )),
                      child: Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          Container(
                            child: Image.asset(
                              "assets/images/ic_coin.png",
                              height: 20,
                              width: 20,
                            ),
                            padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                            child: Text(
                              '${LocaleValues.instance.getNumber(snapshot.wallet['coins'].toString())}',
                              //'${snapshot.userDetails['wallet']['gems'].toString()}',
                              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      CoinsGemsUsage.showDialog(context);
                    },
                    child: Container(
                      height: 28,
                      margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                          border: Border.all(
                            width: 1,
                            color: ColorsLocal.hexToColor("E4CFFF"),
                          )),
                      child: Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          Container(
                            child: Image.asset(
                              "assets/images/ic_gem.png",
                              height: 20,
                              width: 20,
                            ),
                            padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                            child: Text(
                              '${LocaleValues.instance.getNumber(snapshot.wallet['gems'].toString())}',
                              //'${snapshot.userDetails['wallet']['gems'].toString()}',
                              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      );
    } else {
      return MyShimmer.fromColors(
        baseColor: Colors.grey[300],
        highlightColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${LocaleValues.instance.getText(LocaleKey.YOUR_BALANCE)}',
                style: TextStyle(color: ColorsLocal.text_color_purple_2, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
              ),
              Row(
                children: [
                  Container(
                    height: 28,
                    margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        border: Border.all(
                          width: 1,
                          color: ColorsLocal.hexToColor("E4CFFF"),
                        )),
                    child: Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Container(
                          child: Image.asset(
                            "assets/images/ic_coin.png",
                            height: 20,
                            width: 20,
                          ),
                          padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                          child: Text(
                            "",
                            //'${snapshot.userDetails['wallet']['gems'].toString()}',
                            style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                    height: 28,
                    margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        border: Border.all(
                          width: 1,
                          color: ColorsLocal.hexToColor("E4CFFF"),
                        )),
                    child: Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Container(
                          child: Image.asset(
                            "assets/images/ic_gem.png",
                            height: 20,
                            width: 20,
                          ),
                          padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                          child: Text(
                            "",
                            //'${snapshot.userDetails['wallet']['gems'].toString()}',
                            style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      );
    }
  }

  Widget _buildTopDeals(BuildContext context, StoreFragmentVM snapshot) {
    if (snapshot.allBundlesLoaded) {
      return Container(
        child: Column(
          children: [
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: Text(
                      '${LocaleValues.instance.getText(LocaleKey.TOP_DEALS)}',
                      style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                    ),
                    margin: EdgeInsets.fromLTRB(20, 6, 0, 0),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 6, 0, 0),
              height: 115,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemBuilder: (BuildContext context, int index) {
                  return TopDeals.tile(0, 240, index, snapshot.top_deals, onTapBuyNow: () {
                    if (snapshot.profileLoaded) {
                      var arguments = {};
                      arguments['user_id'] = snapshot.userDetails['id'].toString();
                      arguments['user_name'] = snapshot.userDetails['name'].toString();
                      arguments['phone'] = snapshot.userDetails['phone'].toString();
                      arguments['email'] = snapshot.userDetails['email'].toString();
                      arguments["bundle_id"] = snapshot.top_deals[index]["bundle_id"];
                      arguments["caption"] = snapshot.top_deals[index]["caption"];
                      arguments["price"] = snapshot.top_deals[index]["price"];

                      Navigator.pushNamed(context, PaymentMethodRoute, arguments: arguments).then((value) {
                        snapshot.loadAllPurchase(visibleLoad: false);
                      });
                    }
                  }, onTapCard: () {
                    if (snapshot.profileLoaded) {
                      var arguments = {};
                      arguments['user_id'] = snapshot.userDetails['id'].toString();
                      arguments['user_name'] = snapshot.userDetails['name'].toString();
                      arguments['phone'] = snapshot.userDetails['phone'].toString();
                      arguments['email'] = snapshot.userDetails['email'].toString();
                      arguments["bundle_id"] = snapshot.top_deals[index]["bundle_id"];
                      arguments["caption"] = snapshot.top_deals[index]["caption"];
                      arguments["price"] = snapshot.top_deals[index]["price"];

                      Navigator.pushNamed(context, PaymentMethodRoute, arguments: arguments).then((value) {
                        snapshot.loadAllPurchase(visibleLoad: false);
                      });
                    }
                  });
                },
                itemCount: snapshot.top_deals.length,
              ),
            ),
          ],
        ),
      );
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 15,
                margin: EdgeInsets.fromLTRB(20, 10, 210, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 97,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return TopDeals.tileShimmer(97, 152, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  Widget _buildPopularProducts(BuildContext context, StoreFragmentVM snapshot) {
    SizeConfig().init(context);
    if (snapshot.allBundlesLoaded) {
      return Container(
          margin: EdgeInsets.fromLTRB(20, 20, 20, 50),
          //  color: Colors.green,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              snapshot.popular_product != null && snapshot.popular_product.isNotEmpty
                  ? Text(
                      '${LocaleValues.instance.getText(LocaleKey.POPULAR_PRODUCTS)}',
                      style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16),
                    )
                  : Container(),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Wrap(
                  spacing: 10.0,
                  runSpacing: 8.0,
                  children: List<Widget>.generate(snapshot.popular_product.length, (int index) {
//                      bool last = snapshot.topDeals.length == (index + 1);
                    return Material(
                      elevation: 2.5,
                      clipBehavior: Clip.antiAlias,
                      borderRadius: BorderRadius.circular(7),
                      child: InkWell(
                          onTap: () {
                            if (snapshot.profileLoaded) {
                              //print("Card pressed $index ");
                              var arguments = {};
                              arguments['user_id'] = snapshot.userDetails['id'].toString();
                              arguments['user_name'] = snapshot.userDetails['name'].toString();
                              arguments['phone'] = snapshot.userDetails['phone'].toString();
                              arguments['email'] = snapshot.userDetails['email'].toString();
                              arguments["bundle_id"] = snapshot.popular_product[index]["bundle_id"];
                              arguments["caption"] = snapshot.popular_product[index]["caption"];
                              arguments["price"] = snapshot.popular_product[index]["price"];

                              Navigator.pushNamed(context, PaymentMethodRoute, arguments: arguments).then((value) {
                                snapshot.loadAllPurchase(visibleLoad: false);
                              });
                            }
                          },
                          child: Container(
                            height: 127,
                            width: _getProductsWidth(context),
                            child: Column(
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: Stack(
                                    // fit: StackFit.loose,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(top: 7),
                                        child: Center(
                                          child: Text(
                                            snapshot.popular_product[index]['caption'].toString(),
                                            style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.hexToColor("5D3E84"), fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        height: 20,
                                        width: _getProductsWidth(context),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(7.0),
                                        child: Image.asset(
                                          "assets/images/pp_star.png",
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(15, 40, 15, 10),
                                        child: Center(
                                          child: CachedNetworkImage(
                                            imageUrl: '${snapshot.popular_product[index]['image_url'].toString()}',
                                            imageBuilder: (context, imageProvider) => Container(
                                              decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                //borderRadius: BorderRadius.circular(4),
                                                image: DecorationImage(
                                                  image: imageProvider,
                                                  fit: BoxFit.contain,
                                                ),
                                              ),
                                            ),
                                            placeholder: (context, url) => MyShimmer.fromColors(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  //borderRadius: BorderRadius.circular(8),
                                                  color: Colors.grey[300],
                                                ),
                                              ),
                                              baseColor: Colors.grey[300],
                                              highlightColor: Colors.white,
                                            ),
                                            errorWidget: (context, url, error) => Icon(Icons.error),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                Expanded(
                                    child: Container(
                                  color: ColorsLocal.hexToColor("2D76D4"),
                                  child: Center(
                                    child: Text(
                                      '${LocaleValues.instance.getNumber(snapshot.popular_product[index]['price'].toString())} ${LocaleValues.instance.getText(LocaleKey.BDT)}',
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.hexToColor("FFFFFF"), fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                ))
                              ],
                            ),
                          )),
                    );
                  }),
                ),
              ),
            ],
          ));
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 15,
                margin: EdgeInsets.fromLTRB(20, 20, 210, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(20, 0, 10, 0),
                child: Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Wrap(
                    spacing: 10.0,
                    runSpacing: 8.0,
                    children: List<Widget>.generate(6, (int index) {
//                      bool last = snapshot.topDeals.length == (index + 1);
                      return Material(
                        elevation: 2.5,
                        clipBehavior: Clip.antiAlias,
                        borderRadius: BorderRadius.circular(7),
                        child: InkWell(
                            onTap: () {
                              print("Card pressed $index ");
                              Navigator.pushNamed(context, PaymentMethodRoute).then((value) {
                                snapshot.loadAllPurchase(visibleLoad: false);
                              });
                            },
                            child: Container(
                              height: 127,
                              width: _getProductsWidth(context),
                              child: Column(
                                children: [
                                  Expanded(
                                    flex: 3,
                                    child: Stack(
                                      // fit: StackFit.loose,
                                      children: [
                                        Positioned(
                                          child: Text(
                                            ' Coins',
                                            style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.hexToColor("F63677"), fontWeight: FontWeight.w600),
                                          ),
                                          top: 10,
                                          left: 15,
                                        ),
                                        Image.asset(
                                          "assets/images/pp_star.png",
                                          height: 60,
                                          width: 80,
                                        ),
                                        Positioned(
                                            top: 35,
                                            right: 5,
                                            child: Image.asset(
                                              "assets/images/pp_coin.png",
                                              height: 46,
                                              width: 68,
                                            ))
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                      child: Container(
                                    color: ColorsLocal.hexToColor("F63677"),
                                    child: Center(
                                      child: Text(
                                        'BDT ',
                                        style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.hexToColor("FFFFFF"), fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ))
                                ],
                              ),
                            )),
                      );

                      /*Chip(
                            label: Text(charcaterArray[index]),
                            onDeleted: () {
                              setState(() {
                                charcaterArray.removeAt(index);
                              });
                            },
                          );*/
                    }),
                  ),
                ),
              ),
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  int _getRowCount(BuildContext context) {
    double totalWidth = MediaQuery.of(context).size.width.toCustomWidth();
    double availableWidth = totalWidth - 44;

    int rowCount = availableWidth ~/ (productsMinWidth + 10);

    return rowCount;
  }

  double _getProductsWidth(BuildContext context) {
    double totalWidth = MediaQuery.of(context).size.width.toCustomWidth();
    double availableWidth = totalWidth - 44;

    int rowCount = _getRowCount(context);
    double totalVerticalSpacing = (rowCount - 1) * 10.toDouble();
    double availableWidthWithoutSpacing = availableWidth - totalVerticalSpacing;

    return availableWidthWithoutSpacing / rowCount;
  }

  Widget _buildTournamentPackageList(BuildContext context, StoreFragmentVM snapshot) {
    if(!snapshot.tournamentPacksLoaded) {
      return Container(
        margin: EdgeInsets.only(left: 0, right: 0, top: 16, bottom: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              margin: EdgeInsets.only(left: 16, bottom: 12, right: 160),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.grey[300]
              ),
              height: 20,
            ),
            Container(
              height: 128,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: List.generate(3, (index) {
                    return MyShimmer.fromColors(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 10, 0),
                          width: 250,
                          height: 128,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.grey[300],
                          ),
                        ),
                        baseColor: Colors.grey[300],
                        highlightColor: Colors.white
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      );
    }
    else {
      return Container(
        margin: EdgeInsets.only(top: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              margin: EdgeInsets.only(left: 16, right: 16, bottom: 12),
              child: Text(
                LocaleKey.TOURNAMENT_BUNDLES.toLocaleText(),
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 16,
                  color: ColorsLocal.text_color,
                  fontWeight: FontWeight.w600
                ),
              ),
            ),
            Container(
              //height: 112,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(snapshot.tournamentPackages.length, (index) {
                    return Container(
                      margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 12, 0),
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      width: 250,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.grey[200],
                                spreadRadius: 0.1,
                                blurRadius: 8
                            )
                          ]
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            child: Text(
                              snapshot.tournamentPackages[index].title,
                              style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 20,
                                color: ColorsLocal.text_color,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Container(
                            child: Text(
                              snapshot.tournamentPackages[index].caption,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 13,
                                  color: ColorsLocal.text_color.withOpacity(0.7),
                                  fontWeight: FontWeight.w400
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Container(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    child: Text(
                                      '${snapshot.tournamentPackages[index].price} ${LocaleKey.BDT.toLocaleText()}',
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 18,
                                          color: ColorsLocal.text_color_pink,
                                          fontWeight: FontWeight.w700
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  child: RaisedButton(
                                    elevation: 0,
                                    highlightElevation: 0,
                                    child: Text(
                                      //model['is_free'] ? LocaleKey.PLAY_FREE.toLocaleText() : '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_coin'].toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}',
                                      snapshot.canceling &&  snapshot.cancelId == snapshot.tournamentPackages[index].id ? "Processing..." : (snapshot.tournamentPackages[index].isAlreadyBought() ? LocaleKey.SUBSCRIBED.toLocaleText() : LocaleKey.SUBSCRIBE_NOW.toLocaleText()),
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: snapshot.tournamentPackages[index].isAlreadyBought() ? ColorsLocal.button_color_purple : Colors.white, fontWeight: FontWeight.w600),
                                    ),
                                    color: snapshot.tournamentPackages[index].isAlreadyBought() ? ColorsLocal.button_color_purple.withOpacity(0.1) : ColorsLocal.button_color_purple,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                                    onPressed: () {
                                      if(snapshot.tournamentPackages[index].isAlreadyBought()) {
                                        // snapshot.cancelSubscription(snapshot.tournamentPackages[index].id).then((value) {
                                        //   if(value) {
                                        //     snapshot.loadTournamentPacks();
                                        //   }
                                        //   else {
                                        //     LocalAlert.showDialog(context, LocaleKey.SORRY.toLocaleText(), "Package un-subscription failed");
                                        //   }
                                        // });
                                      }
                                      else {
                                        Navigator.pushNamed(context, PaymentMethodRoute, arguments: {
                                          'bundle_id': int.parse(snapshot.tournamentPackages[index].id)
                                        }).then((value) {
                                          snapshot.loadTournamentPacks();
                                        });
                                      }
                                    },
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      );
    }
  }

  Widget _buildBCSPackageList(BuildContext context, StoreFragmentVM snapshot) {
    if(!snapshot.bcsPacksLoaded) {
      return Container(
        margin: EdgeInsets.only(left: 0, right: 0, top: 16, bottom: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              margin: EdgeInsets.only(left: 16, bottom: 12, right: 160),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.grey[300]
              ),
              height: 20,
            ),
            Container(
              height: 128,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: List.generate(3, (index) {
                    return MyShimmer.fromColors(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 10, 0),
                          width: 250,
                          height: 128,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.grey[300],
                          ),
                        ),
                        baseColor: Colors.grey[300],
                        highlightColor: Colors.white
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      );
    }
    else {
      return Container(
        margin: EdgeInsets.only(top: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              margin: EdgeInsets.only(left: 16, right: 16, bottom: 12),
              child: Text(
                LocaleKey.BCS_PACKAGES.toLocaleText(),
                style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 16,
                    color: ColorsLocal.text_color,
                    fontWeight: FontWeight.w600
                ),
              ),
            ),
            Container(
              //height: 112,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List.generate(snapshot.bcsPackages.length, (index) {
                    return Container(
                      margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 12, 0),
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      width: 250,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.grey[200],
                                spreadRadius: 0.1,
                                blurRadius: 8
                            )
                          ]
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            child: Text(
                              snapshot.bcsPackages[index].title,
                              style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 20,
                                color: ColorsLocal.text_color,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Container(
                            child: Text(
                              snapshot.bcsPackages[index].caption,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 13,
                                  color: ColorsLocal.text_color.withOpacity(0.7),
                                  fontWeight: FontWeight.w400
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Container(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    child: Text(
                                      '${snapshot.bcsPackages[index].price} ${LocaleKey.BDT.toLocaleText()}',
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 18,
                                          color: ColorsLocal.text_color_pink,
                                          fontWeight: FontWeight.w700
                                      ),
                                    ),
                                  ),
                                ),
                                snapshot.bcsPackages[index].isAlreadyPurchased() ? Container() : Container(
                                  child: RaisedButton(
                                    elevation: 0,
                                    highlightElevation: 0,
                                    child: Text(
                                      //model['is_free'] ? LocaleKey.PLAY_FREE.toLocaleText() : '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_coin'].toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}',
                                      LocaleKey.PURCHASE_PACK.toLocaleText(),
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w600),
                                    ),
                                    color: ColorsLocal.button_color_purple,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                                    onPressed: () {
                                      Navigator.pushNamed(context, PaymentMethodRoute, arguments: {
                                        'bundle_id': int.parse(snapshot.bcsPackages[index].id)
                                      }).then((value) {
                                        snapshot.loadBcsPacks();
                                      });
                                    },
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      );
    }
  }
}
