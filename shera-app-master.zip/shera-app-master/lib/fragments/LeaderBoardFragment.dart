/*
* Created by Shafiur
* on 3/2/20
*/
import 'dart:ui';

import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/ViewModelFactory.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Menu.dart';
import 'package:quiz/view-components/Pop_Ups/AddFriendPU.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/LeaderBoardFragmentVM.dart';

// ignore: must_be_immutable
class LeaderBoardFragment extends StatelessWidget {
  GlobalKey top1 = GlobalKey();
  GlobalKey top2 = GlobalKey();
  GlobalKey top3 = GlobalKey();

  Size _getSize(GlobalKey globalKey) {
    final RenderBox renderBoxRed = globalKey.currentContext.findRenderObject();
    final size = renderBoxRed.size;
    return size;
  }

//  RefreshController _refreshController =
//  RefreshController(initialRefresh: false);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          ChangeNotifierProvider.value(
            value: ViewModelFactory.getLeaderBoardFragmentVM(context),
          ),
        ],
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(75),
            child: AppBar(
              elevation: 0,
              title: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  '${LocaleValues.instance.getText(LocaleKey.LEADERBOARD)}',
                  style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 22),
                ),
              ),
              actions: [
                IconButton(
                  icon: Image.asset(
                    "assets/images/ic_menu.png",
                    height: 20,
                    width: 20,
                  ),
                  onPressed: () {
                    Menu.show(context);
                  },
                )
              ],
              iconTheme: new IconThemeData(color: Colors.black),
              backgroundColor: Colors.white,
              //bottom: AppBarBottom.shadow(),
            ),
          ),
          body: Consumer<LeaderBoardFragmentVM>(builder: (context, snapshot, _) {
            return RefreshIndicator(
              onRefresh: () async {
                await snapshot.loadLeaderBoard();
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Container(
                      height: 42,
                      decoration: BoxDecoration(color: ColorsLocal.containerFill_color_pink, shape: BoxShape.rectangle, borderRadius: BorderRadius.circular(0), border: Border.all(color: ColorsLocal.containerBorder_color_pink)),
                      child: Consumer<LeaderBoardFragmentVM>(
                        builder: (context, snapshot, _) {
                          return _buildFilter(context, snapshot);
                        },
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(23, 23, 23, 0),
                    child: Consumer<LeaderBoardFragmentVM>(builder: (context, snapshot, _) {
                      return _buildTop3(context, snapshot);
                    }),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                    child: Divider(
                      color: ColorsLocal.divider_color,
                      thickness: 1,
                    ),
                  ),
                  Consumer<LeaderBoardFragmentVM>(
                    builder: (context, snapshot, _) {
                      return _buildLeaderList(context, snapshot);
                    },
                  )
                ],
              ),
            );
          }),
        ));
  }

  Widget _buildFilter(BuildContext context, LeaderBoardFragmentVM snapshot) {
    return Container(
      width: MediaQuery.of(context).size.width,
      child: Row(
        //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          GestureDetector(
            child: Container(
              padding: EdgeInsets.fromLTRB(8, 0, 8, 0),
              decoration: BoxDecoration(shape: BoxShape.rectangle, border: Border(bottom: BorderSide(width: 2, color: snapshot.refer ? ColorsLocal.button_color_pink : Colors.transparent))),
              child: Center(
                child: Text(
                  '${LocaleValues.instance.getText(LocaleKey.REFER)}',
                  style: TextStyle(color: snapshot.refer ? ColorsLocal.text_color_pink_2 : ColorsLocal.text_color_pink_2.withOpacity(0.3), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                ),
              ),
            ),
            onTap: () {
              if (snapshot.refer != true) {
                snapshot.onSelect(true, false, false, false, false, false);
              }
            },
          ),
          GestureDetector(
            child: Container(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
              decoration: BoxDecoration(shape: BoxShape.rectangle, border: Border(bottom: BorderSide(width: 2, color: snapshot.daily ? ColorsLocal.button_color_pink : Colors.transparent))),
              child: Center(
                child: Text(
                  '${LocaleValues.instance.getText(LocaleKey.DAILY)}',
                  style: TextStyle(color: snapshot.daily ? ColorsLocal.text_color_pink_2 : ColorsLocal.text_color_pink_2.withOpacity(0.3), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                ),
              ),
            ),
            onTap: () {
              if (snapshot.daily != true) {
                snapshot.onSelect(false, true, false, false, false, false);
              }
            },
          ),
          GestureDetector(
            child: Container(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
              decoration: BoxDecoration(shape: BoxShape.rectangle, border: Border(bottom: BorderSide(width: 2, color: snapshot.weekly ? ColorsLocal.button_color_pink : Colors.transparent))),
              child: Center(
                child: Text(
                  '${LocaleValues.instance.getText(LocaleKey.WEEKLY)}',
                  style: TextStyle(color: snapshot.weekly ? ColorsLocal.text_color_pink_2 : ColorsLocal.text_color_pink_2.withOpacity(0.3), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                ),
              ),
            ),
            onTap: () {
              if (snapshot.weekly != true) {
                snapshot.onSelect(false, false, true, false, false, false);
              }
            },
          ),
          GestureDetector(
            child: Container(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
              decoration: BoxDecoration(shape: BoxShape.rectangle, border: Border(bottom: BorderSide(width: 2, color: snapshot.monthly ? ColorsLocal.button_color_pink : Colors.transparent))),
              child: Center(
                child: Text(
                  '${LocaleValues.instance.getText(LocaleKey.MONTHLY)}',
                  style: TextStyle(color: snapshot.monthly ? ColorsLocal.text_color_pink_2 : ColorsLocal.text_color_pink_2.withOpacity(0.3), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                ),
              ),
            ),
            onTap: () {
              if (snapshot.monthly != true) {
                snapshot.onSelect(false, false, false, true, false, false);
              }
            },
          ),
          GestureDetector(
            child: Container(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
              decoration: BoxDecoration(shape: BoxShape.rectangle, border: Border(bottom: BorderSide(width: 2, color: snapshot.friends ? ColorsLocal.button_color_pink : Colors.transparent))),
              child: Center(
                child: Text(
                  '${LocaleValues.instance.getText(LocaleKey.FRIENDS)}',
                  style: TextStyle(color: snapshot.friends ? ColorsLocal.text_color_pink_2 : ColorsLocal.text_color_pink_2.withOpacity(0.3), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                ),
              ),
            ),
            onTap: () {
              if (snapshot.friends != true) {
                snapshot.onSelect(false, false, false, false, true, false);
              }
            },
          ),
          // GestureDetector(
          //   child: Container(
          //     padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
          //     decoration: BoxDecoration(
          //       shape: BoxShape.rectangle,
          //         border: Border(
          //             bottom: BorderSide(
          //                 width: 2,
          //                 color: snapshot.overall ? ColorsLocal.button_color_pink : Colors.transparent
          //             )
          //         )
          //     ),
          //     child: Center(
          //       child: Text(
          //         "Overall",
          //         style: TextStyle(
          //             color: snapshot.overall ? ColorsLocal.text_color_pink_2 :ColorsLocal.text_color_pink_2.withOpacity(0.3),
          //             fontFamily: "Poppins",
          //             fontWeight: FontWeight.w600,
          //             fontSize: 15
          //         ),
          //       ),
          //     ),
          //   ),
          //   onTap: (){
          //     if(snapshot.overall != true){
          //       snapshot.onSelect(false,false,false,false,false,true);
          //     }
          //   },
          // ),
        ],
      ),
    );
  }

  Widget _buildTop3(BuildContext context, LeaderBoardFragmentVM snapshot) {
    if (snapshot.leaderBoardListLoaded) {
      if (snapshot.top_list != null && snapshot.top_list.isNotEmpty) {
        int length = snapshot.top_list.length;
        return Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              length >= 2
                  ? Expanded(
                      child: Container(
                        child: Column(
                          children: [
                            Badge(
                              badgeColor: ColorsLocal.hexToColor("8435E8"),
                              position: BadgePosition.topStart(start: -5, top: 0),
                              animationDuration: Duration(milliseconds: 0),
                              animationType: BadgeAnimationType.slide,
                              badgeContent: Text(
                                '${LocaleValues.instance.getNumber("2")}',
                                style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                              ),
                              child: Badge(
                                position: BadgePosition.bottomStart(start: -4, bottom: -22),
                                badgeColor: Colors.transparent,
                                elevation: 0,
                                animationDuration: Duration(milliseconds: 0),
                                badgeContent: Stack(
                                  children: [
                                    Container(
                                      height: 28,
                                      margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          color: Colors.white,
                                          border: Border.all(
                                            width: 1,
                                            color: ColorsLocal.hexToColor("E4CFFF"),
                                          )),
                                      child: Wrap(
                                        crossAxisAlignment: WrapCrossAlignment.center,
                                        children: [
                                          Container(
                                            child: Image.asset(
                                              snapshot.refer ? "assets/images/ic_refer.png" : "assets/images/points.png",
                                              height: 20,
                                              width: 20,
                                            ),
                                            padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                                            child: Text(
                                              snapshot.refer ? LocaleValues.instance.getNumber(snapshot.top_list[1]["refer_count"].toString()) : LocaleValues.instance.getNumber(snapshot.top_list[1]["total_point"].toString()),
                                              //'${snapshot.userDetails['wallet']['gems'].toString()}',
                                              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    snapshot.shouldBlur ? BlurryEffect(0, 5.0, Colors.black, MediaQuery.of(context).size.width.toCustomWidth()) : Container(),
                                  ],
                                ),
                                child: InkWell(
                                  onTap: () {
                                    if (!snapshot.shouldBlur) {
                                      AddFriendPU.show(context, snapshot.top_list[1]);
                                    }
                                  },
                                  child: Container(
                                      //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                            width: 2,
                                            color: ColorsLocal.hexToColor("8435E8"),
                                          ),
                                          shape: BoxShape.circle),
                                      constraints: BoxConstraints.tightFor(height: 65, width: 65),
                                      child: CachedNetworkImage(
                                        imageUrl: snapshot.top_list[1]["image_url"], //imageUrl: snapshot.userDetails['image_url'].toString(),
                                        imageBuilder: (context, imageProvider) => Container(
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            //borderRadius: BorderRadius.circular(4),
                                            image: DecorationImage(
                                              image: imageProvider,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        placeholder: (context, url) => MyShimmer.fromColors(
                                          child: Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              //borderRadius: BorderRadius.circular(8),
                                              color: Colors.grey[300],
                                            ),
                                          ),
                                          baseColor: Colors.grey[300],
                                          highlightColor: Colors.white,
                                        ),
                                        errorWidget: (context, url, error) => Icon(Icons.error),
                                      )),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                              child: Container(
                                child: Center(
                                  child: Text(
                                    snapshot.top_list[1]["name"].toString(),
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 13),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : Container(),
              Expanded(
                child: Column(
                  children: [
                    Badge(
                      badgeColor: ColorsLocal.button_color_pink,
                      position: BadgePosition.topStart(start: 0, top: 0),
                      animationDuration: Duration(milliseconds: 0),
                      animationType: BadgeAnimationType.slide,
                      badgeContent: Padding(
                        padding: const EdgeInsets.all(2.0),
                        child: Text(
                          '${LocaleValues.instance.getNumber("1")}',
                          style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                        ),
                      ),
                      child: Badge(
                        position: BadgePosition.bottomStart(start: 10, bottom: -16),
                        badgeColor: Colors.transparent,
                        elevation: 0,
                        animationDuration: Duration(milliseconds: 0),
                        badgeContent: Stack(
                          children: [
                            Container(
                              height: 28,
                              margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.white,
                                  border: Border.all(
                                    width: 1,
                                    color: ColorsLocal.hexToColor("E4CFFF"),
                                  )),
                              child: Wrap(
                                crossAxisAlignment: WrapCrossAlignment.center,
                                children: [
                                  Container(
                                    child: Image.asset(
                                      snapshot.refer ? "assets/images/ic_refer.png" : "assets/images/points.png",
                                      height: 20,
                                      width: 20,
                                    ),
                                    padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                                    child: Text(
                                      snapshot.refer ? LocaleValues.instance.getNumber(snapshot.top_list[0]["refer_count"].toString()) : LocaleValues.instance.getNumber(snapshot.top_list[0]["total_point"].toString()),
                                      //'${snapshot.userDetails['wallet']['gems'].toString()}',
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            snapshot.shouldBlur ? BlurryEffect(0, 5.0, Colors.black, MediaQuery.of(context).size.width.toCustomWidth()) : Container(),
                          ],
                        ),
                        child: InkWell(
                          onTap: () {
                            if (!snapshot.shouldBlur) {
                              AddFriendPU.show(context, snapshot.top_list[0]);
                            }
                          },
                          child: Container(
                              //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                    width: 2,
                                    color: ColorsLocal.button_color_pink,
                                  ),
                                  shape: BoxShape.circle),
                              constraints: BoxConstraints.tightFor(height: 90, width: 90),
                              child: CachedNetworkImage(
                                imageUrl: snapshot.top_list[0]["image_url"], //imageUrl: snapshot.userDetails['image_url'].toString(),
                                imageBuilder: (context, imageProvider) => Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    //borderRadius: BorderRadius.circular(4),
                                    image: DecorationImage(
                                      image: imageProvider,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                placeholder: (context, url) => MyShimmer.fromColors(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      //borderRadius: BorderRadius.circular(8),
                                      color: Colors.grey[300],
                                    ),
                                  ),
                                  baseColor: Colors.grey[300],
                                  highlightColor: Colors.white,
                                ),
                                errorWidget: (context, url, error) => Icon(Icons.error),
                              )),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(0, 18, 0, 0),
                      child: Text(
                        snapshot.top_list[0]["name"],
                        style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 13),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              length >= 3
                  ? Expanded(
                      child: Container(
                        // color: Colors.green,
                        width: 100,
                        child: Column(
                          children: [
                            Badge(
                              badgeColor: ColorsLocal.hexToColor("8435E8"),
                              position: BadgePosition.topStart(start: -5, top: 0),
                              animationDuration: Duration(milliseconds: 0),
                              animationType: BadgeAnimationType.slide,
                              badgeContent: Text(
                                '${LocaleValues.instance.getNumber("3")}',
                                style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                              ),
                              child: Badge(
                                position: BadgePosition.bottomStart(start: -4, bottom: -22),
                                badgeColor: Colors.transparent,
                                elevation: 0,
                                animationDuration: Duration(milliseconds: 0),
                                badgeContent: Stack(
                                  children: [
                                    Container(
                                      height: 28,
                                      margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          color: Colors.white,
                                          border: Border.all(
                                            width: 1,
                                            color: ColorsLocal.hexToColor("E4CFFF"),
                                          )),
                                      child: Wrap(
                                        crossAxisAlignment: WrapCrossAlignment.center,
                                        children: [
                                          Container(
                                            child: Image.asset(
                                              snapshot.refer ? "assets/images/ic_refer.png" : "assets/images/points.png",
                                              height: 20,
                                              width: 20,
                                            ),
                                            padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                                            child: Text(
                                              snapshot.refer ? LocaleValues.instance.getNumber(snapshot.top_list[2]["refer_count"].toString()) : LocaleValues.instance.getNumber(snapshot.top_list[2]["total_point"].toString()),
                                              //'${snapshot.userDetails['wallet']['gems'].toString()}',
                                              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    snapshot.shouldBlur ? BlurryEffect(0, 5.0, Colors.black, MediaQuery.of(context).size.width.toCustomWidth()) : Container(),
                                  ],
                                ),
                                child: InkWell(
                                  onTap: () {
                                    if (!snapshot.shouldBlur) {
                                      AddFriendPU.show(context, snapshot.top_list[2]);
                                    }
                                  },
                                  child: Container(
                                      //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                            width: 2,
                                            color: ColorsLocal.hexToColor("8435E8"),
                                          ),
                                          shape: BoxShape.circle),
                                      constraints: BoxConstraints.tightFor(height: 65, width: 65),
                                      child: CachedNetworkImage(
                                        imageUrl: snapshot.top_list[2]["image_url"], //imageUrl: snapshot.userDetails['image_url'].toString(),
                                        imageBuilder: (context, imageProvider) => Container(
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            //borderRadius: BorderRadius.circular(4),
                                            image: DecorationImage(
                                              image: imageProvider,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        placeholder: (context, url) => MyShimmer.fromColors(
                                          child: Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              //borderRadius: BorderRadius.circular(8),
                                              color: Colors.grey[300],
                                            ),
                                          ),
                                          baseColor: Colors.grey[300],
                                          highlightColor: Colors.white,
                                        ),
                                        errorWidget: (context, url, error) => Icon(Icons.error),
                                      )),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                              child: Text(
                                snapshot.top_list[2]['name'],
                                style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 13),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : Container(),
            ],
          ),
        );
      } else {
        return Center(
            child: Container(
          child: Text(
            "No history available",
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: ColorsLocal.hexToColor("414141"), fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 13),
          ),
        ));
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                height: 80,
                width: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.grey[300],
                ),
              ),
              Container(
                height: 80,
                width: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.grey[300],
                ),
              ),
              Container(
                height: 80,
                width: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.grey[300],
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  Widget _buildLeaderList(BuildContext context, LeaderBoardFragmentVM snapshot) {
    if (snapshot.leaderBoardListLoaded) {
      if (snapshot.leaderboard != null && snapshot.leaderboard.isNotEmpty) {
        return Expanded(
          child: Container(
            child: ListView.builder(
              itemCount: snapshot.leaderboard.length,
              itemBuilder: (BuildContext context, int i) {
                bool last = snapshot.leaderboard.length == (i + 1);
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: snapshot.leaderboard[i]["self"] ? EdgeInsets.fromLTRB(5, 5, 5, 0) : EdgeInsets.fromLTRB(10, 5, 10, 0),
                      child: Container(
                        margin: last ? EdgeInsets.fromLTRB(0, 0, 0, 56) : EdgeInsets.fromLTRB(0, 0, 0, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(7), border: Border.all(color: snapshot.leaderboard[i]["user"] == "true" ? ColorsLocal.hexToColor("DBBFFF") : ColorsLocal.hexToColor("ffffff"), width: snapshot.leaderboard[i]["user"] == "true" ? 1 : 0)),
                        child: Material(
                          color: snapshot.leaderboard[i]["self"] ? ColorsLocal.hexToColor("8435E8") : Colors.white,
                          borderRadius: BorderRadius.circular(7),
                          clipBehavior: Clip.antiAlias,
                          child: InkWell(
                            onTap: () {
                              AddFriendPU.show(context, snapshot.leaderboard[i]);
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.fromLTRB(10, 10, 0, 10),
                                        child: Badge(
                                          elevation: 0,
                                          padding: EdgeInsets.all(0),
                                          badgeColor: Colors.transparent,
                                          position: BadgePosition.bottomEnd(bottom: -8, end: -4),
                                          animationDuration: Duration(milliseconds: 0),
                                          animationType: BadgeAnimationType.slide,
                                          badgeContent: Container(
                                            margin: EdgeInsets.all(1.5),
                                            padding: EdgeInsets.fromLTRB(6, 0, 6, 0),
                                            decoration: BoxDecoration(
                                              shape: BoxShape.rectangle,
                                              borderRadius: BorderRadius.circular(100),
                                              border: Border.all(width: 2, color: Colors.white),
                                              color: ColorsLocal.hexToColor("8435E8"),
                                            ),
                                            child: Text(
                                              LocaleValues.instance.getNumber(snapshot.leaderboard[i]["position"].toString()),
                                              style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 8),
                                            ),
                                          ),
                                          child: Container(
                                              //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                                              alignment: Alignment.center,
                                              decoration: BoxDecoration(shape: BoxShape.circle),
                                              constraints: BoxConstraints.tightFor(height: 34, width: 34),
                                              child: CachedNetworkImage(
                                                imageUrl: snapshot.leaderboard[i]["image_url"], //imageUrl: snapshot.userDetails['image_url'].toString(),
                                                imageBuilder: (context, imageProvider) => Container(
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    //borderRadius: BorderRadius.circular(4),
                                                    image: DecorationImage(
                                                      image: imageProvider,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                ),
                                                placeholder: (context, url) => MyShimmer.fromColors(
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      //borderRadius: BorderRadius.circular(8),
                                                      color: Colors.grey[300],
                                                    ),
                                                  ),
                                                  baseColor: Colors.grey[300],
                                                  highlightColor: Colors.white,
                                                ),
                                                errorWidget: (context, url, error) => Icon(Icons.error),
                                              )),
                                        ),
                                      ),
                                      Expanded(
                                        child: Padding(
                                          padding: EdgeInsets.only(left: 40),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.stretch,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                snapshot.leaderboard[i]['name'],
                                                style: TextStyle(color: snapshot.leaderboard[i]["self"] ? Colors.white : ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 13),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              Text(
                                                '${LocaleValues.instance.getText(LocaleKey.LEVEL)} ${LocaleValues.instance.getNumber(snapshot.leaderboard[i]['level'].toString())}',
                                                style: TextStyle(color: snapshot.leaderboard[i]["self"] ? Colors.white : ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w400, fontSize: 10),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 28,
                                  margin: EdgeInsets.fromLTRB(16, 0, 12, 0),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.white,
                                      border: Border.all(
                                        width: 1,
                                        color: ColorsLocal.hexToColor("E4CFFF"),
                                      )),
                                  child: Wrap(
                                    crossAxisAlignment: WrapCrossAlignment.center,
                                    children: [
                                      Container(
                                        child: Image.asset(
                                          snapshot.refer ? "assets/images/ic_refer.png" : "assets/images/points.png",
                                          height: 20,
                                          width: 20,
                                        ),
                                        padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(2, 4, 8, 4),
                                        child: Text(
                                          snapshot.refer ? LocaleValues.instance.getNumber(snapshot.leaderboard[i]["refer_count"].toString()) : LocaleValues.instance.getNumber(snapshot.leaderboard[i]["total_point"].toString()),
                                          //'${snapshot.userDetails['wallet']['gems'].toString()}',
                                          style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        );
      } else {
        return Container(
          height: 56,
        );
      }
    } else {
      return Expanded(
        child: Container(
          margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
          child: ListView.builder(
            itemCount: 8,
            //shrinkWrap: true,
            //physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext context, int i) {
              return MyShimmer.fromColors(
                baseColor: Colors.grey[300],
                highlightColor: Colors.white,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(15, 8, 15, 0),
                  child: Material(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(7),
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () {
                        //QuizResultPU.show(context);
                        //WatchVideoPU.show(context);
                      },
                      child: Container(
                        height: 50,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      );
    }
  }
}

class BlurryEffect extends StatelessWidget {
  final double opacity;
  final double blurry;
  final Color shade;
  final double width;

  BlurryEffect(this.opacity, this.blurry, this.shade, this.width);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent,
      child: Material(
        borderRadius: BorderRadius.circular(8),
        type: MaterialType.transparency,
        clipBehavior: Clip.antiAlias,
        child: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 3.0, sigmaY: 3.0),
            child: Container(
              width: 70,
              height: 28,
              color: shade.withOpacity(opacity),
            ),
          ),
        ),
      ),
    );
  }
}
