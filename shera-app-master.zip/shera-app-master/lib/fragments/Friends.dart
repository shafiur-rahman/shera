/*
* Created by Shafiur
* on 3/2/20
*/
import 'dart:math';

import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:provider/provider.dart';
import 'package:quiz/ViewModelFactory.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/models/ChallengeInfo.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Menu.dart';
import 'package:quiz/view-components/Pop_Ups/AddFriendPU.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/FriendsVm.dart';
import 'package:quiz/view-models/UserPopupVM.dart';

// ignore: must_be_immutable
class Friends extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          ChangeNotifierProvider.value(value: ViewModelFactory.getFriendsVM(context)),
          ChangeNotifierProvider(
            create: (_) {
              return UserPopupVm(context);
            },
          ),
        ],
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(75),
            child: AppBar(
              title: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  '${LocaleValues.instance.getText(LocaleKey.FRIENDS)}',
                  style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 22),
                ),
              ),
              actions: [
                IconButton(
                  icon: Icon(
                    Icons.search,
                    size: 24,
                    color: ColorsLocal.button_color_purple,
                  ),
                  onPressed: () {
                    Navigator.pushNamed(context, SearchFriendsRoute);
                  },
                ),
                IconButton(
                    icon: Image.asset(
                      "assets/images/ic_menu.png",
                      height: 20,
                      width: 20,
                    ),
                    onPressed: () {
                      Menu.show(context);
                    })
              ],
              iconTheme: new IconThemeData(color: Colors.black),
              backgroundColor: Colors.white,
              elevation: 0,
              bottom: AppBarBottom.shadow(),
            ),
          ),
          body: Consumer<FriendsVM>(builder: (context, snapshot, _) {
            return RefreshIndicator(
              onRefresh: () async {
                await snapshot.loadLeaderBoard();
              },
              child: Stack(
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    top: 0,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                          ),
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                            child: Container(
                              height: 42,
                              decoration: BoxDecoration(color: ColorsLocal.containerFill_color_pink, shape: BoxShape.rectangle, borderRadius: BorderRadius.circular(5), border: Border.all(color: ColorsLocal.containerBorder_color_pink)),
                              child: _buildFilter(context, snapshot),
                            ),
                          ),
                        ),
                        Consumer2<FriendsVM, UserPopupVm>(
                          builder: (context, snapshot, snapshot2, _) {
                            return _buildLeaderList(context, snapshot, snapshot2);
                          },
                        )
                      ],
                    ),
                  ),
                  //Text("GG")
                ],
              ),
            );
          }),
        ));
  }

  Widget _buildFilter(BuildContext context, FriendsVM snapshot) {
    return Row(
      // mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Expanded(
          child: GestureDetector(
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Container(
                decoration: BoxDecoration(
                  color: snapshot.friend ? ColorsLocal.container_color_pink : ColorsLocal.containerFill_color_pink,
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Center(
                  child: Text(
                    '${LocaleValues.instance.getText(LocaleKey.FRIENDS)}',
                    style: TextStyle(color: snapshot.friend ? Colors.white : ColorsLocal.text_color_pink_3, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ),
            onTap: () {
              snapshot.onSelect(true, false, false);
            },
          ),
        ),
        snapshot.pending != null && snapshot.pending != 0
            ? Expanded(
                child: GestureDetector(
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: snapshot.request ? ColorsLocal.container_color_pink : ColorsLocal.containerFill_color_pink,
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Center(
                        child: Badge(
                          toAnimate: false,
                          position: BadgePosition(top: -3, end: -18),
                          badgeColor: Colors.white,
                          elevation: 0,
                          padding: EdgeInsets.all(0),
                          badgeContent: Container(
                            margin: EdgeInsets.all(2),
                            decoration: BoxDecoration(color: snapshot.request == true ? ColorsLocal.button_color_purple : ColorsLocal.button_color_purple.withOpacity(.4), shape: BoxShape.circle),
                            child: Center(
                              child: Container(
                                padding: EdgeInsets.all(4),
                                child: Text(
                                  snapshot.pending.toString(),
                                  style: TextStyle(fontSize: 8, color: Colors.white, fontWeight: FontWeight.w600, fontFamily: "Poppins"),
                                ),
                              ),
                            ),
                          ),
                          child: Text(
                            '${LocaleValues.instance.getText(LocaleKey.REQUEST)}',
                            style: TextStyle(color: snapshot.request ? Colors.white : ColorsLocal.text_color_pink_3, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 13),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ),
                  ),
                  onTap: () {
                    snapshot.onSelect(false, true, false);
                  },
                ),
              )
            : Expanded(
                child: GestureDetector(
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: snapshot.request ? ColorsLocal.container_color_pink : ColorsLocal.containerFill_color_pink,
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Center(
                        child: Text(
                          '${LocaleValues.instance.getText(LocaleKey.REQUEST)}',
                          style: TextStyle(color: snapshot.request ? Colors.white : ColorsLocal.text_color_pink_3, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 13),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ),
                  onTap: () {
                    snapshot.onSelect(false, true, false);
                  },
                ),
              ),
        Expanded(
          child: GestureDetector(
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Container(
                decoration: BoxDecoration(
                  color: snapshot.sent_request ? ColorsLocal.container_color_pink : ColorsLocal.containerFill_color_pink,
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Center(
                  child: Text(
                    '${LocaleValues.instance.getText(LocaleKey.SENT_REQUEST)}',
                    style: TextStyle(color: snapshot.sent_request ? Colors.white : ColorsLocal.text_color_pink_3, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ),
            onTap: () {
              snapshot.onSelect(false, false, true);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildLeaderList(BuildContext context, FriendsVM snapshot, UserPopupVm snapshot2) {
    if (snapshot.leaderBoardListLoaded) {
      if (snapshot.leaderboard != null && snapshot.leaderboard.isNotEmpty) {
        return Expanded(
          child: Container(
            margin: EdgeInsets.fromLTRB(0, 18, 0, 0),
            child: ListView.builder(
              itemCount: snapshot.leaderboard.length,
              itemBuilder: (BuildContext context, int i) {
                bool last = snapshot.leaderboard.length == (i + 1);
                return Padding(
                  padding: EdgeInsets.fromLTRB(15, 8, 15, 0),
                  child: Container(
                    margin: last ? EdgeInsets.fromLTRB(0, 0, 0, 56) : EdgeInsets.fromLTRB(0, 0, 0, 0),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(7), border: Border.all(color: ColorsLocal.hexToColor("ffffff"), width: 0)),
                    child: Material(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(7),
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        onTap: () {
                          var user = snapshot.leaderboard[i];
                          user['self'] = false;
                          AddFriendPU.show(context, user);
                        },
                        child: Slidable(
                          enabled: snapshot.friend,
                          //delegate: new SlidableDrawerDelegate(),
                          actionExtentRatio: 0.5,
                          actionPane: SlidableDrawerActionPane(),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.fromLTRB(10, 10, 0, 10),
                                      child: Container(
                                          //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(shape: BoxShape.circle),
                                          constraints: BoxConstraints.tightFor(height: 48, width: 48),
                                          child: CachedNetworkImage(
                                            imageUrl: snapshot.leaderboard[i]["image_url"],
                                            //imageUrl: snapshot.userDetails['image_url'].toString(),
                                            imageBuilder: (context, imageProvider) => Container(
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                //borderRadius: BorderRadius.circular(4),
                                                image: DecorationImage(
                                                  image: imageProvider,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                            placeholder: (context, url) => MyShimmer.fromColors(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  //borderRadius: BorderRadius.circular(8),
                                                  color: Colors.grey[300],
                                                ),
                                              ),
                                              baseColor: Colors.grey[300],
                                              highlightColor: Colors.white,
                                            ),
                                            errorWidget: (context, url, error) => Icon(Icons.error),
                                          )),
                                    ),
                                    Flexible(
                                      child: Container(
                                        margin: EdgeInsets.only(left: 30),
                                        //color: Colors.green,
                                        child: Text(
                                          snapshot.leaderboard[i]['name'].toString().substring(0, 1).toUpperCase() + snapshot.leaderboard[i]['name'].toString().substring(1, snapshot.leaderboard[i]['name'].toString().length).toLowerCase(),
                                          overflow: TextOverflow.fade,
                                          maxLines: 1,
                                          softWrap: false,
                                          style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Row(
                                children: [
                                  Visibility(
                                    visible: snapshot.request,
                                    child: Row(
                                      children: [
                                        InkWell(
                                          child: Container(
                                            width: 50,
                                            height: 68,
                                            child: Center(
                                                child: Icon(
                                              Icons.check,
                                              color: ColorsLocal.hexToColor("8C8C8C"),
                                              size: 17,
                                            )),
                                            decoration: BoxDecoration(border: Border.all(color: ColorsLocal.hexToColor("E8E8E8"), width: 1)),
                                          ),
                                          onTap: () {
                                            snapshot.friendRequestAccept(snapshot.leaderboard[i]["user_id"]);
                                          },
                                        ),
                                        InkWell(
                                          onTap: () {
                                            snapshot.friendRequestDeny(snapshot.leaderboard[i]["user_id"]);
                                          },
                                          child: Container(
                                            width: 50,
                                            height: 68,
                                            child: Center(
                                                child: Icon(
                                              Icons.close,
                                              color: ColorsLocal.hexToColor("8C8C8C"),
                                              size: 17,
                                            )),
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.only(
                                                  topRight: Radius.circular(7),
                                                  bottomRight: Radius.circular(7),
                                                ),
                                                border: Border.all(color: ColorsLocal.hexToColor("E8E8E8"), width: 1)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Visibility(
                                    visible: snapshot.sent_request,
                                    child: InkWell(
                                      onTap: () {
                                        snapshot.outgoingRequestDelete(snapshot.leaderboard[i]["user_id"]);
                                      },
                                      child: Container(
                                        width: 50,
                                        height: 68,
                                        child: Center(
                                            child: Icon(
                                          Icons.close,
                                          color: ColorsLocal.hexToColor("8C8C8C"),
                                          size: 17,
                                        )),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(7),
                                              bottomRight: Radius.circular(7),
                                            ),
                                            border: Border.all(color: ColorsLocal.hexToColor("E8E8E8"), width: 1)),
                                      ),
                                    ),
                                  ),
                                  Visibility(
                                    visible: snapshot.friend,
                                    child: InkWell(
                                      onTap: () {
                                        ChallengeInfo.friendUserId = snapshot.leaderboard[i]["user_id"];
                                        Navigator.pushNamed(context, ChallengeFriendRoute);
                                      },
                                      child: Container(
                                        width: 50,
                                        height: 68,
                                        child: Center(
                                          child: Image.asset(
                                            "assets/images/vs.png",
                                            height: 17,
                                          ),
                                        ),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(7),
                                              bottomRight: Radius.circular(7),
                                            ),
                                            border: Border.all(color: ColorsLocal.hexToColor("E8E8E8"), width: 1)),
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                          actions: [
                            Material(
                              color: ColorsLocal.hexToColor("D9DEE7"),
                              child: InkWell(
                                  onTap: () => snapshot.unFriend(snapshot.leaderboard[i]['user_id']),
                                  child: Center(
                                    child: Text(
                                      "Unfriend",
                                      style: TextStyle(
                                        fontFamily: "poppins",
                                        fontSize: 12,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  )),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      } else {
        if (snapshot.type == "friends") {
          return Expanded(
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 32),
                      child: Image.asset(
                        "assets/images/empty_friends_1.png",
                        width: min(200, MediaQuery.of(context).size.width.toCustomWidth() - 48),
                        height: min(200, MediaQuery.of(context).size.width.toCustomWidth() - 48),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 24),
                      child: Text(
                        '${LocaleValues.instance.getText(LocaleKey.YOU_HAVE_NO_FRIENDS)}',
                        style: TextStyle(
                          fontFamily: "poppins",
                          fontSize: 18,
                          color: ColorsLocal.text_color,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 0),
                      child: Text(
                        '${LocaleValues.instance.getText(LocaleKey.YOU_CAN_ADD_FRIEND)}',
                        style: TextStyle(
                          fontFamily: "poppins",
                          fontSize: 14,
                          color: ColorsLocal.text_color.withOpacity(0.8),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 8),
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        color: ColorsLocal.button_color_purple,
                        elevation: 0,
                        highlightElevation: 0,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                          child: Text(
                            '${LocaleValues.instance.getText(LocaleKey.SEARCH_FRIEND)}',
                            style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pushNamed(context, SearchFriendsRoute);
                        },
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        }
        if (snapshot.type == "incoming_requests") {
          return Expanded(
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 32),
                      child: Image.asset(
                        "assets/images/empty_friends_2.png",
                        width: min(200, MediaQuery.of(context).size.width.toCustomWidth() - 48),
                        height: min(200, MediaQuery.of(context).size.width.toCustomWidth() - 48),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 24),
                      child: Text(
                        '${LocaleValues.instance.getText(LocaleKey.EMPTY_REQUEST)}',
                        style: TextStyle(
                          fontFamily: "poppins",
                          fontSize: 18,
                          color: ColorsLocal.text_color,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 0),
                      child: Text(
                        '${LocaleValues.instance.getText(LocaleKey.YOU_CAN_ADD_FRIEND)}',
                        style: TextStyle(
                          fontFamily: "poppins",
                          fontSize: 14,
                          color: ColorsLocal.text_color.withOpacity(0.8),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 8),
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        color: ColorsLocal.button_color_purple,
                        elevation: 0,
                        highlightElevation: 0,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                          child: Text(
                            '${LocaleValues.instance.getText(LocaleKey.SEARCH_FRIEND)}',
                            style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pushNamed(context, SearchFriendsRoute);
                        },
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        } else {
          return Expanded(
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 32),
                      child: Image.asset(
                        "assets/images/empty_friends_3.png",
                        width: min(200, MediaQuery.of(context).size.width.toCustomWidth() - 48),
                        height: min(200, MediaQuery.of(context).size.width.toCustomWidth() - 48),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 24),
                      child: Text(
                        '${LocaleValues.instance.getText(LocaleKey.EMPTY_REQUEST)}',
                        style: TextStyle(
                          fontFamily: "poppins",
                          fontSize: 18,
                          color: ColorsLocal.text_color,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 0),
                      child: Text(
                        '${LocaleValues.instance.getText(LocaleKey.YOU_CAN_ADD_FRIEND)}',
                        style: TextStyle(
                          fontFamily: "poppins",
                          fontSize: 14,
                          color: ColorsLocal.text_color.withOpacity(0.8),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 8),
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        color: ColorsLocal.button_color_purple,
                        elevation: 0,
                        highlightElevation: 0,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                          child: Text(
                            '${LocaleValues.instance.getText(LocaleKey.SEARCH_FRIEND)}',
                            style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pushNamed(context, SearchFriendsRoute);
                        },
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        }
      }
    } else {
      return Expanded(
        child: Container(
          margin: EdgeInsets.fromLTRB(0, 18, 0, 0),
          child: ListView.builder(
            itemCount: 8,
            //shrinkWrap: true,
            //physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext context, int i) {
              return MyShimmer.fromColors(
                baseColor: Colors.grey[300],
                highlightColor: Colors.white,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(15, 8, 15, 0),
                  child: Material(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(7),
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () {
                        //QuizResultPU.show(context);
                        //WatchVideoPU.show(context);
                      },
                      child: Container(
                        height: 50,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      );
    }
  }
}
