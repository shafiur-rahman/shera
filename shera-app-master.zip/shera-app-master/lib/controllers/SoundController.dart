/*
* Created by Ahammed Hossain Shanto
* on 9/27/20
*/


import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:flutter/foundation.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SoundController {
  static AssetsAudioPlayer foregroundPlayer = AssetsAudioPlayer.withId("1");
  static AssetsAudioPlayer backgroundPlayer = AssetsAudioPlayer.withId("2");
  static double backgroundLevel = 1.0;
  static double foregroundLevel = 1.0;
  static var settings;


  static init() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    preferences = await SharedPreferences.getInstance();
    double sound, music;
    sound = preferences.getDouble(SOUND_EFFECT);
    music = preferences.getDouble(MUSIC);

    foregroundLevel = sound ?? 1.0;
    backgroundLevel = music ?? 1.0;
  }

  static correctPlay() async {
    if(!kIsWeb) {
      if (!AppSessionSettings.isNepaliUser()) {
        try {
          foregroundPlayer.open(
            Audio("assets/sounds/correct.mp3"),
            autoStart: true,
            volume: foregroundLevel,
          );
        } catch (_) {
          //do nothing ***
        }
      }
    }
  }

  static wrongPLay() async {
    if(!kIsWeb) {
      if (!AppSessionSettings.isNepaliUser()) {
        try {
          foregroundPlayer.open(
            Audio("assets/sounds/wrong.mp3"),
            autoStart: true,
            volume: foregroundLevel,
          );
        } catch (_) {
          //do nothing ***
        }
      }
    }
  }

  static playTimer() {
    if(!kIsWeb) {
      if (!AppSessionSettings.isNepaliUser()) {
        try {
          backgroundPlayer.open(
            Audio("assets/sounds/time_ticking.wav"),
            autoStart: true,
            loopMode: LoopMode.single,
            volume: backgroundLevel,
          );
        } catch (_) {
          //do nothing ***
        }
      }
    }
  }

  static pauseTimer() {
    if(!kIsWeb) {
      try {
        backgroundPlayer.pause();
      } catch (_) {
        //do nothing ***
      }
    }
  }
}
