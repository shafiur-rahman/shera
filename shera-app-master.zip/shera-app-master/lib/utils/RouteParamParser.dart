/*
* Created by Ahammed Hossain Shanto
* on 2/18/21
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:quiz/utils/Logger.dart';

class RouteParamParser {
  static String getRouteName(String url) {
    String routeName = "";
    for(int i = 0; i < url.length; i++) {
      if(url[i] == "/") {
        routeName = "/";
      }
      else if(url[i] == "?") {
        break;
      }
      else {
        routeName += url[i];
      }
    }
    return routeName;
  }
  static dynamic getArguments(String url) {
    var arg = {};
    var uri = Uri.parse(url);
    if(uri.queryParameters.isEmpty) {
      arg = null;
    }
    else {
      uri.queryParameters.forEach((k, v) {
        arg[k] = v;
        //print('key: $k - value: $v');
      });
    }
    return arg;
  }

  static String getFullUrl(RouteSettings routeSettings) {
    String url = routeSettings.name;
    Map<dynamic, dynamic> params = routeSettings.arguments;
    int count = 0;
    if(params != null) {
      params.forEach((key, value) {
        if(count == 0) {
          url += "?";
        }
        else {
          url += "&";
        }
        url += (key.toString() + "=" + value.toString());
        count++;
      });
    }
    //Logger.dlog("URL", url);
    return url;
  }
}