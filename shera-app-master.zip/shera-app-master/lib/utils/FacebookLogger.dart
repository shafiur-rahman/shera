/*
* Created by Ahammed Hossain Shanto
* on 10/29/20
*/

import 'package:facebook_app_events/facebook_app_events.dart';
import 'package:flutter/cupertino.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/utils/PackageSupport.dart';

class FacebookLogger {
  static final facebookAppEvents = FacebookAppEvents();

  static bool shouldLog() {
    if (BUILD_TYPE == "production" && PackageSupport.instance.isMobile()) {
      return true;
    } else {
      return false;
    }
  }

  static void spin({@required var type, @required var amount}) {
    if (shouldLog()) {
      facebookAppEvents.logEvent(name: "wheel_spin", parameters: {'type': type, 'amount': amount});
    }
  }

  static void adWatchForSpin() {
    if (shouldLog()) {
      facebookAppEvents.logEvent(
        name: "ad_watch_for_spin",
      );
    }
  }

  static void adWatchForRetry({String type = "quiz"}) {
    if (shouldLog()) {
      facebookAppEvents.logEvent(
        name: "ad_watch_for_retry",
      );
    }
  }

  static void adLoadFailed() {
    if (shouldLog()) {
      facebookAppEvents.logEvent(
        name: "ad_load_failed",
      );
    }
  }

  static void leaderboardWatch() {
    if (shouldLog()) {
      facebookAppEvents.logEvent(
        name: "leaderboard_watch",
      );
    }
  }

  static void quizPlayStat({@required int totalQuestion, @required int totalCorrect, @required double accuracy, @required double timeUsage, @required double avgTime}) {
    if (shouldLog()) {
      //Logger.printWrapped("Logging to facebook");
      facebookAppEvents.logEvent(name: "quiz_played", parameters: {
        'total_question': totalQuestion,
        'total_correct': totalCorrect,
        'accuracy': '${accuracy.toStringAsFixed(2)}%',
        'time_usage': '${timeUsage.toStringAsFixed(2)}%',
        'average_time_taken': '${avgTime.toStringAsFixed(2)} Seconds',
      });
    }
  }
}
