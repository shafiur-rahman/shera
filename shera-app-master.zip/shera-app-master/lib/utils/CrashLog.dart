/*
* Created by Ahammed Hossain Shanto
* on 10/27/20
*/

import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';

class CrashLog {
  static postLog(String msg) {
    if(!kIsWeb) {
      FirebaseCrashlytics.instance.log(msg);
    }
  }

  static postKey(String key, String value) {
    if(!kIsWeb) {
      FirebaseCrashlytics.instance.setCustomKey(key, value);
    }
  }
}
