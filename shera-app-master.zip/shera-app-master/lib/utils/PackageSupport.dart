/*
* Created by Ahammed Hossain Shanto
* on 2/10/21
*/


import 'package:flutter/foundation.dart';
import 'package:quiz/utils/Logger.dart';

class PackageSupport {
  static PackageSupport _instance;

  static PackageSupport get instance {
    if (_instance == null) {
      _instance = new PackageSupport();
    }
    return _instance;
  }

  bool isMobile() {
    if (kIsWeb) {
      return false;
    } else {
      return true;
    }
  }
}
