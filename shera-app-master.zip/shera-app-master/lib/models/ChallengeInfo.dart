/*
* Created by Ahammed Hossain Shanto on 8/6/20
*/

class ChallengeInfo {
  static int topicId = -1;
  static int friendUserId = -1;
  static int questionCount = 20;
  static int betAmount = -1;
}
