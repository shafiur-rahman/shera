/*
* Created by Ahammed Hossain Shanto
* on 2/14/21
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:shimmer/shimmer.dart';

class MyShimmer {
  static Widget fromColors({Key key, @required Widget child, @required Color baseColor, @required Color highlightColor, Duration period = const Duration(milliseconds: 1500), ShimmerDirection direction = ShimmerDirection.ltr, int loop = 0, bool enabled = true, LinearGradient gradient}) {
    // DiagnosticPropertiesBuilder propertiesBuilder = new DiagnosticPropertiesBuilder();
    // propertiesBuilder.add(DiagnosticsProperty<Color>('color', baseColor,
    //     defaultValue: null));
    // child.debugFillProperties(propertiesBuilder);
    if (kIsWeb) {
      return child;
    } else {
      return Shimmer.fromColors(child: child, baseColor: baseColor, highlightColor: highlightColor);
    }
  }
}
