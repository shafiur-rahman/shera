/*
* Created by Ahammed Hossain Shanto
* on 2/24/21
*/


import 'package:json_annotation/json_annotation.dart';

part 'TournamentPackage.g.dart';

//flutter pub run build_runner build

@JsonSerializable(explicitToJson: true)
class TournamentPackage {
  static String packageTitle = "";
  String _id;
  String _title;
  String _caption;
  String _price;
  bool _isBought;


  bool get isBought => _isBought;

  set isBought(bool value) {
    _isBought = value;
  }

  String get id => _id;

  set id(String value) {
    _id = value;
  }

  TournamentPackage(String id, String title, String caption, String price, bool isBought) {
    this._id = id;
    this._title = title;
    this._caption = caption;
    this._price = price;
    this._isBought = isBought;
  }

  factory TournamentPackage.fromJson(Map<String, dynamic> json) => _$TournamentPackageFromJson(json);
  Map<String, dynamic> toJson() => _$TournamentPackageToJson(this);

  String get title => _title;

  set title(String value) {
    _title = value;
  }

  String get caption => _caption;

  set caption(String value) {
    _caption = value;
  }

  String get price => _price;

  set price(String value) {
    _price = value;
  }

  bool isAlreadyBought() {

    if(_isBought != null && _isBought == true){
      return true;
    }
    return false;
  }
}