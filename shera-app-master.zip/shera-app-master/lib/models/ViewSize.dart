/*
* Created by Ahammed Hossain Shanto
* on 2/16/21
*/

import 'package:flutter/cupertino.dart';

import '../constants/ProjectConstants.dart';

class ViewSize {
  double _height;
  double _width;
  static ViewSize _instance;

  static ViewSize getInstance(BuildContext context) {
    if (_instance == null) {
      double _height = MediaQuery.of(context).size.height;
      double _width = MediaQuery.of(context).size.width;
      if (MediaQuery.of(context).size.width > SCREEN_BREAK) {
        _width = SCREEN_BREAK;
      }
      _instance = new ViewSize(_height, _width);
    }

    return _instance;
  }

  ViewSize(this._height, this._width);

  double get height => _height;

  double get width => _width;
}
