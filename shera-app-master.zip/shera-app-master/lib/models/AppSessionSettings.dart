/*
* Created by Ahammed Hossain Shanto
* on 7/2/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:socket_io_client/socket_io_client.dart';

class AppSessionSettings {
  static bool showDailyTask = false;
  static bool showReferralPopUp = true;
  static String userCountryCode = "+880";

  static int ncellTournamentId;
  static int ncellFreeQuestionsCount;
  static bool ncellFreeQuestionsEndDialogShow = false;
  static bool isFullScreen = true;

  static bool showScreenToggleButton(BuildContext context) {
    double _width = MediaQuery.of(context).size.width;
    if(_width > SCREEN_BREAK && kIsWeb) {
      return true;
    }
    return false;
  }

  static bool isNepaliUser() {
    if (userCountryCode == "+977") {
      return true;
    } else {
      return false;
    }
  }


  static IO.Socket socket;
}
