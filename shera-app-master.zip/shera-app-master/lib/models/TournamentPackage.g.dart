// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'TournamentPackage.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TournamentPackage _$TournamentPackageFromJson(Map<String, dynamic> json) {
  return TournamentPackage(
    json['bundle_id'].toString(),
    json['title'].toString(),
    json['caption'].toString(),
    json['price'].toString(),
    json['is_subscribed'],
  );
}

Map<String, dynamic> _$TournamentPackageToJson(TournamentPackage instance) =>
    <String, dynamic>{
      'bundle_id': instance.id,
      'title': instance.title,
      'caption': instance.caption,
      'price': instance.price,
      'is_subscribed': instance.isBought
    };
