// /*
// * Created by Ahammed Hossain Shanto
// * on 2/14/21
// */
//
//

//
// import 'dart:html';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:url_launcher/url_launcher.dart';

class RedirectToBrowser {
  static RedirectToBrowser _instance;

  static RedirectToBrowser get instance {
    if (_instance == null) {
      _instance = new RedirectToBrowser();
    }
    return _instance;
  }

  void launch(String url, {bool newTab = true}) async {
    if(PackageSupport.instance.isMobile()) {
      if (await canLaunch(url)) {
        launch(url);
      } else {
        throw 'Could not launch $url';
      }
    }
    else {
      // if (newTab) {
      //   window.open(url, 'new tab');
      // }
      // else {
      //   window.open(url, "_self");
      // }
    }
  }
}

//When build prod app, comment import:html and line 31-38