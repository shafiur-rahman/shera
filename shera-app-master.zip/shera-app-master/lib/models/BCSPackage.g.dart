// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'BCSPackage.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BCSPackage _$BCSPackageFromJson(Map<String, dynamic> json) {
  return BCSPackage(
    json['bundle_id'].toString(),
    json['title'].toString(),
    json['caption'].toString(),
    json['price'].toString(),
    json['is_bought']
  );
}

Map<String, dynamic> _$BCSPackageToJson(BCSPackage instance) =>
    <String, dynamic>{
      'bundle_id': instance.id,
      'title': instance.title,
      'caption': instance.caption,
      'price': instance.price,
      'is_bought': instance.isBought
    };
