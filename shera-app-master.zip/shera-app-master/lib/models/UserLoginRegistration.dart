/*
* Created by Ahammed Hossain Shanto
* on 6/30/20
*/

class UserLoginRegistration {
  static String countryCode = "";
  static String mobile = "";
  static String name = "";
  static String email = "";
  static String password = "";
  static bool accountExists = false;
  static bool isFirebase = false;
  static String verificationId = ""; //for firebase phone auth ****
}
