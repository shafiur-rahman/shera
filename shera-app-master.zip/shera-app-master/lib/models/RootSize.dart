/*
* Created by Ahammed Hossain Shanto
* on 2/16/21
*/

import 'package:flutter/cupertino.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/ViewSize.dart';

import '../constants/ProjectConstants.dart';

class RootSize {
  static RootSize _instance;
  final BuildContext context;
  ViewSize _size;

  RootSize(this.context);

  init() {
    _instance = this;
  }

  ViewSize get size {
    double _height = MediaQuery.of(context).size.height;
    double _width = MediaQuery.of(context).size.width;
    if (MediaQuery.of(context).size.width > SCREEN_BREAK && !AppSessionSettings.isFullScreen) {
      _width = SCREEN_BREAK;
    }

    _size = ViewSize(_height, _width);

    return _size;
  }

  static RootSize getInstance(BuildContext context) {
    return _instance;
  }
}
