/*
* Created by Ahammed Hossain Shanto
* on 3/15/21
*/


import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:quiz/constants/AdmobHelper.dart';

typedef OnAdLoaded = void Function(InterstitialAdLoader ial);
typedef OnAdClosed = void Function(InterstitialAdLoader ial);
typedef OnAdLoadingFailed = void Function(InterstitialAdLoader ial);
typedef OnAdOpened = void Function(InterstitialAdLoader ial);

class InterstitialAdLoader {

  static int adInterval = 0;
  static int showAfter = 0;
  OnAdLoaded onAdLoaded = (value) {};
  OnAdClosed onAdClosed = (value) {};
  OnAdOpened onAdOpened = (value) {};
  OnAdLoadingFailed onAdLoadingFailed = (value) {};

  int retries = 5;

  InterstitialAd _interstitialAd;


  bool shouldLoad() {
    if(showAfter == 0) {
      showAfter = adInterval;
      return true;
    }
    return false;
  }

  InterstitialAdLoader({this.onAdLoaded, this.onAdOpened, this.onAdClosed, this.onAdLoadingFailed, this.retries});

  static final AdRequest request = AdRequest(
    testDevices: <String>["12C2B32706920B8273AA5579BA820FDF"],
    keywords: <String>['quizgiri', 'quizgiri.xyz'],
    contentUrl: 'https://app.quizgiri.com.bd',
    nonPersonalizedAds: true,
  );

  init() {
    if(!kIsWeb) {
      if (shouldLoad()) {
        MobileAds.instance.initialize().then((InitializationStatus status) {
          print('Initialization done: ${status.adapterStatuses}');
          MobileAds.instance
              .updateRequestConfiguration(RequestConfiguration(
              tagForChildDirectedTreatment:
              TagForChildDirectedTreatment.unspecified))
              .then((value) {
            createInterstitialAd();
          });
        });
      }
    }
  }

  retry() {
    if(retries != 0) {
      retries--;
      createInterstitialAd();
    }
  }

  void showAd() {
    _interstitialAd.show();
  }

  void createInterstitialAd() {
    try {
      _interstitialAd ??= InterstitialAd(
        adUnitId: AdmobHelper.getGameResultAdUnit(),
        request: request,
        listener: AdListener(
          onAdLoaded: (Ad ad) {
            onAdLoaded(this);
          },
          onAdFailedToLoad: (Ad ad, LoadAdError error) {
            ad.dispose();
            _interstitialAd = null;
            onAdLoadingFailed(this);
            retry();
          },
          onAdOpened: (Ad ad) {
            onAdOpened(this);
          },
          onAdClosed: (Ad ad) {
            ad.dispose();
            onAdClosed(this);
          },
          onApplicationExit: (Ad ad) =>
              print('${ad.runtimeType} onApplicationExit.'),
        ),
      )
        ..load();
    }
    catch (e) {
      throw e;
    }
  }
}