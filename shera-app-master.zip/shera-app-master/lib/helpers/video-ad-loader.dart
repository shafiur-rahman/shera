/*
* Created by Ahammed Hossain Shanto
* on 3/15/21
*/

import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:quiz/constants/AdmobHelper.dart';

typedef OnAdLoaded = void Function(VideoAdLoader videoAdLoader);
typedef OnRewarded = void Function(VideoAdLoader videoAdLoader);
typedef OnAdClosed = void Function(VideoAdLoader videoAdLoader);
typedef OnAdLoadingFailed = void Function(VideoAdLoader videoAdLoader);

class VideoAdLoader {

  OnAdLoaded onAdLoaded = (value) {};
  OnRewarded onRewarded = (value) {};
  OnAdClosed onAdClosed = (value) {};
  OnAdLoadingFailed onAdLoadingFailed = (value) {};

  int retries = 5;


  VideoAdLoader({this.onAdLoaded, this.onAdClosed, this.onAdLoadingFailed, this.onRewarded, this.retries});

  RewardedAd _rewardedAd;
  bool _adLoaded = false;


  void showAd() {
    _rewardedAd.show();
  }

  retry() {
    if(retries != 0) {
      retries--;
      createRewardedAd();
    }
  }


  // static final AdRequest request = AdRequest(
  //   testDevices: <String>["12C2B32706920B8273AA5579BA820FDF"],
  //   keywords: <String>['quizgiri', 'quizgiri.xyz'],
  //   contentUrl: 'https://app.quizgiri.com.bd',
  //   nonPersonalizedAds: true,
  // );

  static final AdRequest request = new AdRequest();

  init() {
    MobileAds.instance.initialize().then((InitializationStatus status) {
      MobileAds.instance
          .updateRequestConfiguration(RequestConfiguration(
          tagForChildDirectedTreatment:
          TagForChildDirectedTreatment.unspecified))
          .then((value) {
        createRewardedAd();
      });
    });
  }


  void createRewardedAd() {
    try {
      _rewardedAd ??= RewardedAd(
        adUnitId: AdmobHelper.getResumeGameUnitId(),
        request: request,
        listener: AdListener(
            onAdLoaded: (Ad ad) {
              print('${ad.runtimeType} loaded.');
              _adLoaded = true;
              onAdLoaded(this);
            },
            onAdFailedToLoad: (Ad ad, LoadAdError error) {
              print('${ad.runtimeType} failed to load: $error');
              ad.dispose();
              _rewardedAd = null;
              onAdLoadingFailed(this);
              retry();
            },
            onAdOpened: (Ad ad) => print('${ad.runtimeType} onAdOpened.'),
            onAdClosed: (Ad ad) {
              print('${ad.runtimeType} closed.');
              ad.dispose();
              _rewardedAd = null;
              onAdClosed(this);
              createRewardedAd();
            },
            onApplicationExit: (Ad ad) =>
                print('${ad.runtimeType} onApplicationExit.'),
            onRewardedAdUserEarnedReward: (RewardedAd ad, RewardItem reward) {
              onRewarded(this);
              _rewardedAd = null;
              ad.dispose();
              //createRewardedAd();
              print(
                '$RewardedAd with reward $RewardItem(${reward.amount}, ${reward.type})',
              );
            }),
      )
        ..load();
    }
    catch (e) {
      throw e;
    }
  }
}