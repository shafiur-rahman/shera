/*
* Created by Ahammed Hossain Shanto
* on 3/15/21
*/


import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:quiz/constants/AdmobHelper.dart';
import 'package:quiz/utils/Logger.dart';

// ignore: must_be_immutable
class BannerAdLoader extends StatelessWidget {

  BannerAd _bannerAd;
  final Completer<BannerAd> bannerCompleter = Completer<BannerAd>();
  final AdSize adSize;

  static final AdRequest request = AdRequest(
    testDevices: <String>["4b39339cfc3c", "64F6D9DA-0438-4E2D-A862-53976ED1D2F1"],
    keywords: <String>['quizgiri', 'quizgiri.xyz'],
    contentUrl: 'https://app.quizgiri.com.bd',
    nonPersonalizedAds: true,
  );

  init() {
    if(!kIsWeb) {
      Logger.printWrapped("Banner loader inits");
      try {
        _bannerAd = BannerAd(
          adUnitId: AdmobHelper.getBannerAdUnit(),
          request: request,
          size: adSize,
          listener: AdListener(
            onAdLoaded: (Ad ad) {
              print('$BannerAd loaded.');
              bannerCompleter.complete(ad as BannerAd);
            },
            onAdFailedToLoad: (Ad ad, LoadAdError error) {
              print('$BannerAd failedToLoad: $error');
              bannerCompleter.completeError(null);
              //init();
            },
            onAdOpened: (Ad ad) => print('$BannerAd onAdOpened.'),
            onAdClosed: (Ad ad) => print('$BannerAd onAdClosed.'),
            onApplicationExit: (Ad ad) => print('$BannerAd onApplicationExit.'),
          ),
        );

        _bannerAd?.load();
      }
      catch (e) {
        throw e;
      }
    }
  }

  final EdgeInsetsGeometry margin;

  BannerAdLoader(this.adSize, {this.margin = const EdgeInsets.fromLTRB(8, 8, 8, 0)}) {
    init();
  }

  @override
  Widget build(BuildContext context) {
    if(!kIsWeb) {
      return FutureBuilder<BannerAd>(
        future: bannerCompleter.future,
        builder: (BuildContext context, AsyncSnapshot<BannerAd> snapshot) {
          Widget child;

          switch (snapshot.connectionState) {
            case ConnectionState.none:
            case ConnectionState.waiting:
            case ConnectionState.active:
              child = null;
              break;
            case ConnectionState.done:
              if (snapshot.hasData) {
                child = AdWidget(
                  ad: _bannerAd,
                );
              } else {
                child = null;
              }
          }

          if (child == null) {
            return Container();
          }
          else {
            return Container(
              margin: margin,
              width: _bannerAd.size.width.toDouble(),
              height: _bannerAd.size.height.toDouble(),
              child: child,
              //color: Colors.grey[200],
            );
          }
        },
      );
    }
    else {
      return Container();
    }
  }
}
