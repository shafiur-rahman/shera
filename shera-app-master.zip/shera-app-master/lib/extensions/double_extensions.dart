/*
* Created by Ahammed Hossain Shanto
* on 2/17/21
*/

import 'package:flutter/foundation.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/models/AppSessionSettings.dart';

extension DoubleExtensions on double {
  toCustomWidth() {
    double _width = this;
    if (kIsWeb &&!AppSessionSettings.isFullScreen && _width > SCREEN_BREAK) {
      _width = SCREEN_BREAK;
    }
    return _width;
  }
}
