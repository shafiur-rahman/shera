/*
* Created by Ahammed Hossain Shanto
* on 2/8/21
*/

import 'package:quiz/locale-helper/locale_values.dart';

extension StringExtension on String {
  String toLocaleNumber() {
    return LocaleValues.instance.getNumber(this);
  }

  String toLocaleText() {
    return LocaleValues.instance.getText(this);
  }
}
