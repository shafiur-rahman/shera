import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:quiz/fragments/Friends.dart';
import 'package:quiz/fragments/PaymentMethod.dart';
import 'package:quiz/fragments/StoreFragment.dart';
import 'package:quiz/utils/CrashLog.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/utils/RouteParamParser.dart';
import 'package:quiz/views/AllNotifications.dart';
import 'package:quiz/views/BCSModelPlay.dart';
import 'package:quiz/views/BCSPackageList.dart';
import 'package:quiz/views/BkashPacks.dart';
import 'package:quiz/views/BkashPurchasePack.dart';
import 'package:quiz/views/CategoryList.dart';
import 'package:quiz/views/ChallengeFriend.dart';
import 'package:quiz/views/ChallengePartnerSearch.dart';
import 'package:quiz/views/ChallengePlay.dart';
import 'package:quiz/views/ChallengeRoomDetails.dart';
import 'package:quiz/views/ChallengeRoomGameplay.dart';
import 'package:quiz/views/ChallengeRoomResult.dart';
import 'package:quiz/views/Challenges.dart';
import 'package:quiz/views/Confirmation.dart';
import 'package:quiz/views/DailySpin.dart';
import 'package:quiz/views/DailyTaskDetails.dart';
import 'package:quiz/views/DailyTaskPlay.dart';
import 'package:quiz/views/DummyUI.dart';
import 'package:quiz/views/EditProfile.dart';
import 'package:quiz/views/GamePlay.dart';
import 'package:quiz/views/Home.dart';
import 'package:quiz/views/InviteFriends.dart';
import 'package:quiz/views/LoginWithEmail.dart';
import 'package:quiz/views/LoginWithMobile.dart';
import 'package:quiz/views/NcellPackages.dart';
import 'package:quiz/views/PaymentViaMobileOperator.dart';
import 'package:quiz/views/PaysenzPaymentWebView.dart';
import 'package:quiz/views/Profile.dart';
import 'package:quiz/views/PurchaseHistory.dart';
import 'package:quiz/views/RecentBestAll.dart';
import 'package:quiz/views/RedirectionWebView.dart';
import 'package:quiz/views/RegisterUser.dart';
import 'package:quiz/views/SearchFriends.dart';
import 'package:quiz/views/SearchTopics.dart';
import 'package:quiz/views/SelectFriend.dart';
import 'package:quiz/views/SplashScreen.dart';
import 'package:quiz/views/SubcategoryList.dart';
import 'package:quiz/views/TopicDetails.dart';
import 'package:quiz/views/TopicList.dart';
import 'package:quiz/views/TopicSuggestionToNewUser.dart';
import 'package:quiz/views/TournamentDetails.dart';
import 'package:quiz/views/TournamentPackageList.dart';
import 'package:quiz/views/TournamentPlay.dart';
import 'package:quiz/views/TournamentSubscriptionRedirectNepal.dart';
import 'package:quiz/views/UploadAvatar.dart';
import 'package:quiz/views/UserSettings.dart';
import 'package:quiz/views/VerifyOtp.dart';

import 'constants/RoutingConstants.dart';

Route<dynamic> generateRoute(RouteSettings rs) {

  String TAG = "Router";
  try {
    CrashLog.postLog(rs.name.toString());
  } catch (_) {
    //can't log on firebase
  }
  //Logger.dlog("RouteValues", rs.toString());
  RouteSettings settings;
  String routeName = rs.name;
  if(kIsWeb) {
    var arg;
    if(rs.arguments != null) {
      arg = rs.arguments;
    }
    else {
      arg = RouteParamParser.getArguments(rs.name);
    }
    routeName = RouteParamParser.getRouteName(rs.name);
    String fullUrl = RouteParamParser.getFullUrl(rs);
    settings = new RouteSettings(name: fullUrl, arguments: arg);
  }
  else {
    settings = new RouteSettings(name: rs.name, arguments: rs.arguments);
  }


  switch (routeName) {
    case SplashScreenRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => SplashScreen());
    case DummyUIRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => DummyUI());
    case LoginWithMobileRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => LoginWithMobile());
    case LoginWithEmailRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => LoginWithEmail());
    case VerifyOtpRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => VerifyOtp());
    case RegisterUserRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => RegisterUser());
    case TopicSuggestionToNewUserRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => TopicSuggestionToNewUser());
    case HomeRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => Home());
    case ProfileRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => Profile());
    case EditProfileRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => EditProfile(settings.arguments));
    case PurchaseHistoryRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => PurchaseHistory());
    case NotificationsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => AllNotification());
    case TopicListRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => TopicList(settings.arguments));
    case CategoryListRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => CategoryList());
    case SubcategoryListRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => SubcategoryList());
    case TopicDetailsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => TopicDetails(settings.arguments));
    case TournamentDetailsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => TournamentDetails(settings.arguments));
    case DailySpinRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => DailySpin());
    case StoreFragmentRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => StoreFragment());
    case PaymentMethodRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => PaymentMethod(settings.arguments));
    case OtherPaymentMethodRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => OtherPaymentMethod());
    case FriendsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => Friends());
    case GamePlayRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => GamePlay());
    case TournamentPlayRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => TournamentPlay());
    case SettingsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => UserSettings());
    case SearchTopicsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => SearchTopics());
    case ChallengesRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => Challenges());
    case SelectFriendRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => SelectFriend());
    case ChallengeFriendRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => ChallengeFriend());
    case ChallengePlayRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => ChallengePlay());
    case InviteFriendsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => InviteFriends());
    case SearchFriendsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => SearchFriends());
    case ReccentBestAllRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => RecentBestAll(settings.arguments));
    case ConfirmationRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => Confirmation(settings.arguments));
    case UploadAvatarRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => UploadAvatar());
    case PaysenzPaymentRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => PaysenzPaymentWebView(settings.arguments.toString()));
    case PaymentViaMobileOperatorRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => PaymentViaMobileOperator(settings.arguments));
    case DailyTaskDetailsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => DailyTaskDetails());
    case DailyTaskPlayRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => DailyTaskPlay());
    case BCSModelPlayRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => BCSModelPlay());
    case NcellPackagesRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => NcellPackages());
    case TournamentSubscriptionRedirectNepalRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => TournamentSubscriptionRedirectNepal(settings.arguments.toString()));
    case RedirectionWebViewRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => RedirectionWebView());
    case BkashPackLandingRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => BkashPacks());
    case BkashPurchasePackRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => BkashPurchasePack());
    case BCSPackagesRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => BCSPackageList());
    case TournamentBundlesRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => TournamentPackageList());
    case ChallengePartnerSearchRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => ChallengePartnerSearch());
    case ChallengeRoomDetailsRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => ChallengeRoomDetails(settings.arguments));
    case ChallengeRoomGameplayRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => ChallengeRoomGameplay());
    case ChallengeRoomResultRoute:
      return MaterialPageRoute(settings: settings, builder: (context) => ChallengeRoomResult());


    default:
      return MaterialPageRoute(settings: settings, builder: (context) => DummyUI());
  }
}
