import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:quiz/router.dart';
import 'package:quiz/utils/CrashLog.dart';
import 'package:quiz/values/ColorsLocal.dart';

import 'constants/ProjectConstants.dart';
import 'constants/RoutingConstants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  //SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light);

//  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
//    systemNavigationBarColor: Colors.white,
//    systemNavigationBarIconBrightness: Brightness.dark,
//  ));

  //Firebase setup ***********


  if (!kIsWeb) {
    await Firebase.initializeApp();

    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.white,
      statusBarIconBrightness: Brightness.dark,
//    systemNavigationBarColor: Colors.white,
//    systemNavigationBarIconBrightness: Brightness.dark,
    ));

    await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(true);
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;
    CrashLog.postKey("Build_Type", BUILD_TYPE);
  }

  FirebaseAnalytics analytics = FirebaseAnalytics();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]).then((_) {
    runApp(MaterialApp(
        title: "QuizGiri",
        navigatorObservers: [
          FirebaseAnalyticsObserver(analytics: analytics)
        ],
        debugShowCheckedModeBanner: false,
        navigatorKey: Get.key,
        initialRoute: SplashScreenRoute,
        onGenerateRoute: generateRoute,
        theme: ThemeData(
          //accentColor: Colors.pink[400],
          //primaryColor: Colors.pink,
          fontFamily: "Poppins",
          primarySwatch: Colors.pink,
          scaffoldBackgroundColor: ColorsLocal.scaffold_background,
          visualDensity: VisualDensity.adaptivePlatformDensity,
          appBarTheme: AppBarTheme(
              elevation: 1,
              brightness: Brightness.light,
              color: Colors.white,
              iconTheme: IconThemeData(
                color: Colors.grey[800],
              )),
        )));
  });
}
