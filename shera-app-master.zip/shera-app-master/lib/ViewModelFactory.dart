/*
* Created by Ahammed Hossain Shanto
* on 8/13/20
*/

import 'package:flutter/cupertino.dart';
import 'package:quiz/view-models/FriendsVm.dart';
import 'package:quiz/view-models/HomeFragmentVM.dart';
import 'package:quiz/view-models/LeaderBoardFragmentVM.dart';
import 'package:quiz/view-models/StoreFragmentVM.dart';
import 'package:quiz/view-models/TopicListVM.dart';
import 'package:quiz/view-models/UtilsVM.dart';

class ViewModelFactory {
  static HomeFragmentVM _homeFragmentVM;

  static HomeFragmentVM getHomeFragmentVM(BuildContext context) {
    if (_homeFragmentVM == null) {
      _homeFragmentVM = new HomeFragmentVM(context);
    }
    _homeFragmentVM.loadProfile();
    return _homeFragmentVM;
  }

  static FriendsVM _friendsVM;

  static FriendsVM getFriendsVM(BuildContext context) {
    if (_friendsVM == null) {
      _friendsVM = new FriendsVM(context);
    }
    return _friendsVM;
  }

  static LeaderBoardFragmentVM _leaderBoardFragmentVM;

  static LeaderBoardFragmentVM getLeaderBoardFragmentVM(BuildContext context) {
    if (_leaderBoardFragmentVM == null) {
      _leaderBoardFragmentVM = new LeaderBoardFragmentVM(context);
    }
    _leaderBoardFragmentVM.loadLeaderBoard(visibleLoad: false);
    return _leaderBoardFragmentVM;
  }

  static StoreFragmentVM _storeFragmentVM;

  static StoreFragmentVM getStoreFragmentVM(BuildContext context) {
    if (_storeFragmentVM == null) {
      _storeFragmentVM = new StoreFragmentVM(context);
    }
    _storeFragmentVM.loadAllPurchase(visibleLoad: false);
    return _storeFragmentVM;
  }

  static TopicsListVM _topicsListVM;

  static TopicsListVM getTopicListVM() {
    if (_topicsListVM == null) {
      _topicsListVM = new TopicsListVM();
    }
    return _topicsListVM;
  }

  static UtilsVM _utilsVM;

  static UtilsVM getUtilsVM(BuildContext context) {
    if (_utilsVM == null) {
      _utilsVM = new UtilsVM(context);
    }
    return _utilsVM;
  }
}
