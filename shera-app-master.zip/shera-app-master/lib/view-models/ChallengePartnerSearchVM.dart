/*
* ReCreated by Shafiur
* on 01/07/2021
*/

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:laravel_echo/laravel_echo.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:socket_io_client/socket_io_client.dart';

class ChallengeRoomPartnerSearchVM with ChangeNotifier {
  BuildContext context;
  var arguments;
  var roomInfo;
  var userInfo;
  bool isMatchFound = false;
  var opponentInfo;

  ChallengeRoomPartnerSearchVM(this.context, this.arguments) {
    roomInfo = arguments['room_info'];
    userInfo = arguments['user_info'];

    _connectSocket();
    joinLobby();
    updatePlayers();
  }

  _connectSocket() {
    Logger.dlog("UserInfo", userInfo['user_id'].toString());

    AppSessionSettings.socket = io(
        UrlHelper.ChallengeRoomDomain_Production,
        OptionBuilder()
            .setTransports(['websocket']) // for Flutter or Dart VM
            .disableAutoConnect() // disable auto-connection
            // .setExtraHeaders({'foo': 'bar'}) // optional
            .setQuery({'user_id': userInfo['user_id']})
            .build());
    AppSessionSettings.socket.connect();
  }

  disconnectSocket() {
    AppSessionSettings.socket
        .on('disconnect', (data) => Navigator.of(context).pop());
  }

  joinLobby() {
    AppSessionSettings.socket.on('joined_in_lobby', (data) {
      Logger.dlog("joined_in_lobby", roomInfo['id'].toString());
      AppSessionSettings.socket.emitWithAck('join_game', {'room_id': roomInfo['id']}, ack: (data) {
        Logger.dlog("join_game", data.toString());
        if (data['success'] == false) {
          AppSessionSettings.socket.dispose();
          Navigator.of(context).pop();
          return;
        }
      });
    });
  }

  updatePlayers(){
    AppSessionSettings.socket.on("update:players", (players) async {
      Logger.dlog("update_players", players.toString());

      for(int i=0; i<players.length; i++){
        if(players[i]['user_id'] != userInfo['user_id']){
          opponentInfo = players[i];
          Logger.dlog("opponent", opponentInfo.toString());
        }
      }

      isMatchFound = true;
      notifyListeners();
      var arguments = {
        "room_info": roomInfo,
        "user_info": userInfo,
        "opponent_info": opponentInfo,
      };

      Timer(Duration(seconds: 2), (){
        Navigator.pushReplacementNamed(
            context, ChallengeRoomGameplayRoute,
            arguments: json.encode(arguments));
      });

    });
  }

}
