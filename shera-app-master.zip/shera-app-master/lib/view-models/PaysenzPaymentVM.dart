/*
* Created by Ahammed Hossain Shanto
* on 10/12/20
*/

import 'package:flutter/cupertino.dart';

class PaysenzPaymentVM with ChangeNotifier {
  BuildContext context;
  bool pageLoaded = false;

  PaysenzPaymentVM(this.context);

  updateLoadStatus(bool value) {
    pageLoaded = value;
    notifyListeners();
  }
}
