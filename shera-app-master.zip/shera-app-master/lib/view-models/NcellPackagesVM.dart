/*
* Created by Ahammed Hossain Shanto
* on 12/23/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NcellPackagesVM with ChangeNotifier {
  BuildContext context;
  var arguments;
  bool packagesLoaded = false;
  List packages = new List();
  String selectedPackageId = "";
  bool isSubscribing = false;

  NcellPackagesVM(this.context, this.arguments) {
    loadNcellPackages();
  }

  loadNcellPackages() async {
    var response = await http.get(Uri.encodeFull(UrlHelper.ncellPackages()), headers: {
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped("Ncell_PackageList:" + responseBody.toString());
    packagesLoaded = true;
    if (responseBody['status'] == "success") {
      packages = responseBody['data']['packages'];
    }
    notifyListeners();
  }

  subscribePackage(String packageId) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    isSubscribing = true;
    selectedPackageId = packageId;
    notifyListeners();

    var body = json.encode({"channel": "APP", "tournament_id": arguments['tournament_id'], "package_id": packageId});

    var response = await http.post(Uri.encodeFull(UrlHelper.nepalTournamentEntry()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    isSubscribing = false;
    notifyListeners();
    if (responseBody["success"] == true) {
      //LocalAlert.showDialog(context, "Success!!", responseBody['message'].toString());

      Navigator.pushNamed(context, TournamentSubscriptionRedirectNepalRoute, arguments: responseBody['redirect_url'].toString());
    } else {
      LocalAlert.showDialog(context, "Opps!!", responseBody['message'] ?? "Something went wrong");
    }
  }
}
