/*
* Created by Ahammed Hossain Shanto
* on 8/10/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class InviteFriendsVM with ChangeNotifier {
  var invitationDetails;
  bool invitationLoaded = false;
  bool applying = false;
  String message = "";

  InviteFriendsVM() {
    loadInvitation();
  }

  loadInvitation() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    invitationLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.referralGet()), headers: {
      "Authorization": 'Bearer ${access_token}',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });

    var responseBody = json.decode(response.body);
    invitationDetails = responseBody;
    invitationLoaded = true;
    notifyListeners();
  }

  Future<bool> applyCode(String code) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    applying = true;
    notifyListeners();

    var body = json.encode({
      "invite_code": code,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.referralApply()),
        headers: {
          "Authorization": 'Bearer ${access_token}',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    applying = false;
    message = responseBody['message'].toString();
    notifyListeners();
    if (responseBody['success'] == true) {
      return true;
    } else {
      return false;
    }
  }
}
