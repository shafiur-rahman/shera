/*
* Created by Ahammed Hossain Shanto on 7/22/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserPopupVm with ChangeNotifier {
  var user;
  bool processing = false;

  UserPopupVm(this.user);

  sendRequest(user_id) async {
    processing = true;
    notifyListeners();

//    await Future.delayed(Duration(seconds: 1));
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({
      'user_id': user_id,
    });
    var response = await http.post(Uri.encodeFull(UrlHelper.sendFriendRequest()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    //Logger.printWrapped("Friends List :"+response.body);

    var responseBody = json.decode(response.body);
    notifyListeners();

    if (responseBody['success'] == true) {
      user['friendship_status'] = "requested";
    }

    processing = false;
    notifyListeners();
  }

  friendRequestAccept() async {
    processing = true;
    notifyListeners();

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({
      'user_id': user['user_id'],
    });
    var response = await http.post(Uri.encodeFull(UrlHelper.acceptFriendRequest()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    processing = false;

    if (responseBody['success'] == true) {
      user['friendship_status'] = "friend";
    }
    notifyListeners();
  }
}
