/*
* Created by Ahammed Hossain Shanto on 7/23/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/UserLoginRegistration.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginWithEmailVM with ChangeNotifier {
  BuildContext context;
  String message = "";
  bool processing = false;

  LoginWithEmailVM(this.context);

  loginWithEmail() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String fcmToken = sharedPreferences.getString(FCM_TOKEN);

    processing = true;
    notifyListeners();

    var body = json.encode({"email": UserLoginRegistration.email, "password": UserLoginRegistration.password, "fcm_token": fcmToken});

    var response = await http.post(Uri.encodeFull(UrlHelper.loginWithEmail()),
        headers: {
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);

    if (responseBody['success'] == true) {
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      sharedPreferences.setString(USER_ID, responseBody['user_id'].toString());
      sharedPreferences.setString(ACCESS_TOKEN, responseBody['access_token'].toString());

      message = "";
      notifyListeners();

      while (Navigator.canPop(context)) {
        Navigator.pop(context);
      }
      Navigator.pushReplacementNamed(context, HomeRoute);
    } else {
      message = responseBody['message'].toString();
      notifyListeners();
    }
  }

  recoverPassword() async {
    processing = true;
    notifyListeners();

    var body = json.encode({
      "email": UserLoginRegistration.email,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.recoverPassword()),
        headers: {
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    message = responseBody['message'].toString();
    processing = false;
    notifyListeners();
  }

  notify() {
    notifyListeners();
  }
}
