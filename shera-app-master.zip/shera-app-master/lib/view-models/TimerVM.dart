/*
* Created by Ahammed Hossain Shanto
* on 6/30/20
*/

import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:quiz/controllers/SoundController.dart';
import 'package:quiz/view-models/ChallengePlayVM.dart';
import 'package:quiz/view-models/DailyTaskPlayVM.dart';
import 'package:quiz/view-models/GamePlayVM.dart';
import 'package:quiz/view-models/TournamentPlayVM.dart';

import 'ChallengeRoomGameplay.dart';

class TimerVM with ChangeNotifier {
  BuildContext context;
  GamePlayVM gamePlayVM;
  TournamentPlayVM tournamentPlayVM;
  DailyTaskPlayVM dailyTaskPlayVM;
  ChallengePlayVM challengePlayVM;
  ChallengeRoomGameplayVM challengeRoomGameplayVM;
  int duration = 0; //duration in seconds
  int timeLeft = 0;
  bool autoStart = false;
  bool finished = false;
  Timer myTimer;

  TimerVM({this.duration = 30, this.autoStart = false, bool playSound = true}) {
    timeLeft = duration;
    if (autoStart) {
      startTimer(playSound: playSound);
    }
  }

  setDuration(int sec) {
    this.duration = sec;
    this.timeLeft = sec;
    notifyListeners();
  }

  setGamePlayVM(GamePlayVM gamePlayVM) {
    this.gamePlayVM = gamePlayVM;
  }

  setTournamentPlayVM(TournamentPlayVM tournamentPlayVM) {
    this.tournamentPlayVM = tournamentPlayVM;
  }

  setDailyTaskPlayVM(DailyTaskPlayVM dailyTaskPlayVM) {
    this.dailyTaskPlayVM = dailyTaskPlayVM;
  }

  setChallengePlayVM(ChallengePlayVM challengePlayVM) {
    this.challengePlayVM = challengePlayVM;
  }
  setChallengeRoomGameplayVM(ChallengeRoomGameplayVM challengeRoomGameplayVM) {
    this.challengeRoomGameplayVM = challengeRoomGameplayVM;
  }


  setContext(BuildContext context) {
    this.context = context;
  }

  Future<bool> startTimer({bool playSound = true}) async {
    if (playSound) {
      SoundController.playTimer();
    }
    try {
      timeLeft = duration;
      finished = false;
      myTimer?.cancel();
      myTimer = new Timer.periodic(Duration(seconds: 1), (t) {
        if (timeLeft < 1) {
          finished = true;
          SoundController.pauseTimer();
          myTimer.cancel();
          notifyListeners();
          gamePlayVM?.setTimeUp();
          tournamentPlayVM?.setTimeUp();
          challengePlayVM?.setTimeUp();
          challengeRoomGameplayVM?.setTimeUp();
        } else {
          timeLeft--;
          notifyListeners();
        }
      });
    } catch (_) {
      myTimer?.cancel();
    }
  }

  stopTimer() async {
    SoundController.pauseTimer();
    await myTimer?.cancel();
    timeLeft = 0;
    notifyListeners();
  }

  pause() {
    SoundController.pauseTimer();
    myTimer?.cancel();
    notifyListeners();
  }

  double getTimerProgress() {
    return timeLeft / duration;
  }
}
