/*
* Created by Ahammed Hossain Shanto
* on 12/22/20
* * ReCreated by Shafiur
* on 01/07/2021
*/


import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:laravel_echo/laravel_echo.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/controllers/SoundController.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/view-models/TimerVM.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class ChallengeRoomGameplayVM with ChangeNotifier {
  BuildContext context;
  var arguments;
  var roomInfo;
  var userInfo;
  var opponentInfo;
  bool isTimeUp = false;
  int selectedOptionId ;
  bool submitting = false;
  bool submitted = false;
  var challengeRoomId;
  var waitingFor;
  TimerVM timerVM;

  //TODO: Shorol
  var question;
  var answerGiven = false;
  int selectedOption;
  int questionId;
  int answerId;
  var isCorrect = -1;
  var isOpponentLastAnswerCorrect = -1;

  int userTotalCorrect = 0;
  int userTotalAnswered = 0;
  int opponentTotalCorrect = 0;
  int opponentTotalAnswered = 0;


  ChallengeRoomGameplayVM(this.context, this.arguments, this.timerVM) {
    roomInfo = arguments['room_info'];
    userInfo = arguments['user_info'];
    opponentInfo = arguments['opponent_info'];

    _gamePlayStart();
  }

  _gamePlayStart(){
     _onQuestionSend();
     _onUpdateScore();
     _onUpdateFinish();
  }

  _onQuestionSend() {
    AppSessionSettings.socket.on("question", (data) {
      Logger.dlog("questionSend", data.toString());
      question = data['question'];
      questionId = question['id'];
      timerVM.setDuration(question['time']);
      timerVM.startTimer(playSound: false);
      isCorrect = -1;
      isOpponentLastAnswerCorrect = -1;
      answerGiven = false;
      submitted = false;
      notifyListeners();
    });

  }

  _onUpdateScore() {
    AppSessionSettings.socket.on("update:score", (data) {
      Logger.dlog("updateScore", data.toString());

      if( userInfo['user_id'] == data['participant_id']){
        userTotalCorrect = data['total_correct'];
        userTotalAnswered = data['total_answered'];
        notifyListeners();
      }

      if( opponentInfo['user_id'] == data['participant_id']){
        opponentTotalCorrect = data['total_correct'];
        opponentTotalAnswered = data['total_answered'];
         if(data['is_last_answer_correct']) {
          isOpponentLastAnswerCorrect = 1;
          notifyListeners();
          SoundController.correctPlay();
        }
         else{
          isOpponentLastAnswerCorrect = 0;
          notifyListeners();
          SoundController.wrongPLay();
        }
      }
    });
  }

  _onUpdateFinish() {
    AppSessionSettings.socket.on("update:finish", (result) {
      Logger.dlog("finish", result.toString());
          var arguments = {
          "room_info": roomInfo,
          "user_info": userInfo,
          "opponent_info": opponentInfo,
          "result_info": result
        };

      AppSessionSettings.socket.dispose();
        Navigator.pushReplacementNamed(context, ChallengeRoomResultRoute,
            arguments: json.encode(arguments));

    });
  }

  selectOption(int optionId) {
    selectedOptionId = optionId;
    submitting = true;
    submitted = true;
    notifyListeners();

    AppSessionSettings.socket.emitWithAck( "answer", { 'question_id' : questionId, 'answer_id' : selectedOptionId }, ack: (data) {
      Logger.dlog("correct", data.toString());
      if(data['is_correct']){
        answerGiven = true;
        isCorrect = 1;
        notifyListeners();
        SoundController.correctPlay();
      }
      else{
        answerGiven = true;
        isCorrect = 0;
        notifyListeners();
        SoundController.wrongPLay();
      }

      submitting = false;
      notifyListeners();
    });
  }

  setTimeUp() {
    //TODO after question timeout occurs ***
    isTimeUp = true;
    notifyListeners();
  }
}
