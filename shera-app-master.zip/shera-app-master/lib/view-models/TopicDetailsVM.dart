/*
* Created by Ahammed Hossain Shanto on 7/8/20
*/

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TopicDetailsVM with ChangeNotifier {
  var topicDetails;
  bool detailsLoaded = false;
  int topicId;
  bool starting = false;

  TopicDetailsVM(this.topicId) {
    loadDetails();
  }

  loadDetails() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    detailsLoaded = false;
    notifyListeners();

    var body = json.encode({'topic_id': topicId});

    var response = await http.post(Uri.encodeFull(UrlHelper.topicDetails()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    // Logger.printWrapped("Topic Details"+responseBody);
    //  Logger.printWrapped(responseBody.toString());
    topicDetails = responseBody;
    topicDetails['updating'] = false;
    detailsLoaded = true;
    notifyListeners();
  }

  toggleFavourite() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    int topicId = topicDetails['topic']['id'];

    topicDetails['updating'] = true;
    notifyListeners();

    var body = json.encode({
      'topic_id': topicId,
      'follow': !topicDetails['following'],
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.followUnfollowTopic()),
        headers: {
          "Authorization": 'Bearer ${access_token}',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);

    if (responseBody != null && responseBody['success'] == true) {
      topicDetails['updating'] = false;
      topicDetails['following'] = responseBody['following'];
      loadDetails();
      notifyListeners();
    } else {
      topicDetails['updating'] = false;
      notifyListeners();
    }
  }

  Future<dynamic> startGame(String type, String categoryName) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    int topicId = topicDetails['topic']['id'];

    starting = true;
    notifyListeners();

    var body = json.encode({
      'topic_id': topicId,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.startGame()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    if (UrlHelper.isSuccessful(response)) {
      var responseBody = json.decode(response.body);

      responseBody['appbar_type'] = type;
      responseBody['appbar_name'] = categoryName;
      sharedPreferences.setString(GAME_ID, responseBody['game_id'].toString());
      sharedPreferences.setString(GAME_TYPE, responseBody['game_type'].toString());
      //Logger.printWrapped(responseBody.toString());
      starting = false;
      notifyListeners();
      return responseBody;
    } else {
      starting = false;
      notifyListeners();
      return null;
    }
  }
}
