/*
* Created by Ahammed Hossain Shanto on 8/6/20
*/
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/ChallengeInfo.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SelectFriendVM with ChangeNotifier {
  List friends = new List();
  bool friendsLoaded = false;

  SelectFriendVM() {
    ChallengeInfo.friendUserId = -1;
    loadFriends();
  }

  isSelected(int index) {
    return friends[index]['user_id'] == ChallengeInfo.friendUserId;
  }

  selectFriend(int index) {
    ChallengeInfo.friendUserId = friends[index]['user_id'];
    notifyListeners();
  }

  loadFriends() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    friendsLoaded = false;
    notifyListeners();

    var body = json.encode({"type": "friends"});

    var response = await http.post(Uri.encodeFull(UrlHelper.friendList()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    if (response != null) {
      var responseBody = json.decode(response.body);
      friends = responseBody['friend_list'];
    }

    friendsLoaded = true;
    notifyListeners();
  }
}
