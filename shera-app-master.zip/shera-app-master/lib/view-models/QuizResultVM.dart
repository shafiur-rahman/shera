import 'package:flutter/cupertino.dart';

class QuizResultVM with ChangeNotifier {
  BuildContext context;

  QuizResultVM(this.context);

  bool friendRequestSend = false;

  onRequestSend() {
    friendRequestSend = true;
    notifyListeners();
  }
}
