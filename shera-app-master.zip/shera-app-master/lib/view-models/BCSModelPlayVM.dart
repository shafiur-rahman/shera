/*
* Created by Ahammed Hossain Shanto
* on 12/2/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/view-components/Pop_Ups/BCSModelResult.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BCSModelPlayVM with ChangeNotifier {
  BuildContext context;
  var arguments;
  final ItemScrollController itemScrollController = ItemScrollController();
  final ItemPositionsListener itemPositionsListener = ItemPositionsListener.create();
  List questions = new List();
  List<String> answers = new List();
  bool isSubmitting = false;
  bool isSubmitted = false;

  BCSModelPlayVM(this.context, this.arguments) {
    questions = new List();
    answers = new List();
    questions = arguments['details']['questions'];
    for (int i = 0; i < questions.length; i++) {
      answers.add("-1");
    }
  }

  void updateSelection(int index, String optionId) {
    if (!isSubmitting && answers[index] == "-1") {
      answers[index] = optionId;
      itemScrollController.scrollTo(index: index, duration: Duration(milliseconds: 500));
      notifyListeners();
    }
  }

  submitAnswers() async {
    if (!isSubmitting && !isSubmitted) {
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      String access_token = sharedPreferences.getString(ACCESS_TOKEN);

      isSubmitting = true;
      notifyListeners();

      var body = json.encode({"game_id": arguments['details']['game_id'], "submission": getAnswerListForSubmission()});

      var response = await http.post(Uri.encodeFull(UrlHelper.bcsModelPlaySubmit()),
          headers: {
            "Authorization": 'Bearer $access_token',
            "Content-type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "x-api-key": API_KEY,
          },
          body: body);
      var responseBody = json.decode(response.body);
      if (responseBody['success'] != null && responseBody['success']) {
        isSubmitted = true;
        responseBody['result']['title'] = arguments['model']['title'].toString();
        BCSModelResult.showDialog(context, responseBody['result'], onTap: () {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
        });
      } else {
        LocalAlert.showDialog(context, "Opps!!!", "Something went wrong");
      }
      Logger.printWrapped(responseBody.toString());
      isSubmitting = false;

      notifyListeners();
    }
  }

  List getAnswerListForSubmission() {
    List answersForBody = new List();

    for (int i = 0; i < answers.length; i++) {
      answersForBody.add({"question_id": questions[i]['question_id'], "option_id": answers[i]});
    }

    return answersForBody;
  }

  int getAnswerCount() {
    int count = 0;
    for (int i = 0; i < answers.length; i++) {
      if (answers[i] != "-1") {
        count++;
      }
    }
    return count;
  }
}
