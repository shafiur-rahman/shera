/*
* Created by Ahammed Hossain Shanto on 8/6/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChallengesVM with ChangeNotifier {
  List challenges = new List();
  bool listLoaded = false;
  BuildContext context;

  ChallengesVM(this.context) {
    loadChallenges();
  }

  loadChallenges() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    listLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.challengeList()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    if (responseBody['challenges'] != null) {
      challenges = responseBody['challenges'];
    }
    listLoaded = true;
    notifyListeners();
  }

  getCaption(int index) {
    String caption = "";
    if (challenges[index]['challenger'] == "self") {
      if (challenges[index]['status'].toString() == "pending") {
        caption = '${LocaleKey.CHALLENGE.toLocaleText()} ${LocaleKey.PENDING.toLocaleText()}';
      }
      if (challenges[index]['status'].toString() == "accepted") {
        caption = '${LocaleKey.CHALLENGE.toLocaleText()} ${LocaleKey.ACCEPTED.toLocaleText()}';
      }
      if (challenges[index]['status'].toString() == "denied") {
        caption = '${LocaleKey.CHALLENGE.toLocaleText()} ${LocaleKey.REJECTED.toLocaleText()}';
      }
      if (challenges[index]['status'].toString() == "completed") {
        caption = '${LocaleKey.CHALLENGE.toLocaleText()} ${LocaleKey.COMPLETED.toLocaleText()}';
      }
      if (challenges[index]['status'].toString() == "played") {
        if (challenges[index]['opponent_played'] == true) {
          caption = '${LocaleKey.OPPONENT_PLAYED.toLocaleText()}';
        } else {
          caption = '${LocaleKey.OPPONENT_NOT_PLAYED.toLocaleText()}';
        }
      }
    } else {
      if (challenges[index]['status'].toString() == "pending") {
        caption = '${LocaleKey.CHALLENGE.toLocaleText()} ${LocaleKey.PENDING.toLocaleText()}';
      }
      if (challenges[index]['status'].toString() == "accepted") {
        caption = '${LocaleKey.CHALLENGE.toLocaleText()} ${LocaleKey.ACCEPTED.toLocaleText()}';
      }
      if (challenges[index]['status'].toString() == "denied") {
        caption = '${LocaleKey.CHALLENGE.toLocaleText()} ${LocaleKey.REJECTED.toLocaleText()}';
      }
      if (challenges[index]['status'].toString() == "completed") {
        caption = '${LocaleKey.CHALLENGE.toLocaleText()} ${LocaleKey.COMPLETED.toLocaleText()}';
      }
      if (challenges[index]['status'].toString() == "played") {
        if (challenges[index]['opponent_played'] == true) {
          caption = '${LocaleKey.OPPONENT_PLAYED.toLocaleText()}';
        } else {
          caption = '${LocaleKey.OPPONENT_NOT_PLAYED.toLocaleText()}';
        }
      }
    }

    return caption;
  }

  acceptChallenge(int index) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    challenges[index]['process_status'] = "accepting";
    notifyListeners();

    var body = json.encode({
      "challenge_id": challenges[index]['challenge_id'],
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.challengeAccept()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    if (responseBody['success'] == true) {
      challenges[index]['status'] = "accepted";
    }
    challenges[index]['process_status'] = "none";
    notifyListeners();
  }

  denyChallenge(int index) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    challenges[index]['process_status'] = "denying";
    notifyListeners();

    var body = json.encode({
      "challenge_id": challenges[index]['challenge_id'],
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.challengeDeny()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    if (responseBody['success'] == true) {
      challenges[index]['status'] = "denied";
    }
    challenges[index]['process_status'] = "none";
    notifyListeners();
  }

  Future<dynamic> startChallenge(int index) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    challenges[index]['process_status'] = "starting";
    notifyListeners();

    var body = json.encode({
      'challenge_id': challenges[index]['challenge_id'],
    });
    Logger.dlog("Start Challenge: ", Uri.encodeFull(UrlHelper.challengeStart()).toString());
    var response = await http.post(Uri.encodeFull(UrlHelper.challengeStart()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    Logger.dlog("Start Challenge: ",responseBody.toString());

    if (UrlHelper.isSuccessful(response)) {
      var responseBody = json.decode(response.body);
      responseBody['appbar_type'] = "Challenge";
      responseBody['appbar_name'] = challenges[index]['topic_name'].toString();
      sharedPreferences.setString(GAME_ID, responseBody['game_id'].toString());
      sharedPreferences.setString(GAME_TYPE, responseBody['game_type'].toString());
      //Logger.printWrapped(responseBody.toString());
      challenges[index]['process_status'] = "none";
      notifyListeners();
      return responseBody;
    } else {
      challenges[index]['process_status'] = "none";
      notifyListeners();
      return null;
    }
  }
}
