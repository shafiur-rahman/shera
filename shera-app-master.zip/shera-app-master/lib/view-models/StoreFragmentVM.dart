import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/BCSPackage.dart';
import 'package:quiz/models/TournamentPackage.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StoreFragmentVM with ChangeNotifier {
  BuildContext context;

  bool allBundlesLoaded = false;

  var wallet;
  List top_deals;
  List popular_product;
  var userDetails;
  bool profileLoaded = false;

  StoreFragmentVM(this.context) {
    loadAllPurchase();
    loadProfile();
    loadTournamentPacks();
    loadBcsPacks();
  }

  loadAllPurchase({bool visibleLoad = true}) async {
    if (visibleLoad) {
      allBundlesLoaded = false;
      notifyListeners();
    }

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    var response = await http.get(
      Uri.encodeFull(UrlHelper.allBundle()),
      headers: {
        "Authorization": 'Bearer $access_token',
        "Content-type": "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "x-api-key": API_KEY,
      },
    );
    //Logger.printWrapped("Friends List :"+response.body);

    var responseBody = json.decode(response.body);

    wallet = responseBody['wallet'];
    top_deals = responseBody['top_deals'];
    popular_product = responseBody['popular_products'];

    allBundlesLoaded = true;
    notifyListeners();
  }

  loadProfile() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

//    profileLoaded = false;
//    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.profile()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    userDetails = responseBody;
    profileLoaded = true;
    notifyListeners();
  }

  bool bcsPacksLoaded = false;
  List<BCSPackage> bcsPackages = [];


  loadBcsPacks() async {

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String accessToken = sharedPreferences.getString(ACCESS_TOKEN);

    bcsPacksLoaded = false;
    notifyListeners();

    var response = await http.get(UrlHelper.bcsPacks(), headers: {
      "Authorization": 'Bearer $accessToken',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    BCSPackage.packageTitle = responseBody['name'].toString();
    setBcsPackList(responseBody['packages']);
    bcsPacksLoaded = true;
    notifyListeners();
  }

  setBcsPackList(List<dynamic> values) {
    bcsPackages.clear();
    values.forEach((element) {
      bcsPackages.add(BCSPackage.fromJson(element));
    });
  }

  bool tournamentPacksLoaded = false;
  List<TournamentPackage> tournamentPackages = [];
  bool canceling = false;
  String cancelId = "";


  loadTournamentPacks() async {

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String accessToken = sharedPreferences.getString(ACCESS_TOKEN);

    tournamentPacksLoaded = false;
    notifyListeners();

    var response = await http.get(UrlHelper.tournamentPacks(), headers: {
      "Authorization": 'Bearer $accessToken',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    TournamentPackage.packageTitle = responseBody['name'].toString();
    setTournamentPackList(responseBody['packages']);
    tournamentPacksLoaded = true;
    notifyListeners();
  }

  Future<bool> cancelSubscription(String bundleId) async {

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String accessToken = sharedPreferences.getString(ACCESS_TOKEN);

    canceling = true;
    cancelId = bundleId;
    notifyListeners();

    var body = json.encode({
      'bundle_id': bundleId
    });

    var response = await http.post(UrlHelper.cancelBundleSubscriptionGhoori(), headers: {
      "Authorization": 'Bearer $accessToken',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    }, body: body);

    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    canceling = false;
    cancelId = "";
    notifyListeners();
    if(responseBody['success'] == true) {
      return true;
    }
    return false;
  }

  setTournamentPackList(List<dynamic> values) {
    tournamentPackages.clear();
    values.forEach((element) {
      tournamentPackages.add(TournamentPackage.fromJson(element));
    });
  }
}
