/*
* Created by Ahammed Hossain Shanto
* on 11/25/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DailyTaskDetailsVM with ChangeNotifier {
  BuildContext context;

  bool detailsLoaded = false;
  var details;
  bool starting = false;

  DailyTaskDetailsVM(this.context) {
    loadDetails();
  }

  loadDetails() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    detailsLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.weeklyTaskDetails()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    //Logger.printWrapped("Details"+response.body);
    details = responseBody;
    detailsLoaded = true;
    notifyListeners();
  }

  Future<dynamic> startGame() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    starting = true;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.startDailyTask()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });

    if (UrlHelper.isSuccessful(response)) {
      var responseBody = json.decode(response.body);

      responseBody['appbar_type'] = LocaleKey.WEEKLY_TASK.toLocaleText();
      responseBody['appbar_name'] = '${LocaleKey.DAY.toLocaleText()} ${details['day_running'].toString().toLocaleNumber()}';
      // sharedPreferences.setString(GAME_ID, responseBody['game_id'].toString());
      // sharedPreferences.setString(
      //     GAME_TYPE, responseBody['game_type'].toString());
      Logger.printWrapped(responseBody.toString());
      starting = false;
      notifyListeners();
      return responseBody;
    } else {
      starting = false;
      notifyListeners();
      return null;
    }
  }
}
