/*
* Created by Shafiur
* on 2/2/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

class FriendsVM with ChangeNotifier {
  BuildContext context;
  bool friend = true;
  bool request = false;
  bool sent_request = false;

  String type = "friends";

  bool leaderBoardListLoaded = false;
  List leaderboard = new List();
  List top_list = new List();

  var pending;

  loadLeaderBoard() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    leaderBoardListLoaded = false;
    notifyListeners();

//    //TODO remove the line below after connecting API
//    await Future.delayed(Duration(seconds: 1));
    //  var response = MockResponse.getLeaderBoardHistory(json.encode({'type': this.type}));

    var body = json.encode({
      'type': this.type,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.getFriendList()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    //Logger.printWrapped("Friends List :"+response.body);

    var responseBody = json.decode(response.body);
    pending = responseBody['pending'];
    leaderboard = responseBody['friend_list'];
    top_list = responseBody['Top_list'];
    leaderBoardListLoaded = true;
    notifyListeners();
  }

  friendRequestAccept(user_id) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({
      'user_id': user_id,
    });
    var response = await http.post(Uri.encodeFull(UrlHelper.acceptFriendRequest()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    //Logger.printWrapped("Friend accept :"+response.body);

    if (UrlHelper.isSuccessful(response)) {
      var reponseBody = jsonDecode(response.body);
      if (reponseBody["success"] == true) {
        loadLeaderBoard();
        notifyListeners();
        Toast.show("Request accepted", context);
      }
    } else {
      Toast.show("Request accepted failed", context);
      notifyListeners();
    }
  }

  friendRequestDeny(user_id) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({
      'user_id': user_id,
    });
    var response = await http.post(Uri.encodeFull(UrlHelper.denyFriendRequest()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    //Logger.printWrapped("Friends List :"+response.body);
    if (UrlHelper.isSuccessful(response) == true) {
      loadLeaderBoard();
      notifyListeners();
      Toast.show("Request denied", context);
    } else {
      Toast.show("Request denied failed", context);
      notifyListeners();
    }
  }

  unFriend(user_id) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({
      'user_id': user_id,
    });
    var response = await http.post(Uri.encodeFull(UrlHelper.unFriend()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    if (UrlHelper.isSuccessful(response) == true) {
      loadLeaderBoard();
      notifyListeners();
      Toast.show("Unfriend successfully", context);
    } else {
      Toast.show("Unfriend failed", context);
      notifyListeners();
    }

//    Logger.printWrapped("Unfriend :"+response.body);
//    notifyListeners();
  }

  outgoingRequestDelete(user_id) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({
      'user_id': user_id,
    });
    var response = await http.post(Uri.encodeFull(UrlHelper.outgoingRequestDelete()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    if (UrlHelper.isSuccessful(response) == true) {
      loadLeaderBoard();
      notifyListeners();
      Toast.show("Outgoing request delete successfully", context);
    } else {
      Toast.show("Outgoing request delete failed", context);
      notifyListeners();
    }

//    Logger.printWrapped("Unfriend :"+response.body);
//    notifyListeners();
  }

  FriendsVM(this.context) {
    loadLeaderBoard();
  }

  onSelect(bool value1, value2, value3) {
    this.friend = value1;
    this.request = value2;
    this.sent_request = value3;

    if (this.friend == true) {
      this.type = "friends";
    } else if (this.request == true) {
      this.type = "incoming_requests";
    } else if (this.sent_request == true) {
      this.type = "outgoing_requests";
    }
    loadLeaderBoard();
    notifyListeners();
  }
}
