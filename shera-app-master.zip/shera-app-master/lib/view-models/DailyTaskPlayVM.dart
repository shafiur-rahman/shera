/*
* Created by Ahammed Hossain Shanto on 7/13/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/controllers/SoundController.dart';
import 'package:quiz/helpers/banner-ad-loader.dart';
import 'package:quiz/helpers/interstitial-ad_loader.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

import 'TimerVM.dart';

class DailyTaskPlayVM with ChangeNotifier {
  BuildContext context;
  bool popupWorking = false;
  bool adWatchDone = false;
  var wallet;
  var question;
  var otherDetails;
  bool isTimeUp = false;
  bool ll50Working = false;
  bool getAnswerWorking = false;
  bool ll50Used = false;
  bool getAnswerUsed = false;
  int selectedIndex = -1;
  bool isSubmitted = false;
  bool isSubmitting = false;
  bool questionFinished = false;
  bool showOptions = false;
  TimerVM timerVM;
  var submitResponse;
  bool mediaPlayed = false;
  Duration mediaDuration;
  Duration mediaPosition;
  bool isCorrect = false;

  /// interstitial ad variables & methods *****
  InterstitialAdLoader _interstitialAdLoader;
  bool isAdReady = false;
  showInterstitial() {
    if(isAdReady) {
      _interstitialAdLoader.showAd();
    }
  }


  DailyTaskPlayVM(this.context, this.timerVM) {
    init();
    initBannerAds();
  }

  List<BannerAdLoader> bannerAds = [];

  initBannerAds() {
    // bannerAds.clear();
    // bannerAds.add(new BannerAdLoader(AdSize.banner));
  }

  init() {
    ///initializing interstitial ad ******
    _interstitialAdLoader = new InterstitialAdLoader(
        onAdLoaded: (ial) {
          isAdReady = true;
        },
        onAdOpened: (ial) {
          isAdReady = false;
        }
    );
    _interstitialAdLoader.init();
  }
  setMediaStatus(bool value) {
    this.mediaPlayed = value;
    notifyListeners();
  }

  setTimeUp() {
    if (ModalRoute.of(context).settings.name == DailyTaskPlayRoute) {
      isTimeUp = true;
      submitTimeUp();
      notifyListeners();
      //Logger.printWrapped("Time Up");
    }
  }

  submitAnswer(int index) async {
    if (!isSubmitting && !isTimeUp && !isSubmitted) {
      selectedIndex = index;
      isSubmitted = false;

      isSubmitting = true;
      notifyListeners();

      List options = question['options'];

      SharedPreferences preferences = await SharedPreferences.getInstance();
      String access_token = preferences.getString(ACCESS_TOKEN);
      int questionId = question['question_id'];
      int answerId = options[selectedIndex]['id'];
      int remainingTime = timerVM.timeLeft;

      var body = json.encode({'game_id': otherDetails['game_id'], 'question_id': questionId, 'answer_id': answerId, 'remaining_time': remainingTime});

      var response = await http.post(Uri.encodeFull(UrlHelper.submitAnswerOfDailyTask()),
          headers: {
            "Authorization": 'Bearer $access_token',
            "Content-type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "x-api-key": API_KEY,
          },
          body: body);

      var responseBody = json.decode(response.body);

      //Logger.printWrapped(responseBody.toString());

      isSubmitting = false;
      isSubmitted = true;
      submitResponse = responseBody;
      if (submitResponse['wallet'] != null) {
        wallet = submitResponse['wallet'];
      }
      questionFinished = responseBody['question_finished'];
      isCorrect = responseBody['is_correct'];
      if (isCorrect) {
        await SoundController.correctPlay();
      } else {
        await SoundController.wrongPLay();
      }
      if (questionFinished != null && questionFinished) {
        timerVM.stopTimer();
      }
      notifyListeners();
    }
  }

  setMediaDuration(Duration duration) {
    this.mediaDuration = duration;
    notifyListeners();
  }

  setMediaPosition(Duration duration) {
    if (mediaDuration != null && duration <= mediaDuration) {
      this.mediaPosition = duration;
      notifyListeners();
    }
  }

  submitTimeUp() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    int questionId = question['question_id'];

    var body = json.encode({'game_id': otherDetails['game_id'], 'question_id': questionId, 'remaining_time': 0});

    var response = await http.post(Uri.encodeFull(UrlHelper.submitAnswerOfDailyTask()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    submitResponse = responseBody;
    questionFinished = responseBody['question_finished'];
    notifyListeners();
  }

  setShowOptions(bool value) {
    this.showOptions = value;
    notifyListeners();
  }

  Future<bool> retryWithCoins() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    popupWorking = true;
    notifyListeners();

    int questionId = question['question_id'];

    var body = json.encode({
      'game_id': otherDetails['game_id'],
      'question_id': questionId,
      'using': 'coins',
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.tryAgainDailyTask()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);

    popupWorking = false;
    //Logger.printWrapped(responseBody.toString());
    if (responseBody['success'] == true) {
      int remainingCoins = wallet['coins'] - int.parse(otherDetails['retry_coin_amount'].toString());
      wallet['coins'] = remainingCoins;
      if (responseBody['retry_coin_amount'] != null) {
        otherDetails['retry_coin_amount'] = responseBody['retry_coin_amount'];
      }
      notifyListeners();
      return true;
    } else {
      Toast.show(responseBody['message'].toString(), context);
      notifyListeners();
      return false;
    }
  }

  Future<bool> retryWithAd() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    popupWorking = true;
    notifyListeners();

    int questionId = question['question_id'];

    var body = json.encode({
      'game_id': otherDetails['game_id'],
      'question_id': questionId,
      'using': 'ad',
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.tryAgainDailyTask()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);

    popupWorking = false;
    adWatchDone = false;
    notifyListeners();
    //Logger.printWrapped(responseBody.toString());
    if (responseBody['success'] == true) {
      return true;
    } else {
      Toast.show(responseBody['message'].toString(), context);
      return false;
    }
  }

  tryAgain() {
    selectedIndex = -1;
    isCorrect = false;
    isSubmitted = false;
    isSubmitting = false;
    questionFinished = false;
    submitResponse = null;
    if (question['type'] == "text" || question['type'] == "image") {
      showOptions = true;
    } else {
      showOptions = false;
    }
    mediaPlayed = false;
    mediaDuration = null;
    mediaPosition = null;
    notifyListeners();
  }

  nextQuiz() {
    //otherDetails = submitResponse;
    question = submitResponse['question'];
    isTimeUp = false;
    selectedIndex = -1;
    isSubmitted = false;
    isSubmitting = false;
    questionFinished = false;
    //submitResponse = null;
    ll50Used = false;
    getAnswerUsed = false;
    ll50Working = false;
    getAnswerWorking = false;
    if (question['type'] == "text" || question['type'] == "image") {
      showOptions = true;
    } else {
      showOptions = false;
    }
    mediaPlayed = false;
    mediaDuration = null;
    mediaPosition = null;
    initBannerAds();
    notifyListeners();
  }

  notify() {
    notifyListeners();
  }
}
