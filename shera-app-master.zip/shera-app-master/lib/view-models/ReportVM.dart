import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

class ReportVM with ChangeNotifier {
  BuildContext context;

  ReportVM(this.context);

  String msg = "";
  bool reportedSubmitted = false;

  bool reportSend = false;
  var optionsIndex;

  List options = [LocaleKey.WRONG_QUESTION.toLocaleText(), LocaleKey.WRONG_ANSWER.toLocaleText(), LocaleKey.OTHERS.toLocaleText()];

  isSelected(int index) {
    optionsIndex = index;
    notifyListeners();
  }

  bool toggoleReport(int index) {
    if (optionsIndex == index) {
      return true;
    } else {
      return false;
    }
  }

  onReportSubmit(question_id, type) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({'question_id': question_id, "type": type});
    var response = await http.post(Uri.encodeFull(UrlHelper.reportQuestion()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    Logger.dlog("GG", responseBody.toString());
    if (responseBody["success"] == true) {
      reportedSubmitted = true;
      notifyListeners();
      msg = responseBody["message"];
      Toast.show(msg, context);
    } else {
      msg = responseBody["message"];
      Toast.show(msg, context);
    }

    notifyListeners();
    reportSend = true;
    notifyListeners();
  }
}
