/*
* Created by Ahammed Hossain Shanto on 7/7/20
*/

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SubcategoryListVM with ChangeNotifier {
  bool subcategoriesLoaded = false;
  List subcategories = new List();

  SubcategoryListVM();

  loadSubcategories(String id) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    subcategoriesLoaded = false;
    notifyListeners();

    var body = json.encode({
      'category_id': id,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.subcategories()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    subcategories = responseBody['category_list'];
    subcategoriesLoaded = true;
    notifyListeners();
  }

  toggleFavourite(int index) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    int categoryId = subcategories[index]['id'];

    subcategories[index]['updating'] = true;
    notifyListeners();

    var body = json.encode({
      'category_id': categoryId,
    });

    String url = UrlHelper.addFavouriteCategory();
    if (subcategories[index]['following']) {
      url = UrlHelper.removeFavouriteCategory();
    }

    var response = await http.post(Uri.encodeFull(url),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    if (responseBody != null && responseBody['success'] == true) {
      subcategories[index]['updating'] = false;
      subcategories[index]['following'] = !subcategories[index]['following'];
      notifyListeners();
    } else {
      subcategories[index]['updating'] = false;
      notifyListeners();
    }
  }
}
