import 'package:flutter/cupertino.dart';

class ChallengeResultVM with ChangeNotifier {
  BuildContext context;

  ChallengeResultVM(this.context);
}
