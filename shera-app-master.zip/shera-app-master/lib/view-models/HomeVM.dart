/*
* Created by Ahammed Hossain Shanto
* on 7/1/20
*/

import 'dart:convert';
import 'dart:io';

import 'package:badges/badges.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/controllers/SoundController.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/fragments/Friends.dart';
import 'package:quiz/fragments/HomeFragment.dart';
import 'package:quiz/fragments/LeaderBoardFragment.dart';
import 'package:quiz/fragments/StoreFragment.dart';
import 'package:quiz/fragments/StoreFragmentEmpty.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/views/CategoryList.dart';
import 'package:quiz/views/DummyUI.dart';
import 'package:quiz/views/TopicList.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'UtilsVM.dart';

class HomeVM with ChangeNotifier {
  BuildContext context;
  int navbarIndex = 2;

  HomeFragment homeFragment;
  DummyUI dummyUI;
  TopicList topicList;
  CategoryList categoryList;
  LeaderBoardFragment leaderBoardFragment;
  StoreFragment storeFragment;
  Friends friendsFragment;
  double itemWidth = 0;

  HomeVM(this.context, var arguments) {
    // itemWidth = MediaQuery.of(context).size.width.toCustomWidth() / 5.0;
    itemWidth = MediaQuery.of(context).size.width.toCustomWidth() / 5.0;
    if (arguments != null) {
      try {
        navbarIndex = int.parse(arguments['target_index'].toString());
      }
      catch (_) {
        //
      }
    }
    _checkDynamicLinkLanding();
    SoundController.init();
  }

  List<Widget> getNavbarItems(UtilsVM utilsVM) {
    return [
      InkWell(
        child: Container(
          width: itemWidth,
          padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(
                Icons.home,
                color: navbarIndex == 0 ? ColorsLocal.button_color_pink : Colors.grey[400],
                size: 24,
              ),
              Container(
                margin: EdgeInsets.only(top: 4),
                child: Text(
                  'হোম',
                  style: TextStyle(fontFamily: "Poppins", fontSize: 8, color: navbarIndex == 0 ? ColorsLocal.button_color_pink : Colors.grey[400], fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                ),
              )
            ],
          ),
        ),
        onTap: () {
          if (navbarIndex != 0) {
            navbarIndex = 0;
            notifyListeners();
          }
        },
      ),
      InkWell(
        child: Container(
          width: itemWidth,
          padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(
                Icons.shopping_bag,
                color: navbarIndex == 1 ? ColorsLocal.button_color_pink : Colors.grey[400],
                size: 24,
              ),
              Container(
                margin: EdgeInsets.only(top: 4),
                child: Text(
                  'স্টোর',
                  style: TextStyle(fontFamily: "Poppins", fontSize: 8, color: navbarIndex == 1 ? ColorsLocal.button_color_pink : Colors.grey[400], fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                ),
              )
            ],
          ),
        ),
        onTap: () {
          if (navbarIndex != 1) {
            navbarIndex = 1;
            notifyListeners();
          }
        },
      ),
      Container(
        width: itemWidth,
      ),
      InkWell(
        child: Container(
          width: itemWidth,
          padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(
                Icons.track_changes,
                color: navbarIndex == 3 ? ColorsLocal.button_color_pink : Colors.grey[400],
                size: 24,
              ),
              Container(
                margin: EdgeInsets.only(top: 4),
                child: Text(
                  'চ্যালেঞ্জ',
                  style: TextStyle(fontFamily: "Poppins", fontSize: 8, color: navbarIndex == 3 ? ColorsLocal.button_color_pink : Colors.grey[400], fontWeight: FontWeight.w500),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                ),
              )
            ],
          ),
        ),
        onTap: () {
          if (navbarIndex != 3) {
            navbarIndex = 3;
            notifyListeners();
          }
        },
      ),
      Badge(
        badgeColor: Colors.white,
        showBadge: utilsVM.noti != null && utilsVM.noti['request'] != null && utilsVM.noti['request'],
        padding: EdgeInsets.all(0),
        position: BadgePosition(top: 10, end: 5),
        elevation: 1,
        badgeContent: Container(
          margin: EdgeInsets.all(2),
          decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.button_color_pink),
          height: 8,
          width: 8,
        ),
        child: InkWell(
          child: Container(
            width: itemWidth,
            padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                  Icons.people,
                  color: navbarIndex == 4 ? Colors.blue : Colors.grey[400],
                  size: 24,
                ),
                Container(
                  margin: EdgeInsets.only(top: 4),
                  child: Text(
                    'ফ্রেন্ডস',
                    style: TextStyle(fontFamily: "Poppins", fontSize: 8, color: navbarIndex == 4 ? ColorsLocal.button_color_pink : Colors.grey[400], fontWeight: FontWeight.w500),
                    textAlign: TextAlign.center,
                    maxLines: 1,
                  ),
                )
              ],
            ),
          ),
          onTap: () {
            if (navbarIndex != 4) {
              navbarIndex = 4;
              notifyListeners();
            }
          },
        ),
      ),
    ];
  }

  notify() {
    notifyListeners();
  }

  homeClicked() {
    if (navbarIndex != 2) {
      navbarIndex = 2;
      notifyListeners();
    }
  }

  Widget getFragmentToShow() {
    if (navbarIndex == 2) {
      if (homeFragment == null) {
        homeFragment = new HomeFragment();
      }
      return homeFragment;
    } else if (navbarIndex == 0) {
      if (categoryList == null) {
        categoryList = new CategoryList(backArrowEnable: false);
      }
      return categoryList;
    } else if (navbarIndex == 1) {
      return leaderBoardFragment = LeaderBoardFragment();
    } else if (navbarIndex == 3) {
      return storeFragment = StoreFragment();
      // if (PackageSupport.instance.isMobile()) {
      //   if (Platform.isIOS) {
      //     return new StoreFragmentEmpty();
      //   } else {
      //     return storeFragment = StoreFragment();
      //   }
      // } else {
      //   return storeFragment = StoreFragment();
      // }
    } else if (navbarIndex == 4) {
      return friendsFragment = Friends();
    }

//    else {
//      if(dummyUI == null) {
//        dummyUI = new DummyUI();
//      }
//      return dummyUI;
//    }
  }

  _checkDynamicLinkLanding() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    int tournamentId = sharedPreferences.getInt(TOURNAMENT_INVITATION_ID);
    String inviteCode = sharedPreferences.getString(QUIZGIRI_INVITATION_CODE);
    String pendingRoute = sharedPreferences.getString(PENDING_ROUTE);
    sharedPreferences.remove(PENDING_ROUTE);

    if (tournamentId != null) {
      sharedPreferences.remove(TOURNAMENT_INVITATION_ID);
      Navigator.pushNamed(context, TournamentDetailsRoute, arguments: {
        'tournament_id': tournamentId,
      });
    }
    if (inviteCode != null) {
      sharedPreferences.remove(QUIZGIRI_INVITATION_CODE);
      Navigator.pushNamed(context, InviteFriendsRoute,
          arguments: {
            'invite_code': inviteCode,
          });
    }
    if(pendingRoute != null && pendingRoute.isNotEmpty) {
      var values = json.decode(pendingRoute);
      Navigator.pushNamed(context, values['route'], arguments: values['argument']);
    }
  }
}
