/*
* Created by Ahammed Hossain Shanto on 7/9/20
*/

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/TournamentPackage.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PurchaseHistoryVM with ChangeNotifier {
  bool historyLoaded = false;
  List history = new List();
  bool tournamentPacksLoaded = false;
  List<TournamentPackage> tournamentPackages = [];

  bool canceling = false;
  int currentIndex = -1;
  String cancelId = "";

  List ranges = [
    {'name': LocaleKey.THIS_WEEK.toLocaleText(), 'type': "weekly"},
    {'name': LocaleKey.THIS_MONTH.toLocaleText(), 'type': "monthly"},
    {'name': LocaleKey.THIS_YEAR.toLocaleText(), 'type': "yearly"},
  ];

  int selectedIndex = 0;

  PurchaseHistoryVM() {
    loadHistory();
    loadTournamentPacks();
  }

  Future<bool> cancelSubscription(String bundleId) async {

    if(!canceling) {
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      String accessToken = sharedPreferences.getString(ACCESS_TOKEN);

      canceling = true;
      //currentIndex = index;
      notifyListeners();

      var body = json.encode({
        'bundle_id': bundleId
      });

      var response = await http.post(UrlHelper.cancelBundleSubscriptionGhoori(), headers: {
        "Authorization": 'Bearer $accessToken',
        "Content-type": "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "x-api-key": API_KEY,
      }, body: body);

      var responseBody = json.decode(response.body);
      Logger.printWrapped(responseBody.toString());
      canceling = false;
      currentIndex = -1;
      notifyListeners();
      if (responseBody['success'] == true) {
        return true;
      }
      return false;
    }
  }

  loadHistory() async {
    historyLoaded = false;
    notifyListeners();

    //TODO remove the line below after connecting API
    await Future.delayed(Duration(seconds: 1));

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({
      'filter_type': ranges[selectedIndex]['type'],
    });
    var response = await http.post(Uri.encodeFull(UrlHelper.purchaseHistory()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    //Logger.printWrapped("Purchase History :"+response.body);

    var responseBody = json.decode(response.body);
    history = responseBody['history'];
    historyLoaded = true;
    notifyListeners();
  }

  updateIndex(String name) {
    for (int i = 0; i < ranges.length; i++) {
      if (ranges[i]['name'] == name) {
        selectedIndex = i;
        break;
      }
    }
    //call api
    loadHistory();
    notifyListeners();
  }

  loadTournamentPacks() async {

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String accessToken = sharedPreferences.getString(ACCESS_TOKEN);

    tournamentPacksLoaded = false;
    notifyListeners();

    var response = await http.get(UrlHelper.tournamentPacks(), headers: {
      "Authorization": 'Bearer $accessToken',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    TournamentPackage.packageTitle = responseBody['name'].toString();
    setTournamentPackList(responseBody['packages']);
    tournamentPacksLoaded = true;
    notifyListeners();
  }
  setTournamentPackList(List<dynamic> values) {
    tournamentPackages.clear();
    values.forEach((element) {
      tournamentPackages.add(TournamentPackage.fromJson(element));
    });
  }
}
