import 'dart:convert';
import 'dart:io';

import 'package:connectivity/connectivity.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:package_info/package_info.dart';
import 'package:path_provider/path_provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/constants/notification-channels.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';


Future<String> _downloadAndSaveFile(String url, String fileName) async {
  final Directory directory = await getApplicationDocumentsDirectory();
  final String filePath = '${directory.path}/$fileName';
  final http.Response response = await http.get(url);
  final File file = File(filePath);
  await file.writeAsBytes(response.bodyBytes);
  return filePath;
}

/// firebase messaging background message handler

// Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
//   print('Handling a background message ${message.messageId}');
//   // final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
//   // FlutterLocalNotificationsPlugin();
//   //
//   // await flutterLocalNotificationsPlugin
//   //     .resolvePlatformSpecificImplementation<
//   //     AndroidFlutterLocalNotificationsPlugin>()
//   //     ?.createNotificationChannel(NOTIFICATION_GLOBAL_CHANNEL);
//   //
//   // RemoteNotification notification = message.notification;
//   // AndroidNotification android = message.notification?.android;
//   // String banner = message.data['banner'];
//   // banner = "https://static.remove.bg/sample-gallery/graphics/bird-thumbnail.png";
//   // print("message received" + message.data.toString());
//   //
//   // if (notification != null) {
//   //
//   //   BigPictureStyleInformation bigPictureStyleInformation;
//   //   if(banner != null) {
//   //     final String bigPicturePath = await _downloadAndSaveFile(
//   //         banner, 'bigPicture');
//   //
//   //     bigPictureStyleInformation = BigPictureStyleInformation(FilePathAndroidBitmap(bigPicturePath),
//   //         contentTitle: notification.title,
//   //         htmlFormatContentTitle: true,
//   //         summaryText: notification.body,
//   //         htmlFormatSummaryText: true);
//   //   }
//   //
//   //   flutterLocalNotificationsPlugin.show(
//   //     notification.hashCode,
//   //     notification.title,
//   //     notification.body,
//   //     NotificationDetails(
//   //         android: AndroidNotificationDetails(
//   //             NOTIFICATION_GLOBAL_CHANNEL.id,
//   //             NOTIFICATION_GLOBAL_CHANNEL.name,
//   //             NOTIFICATION_GLOBAL_CHANNEL.description,
//   //             // TODO add a proper drawable resource to android, for now using
//   //             //      one that already exists in example app.
//   //             icon: 'ic_notification',
//   //             color: ColorsLocal.button_color_pink,
//   //             channelShowBadge: true,
//   //             largeIcon: DrawableResourceAndroidBitmap("ic_notification"),
//   //             styleInformation: banner != null ? bigPictureStyleInformation : null
//   //         ),
//   //         iOS: IOSNotificationDetails(
//   //             presentAlert: true,
//   //             presentBadge: true,
//   //             presentSound: true,
//   //             badgeNumber: 1
//   //         )
//   //     ),
//   //   );
//   // }
// }

class SplashScreenVM with ChangeNotifier {
  int connectionAvailable = 0, updateAvailable = 0, tokenOk = 0;
  bool isMajorUpdate = false, isCheckingComplete = false;
  String updateMessage = "";
  BuildContext _context;
  int called = 0;

  SplashScreenVM(this._context) {
    startCheckingRequirements();
    if (PackageSupport.instance.isMobile()) {
      firebaseCloudMessaging_Listeners();
      initDynamicLinks();
    }
  }

  BuildContext get context => _context;

  set context(BuildContext value) {
    _context = value;
  }

  reset() {
    connectionAvailable = 0;
    updateAvailable = 0;
    tokenOk = 0;
    isMajorUpdate = false;
    isCheckingComplete = false;
    updateMessage = "";
    notifyListeners();
  }

  void startCheckingRequirements() {
    called++;
//    Logger.printWrapped(
//        'connection: $connectionAvailable --- update $updateAvailable --- token: $tokenOk --- called: $called');
    if (connectionAvailable == 0) {
      checkInternetConnection();
    } else if (updateAvailable == 0) {
      checkUpdate();
    } else if (tokenOk == 0) {
      checkToken();
    } else {
      isCheckingComplete = true;
      notifyListeners();
      if (connectionAvailable == 1 && updateAvailable == -1 && tokenOk == 1) {
        Navigator.pushReplacementNamed(context, HomeRoute);
        //Navigator.pushReplacementNamed(context, TopicSuggestionToNewUserRoute);
      }
    }
  }

  checkInternetConnection() async {
//    try {
//      var result;
//      InternetAddress.lookup('example.com').then((value) {
//        result = value;
//        if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
//          connectionAvailable = 1;
//          startCheckingRequirements();
//          //checkUpdate();
//        }
//        else {
//          connectionAvailable = -1;
//          isCheckingComplete = true;
//          notifyListeners();
//        }
//      });
//    } on SocketException catch (_) {
//      connectionAvailable = -1;
//      isCheckingComplete = true;
//      notifyListeners();
//    }
    if (PackageSupport.instance.isMobile()) {
      var connectivityResult = await (Connectivity().checkConnectivity());

      if (connectivityResult == ConnectivityResult.mobile) {
        // I am connected to a mobile network.
        connectionAvailable = 1;
        startCheckingRequirements();
      } else if (connectivityResult == ConnectivityResult.wifi) {
        // I am connected to a wifi network.
        connectionAvailable = 1;
        startCheckingRequirements();
      } else {
        connectionAvailable = -1;
        isCheckingComplete = true;
        notifyListeners();
      }
    } else {
      connectionAvailable = 1;
      startCheckingRequirements();
    }
  }

  checkUpdate() async {
    String platform = "web";
    String versionName = "";
    String versionCode = "";
    if (PackageSupport.instance.isMobile()) {
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      versionName = packageInfo.version;
      versionCode = packageInfo.buildNumber;
      if (Platform.isIOS) {
        platform = "ios";
      } else if (Platform.isAndroid) {
        platform = "android";
      }
    }

    //Logger.printWrapped(Platform.operatingSystem);

    var body = json.encode({'version_code': versionCode, 'version_name': versionName, 'platform': platform});

    var response = await http.post(Uri.encodeFull(UrlHelper.checkUpdate()),
        headers: {
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    //var response = MockResponse.getUpdateResponse();

    if (response != null && UrlHelper.isSuccessful(response)) {
      var responseBody = json.decode(response.body);
      //Logger.printWrapped(responseBody.toString());
      if (BUILD_TYPE == "staging") {
        updateAvailable = -1;
      } else {
        if (responseBody['success'] == true) {
          updateAvailable = 1;
          updateMessage = responseBody['message'].toString();
          if (responseBody['priority'] == "high") {
            isMajorUpdate = true;
          }
        } else {
          updateAvailable = -1;
        }
      }
      startCheckingRequirements();
    } else {
      updateAvailable = -1;
      startCheckingRequirements();
    }
  }

  checkToken() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    if (access_token != null && access_token.length != 0) {
      //Logger.printWrapped(access_token.toString());
      var response = await http.get(Uri.encodeFull(UrlHelper.checkToken()), headers: {
        "Authorization": 'Bearer $access_token',
        "Content-type": "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "x-api-key": API_KEY,
      });

      //var response = MockResponse.getTokenResponse();
      if (response != null) {
        var responseBody = json.decode(response.body);
        Logger.printWrapped(responseBody.toString());
        if (responseBody['success'] == true) {
          tokenOk = 1;
          await _refreshToken();
          if (responseBody['country_code'] != null) {
            AppSessionSettings.userCountryCode = responseBody['country_code'].toString();
          }
        } else {
          tokenOk = -1;
        }
        startCheckingRequirements();
      }
    } else {
      tokenOk = -1;
      startCheckingRequirements();
    }
  }

  bool readyToStart() {
    if (connectionAvailable == 1 && updateAvailable == -1 && tokenOk == -1 && isCheckingComplete) {
      return true;
    } else {
      return false;
    }
  }

  bool readyToUpdate() {
    if (connectionAvailable == 1 && updateAvailable == 1 && isCheckingComplete) {
      return true;
    } else {
      return false;
    }
  }

  bool connectedToInternet() {
    if (connectionAvailable != -1) {
      return true;
    } else {
      return false;
    }
  }

  bool allOk() {
    if (connectionAvailable == 1 && updateAvailable == -1 && tokenOk == 1) {
      return true;
    } else {
      return false;
    }
  }



  void firebaseCloudMessaging_Listeners() async {
    if (Platform.isIOS) iOS_Permission();

    FirebaseMessaging.instance.getToken().then((token) async {
      SharedPreferences preferences = await SharedPreferences.getInstance();
      preferences.setString(FCM_TOKEN, token);
    });

    FirebaseMessaging.instance.onTokenRefresh.listen((newToken) async {
      SharedPreferences preferences = await SharedPreferences.getInstance();
      String fcm_token_old = await preferences.get(FCM_TOKEN);
      if (newToken.toString() != fcm_token_old) {
        await preferences.setBool(FCM_TOKEN_REFRESHED, true);
        await preferences.setString(FCM_TOKEN_OLD, fcm_token_old);
        await preferences.setString(FCM_TOKEN, newToken);
        await _refreshToken();
      }
    });

    //FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('ic_notification');

    /// Note: permissions aren't requested here just to demonstrate that can be
    /// done later
    final IOSInitializationSettings initializationSettingsIOS =
    IOSInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
        onDidReceiveLocalNotification:
            (int id, String title, String body, String payload) async {

        });

    final InitializationSettings initializationSettings = InitializationSettings(
        android: initializationSettingsAndroid,
        iOS: initializationSettingsIOS);

    await flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: (String payload) async {
          if (payload != null) {
            debugPrint('notification payload: $payload');
          }
          // navigate where i want *****
          try {
            _landNotification(json.decode(payload));
          }
          catch (_) {
            //
          }
        });


    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(NOTIFICATION_GLOBAL_CHANNEL);




    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      RemoteNotification notification = message.notification;
      //AndroidNotification android = message.notification?.android;
      String banner = message.data['banner'];
      print("message received" + message.data.toString());

      if (notification != null) {

        BigPictureStyleInformation bigPictureStyleInformation;
        if(banner != null) {
          final String bigPicturePath = await _downloadAndSaveFile(
              banner, 'bigPicture');

          bigPictureStyleInformation = BigPictureStyleInformation(FilePathAndroidBitmap(bigPicturePath),
              contentTitle: notification.title,
              htmlFormatContentTitle: true,
              summaryText: notification.body,
              htmlFormatSummaryText: true);
        }

        flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
              android: AndroidNotificationDetails(
                NOTIFICATION_GLOBAL_CHANNEL.id,
                NOTIFICATION_GLOBAL_CHANNEL.name,
                NOTIFICATION_GLOBAL_CHANNEL.description,
                // TODO add a proper drawable resource to android, for now using
                //      one that already exists in example app.
                icon: 'ic_notification',
                color: ColorsLocal.button_color_pink,
                channelShowBadge: true,
                largeIcon: DrawableResourceAndroidBitmap("ic_notification"),
                styleInformation: banner != null ? bigPictureStyleInformation : null
              ),
              iOS: IOSNotificationDetails(
                presentAlert: true,
                presentBadge: true,
                presentSound: true,
                badgeNumber: 1
              ),
            ),
          payload: json.encode(message.data),
        );
      }
    });

    FirebaseMessaging.instance.getInitialMessage().then((RemoteMessage message) async {
      var data = message?.data;
      //Logger.printWrapped('on launch $data');
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      sharedPreferences.setString(NOTIFICATION, json.encode(data));
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      //print('A new onMessageOpenedApp event was published! ${message.data.toString()}');
      _landNotification(message.data);
    });
  }

  // ignore: non_constant_identifier_names
  void iOS_Permission() {
    FirebaseMessaging.instance.requestPermission(sound: true, badge: true, alert: true, provisional: false);
  }

  _refreshToken() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    bool isRefreshed = await preferences.getBool(FCM_TOKEN_REFRESHED);

    if (isRefreshed != null && isRefreshed != false) {
      String newToken = await preferences.getString(FCM_TOKEN);
      String oldToken = await preferences.getString(FCM_TOKEN_OLD);

      var body = jsonEncode({
        'newToken': newToken,
        'oldToken': oldToken,
      });

      var response = await http.post(Uri.encodeFull(UrlHelper.refreshToken()),
          headers: {
            "Authorization": 'Bearer ${access_token}',
            "Content-type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "x-api-key": API_KEY,
          },
          body: body);

      var responseBody = json.decode(response.body);
      //Logger.printWrapped(responseBody.toString());
      if (responseBody['success'] == true) {
        preferences.remove(FCM_TOKEN_OLD);
        preferences.remove(FCM_TOKEN_REFRESHED);
      }
    }
  }

  initDynamicLinks() async {
    var data = await FirebaseDynamicLinks.instance.getInitialLink();
    var deepLink = data?.link;
    if (deepLink != null) {
      //Trigger on app launch
      final queryParams = deepLink.queryParameters;
      if (queryParams.length > 0) {
        SharedPreferences preferences = await SharedPreferences.getInstance();
        try {
          if (queryParams['tournament_id'] != null) {
            preferences.setInt(TOURNAMENT_INVITATION_ID, int.parse(queryParams['tournament_id']));
          }
          if (queryParams['invite_code'] != null) {
            preferences.setString(QUIZGIRI_INVITATION_CODE, queryParams['invite_code'].toString());
          }
        } catch (_) {
          //
        }
      }
    }
    FirebaseDynamicLinks.instance.onLink(onSuccess: (dynamicLink) async {
      //Trigger on app resume
      var deepLink = dynamicLink?.link;
      if (deepLink != null) {
        final queryParams = deepLink.queryParameters;
        if (queryParams.length > 0) {
          try {
            if (queryParams['tournament_id'] != null) {
              Get.toNamed(TournamentDetailsRoute, arguments: {
                'tournament_id': int.parse(queryParams['tournament_id']),
              });
            }
            if (queryParams['invite_code'] != null) {
              Get.toNamed(InviteFriendsRoute,
                  arguments: {
                    'invite_code': queryParams['invite_code'].toString(),
                  });
            }
          } catch (_) {
            //
          }
        }
      }
    }, onError: (e) async {
      //do something
    });
  }

  _landNotification(var notification) async {
    if (notification['channel_id'] == CHANNEL_NEW_TOPIC) {
      Get.toNamed(TopicDetailsRoute, arguments: {
        'topic_id': int.parse(notification['topic_id'].toString()),
        'type': "Topic",
        'category_name': "New"
      });
    } else if (notification['channel_id'] == CHANNEL_TOURNAMENT ||
        notification['channel_id'] == CHANNEL_TOURNAMENT_START) {
      Get.toNamed(TournamentDetailsRoute, arguments: {
        'tournament_id': int.parse(notification['tournament_id'].toString()),
      });
    } else if (notification['channel_id'] == CHANNEL_FRIEND_REQUEST) {
      while (Get.key.currentState.canPop()) {
        Get.back();
      }
      Get.toNamed(HomeRoute, arguments: {'target_index': 4});
    } else if (notification['channel_id'] == CHANNEL_CHALLENGE) {
      Get.toNamed(ChallengesRoute);
    } else if (notification['channel_id'] == CHANNEL_PURCHASE) {
      Get.toNamed(PurchaseHistoryRoute);
    }
  }
}
