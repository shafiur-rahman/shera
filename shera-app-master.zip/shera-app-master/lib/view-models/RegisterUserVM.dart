/*
* Created by Ahammed Hossain Shanto
* on 6/30/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/UserLoginRegistration.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RegisterUserVM with ChangeNotifier {
  BuildContext context;
  YYDialog yyDialog = new YYDialog();
  bool creating = false;
  String message = "";

  RegisterUserVM(this.context);

  createUser() async {
    creating = true;
    notifyListeners();
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String fcmToken = sharedPreferences.getString(FCM_TOKEN);
    String mobile = "";
    String type = "";
    if (!UserLoginRegistration.isFirebase) {
      type = "general";
      mobile = '${UserLoginRegistration.mobile}';
    } else {
      type = "firebase";
      mobile = UserLoginRegistration.mobile;
    }

    // String mobile10Digit = mobile.substring(1, 11);
    // UserLoginRegistration.countryCode = "+880";
    // UserLoginRegistration.mobile = mobile10Digit;

    var data = {
      "country_code": UserLoginRegistration.countryCode,
      "phone": mobile,
      "name": UserLoginRegistration.name,
      "email": UserLoginRegistration.email,
      "password": UserLoginRegistration.password,
      'type': type
    };
    if(!kIsWeb) {
      data['fcm_token'] = fcmToken;
    }

    var body = json.encode(data);

    var response = await http.post(Uri.encodeFull(UrlHelper.registerUser()),
        headers: {
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    //response received ************
    creating = false;
    notifyListeners();
    if (response != null) {
      var responseBody = json.decode(response.body);
      if (responseBody['success'] == true) {
        await sharedPreferences.setString(USER_ID, responseBody['user_id'].toString());
        await sharedPreferences.setString(ACCESS_TOKEN, responseBody['access_token'].toString());

        if (AppSessionSettings.isNepaliUser()) {
          Navigator.pushReplacementNamed(context, UploadAvatarRoute);
        } else {
          Navigator.pushReplacementNamed(context, TopicSuggestionToNewUserRoute);
        }
      } else {
        showDialog("Alert", responseBody['message'].toString());
      }
    } else {
      showDialog("Opss!!!", "Some error occurred. Please try again later");
    }
  }

  showDialog(String title, String message) {
    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width - 100
      //..height = 110
      ..backgroundColor = Colors.white
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
              child: Text(
                title,
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 22,
                  color: ColorsLocal.text_color_purple,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
              child: Text(
                message,
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 16,
                  color: ColorsLocal.text_color,
                  fontWeight: FontWeight.w400,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
              child: RaisedButton(
                child: Text(
                  "OK",
                  style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                ),
                color: ColorsLocal.button_color_pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                onPressed: () {
                  yyDialog.dismiss();
                  yyDialog = new YYDialog();
                },
              ),
            )
          ],
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }

  notify() {
    notifyListeners();
  }
}
