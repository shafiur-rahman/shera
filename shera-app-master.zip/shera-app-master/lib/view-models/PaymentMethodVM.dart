import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

class PaymentMethodVM with ChangeNotifier {
  BuildContext context;
  bool paymentDone = false;
  var wallet;
  bool creatingPayment = false;
  bool checkingPaymentStatus = false;
  bool isProcessing = false;

  PaymentMethodVM(this.context);

  // Future<bool> payment(bundle_id) async {
  //   paymentDone = false;
  //   notifyListeners();
  //   var body = json.encode({
  //     'bundle_id': bundle_id,
  //   });
  //   print(bundle_id);
  //   SharedPreferences preferences = await SharedPreferences.getInstance();
  //   String accessToken = preferences.getString(ACCESS_TOKEN);
  //   var response = await http.post(Uri.encodeFull(UrlHelper.purchaseBundle()),
  //       headers: {
  //         "Authorization": 'Bearer $accessToken',
  //         "Content-type": "application/json",
  //         "X-Requested-With": "XMLHttpRequest",
  //         "x-api-key": API_KEY,
  //       },
  //       body: body);
  //   Logger.printWrapped("Payment status: " + response.body);
  //
  //   if (UrlHelper.isSuccessful(response)) {
  //     var responsebody = jsonDecode(response.body);
  //     if (responsebody['success'] == true) {
  //       paymentDone = true;
  //       return true;
  //     } else {
  //       Toast.show("Payment failed", context);
  //       return false;
  //     }
  //   } else {
  //     Toast.show("Server error", context);
  //     return false;
  //   }
  //   notifyListeners();
  // }

  purchaseBundleNepal(String bundleId) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    isProcessing = true;
    notifyListeners();

    var body = json.encode({"channel": "APP", "bundle_id": bundleId});

    var response = await http.post(Uri.encodeFull(UrlHelper.bundlePurchaseNepal()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    isProcessing = false;
    notifyListeners();
    if (responseBody["success"] == true) {
      LocalAlert.showDialog(context, "Success!!", responseBody['message'].toString());
    } else {
      LocalAlert.showDialog(context, "Opps!!", responseBody['message'] ?? "Something went wrong");
    }
  }

  // Future<bool> getTournamentPass(tournament_id) async {
  //   paymentDone = false;
  //   notifyListeners();
  //   var body = json.encode({
  //     'tournament_id': tournament_id,
  //   });
  //   print(tournament_id);
  //   SharedPreferences preferences = await SharedPreferences.getInstance();
  //   String accessToken = preferences.getString(ACCESS_TOKEN);
  //   var response = await http.post(Uri.encodeFull(UrlHelper.getTournamentPass()),
  //       headers: {
  //         "Authorization": 'Bearer $accessToken',
  //         "Content-type": "application/json",
  //         "X-Requested-With": "XMLHttpRequest",
  //         "x-api-key": API_KEY,
  //       },
  //       body: body);
  //
  //   Logger.printWrapped("Payment status: " + response.body);
  //
  //   if (UrlHelper.isSuccessful(response)) {
  //     var responsebody = jsonDecode(response.body);
  //     if (responsebody['success'] == true) {
  //       paymentDone = true;
  //       return true;
  //     } else {
  //       Toast.show("Payment failed", context);
  //       return false;
  //     }
  //   } else {
  //     Toast.show("Server error", context);
  //     return false;
  //   }
  // }

  Future<String> createRequest(String type, String bundleId) async {
    creatingPayment = true;
    notifyListeners();

    var body = json.encode({'id': bundleId, 'type': type});

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String accessToken = preferences.getString(ACCESS_TOKEN);
    var response = await http.post(Uri.encodeFull(UrlHelper.createPayment()),
        headers: {
          "Authorization": 'Bearer $accessToken',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    var result;
    Logger.printWrapped(responseBody.toString());
    if (responseBody != null && responseBody['expected_response'] != null) {
      result = responseBody['expected_response'].toString();
    }

    creatingPayment = false;
    notifyListeners();

    return result;
  }

  Future<bool> checkPaymentStatus(String url) async {
    checkingPaymentStatus = true;
    notifyListeners();

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String accessToken = preferences.getString(ACCESS_TOKEN);

    var response = await http.get(Uri.encodeFull(url), headers: {
      "Authorization": 'Bearer $accessToken',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });

    var responseBody = json.decode(response.body);
    bool result = false;
    if (responseBody != null) {
      //Logger.printWrapped(responseBody.toString());
      result = responseBody['success'];
    }

    checkingPaymentStatus = false;
    notifyListeners();

    return result;
  }
}
