/*
* Created by Ahammed Hossain Shanto on 7/19/20
*/

import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:http/http.dart' as http;
import 'package:image/image.dart' as IMG;
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

class EditProfileVM with ChangeNotifier {
  var profileDetails;
  bool infoUpdating = false;
  bool uploadingImage = false;

  EditProfileVM(this.profileDetails);

  Future<bool> updateInfo() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String accessToken = sharedPreferences.getString(ACCESS_TOKEN);
    infoUpdating = true;
    notifyListeners();

    var body = json.encode({"name": profileDetails['name'].toString(), "email": profileDetails['email'].toString()});

    var response = await http.post(Uri.encodeFull(UrlHelper.updateProfile()),
        headers: {
          "Authorization": 'Bearer $accessToken',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    infoUpdating = false;
    notifyListeners();
    if (responseBody['success'] == true) {
      return true;
    } else {
      return false;
    }
  }

  pickImage(BuildContext context) async {
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      await ImageCropper.cropImage(
              sourcePath: image.path,
              aspectRatioPresets: [
                CropAspectRatioPreset.square,
//            CropAspectRatioPreset.ratio3x2,
//            CropAspectRatioPreset.original,
//            CropAspectRatioPreset.ratio4x3,
//            CropAspectRatioPreset.ratio16x9
              ],
              androidUiSettings: AndroidUiSettings(toolbarTitle: 'Crop Image', toolbarColor: Colors.deepPurple, toolbarWidgetColor: Colors.white, initAspectRatio: CropAspectRatioPreset.square, lockAspectRatio: true),
              iosUiSettings: IOSUiSettings(minimumAspectRatio: 1.0, title: "Crop Image", doneButtonTitle: "Upload"))
          .then((File croppedImage) {
        if (croppedImage != null) {
          _uploadImage(croppedImage, context);
        } else {
          Toast.show("No image selected", context);
        }
      });
    }
  }

  _uploadImage(File imageFile, BuildContext context) async {
    uploadingImage = true;
    notifyListeners();

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String accessToken = preferences.getString(ACCESS_TOKEN);

    var uri = Uri.parse(UrlHelper.updateProfileImage());

    var request = new http.MultipartRequest("POST", uri);

    double minOfDisplaySize = min(MediaQuery.of(context).size.width, MediaQuery.of(context).size.height);
    // double minOfDisplaySize = 200;

    var result = await FlutterImageCompress.compressWithFile(
      imageFile.absolute.path,
      minWidth: min(minOfDisplaySize.toInt(), 500),
      minHeight: min(minOfDisplaySize.toInt(), 500),
      quality: 100,
      rotate: 0,
    );

    //limit the size withing 300 kb *********
    for (int i = 0; i < 10; i++) {
      if (result.length > 300000) {
        result = await FlutterImageCompress.compressWithFile(
          imageFile.absolute.path,
          minWidth: min(minOfDisplaySize.toInt(), 500),
          minHeight: min(minOfDisplaySize.toInt(), 500),
          quality: (100 - (i + 1) * 10),
          rotate: 0,
        );
        //Utils.printWrapped(result.length.toString());
      } else {
        break;
      }
      IMG.Image img = IMG.decodeImage(result);
      Logger.printWrapped('${img.width}x${img.height} - ${result.length / 1000}KB');
    }
    //Utils.printWrapped(result.length.toString());

    var imageToUpload = http.MultipartFile.fromBytes("image", result, filename: "avatar.jpg");

    Map<String, String> requestHeaders = {
      "Authorization": 'Bearer $accessToken',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    };

    request.files.add(imageToUpload);
    request.headers.addAll(requestHeaders);
    var response = await request.send();

    response.stream.transform(utf8.decoder).listen((value) {
      var result = json.decode(value.toString());
//      Logger.printWrapped(result.toString());
//      Logger.printWrapped(profileDetails.toString());
      if (result['success'] == true) {
        profileDetails = result;
        notifyListeners();
      } else {
        Toast.show("Something went wrong", context, duration: 2);
      }
    });

    uploadingImage = false;
    notifyListeners();
  }
}
