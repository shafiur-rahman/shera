/*
* Created by Ahammed Hossain Shanto on 7/8/20
*/

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/TournamentPackage.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TournamentDetailsVM with ChangeNotifier {
  var tournamentDetails;
  bool detailsLoaded = false;
  int tournamentId;
  bool starting = false;
  bool subscribing = false;
  bool isEligible = false;
  String passcodeMessage = "";
  bool verifying = false;
  String passcode = "";
  String coinPurchaseMessage = "";

  bool tournamentPacksLoaded = false;
  List<TournamentPackage> tournamentPackages = [];

  TournamentDetailsVM(this.tournamentId) {
    loadDetails();
    loadTournamentPacks();
    AppSessionSettings.isNepaliUser() ? AppSessionSettings.ncellTournamentId = tournamentId : null;
  }

  setEligibility(bool value) {
    if (isEligible != value) {
      isEligible = value;
      notifyListeners();
    }
  }

  loadDetails() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    detailsLoaded = false;
    notifyListeners();
    var body = json.encode({'tournament_id': tournamentId});

    var response = await http.post(Uri.encodeFull(UrlHelper.tournamentDetails()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    Logger.printWrapped("Details" + responseBody.toString());
    tournamentDetails = responseBody;
    tournamentDetails['updating'] = false;
    detailsLoaded = true;
    AppSessionSettings.ncellFreeQuestionsCount = tournamentDetails["tournament"]["free_questions"];

    if(AppSessionSettings.ncellFreeQuestionsCount == 0){
      AppSessionSettings.ncellFreeQuestionsEndDialogShow = true;
    }
    notifyListeners();
    //print("Free Questions"+tournamentDetails["tournament"]["free_questions"].toString());
  }

  Future<dynamic> startGame(String type, String categoryName) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    int tournamentId = tournamentDetails['tournament']['id'];

    starting = true;
    notifyListeners();

    var body = json.encode({
      'tournament_id': tournamentId,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.startTournament()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    if (UrlHelper.isSuccessful(response)) {
      var responseBody = json.decode(response.body);
      Logger.printWrapped("START_GAME: " + responseBody.toString());
      responseBody['appbar_type'] = type;
      responseBody['appbar_name'] = categoryName;
      sharedPreferences.setString(GAME_ID, responseBody['game_id'].toString());
      sharedPreferences.setString(GAME_TYPE, responseBody['game_type'].toString());
      //Logger.printWrapped(responseBody.toString());
      starting = false;
      notifyListeners();
      return responseBody;
    } else {
      starting = false;
      notifyListeners();
      return null;
    }
  }

  String getDuration() {
    String value = "";
    int seconds = tournamentDetails['tournament']['duration'];
    Duration duration = Duration(seconds: seconds);
    value = '${duration.inMinutes} minutes';
    return value;
  }

  Future<bool> verifyPasscode(String passcode) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    verifying = true;
    notifyListeners();

    var body = json.encode({'tournament_id': tournamentId, 'passcode': passcode});

    var response = await http.post(Uri.encodeFull(UrlHelper.verifyPasscode()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    verifying = false;
    passcodeMessage = responseBody['message'];
    notifyListeners();
    if (responseBody['success'] == true) {
      isEligible = true;
      return true;
    } else {
      isEligible = false;
      return false;
    }
  }

  Future<bool> subscribeByCoins() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    verifying = true;
    notifyListeners();

    var body = json.encode({
      'tournament_id': tournamentId,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.subscribeByCoin()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    verifying = false;
    coinPurchaseMessage = responseBody['message'].toString();
    notifyListeners();
    if (responseBody['success'] == true) {
      return true;
    } else {
      return false;
    }
  }

  String getButtonTitle() {
    String title = "";
    if (!AppSessionSettings.isNepaliUser()) {
      if (tournamentDetails['tournament']['currency'] == "optional" || tournamentDetails['tournament']['currency'] == "money") {
        title += '${LocaleKey.PLAY_USING.toLocaleText()} ${tournamentDetails['tournament']['subscription_fee'].toString().toLocaleNumber()} ${LocaleKey.BDT.toLocaleText()}';
      }
      if (tournamentDetails['tournament']['currency'] == "optional") {
        title += " /";
      }
      if (tournamentDetails['tournament']['currency'] == "optional" || tournamentDetails['tournament']['currency'] == "coin") {
        title += ' ${LocaleKey.PLAY_USING.toLocaleText()} ${tournamentDetails['tournament']['coin_fee'].toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}';
      }
    } else {
      title = LocaleKey.SUBSCRIBE_NOW.toLocaleText();
    }
    return title;
  }

  callUnsubscribe() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);
    subscribing = true;
    notifyListeners();

    var body = json.encode({
      'channel': "APP",
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.unsubscribeTournamnet()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    subscribing = false;
    // coinPurchaseMessage = responseBody['message'].toString();
    // loadDetails();
    notifyListeners();
  }

  loadTournamentPacks() async {

    tournamentPacksLoaded = false;
    notifyListeners();

    var response = await http.get(UrlHelper.tournamentPacks(), headers: {
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    TournamentPackage.packageTitle = responseBody['name'].toString();
    setTournamentPackList(responseBody['packages']);
    tournamentPacksLoaded = true;
    notifyListeners();
  }

  setTournamentPackList(List<dynamic> values) {
    tournamentPackages.clear();
    values.forEach((element) {
      tournamentPackages.add(TournamentPackage.fromJson(element));
    });
    tournamentPackages = List.from(tournamentPackages.reversed);
  }
}
