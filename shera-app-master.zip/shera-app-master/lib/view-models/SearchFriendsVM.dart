/*
* Created by Shanto on 28/08/2020
*/

import 'dart:convert';

import 'package:contacts_service/contacts_service.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SearchFriendsVM with ChangeNotifier {
  BuildContext context;

  String searchString = "";
  bool searching = false;
  bool searchCalled = false;
  List searchResults = new List();
  List searchResultsContacts = new List();
  Iterable<Contact> contacts;
  bool isFromContacts = false;

  SearchFriendsVM(this.context) {
    getContacts();
  }

  getContacts() async {
    if (contacts == null) {
      if (await Permission.contacts.status.isGranted) {
        contacts = await ContactsService.getContacts(withThumbnails: false);
        if (contacts != null) {
          searchFromContacts();
        }
      } else if (await Permission.contacts.status.isDenied || await Permission.contacts.status.isUndetermined) {
        Permission.contacts.request().then((value) {
          if (value.isGranted) {
            getContacts();
          } else {
            //do nothing ****
          }
        });
      }
    }
  }

  requestSearch(String searchString) {
    this.searchString = searchString;
    if (!searchCalled) {
      searchCalled = true;
      Future.delayed(Duration(seconds: 1), () {
        searchCalled = false;
        _executeSearch();
      });
    }
  }

  _executeSearch() async {
    if (searchString.trim().length == 0) {
      if (contacts != null) {
        searchFromContacts();
      } else {
        searchResults = new List();
        notifyListeners();
      }
    } else {
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      String access_token = sharedPreferences.getString(ACCESS_TOKEN);
      searching = true;
      notifyListeners();
      var body = json.encode({"search_string": searchString});

      var response = await http.post(Uri.encodeFull(UrlHelper.searchFriends()),
          headers: {
            "Authorization": 'Bearer $access_token',
            "Content-type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "x-api-key": API_KEY,
          },
          body: body);
      var responseBody = json.decode(response.body);
      if (responseBody != null) {
        searchResults = responseBody['search_result'];
        //Logger.printWrapped(searchResults.toString());
      }
      searching = false;
      isFromContacts = false;
      notifyListeners();
    }
  }

  searchFromContacts() async {
    if (searchResultsContacts != null && searchResultsContacts.length != 0) {
      searchResults = searchResultsContacts;
      isFromContacts = true;
      notifyListeners();
    } else {
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      String access_token = sharedPreferences.getString(ACCESS_TOKEN);
      searching = true;
      notifyListeners();

      List<String> all = new List();
      contacts.forEach((contact) {
        contact.phones.forEach((item) {
          all.add(item.value);
        });
      });

      var body = json.encode({'contacts': all});

      //Logger.printWrapped(body.toString());

      var response = await http.post(Uri.encodeFull(UrlHelper.searchFromContacts()),
          headers: {
            "Authorization": 'Bearer $access_token',
            "Content-type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "x-api-key": API_KEY,
          },
          body: body);
      var responseBody = json.decode(response.body);
      if (responseBody != null) {
        searchResults = responseBody['search_result'];
        searchResultsContacts = responseBody['search_result'];
        //Logger.printWrapped(searchResults.toString());
      }
      searching = false;
      isFromContacts = true;
      notifyListeners();
    }
  }
}
