/*
* Created by Ahammed Hossain Shanto
* on 7/6/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileVM with ChangeNotifier {
  BuildContext context;
  bool profileLoaded = false;
  bool categoriesLoaded = false;
  var userDetails;
  List categories;
  var bcsHistory;
  bool bcsHistoryLoaded = false;
  var selectedBcsFilter = {"key": "today", "value": LocaleKey.TODAY.toLocaleText()};

  List bcsFilter = [
    {"key": "today", "value": LocaleKey.TODAY.toLocaleText()},
    {"key": "this_week", "value": LocaleKey.THIS_WEEK.toLocaleText()},
    {"key": "this_month", "value": LocaleKey.THIS_MONTH.toLocaleText()},
  ];

  updateBcsFilterSelection(var value) {
    if (selectedBcsFilter != value) {
      selectedBcsFilter = value;
      notifyListeners();
    }
  }

  ProfileVM() {
    loadProfile();
    //loadCategoriesPlayed();
    loadBcsHistory();
  }

  refresh() {}

  loadProfile() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    profileLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.profile()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    userDetails = responseBody;
    profileLoaded = true;
    notifyListeners();
  }

  loadBcsHistory() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    bcsHistoryLoaded = false;
    notifyListeners();

    var response = await http.get(UrlHelper.bcsHistory(), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped("BCS History " + responseBody.toString());
    bcsHistory = responseBody;
    bcsHistoryLoaded = true;
    notifyListeners();
  }

  loadCategoriesPlayed() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    categoriesLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.categoriesPlayed()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    categories = responseBody['categories'];
    if (categories != null) {
      //categories.sort((b, a) => a['progress'].compareTo(b['progress']));
    }
    categoriesLoaded = true;
    //Logger.printWrapped(categories.toString());
    notifyListeners();
  }
}
