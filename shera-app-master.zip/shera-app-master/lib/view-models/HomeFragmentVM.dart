/*
* Created by Ahammed Hossain Shanto
* on 7/1/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/helpers/banner-ad-loader.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:quiz/extensions/string_extensions.dart';

class HomeFragmentVM with ChangeNotifier {
  BuildContext context;
  bool profileLoaded = false;
  bool dailyTaskLoaded = false;
  bool showDailyTask = true;
  bool latestTournamentsLoaded = false;
  bool latestBattleRoomLoaded = false;
  bool latestLiveQuizLoaded = false;
  bool topTopicsLoaded = false;
  bool interestedTopicsLoaded = false;
  bool favouriteTopicsLoaded = false;
  bool isBcsSubscribed = false;
  var userDetails;
  var dailyTask;
  var latestTournaments;
  var latestBattleRoom;
  var latestLiveQuiz;
  var topTopics;
  var favouriteTopics;
  var interestedTopics;
  List bcsTests = [];
  bool bcsTestsLoaded = false;
  bool bcsModelStarting = false;
  String selectedBcsModelId = "-1";
  var bcsModelQuestions;

  bool categoriesLoaded = false;
  var categories;

  List<BannerAdLoader> bannerAds = [];

  HomeFragmentVM(this.context) {
    loadProfile();
    loadDailyTask();
    loadLiveQuiz();
    loadLatestTournaments();
    loadBattleRoom();
    loadBcsTests();
    loadTopTopics();
    loadFavouriteTopics();
    loadInterestedCategories();
    loadAllCategories();
    checkNotification();
    initAds();
  }

  initAds() {
    bannerAds = [];
    bannerAds.add(new BannerAdLoader(AdSize.banner));
    bannerAds.add(new BannerAdLoader(AdSize.banner));
  }

  getAd(int index, {EdgeInsetsGeometry margin = const EdgeInsets.all(0)}) {
    return Container(
      margin: margin,
      child: bannerAds[index],
    );
  }

  loadAllCategories() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    categoriesLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.allCategories()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    categories = responseBody;
    categoriesLoaded = true;
    notifyListeners();
  }

  Future<bool> refresh() async {
    dailyTaskLoaded = false;
    showDailyTask = true;
    latestTournamentsLoaded = false;
    topTopicsLoaded = false;
    interestedTopicsLoaded = false;
    favouriteTopicsLoaded = false;
    bcsTestsLoaded = false;

    notifyListeners();

    await loadProfile();
    await loadDailyTask();
    await loadBcsTests();
    await loadLatestTournaments();
    await loadBattleRoom();
    await loadTopTopics();
    await loadFavouriteTopics();
    await loadInterestedCategories();
  }

  loadProfile() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    profileLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.profile()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    userDetails = responseBody;
    profileLoaded = true;
    notifyListeners();
  }

  loadDailyTask() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    dailyTaskLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.dailyTask()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped("Daily Task: " + responseBody.toString());
    dailyTask = responseBody;
    dailyTaskLoaded = true;
    notifyListeners();
  }

  loadBCSModelQuestions(String id) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    bcsModelStarting = true;
    selectedBcsModelId = id;
    notifyListeners();

    var body = json.encode({"id": id});

    var response = await http.post(Uri.encodeFull(UrlHelper.bcsTestStart()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    if (responseBody != null) {
      if (responseBody['questions'] != null) {
        bcsModelQuestions = responseBody;
        var arguments;
        var selectedModel;
        for (int i = 0; i < bcsTests.length; i++) {
          if (bcsTests[i]['id'].toString() == selectedBcsModelId) {
            selectedModel = bcsTests[i];
            break;
          }
        }
        arguments = {
          "model": selectedModel,
          "details": responseBody,
        };
        Navigator.of(context).pushNamed(BCSModelPlayRoute, arguments: arguments).then((value) {
          loadProfile();
          loadBcsTests();
        });
      } else {
        LocalAlert.showDialog(context, "Sorry", responseBody['message'].toString());
      }
    } else {
      LocalAlert.showDialog(context, "Sorry", "Something went wrong");
    }
    bcsModelStarting = false;
    notifyListeners();
  }

  loadLiveQuiz() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    latestLiveQuizLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.liveQuizList()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.dlog("Live Quiz List: ", responseBody.toString());

    latestLiveQuiz = responseBody;
    latestLiveQuizLoaded = true;
    notifyListeners();
  }

  loadLatestTournaments() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    latestTournamentsLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.latestTournaments()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.dlog("Latest Tournament: ", responseBody.toString());

    latestTournaments = responseBody;
    Logger.dlog("Latest Tournament xyz: ", latestTournaments.toString());
    latestTournamentsLoaded = true;
    notifyListeners();
  }

  loadBattleRoom() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    latestBattleRoomLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.battleRoomList()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.dlog("Battle Room: ", responseBody.toString());

    latestBattleRoom = responseBody;
    latestBattleRoomLoaded = true;
    notifyListeners();
  }

  loadBcsTests() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    bcsTestsLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.bcsTestList()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    bcsTests = responseBody['model_tests'];
    isBcsSubscribed = false;
    if(responseBody['is_subscribed'] != null && responseBody['is_subscribed'] == true) {
      isBcsSubscribed = true;
    }
    bcsTestsLoaded = true;
    notifyListeners();
  }

  String getFirstName() {
    String fullName = userDetails['name'].toString();
    for (int i = 0; i < fullName.toString().length; i++) {
      if (fullName[i] == " ") {
        return fullName.substring(0, i);
      }
    }
    return fullName;
  }

  void setHideDailyTask(bool value) {
    showDailyTask = value;
    AppSessionSettings.showDailyTask = value;
    notifyListeners();
  }

  loadTopTopics() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    topTopicsLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.topTopics()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    // print("TopicList :"+responseBody.toString());
    topTopics = responseBody;
    topTopicsLoaded = true;
    notifyListeners();
  }

  loadFavouriteTopics() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    favouriteTopicsLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.favouriteTopics()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    favouriteTopics = responseBody;
    favouriteTopicsLoaded = true;
    notifyListeners();
  }

  loadInterestedCategories() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    interestedTopicsLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.categoriesPlayed()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);

    interestedTopics = responseBody;
    // print(responseBody.toString());
    interestedTopicsLoaded = true;
    notifyListeners();
  }

  checkNotification() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var noti = sharedPreferences.getString(NOTIFICATION);
    if (noti != null && noti.toString().isNotEmpty) {
      var notification = json.decode(noti);
      await sharedPreferences.remove(NOTIFICATION).then((value) {
        _landNotification(notification);
      });
    }
  }

  _landNotification(var notification) {
    if(notification != null) {
      Logger.printWrapped(notification.toString());
      if (notification['channel_id'] == CHANNEL_NEW_TOPIC) {
        Get.toNamed(TopicDetailsRoute, arguments: {
          'topic_id': int.parse(notification['topic_id'].toString()),
          'type': "Topic",
          'category_name': "New"
        });
      } else if (notification['channel_id'] == CHANNEL_TOURNAMENT ||
          notification['channel_id'] == CHANNEL_TOURNAMENT_START) {
        Get.toNamed(TournamentDetailsRoute, arguments: {
          'tournament_id': int.parse(notification['tournament_id'].toString()),
        });
      } else if (notification['channel_id'] == CHANNEL_FRIEND_REQUEST) {
        while (Navigator.canPop(context)) {
          Navigator.pop(context);
        }
        Navigator.pushNamed(context, HomeRoute, arguments: {'target_index': 4});
      } else if (notification['channel_id'] == CHANNEL_CHALLENGE) {
        Navigator.pushNamed(context, ChallengesRoute);
      } else if (notification['channel_id'] == CHANNEL_PURCHASE) {
        Get.toNamed(PurchaseHistoryRoute);
      }
    }
  }

  getBcsModelPricing(var model) {
    String value = "";
    if(model['is_free'] || isBcsSubscribed) {
      value = LocaleKey.PLAY_FREE.toLocaleText();
    }
    else {
      if (model['fee_type'] != null && model['fee_type'] == 'money') {
        if(model['is_paid'] != null && model['is_paid'] == true) {
          value = LocaleKey.PLAY_NOW.toLocaleText();
        }
        else {
          value =
          '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_money'].toString().toLocaleNumber()} ${LocaleKey.BDT
              .toLocaleText()}';
        }
      }
      else {
        value =
        '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_coin'].toString().toLocaleNumber()} ${LocaleKey
            .USING_COINS.toLocaleText()}';
      }
    }
    return value;
  }

  bool needToPayForBcsTest(var model) {
    if(isBcsSubscribed || model['is_free']) {
      return false;
    }
    else if(model['fee_type'] != null && model['fee_type'] == "money") {
      if(model['is_paid'] != null && model['is_paid'] == true) {
        return false;
      }
      else {
        return true;
      }
    }
    return false;
  }

}
