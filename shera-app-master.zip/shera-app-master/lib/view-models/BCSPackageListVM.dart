/*
* Created by Ahammed Hossain Shanto
* on 3/8/21
*/


import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/BCSPackage.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BCSPackageListVM with ChangeNotifier {
  BuildContext context;
  bool bcsPacksLoaded = false;
  List<BCSPackage> bcsPackages = [];

  BCSPackageListVM(this.context) {
    loadBcsPacks();
  }

  loadBcsPacks() async {

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String accessToken = sharedPreferences.getString(ACCESS_TOKEN);

    bcsPacksLoaded = false;
    notifyListeners();

    var response = await http.get(UrlHelper.bcsPacks(), headers: {
      "Authorization": 'Bearer $accessToken',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    BCSPackage.packageTitle = responseBody['name'].toString();
    setBcsPackList(responseBody['packages']);
    bcsPacksLoaded = true;
    notifyListeners();
  }

  setBcsPackList(List<dynamic> values) {
    bcsPackages.clear();
    values.forEach((element) {
      bcsPackages.add(BCSPackage.fromJson(element));
    });
  }
}