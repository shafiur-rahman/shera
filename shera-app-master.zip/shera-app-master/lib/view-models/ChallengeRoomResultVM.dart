/*
* Created by Ahammed Hossain Shanto
* on 1/4/21
*/

import 'package:flutter/cupertino.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/utils/Logger.dart';

class ChallengeRoomResultVM with ChangeNotifier {
  BuildContext context;
  var arguments;
  var roomInfo;
  var userInfo;
  var opponentInfo;
  var resultInfo;

  ChallengeRoomResultVM(this.context, this.arguments) {
    roomInfo = arguments['room_info'];
    userInfo = arguments['user_info'];
    opponentInfo = arguments['opponent_info'];
    resultInfo = arguments['result_info'];

    Logger.dlog("Result Info", resultInfo.toString());
  }

  bool isUserWinner() {
    if (resultInfo['game_status'] == "win") {
      if (resultInfo['winner']['participant_id'] == userInfo['user_id']) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  bool isOpponentWinner() {
    if (resultInfo["game_status"].toString() == 'win') {
      if (resultInfo['winner']['participant_id'] == opponentInfo['user_id']) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
}
