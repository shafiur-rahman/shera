/*
* Created by Ahammed Hossain Shanto
* on 7/2/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/view-components/Pop_Ups/ReferralPU.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UtilsVM with ChangeNotifier {
  BuildContext context;
  bool walletVisible = true;
  var noti;

  bool referralBannerLoaded = false;

  UtilsVM(this.context) {
    //checkNoti();
  }

  double getElevation() {
    return walletVisible ? 0 : 1;
  }

  setWalletVisibility(bool value) {
    this.walletVisible = value;
    notifyListeners();
  }

  checkNoti() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    var response = await http.get(Uri.encodeFull(UrlHelper.checkNotificationStatus()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    noti = responseBody;
    notifyListeners();
  }

  checkRferral() async {
    String imageUrl;
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    referralBannerLoaded = false;
    notifyListeners();
    var response = await http.get(Uri.encodeFull(UrlHelper.inAppPupup()), headers: {
      "Authorization": 'Bearer ${access_token}',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });

    try {
      var responseBody = json.decode(response.body);
      imageUrl = responseBody["banner_url"].toString();
      bool isVisible = responseBody['is_visible'];
      var data = responseBody['data'];
      referralBannerLoaded = true;
      if (AppSessionSettings.showReferralPopUp && imageUrl != null && imageUrl.isNotEmpty && isVisible != null && isVisible) {
        AppSessionSettings.showReferralPopUp = false;
        if( !AppSessionSettings.isNepaliUser()){
          ReferralPU.showDialog(context, imageUrl, data: data);
        }

      }
    } catch (_) {
      //
    }
    notifyListeners();
  }

  Future delay(int second) async {
    return await new Future.delayed(new Duration(seconds: second));
  }
}
