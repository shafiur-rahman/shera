/*
* Created by Ahammed Hossain Shanto
* on 12/10/20
*/

import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeChallengeRoomVM with ChangeNotifier {
  BuildContext context;
  List challengeRooms = new List();
  bool challengeRoomsLoaded = false;
  int visibleRoomIndex = 0;
  bool joiningRoom = false;
  String joiningRoomId = "-1";

  String detailsVisibleId = "-1";

  void setDetailsVisibility(String id) {
    if(detailsVisibleId == id) {
      detailsVisibleId = "-1";
    }
    else {
      detailsVisibleId = id;
    }
    notifyListeners();
  }

  HomeChallengeRoomVM(this.context) {
    loadChallengeRooms();
  }

  loadChallengeRooms() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    Logger.dlog("Live Quiz List", UrlHelper.liveQuizList());
    var response =
    await http.get(UrlHelper.battleRoomList(), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.dlog("Live Quiz List", response.body.toString());
    if(responseBody['rooms'] != null) {
      challengeRooms = responseBody['rooms'];
    }
    challengeRoomsLoaded = true;
    notifyListeners();
  }

  Future<dynamic> joinRoom(String id) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    joiningRoom = true;
    joiningRoomId = id;
    notifyListeners();

    var body = json.encode({
      "id": id,
    });

    var response =
    await http.post(UrlHelper.challengeRoomJoin(), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    }, body: body);
    Logger.dlog("Response", response.body.toString());

    var responseBody = json.decode(response.body);
    Logger.dlog("Challenge Room: ", responseBody.toString());
    joiningRoom = false;
    joiningRoomId = "-1";
    notifyListeners();
    if(responseBody != null && responseBody['success'] != null && responseBody['success'] == true) {
      return responseBody;
    }
    else {
      return null;
    }
  }

  double getRoomWidth(BuildContext context) {
    double expectedRoomWidth = MediaQuery.of(context).size.width;
    double availableWidth = MediaQuery.of(context).size.width;
    return min(expectedRoomWidth, availableWidth);
  }

  double getRoomHeight(BuildContext context) {
    //return 236.0;
    return 180.0;
  }

  void setVisibleRoomIndex(int index) {
    if(visibleRoomIndex != index) {
      visibleRoomIndex = index;
      notifyListeners();
    }
  }
}
