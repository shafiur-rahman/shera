/*
* Created by Ahammed Hossain Shanto on 7/8/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/FacebookLogger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DailySpinVM with ChangeNotifier {
  bool infoLoaded = false;
  bool spinAvailable = false;
  String nextSpin = "";
  bool spinning = false;
  bool spinned = false;
  bool spinSubmitting = false;
  int giftType = 0;
  int amount = 0;

  DailySpinVM() {
    loadInfo();
  }

  loadInfo() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    infoLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.spinInfo()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    spinAvailable = responseBody['spin_available'];
    if (spinAvailable) {
      spinned = false;
    } else {
      nextSpin = responseBody['next_spin_left'].toString();
    }
    infoLoaded = true;
    notifyListeners();
  }

  Future<int> submitSpin() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    spinSubmitting = true;
    spinning = true;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.submitSpin()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);

    nextSpin = responseBody['next_spin_left'].toString();
    giftType = responseBody['gift_type'];
    amount = responseBody['amount'];

    //logging facebook app event*****
    FacebookLogger.spin(type: giftType, amount: amount);

    return responseBody['result_index'];
  }

  spinByAd() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    spinSubmitting = true;
    notifyListeners();

    var body = json.encode({"type": "ad"});

    var response = await http.post(Uri.encodeFull(UrlHelper.resetSpin()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    if (responseBody['success'] == true) {
      spinSubmitting = false;
      loadInfo();
      notifyListeners();
    } else {
      spinSubmitting = false;
      notifyListeners();
    }
  }

  updateResult() {
    spinSubmitting = false;
    spinned = true;
    spinning = false;
    spinAvailable = false;
    notifyListeners();
  }

  notify() {
    notifyListeners();
  }
}
