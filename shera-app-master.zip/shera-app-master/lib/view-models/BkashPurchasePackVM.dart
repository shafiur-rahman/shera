/*
* Created by Ahammed Hossain Shanto
* on 2/24/21
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/RedirectToBrowser.dart';
import 'package:quiz/utils/Logger.dart';

class BkashPurchasePackVM with ChangeNotifier {
  BuildContext context;
  var arguments;
  bool isNameOk = false;
  bool isMobileOk = false;
  bool processing = false;
  TextEditingController nameController = new TextEditingController(), mobileController = new TextEditingController();
  String bundleId;

  BkashPurchasePackVM(this.context, this.arguments) {
    bundleId = arguments['bundle_id'].toString();
  }

  notify() {
    notifyListeners();
  }

  purchaseBundle() async {

    processing = true;
    notifyListeners();

    var body = json.encode({
      'id': bundleId,
      'type': 'bundle',
      'name': nameController.text,
      'phone': mobileController.text
    });

    var response = await http.post(UrlHelper.purchaseBkashPacks(), headers: {
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    }, body: body);
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    if(responseBody['expected_response'] != null) {
      Navigator.pop(context);
      String launchUrl = responseBody['expected_response'].toString();
      if(kIsWeb) {
        RedirectToBrowser.instance.launch(launchUrl, newTab: false);
      }
      else {
        Navigator.pushNamed(context, RedirectionWebViewRoute, arguments: {
          'launch_url': launchUrl
        });
      }
    }
    processing = false;
    notifyListeners();
  }



  isOkToProceed() {
    return isMobileOk && isNameOk;
  }
}