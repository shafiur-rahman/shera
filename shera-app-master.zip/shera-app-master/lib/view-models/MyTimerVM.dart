/*
* Created by Ahammed Hossain Shanto
* on 12/2/20
*/

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:quiz/controllers/SoundController.dart';

typedef void OnFinish();

class MyTimerVM with ChangeNotifier {
  OnFinish onFinish;
  BuildContext context;
  bool autoStart = false;
  int totalTimeInSeconds = 0;
  int remainingTimeInSeconds = 0;
  Timer timer;

  MyTimerVM(this.context, {this.onFinish, @required this.autoStart, @required this.totalTimeInSeconds}) {
    remainingTimeInSeconds = totalTimeInSeconds;
    if (autoStart) {
      startTimer();
    }
  }

  startTimer({bool playSound = false}) async {
    if (playSound) {
      SoundController.playTimer();
    }
    // try {
    timer?.cancel();
    timer = new Timer.periodic(Duration(seconds: 1), (t) {
      if (remainingTimeInSeconds < 1) {
        SoundController.pauseTimer();
        timer.cancel();
        notifyListeners();
        onFinish();
      } else {
        remainingTimeInSeconds--;
        //Logger.printWrapped(remainingTimeInSeconds.toString());
        notifyListeners();
      }
    });
    // }
    // catch (_) {
    //   timer?.cancel();
    // }
  }

  double timeLeftPercentage() {
    if (totalTimeInSeconds != 0) {
      return (remainingTimeInSeconds / (totalTimeInSeconds * 1.0));
    } else {
      return 0;
    }
  }

  HMSTimeFormat getRemainingTime() {
    return new HMSTimeFormat(remainingTimeInSeconds);
  }
}

class HMSTimeFormat {
  int _hour = 0, _minute = 0, _second = 0;
  int _durationInSecond = 0;
  int _totalDuration = 0;
  String _formattedString = "";

  HMSTimeFormat(this._durationInSecond) {
    _totalDuration = _durationInSecond;
    _hour = _durationInSecond ~/ (60 * 60);
    _durationInSecond = _durationInSecond % (60 * 60);
    _minute = _durationInSecond ~/ 60;
    _durationInSecond = _durationInSecond % 60;
    _second = _durationInSecond;
    if (_hour > 0) {
      if (_hour < 10) {
        _formattedString += '0$_hour';
      } else {
        _formattedString += '$_hour';
      }
      if (_minute < 10) {
        _formattedString += ':0$_minute';
      } else {
        _formattedString += ':$_minute';
      }
    } else {
      if (_minute < 10) {
        _formattedString += '0$_minute';
      } else {
        _formattedString += '$_minute';
      }
      if (_second < 10) {
        _formattedString += ':0$_second';
      } else {
        _formattedString += ':$_second';
      }
    }
  }

  int get totalDuration => _totalDuration;

  int get durationInSecond => _durationInSecond;

  get second => _second;

  get minute => _minute;

  int get hour => _hour;

  String get formattedString => _formattedString;
}
