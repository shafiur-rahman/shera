import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/FacebookLogger.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ChallengeRoomDetailsVM with ChangeNotifier{
  int roomId;
  BuildContext context;
  bool detailsLoaded = false;
  bool canPlay = false;
  var challengeRoomDetails;
  int visibleRoomIndex = 0;
  bool joiningRoom = false;
  String joiningRoomId = "-1";
  String detailsVisibleId = "-1";

  bool weekly = false;
  bool friends = false;
  bool overall = false;
  bool daily = true;
  bool monthly = false;
  bool refer = false;
  bool shouldBlur = false;

  double x;

  String type = "daily";
  bool leaderBoardListLoaded = false;
  List leaderboard = new List();
  List top_list = new List();

  onSelect(bool value0, value1, value2) {
    this.daily = value0;
    this.weekly = value1;
    this.monthly = value2;


    if (this.daily == true) {
      this.type = "daily";
    } else if (this.weekly == true) {
      this.type = "weekly";
    } else if (this.monthly == true) {
      this.type = "monthly";
    }
    loadLeaderBoard();
    notifyListeners();
  }

  loadDetails() async {

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    detailsLoaded = false;
    notifyListeners();

    var body = json.encode({'room_id': roomId});

    var response = await http.post(Uri.encodeFull(UrlHelper.challengeRoomDetails()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    Logger.dlog("ChallengeRoomDetails" , responseBody.toString());
    challengeRoomDetails = responseBody['data'];
    //tournamentDetails['updating'] = false;
    detailsLoaded = true;
    notifyListeners();
    //print("Free Questions"+tournamentDetails["tournament"]["free_questions"].toString());
  }

  loadLeaderBoard({bool visibleLoad = true}) async {
    if (visibleLoad) {
      leaderBoardListLoaded = false;
      notifyListeners();
    }

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String accessToken = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({'type': this.type, 'room_id' : roomId});
    var response = await http.post(Uri.encodeFull(UrlHelper.ChallengeRoomLeaderBoardList()),
        headers: {
          "Authorization": 'Bearer $accessToken',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    Logger.printWrapped("Leaderboard List :"+response.body);

    var responseBody = json.decode(response.body);
    leaderboard = responseBody['list'];
    top_list = responseBody['top_list'];
    if (responseBody['user_exists_in_top'] != null) {
      //shouldBlur = !responseBody['user_exists_in_top'];
    }

    try {
      FacebookLogger.leaderboardWatch();
    } catch (_) {
      //do something
    }

//    if (leaderboard.last == true){
//      this.x = 56;
//    }
//    else (this.x =0);
    leaderBoardListLoaded = true;
    notifyListeners();
  }

  void setDetailsVisibility(String id) {
    if(detailsVisibleId == id) {
      detailsVisibleId = "-1";
    }
    else {
      detailsVisibleId = id;
    }
    notifyListeners();
  }

  double getRoomWidth(BuildContext context) {
    double expectedRoomWidth = MediaQuery.of(context).size.width;
    double availableWidth = MediaQuery.of(context).size.width;
    return min(expectedRoomWidth, availableWidth);
  }

  double getRoomHeight(BuildContext context) {
    //return 236.0;
    return 200.0;
  }

  void setVisibleRoomIndex(int index) {
    if(visibleRoomIndex != index) {
      visibleRoomIndex = index;
      notifyListeners();
    }
  }

  ChallengeRoomDetailsVM(this.context, this.roomId){
    loadDetails();
    loadLeaderBoard();
  }



  Future<dynamic> joinRoom(String id) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    joiningRoom = true;
    joiningRoomId = id;
    notifyListeners();

    var body = json.encode({
      "id": id,
    });

    var response =
    await http.post(UrlHelper.challengeRoomJoin(), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    }, body: body);
    Logger.dlog("Response", response.body.toString());

    var responseBody = json.decode(response.body);
    Logger.printWrapped(responseBody.toString());
    joiningRoom = false;
    joiningRoomId = "-1";
    notifyListeners();
    if(responseBody != null && responseBody['success'] != null && responseBody['success'] == true) {
      return responseBody;
    }
    else {
      return null;
    }
  }

}