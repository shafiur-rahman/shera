/*
* Created by Ahammed Hossain Shanto on 8/6/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/ChallengeInfo.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/views/Home.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChallengeFriendVM with ChangeNotifier {
  List<int> bets = [200, 500, 1000, 1500, 2000];
  List categories = new List();
  List topics = new List();
  BuildContext context;
  bool singleTopic = true;
  bool categoriesLoaded = false;
  bool challenging = false;
  bool topicsLoaded = false;
  int maxQuestionAmount = 100;
  int minQuestionAmount = 10;
  int selectedCategoryId = -1;
  int selectedTopicId = -1;

  ChallengeFriendVM(this.context) {
    ChallengeInfo.betAmount = bets[0];
    ChallengeInfo.questionCount = 20;
    ChallengeInfo.topicId = -1;
    loadAllCategories();
  }

  loadAllCategories() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    categoriesLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.allCategories()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    categories = responseBody['category_list'];
    if (categories.isNotEmpty) {
      selectedCategoryId = categories[0]['id'];
    }
    categoriesLoaded = true;
    loadAllTopicsFromCategory();
    notifyListeners();
  }

  loadAllTopicsFromCategory() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    topicsLoaded = false;
    notifyListeners();

    var body = json.encode({
      'category_id': selectedCategoryId,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.topicsOfCategory()),
        headers: {
          "Authorization": 'Bearer ${access_token}',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    topics = responseBody['topics'];
    if (topics.isNotEmpty) {
      selectedTopicId = topics[0]['topic_id'];
      ChallengeInfo.topicId = selectedTopicId;
    } else {
      selectedTopicId = -1;
      ChallengeInfo.topicId = selectedTopicId;
    }
    topicsLoaded = true;
    notifyListeners();
  }

  challengeFriend() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    challenging = true;
    notifyListeners();

    var body;
    // if (singleTopic) {
    //   body = json.encode({"friend_user_id": ChallengeInfo.friendUserId, "topic_id": ChallengeInfo.topicId, "number_of_question": ChallengeInfo.questionCount, "bet": ChallengeInfo.betAmount});
    // } else {
    body = json.encode({"friend_user_id": ChallengeInfo.friendUserId, "number_of_question": ChallengeInfo.questionCount, "bet": ChallengeInfo.betAmount});
    // }

    Logger.dlog("Challenge Friend Request Body: ",Uri.encodeFull(UrlHelper.challengeFriend()));
    var response = await http.post(Uri.encodeFull(UrlHelper.challengeFriend()),
        headers: {
          "Authorization": 'Bearer ${access_token}',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    Logger.dlog("Challenge Friend Response Body: ", responseBody.toString());
    if (responseBody['success'] == true) {
      Navigator.popUntil(context, (route) {
        if(route.settings.name == HomeRoute) {
          return true;
        }
        else {
          return false;
        }
      });
      Navigator.pushNamed(context, ChallengesRoute);
    } else {
      LocalAlert.showDialog(context, "Opps!s!", responseBody['message'].toString());
    }

    challenging = false;
    notifyListeners();
  }

  String getSelectedCategoryName() {
    for (int i = 0; i < categories.length; i++) {
      if (categories[i]['id'] == selectedCategoryId) {
        return categories[i]['name'].toString();
      }
    }
    return "";
  }

  String getSelectedTopicName() {
    for (int i = 0; i < topics.length; i++) {
      if (topics[i]['topic_id'] == selectedTopicId) {
        return topics[i]['name'].toString();
      }
    }
    return "";
  }

  setCategoryId(int id) {
    selectedCategoryId = id;
    notifyListeners();
    loadAllTopicsFromCategory();
  }

  setTopicId(int id) {
    selectedTopicId = id;
    ChallengeInfo.topicId = id;
    notifyListeners();
  }

  notify() {
    notifyListeners();
  }
}
