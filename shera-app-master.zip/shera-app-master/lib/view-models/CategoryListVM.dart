/*
* Created by Ahammed Hossain Shanto on 7/7/20
*/

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CategoryListVM with ChangeNotifier {
  bool categoriesLoaded = false;
  List categories = new List();

  CategoryListVM();

  loadAllCategories() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    categoriesLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.allCategories()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    categories = responseBody['category_list'];
    categoriesLoaded = true;
    notifyListeners();
  }

  toggleFavourite(int index) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    int categoryId = categories[index]['id'];

    categories[index]['updating'] = true;
    notifyListeners();

    var body = json.encode({
      'category_id': categoryId,
    });

    String url = UrlHelper.addFavouriteCategory();
    if (categories[index]['following']) {
      url = UrlHelper.removeFavouriteCategory();
    }

    var response = await http.post(Uri.encodeFull(url),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    if (responseBody != null && responseBody['success'] == true) {
      categories[index]['updating'] = false;
      categories[index]['following'] = !categories[index]['following'];
      notifyListeners();
    } else {
      categories[index]['updating'] = false;
      notifyListeners();
    }
  }
}
