import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RecentBestAllVM with ChangeNotifier {
  BuildContext context;
  bool detailsLoaded = false;
  int topicId;
  int tournamentId;
  var page_count;
  List rankList = [];

  int totalPage = 0;
  int currentPage = 1;
  int categoryId;
  String type;

  RecentBestAllVM({this.topicId, this.tournamentId, this.type = ""}) {
    if (topicId != null) {
      loadDetails();
    } else if (tournamentId != null) {
      loadTournamentDetails();
    } else if (type != null && type == "daily_task") {
      loadDailyTaskRanklist();
    }
  }

  loadDetails() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);
    detailsLoaded = false;
    notifyListeners();

    var body = json.encode({
      "topic_id": topicId,
      "page": currentPage,
      "per_page": RANKLIST_PER_PAGE,
    });

    Logger.printWrapped(body.toString());

    var response = await http.post(Uri.encodeFull(UrlHelper.seeAllRecent()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    //  Logger.printWrapped("Recentlist:"+responseBody.toString());
    totalPage = responseBody["page_count"];
    rankList = responseBody["ranking"];

    detailsLoaded = true;
    notifyListeners();
  }

  loadDailyTaskRanklist() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);
    detailsLoaded = false;
    notifyListeners();

    var body = json.encode({
      "type": "daily_task",
      "page": currentPage,
      "per_page": RANKLIST_PER_PAGE,
    });

    //Logger.printWrapped(body.toString());

    var response = await http.post(Uri.encodeFull(UrlHelper.dailyTaskRanking()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    Logger.printWrapped("Recentlist:" + responseBody.toString());
    totalPage = responseBody["page_count"];
    rankList = responseBody["ranking"];

    detailsLoaded = true;
    notifyListeners();
  }

  loadTournamentDetails() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);
    detailsLoaded = false;
    notifyListeners();

    var body = json.encode({
      "tournament_id": tournamentId,
      "page": currentPage,
      "per_page": RANKLIST_PER_PAGE,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.seeAllRecentTournament()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    Logger.printWrapped("Recentlist:" + responseBody.toString());
    totalPage = responseBody["page_count"];
    rankList = responseBody["ranking"];

    detailsLoaded = true;
    notifyListeners();
  }

  nextPage() {
    rankList = new List();
    detailsLoaded = false;
    currentPage++;
    notifyListeners();
    _loadRanklist();
  }

  previousPage() {
    rankList = new List();
    detailsLoaded = false;
    currentPage--;
    notifyListeners();
    _loadRanklist();
  }

  jumpToPage(int page) {
    rankList = new List();
    detailsLoaded = false;
    currentPage = page;
    notifyListeners();
    _loadRanklist();
  }

  void _loadRanklist() {
    if (type != null && type != "daily_task") {
      if (topicId != null) {
        loadDetails();
      } else if (tournamentId != null) {
        loadTournamentDetails();
      }
    } else {
      loadDailyTaskRanklist();
    }
  }
}
