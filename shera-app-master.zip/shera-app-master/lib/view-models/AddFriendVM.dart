import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AddFriendVM with ChangeNotifier {
  BuildContext context;

  AddFriendVM(this.context);

  bool friendRequestSend = false;

  onRequestSend(user_id) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({
      'user_id': user_id,
    });
    var response = await http.post(Uri.encodeFull(UrlHelper.denyFriendRequest()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    //Logger.printWrapped("Friends List :"+response.body);

    var responseBody = json.decode(response.body);
    notifyListeners();

    friendRequestSend = true;
    notifyListeners();
  }
}
