/*
* Created by Ahammed Hossain Shanto on 7/7/20
*/

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TopicsListVM with ChangeNotifier {
  bool topicsLoaded = false;
  List topics = new List();
  String type = "";

  TopicsListVM();

  Future<bool> loadAllTop() async {
    type = "top";
    topicsLoaded = false;
    notifyListeners();

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    var response = await http.get(Uri.encodeFull(UrlHelper.topTopics()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);

    topics = responseBody['topics'];
    topicsLoaded = true;
    notifyListeners();
    return true;
  }

  Future<bool> loadAllFavourite() async {
    type = "favourite";
    topicsLoaded = false;
    notifyListeners();

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    var response = await http.get(Uri.encodeFull(UrlHelper.favouriteTopics()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);

    topics = responseBody['topics'];
    topicsLoaded = true;
    notifyListeners();
    return true;
  }

  Future<bool> loadAllTopicsFromCategory(int categoryId) async {
    type = "category";
    topicsLoaded = false;
    notifyListeners();

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    var body = json.encode({
      'category_id': categoryId,
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.topicsOfCategory()),
        headers: {
          "Authorization": 'Bearer ${access_token}',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    topics = responseBody['topics'];
    topicsLoaded = true;
    notifyListeners();
    return true;
  }

  toggleFavourite(int index) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    int topicId = topics[index]['topic_id'];

    topics[index]['updating'] = true;
    notifyListeners();

    var body = json.encode({
      'topic_id': topicId,
      'follow': !topics[index]['following'],
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.followUnfollowTopic()),
        headers: {
          "Authorization": 'Bearer ${access_token}',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    if (responseBody != null && responseBody['success'] == true) {
      topics[index]['updating'] = false;
      topics[index]['following'] = responseBody['following'];
      notifyListeners();
    } else {
      topics[index]['updating'] = false;
      notifyListeners();
    }
  }
}
