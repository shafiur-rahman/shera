/*
* Created by Ahammed Hossain Shanto
* on 10/13/20
*/

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

class PaymentViaMobileOperatorVM with ChangeNotifier {
  BuildContext context;
  bool paymentDone = false;
  bool processingPayment = false;

  PaymentViaMobileOperatorVM(this.context);

  Future<bool> payment(bundle_id) async {
    paymentDone = false;
    processingPayment = true;
    notifyListeners();
    var body = json.encode({
      'bundle_id': bundle_id,
    });
    print(bundle_id);
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String accessToken = preferences.getString(ACCESS_TOKEN);
    var response = await http.post(Uri.encodeFull(UrlHelper.purchaseBundle()),
        headers: {
          "Authorization": 'Bearer $accessToken',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    //Logger.printWrapped("Payment status: "+response.body);
    processingPayment = false;
    notifyListeners();
    if (UrlHelper.isSuccessful(response)) {
      var responsebody = jsonDecode(response.body);
      if (responsebody['success'] == true) {
        paymentDone = true;
        return true;
      } else {
        Toast.show("Payment failed", context);
        return false;
      }
    } else {
      Toast.show("Server error", context);
      return false;
    }

    notifyListeners();
  }

  Future<bool> getTournamentPass(tournament_id) async {
    paymentDone = false;
    notifyListeners();
    var body = json.encode({
      'tournament_id': tournament_id,
    });
    print(tournament_id);
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String accessToken = preferences.getString(ACCESS_TOKEN);
    var response = await http.post(Uri.encodeFull(UrlHelper.getTournamentPass()),
        headers: {
          "Authorization": 'Bearer $accessToken',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    Logger.printWrapped("Payment status: " + response.body);

    if (UrlHelper.isSuccessful(response)) {
      var responsebody = jsonDecode(response.body);
      if (responsebody['success'] == true) {
        paymentDone = true;
        return true;
      } else {
        Toast.show("Payment failed", context);
        return false;
      }
    } else {
      Toast.show("Server error", context);
      return false;
    }
  }
}
