/*
* Created by Ahammed Hossain Shanto
* on 6/30/20
*/

import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/UserLoginRegistration.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'TimerVM.dart';

class VerifyOtpVM with ChangeNotifier {
  BuildContext context;
  String otpMessage = "";
  bool otpSending = false;
  String pin = "";
  bool verifying = false;
  String verifyMessage = "";
  YYDialog yyDialog = new YYDialog();

  VerifyOtpVM(this.context) {
    //do initialize anything here ***
  }

  Future<bool> sendOTP(String mobile) async {
    //Request Start ###########
    otpSending = true;
    notifyListeners();
    var body = jsonEncode({'phone': mobile, 'country_code': UserLoginRegistration.countryCode});
    var response = await http.post(Uri.encodeFull(UrlHelper.resendOtp()),
        headers: {
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    //response arrived #################
    otpSending = false;
    notifyListeners();
    if (response != null) {
      var responseBody = json.decode(response.body);
      if (responseBody['success'] == true) {
        otpMessage = responseBody['message'].toString();
        //notifyListeners();
        return true;
      } else {
        otpMessage = responseBody['message'].toString();
        notifyListeners();
        return false;
      }
    } else {
      otpMessage = "Error Occured";
      return false;
    }
  }

  Future<int> sendOTPFirebase() async {
    otpSending = true;
    notifyListeners();

    FirebaseAuth _auth = FirebaseAuth.instance;

    await _auth.verifyPhoneNumber(
        phoneNumber: UserLoginRegistration.countryCode + UserLoginRegistration.mobile,
        timeout: Duration(seconds: 60),
        verificationCompleted: (AuthCredential authCredential) {
          Logger.printWrapped("Complete Verification");
          otpSending = false;
          notifyListeners();

          return 1;
        },
        verificationFailed: (FirebaseAuthException authException) {
          Logger.printWrapped("Failed Verification");
          otpSending = false;
          otpMessage = "Code Sending Failed. Try again later";
          notifyListeners();
          return 2;
        },
        codeSent: (String verificationId, [int forceResendingToken]) {
          Logger.printWrapped("Code Sent");
          UserLoginRegistration.verificationId = verificationId;
          otpSending = false;
          otpMessage = "Code Sent";
          notifyListeners();
          return 3;
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          Logger.printWrapped("Code Retrieval Timeout");
          otpSending = false;
          notifyListeners();
          return 4;
        });
  }

  verifyOtp(TimerVM timerVM) async {
    verifying = true;
    notifyListeners();

    String mobile = UserLoginRegistration.mobile;

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String fcmToken = sharedPreferences.getString(FCM_TOKEN);

    var body = json.encode({"type": "general", "country_code": UserLoginRegistration.countryCode, "phone": mobile, "otp": pin, "fcm_token": fcmToken.toString()});
    Logger.printWrapped('loginData => ${body.toString()}');

    var response = await http.post(Uri.encodeFull(UrlHelper.verifyOtp()),
        headers: {
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    verifying = false;
    notifyListeners();

    if (response != null) {
      var responseBody = json.decode(response.body);
      if (responseBody['success'] == true) {
        if (responseBody['account_exists'] == true) {
          SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
          sharedPreferences.setString(USER_ID, responseBody['user_id'].toString());
          sharedPreferences.setString(ACCESS_TOKEN, responseBody['access_token'].toString());
          await timerVM.stopTimer();
          Navigator.pushReplacementNamed(context, HomeRoute);
        } else {
          await timerVM.stopTimer();
          Navigator.pushReplacementNamed(context, RegisterUserRoute);
        }
      } else {
        showDialog("Alert", responseBody['message'].toString());
      }
    } else {
      showDialog("Opss!!!", "Some error occurred. Please try again later");
    }
  }

  verifyOtpFirebase(TimerVM timerVM) async {
    verifying = true;
    notifyListeners();

    FirebaseAuth auth = FirebaseAuth.instance;
    var _credential = PhoneAuthProvider.credential(verificationId: UserLoginRegistration.verificationId, smsCode: pin);

    auth.signInWithCredential(_credential).then((UserCredential result) {
      //Logger.printWrapped(result.user.uid);
      result.user.getIdTokenResult().then((value) {
        //Logger.printWrapped("Token: " + value.token);
        loginWithFirebaseOtp(timerVM, result.user.uid, value.token);
      });
    }).catchError((e) {});
  }

  loginWithFirebaseOtp(TimerVM timerVM, String uid, String token) async {
    verifying = true;
    notifyListeners();

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String fcmToken = sharedPreferences.getString(FCM_TOKEN);

    var body = json.encode({"type": "firebase", "user_id": uid, "firebase_token": token, "country_code": UserLoginRegistration.countryCode, "fcm_token": fcmToken.toString()});

    Logger.printWrapped(body.toString());

    var response = await http.post(Uri.encodeFull(UrlHelper.verifyOtp()),
        headers: {
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    verifying = false;
    notifyListeners();

    if (response != null) {
      var responseBody = json.decode(response.body);
      if (responseBody['success'] == true) {
        if (responseBody['account_exists'] == true) {
          SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
          sharedPreferences.setString(USER_ID, responseBody['user_id'].toString());
          sharedPreferences.setString(ACCESS_TOKEN, responseBody['access_token'].toString());
          await timerVM.stopTimer();
          Navigator.pushReplacementNamed(context, HomeRoute);
        } else {
          await timerVM.stopTimer();
          Navigator.pushReplacementNamed(context, RegisterUserRoute);
        }
      } else {
        showDialog("Alert", responseBody['message'].toString());
      }
    } else {
      showDialog("Opss!!!", "Some error occurred. Please try again later");
    }
  }

  showDialog(String title, String message) {
    yyDialog.build(context)
      ..width = MediaQuery.of(context).size.width - 100
      //..height = 110
      ..backgroundColor = Colors.white
      ..borderRadius = 10.0
      ..showCallBack = () {
        //print("showCallBack invoke");
      }
      ..dismissCallBack = () {
        //print("dismissCallBack invoke");
        yyDialog = new YYDialog();
      }
      ..widget(Container(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
              child: Text(
                title,
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 22,
                  color: ColorsLocal.text_color_purple,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
              child: Text(
                message,
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 16,
                  color: ColorsLocal.text_color,
                  fontWeight: FontWeight.w400,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
              child: RaisedButton(
                child: Text(
                  "OK",
                  style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                ),
                color: ColorsLocal.button_color_pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                onPressed: () {
                  yyDialog.dismiss();
                  yyDialog = new YYDialog();
                },
              ),
            )
          ],
        ),
      ))
      ..animatedFunc = (child, animation) {
        return FadeTransition(
          child: child,
          opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
        );
      }
      ..show();
  }

  setPin(String pin) {
    this.pin = pin;
    notifyListeners();
  }
}
