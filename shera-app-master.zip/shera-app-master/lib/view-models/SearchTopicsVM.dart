/*
* Created by Shanto on 28/08/2020
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SearchTopicsVM with ChangeNotifier {
  String searchString = "";
  bool searching = false;
  bool searchCalled = false;
  List searchResults = new List();

  requestSearch(String searchString) {
    this.searchString = searchString;
    if (!searchCalled) {
      searchCalled = true;
      Future.delayed(Duration(seconds: 1), () {
        searchCalled = false;
        _executeSearch();
      });
    }
  }

  _executeSearch() async {
    if (searchString.trim().length == 0) {
      searchResults = new List();
      notifyListeners();
    } else {
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      String access_token = sharedPreferences.getString(ACCESS_TOKEN);
      searching = true;
      notifyListeners();
      var body = json.encode({"search_string": searchString});

      var response = await http.post(Uri.encodeFull(UrlHelper.searchTopics()),
          headers: {
            "Authorization": 'Bearer $access_token',
            "Content-type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "x-api-key": API_KEY,
          },
          body: body);
      var responseBody = json.decode(response.body);
      if (responseBody != null) {
        searchResults = responseBody['search_results'];
        //Logger.printWrapped(searchResults.toString());
      }
      searching = false;
      notifyListeners();
    }
  }

  toggleFavourite(int index) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    int topicId = searchResults[index]['topic_id'];

    searchResults[index]['updating'] = true;
    notifyListeners();

    var body = json.encode({
      'topic_id': topicId,
      'follow': !searchResults[index]['following'],
    });

    var response = await http.post(Uri.encodeFull(UrlHelper.followUnfollowTopic()),
        headers: {
          "Authorization": 'Bearer ${access_token}',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    if (responseBody != null && responseBody['success'] == true) {
      searchResults[index]['updating'] = false;
      searchResults[index]['following'] = responseBody['following'];
      notifyListeners();
    } else {
      searchResults[index]['updating'] = false;
      notifyListeners();
    }
  }
}
