/*
* Created by Ahammed Hossain Shanto on 7/20/20
*/

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/controllers/SoundController.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserSettingsVM with ChangeNotifier {
  var settings;
  bool settingsLoaded = false;
  double soundEffectLevel = 1.0;
  double musicLevel = 1.0;
  SharedPreferences preferences;
  bool loggingOut = false;

  UserSettingsVM() {
    loadSettings();
    loadSoundSettings();
  }

  loadSettings() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    settingsLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.getSettings()), headers: {
      "Authorization": 'Bearer $access_token',
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    settings = responseBody;
    settingsLoaded = true;
    notifyListeners();
  }

  updateSettings() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    notifyListeners();
    var body = json.encode(settings);

    var response = await http.post(Uri.encodeFull(UrlHelper.getSettings()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    var responseBody = json.decode(response.body);
    if (responseBody['success'] == true) {
      //do something if required ***
    }
  }

  Future<bool> logout() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);
    String fcm_token = sharedPreferences.getString(FCM_TOKEN);

    loggingOut = true;
    notifyListeners();

    var body = json.encode({"fcm_token": fcm_token});

    var response = await http.post(Uri.encodeFull(UrlHelper.logout()),
        headers: {
          "Authorization": 'Bearer $access_token',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);

    var responseBody = json.decode(response.body);
    if (responseBody['success'] == true) {
      sharedPreferences.remove(ACCESS_TOKEN);
      sharedPreferences.remove(FCM_TOKEN);
      return true;
    } else {
      return false;
    }

    loggingOut = false;
    notifyListeners();
  }

  loadSoundSettings() async {
    preferences = await SharedPreferences.getInstance();
    double sound, music;
    sound = preferences.getDouble(SOUND_EFFECT);
    music = preferences.getDouble(MUSIC);

    soundEffectLevel = sound ?? 1.0;
    musicLevel = music ?? 1.0;
    notifyListeners();
  }

  updateSoundEffect(double value) async {
    preferences.setDouble(SOUND_EFFECT, value);
    soundEffectLevel = value;
    SoundController.init();
    notifyListeners();
  }

  updateMusicLevel(double value) async {
    preferences.setDouble(MUSIC, value);
    musicLevel = value;
    SoundController.init();
    notifyListeners();
  }

  notify() {
    notifyListeners();
  }
}
