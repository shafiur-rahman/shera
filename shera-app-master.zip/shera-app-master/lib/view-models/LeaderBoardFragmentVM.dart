/*
* Created by Shafiur
* on 2/2/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/helpers/banner-ad-loader.dart';
import 'package:quiz/utils/FacebookLogger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LeaderBoardFragmentVM with ChangeNotifier {
  BuildContext context;
  bool weekly = false;
  bool friends = false;
  bool overall = false;
  bool daily = true;
  bool monthly = false;
  bool refer = false;
  bool shouldBlur = false;

  double x;

  String type = "daily";
  bool leaderBoardListLoaded = false;
  List leaderboard = new List();
  List top_list = new List();

  loadLeaderBoard({bool visibleLoad = true}) async {
    if (visibleLoad) {
      leaderBoardListLoaded = false;
      notifyListeners();
    }

    SharedPreferences preferences = await SharedPreferences.getInstance();
    String accessToken = preferences.getString(ACCESS_TOKEN);
    var body = json.encode({'type': this.type});
    var response = await http.post(Uri.encodeFull(UrlHelper.leaderboardList()),
        headers: {
          "Authorization": 'Bearer $accessToken',
          "Content-type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
          "x-api-key": API_KEY,
        },
        body: body);
    //Logger.printWrapped("Leaderboard List :"+response.body);

    var responseBody = json.decode(response.body);
    leaderboard = responseBody['list'];
    top_list = responseBody['top_list'];
    if (responseBody['user_exists_in_top'] != null) {
      //shouldBlur = !responseBody['user_exists_in_top'];
    }

    try {
      FacebookLogger.leaderboardWatch();
    } catch (_) {
      //do something
    }

//    if (leaderboard.last == true){
//      this.x = 56;
//    }
//    else (this.x =0);
    leaderBoardListLoaded = true;
    notifyListeners();
  }

  LeaderBoardFragmentVM(this.context) {
    loadLeaderBoard();
  }

  onSelect(bool value0, value1, value2, value3, value4, value5) {
    this.refer = value0;
    this.daily = value1;
    this.weekly = value2;
    this.monthly = value3;
    this.friends = value4;
    this.overall = value5;

    if (this.refer == true) {
      this.type = "refer";
    } else if (this.weekly == true) {
      this.type = "weekly";
    } else if (this.daily == true) {
      this.type = "daily";
    } else if (this.monthly == true) {
      this.type = "monthly";
    } else if (this.friends == true) {
      this.type = "friends";
    } else if (this.overall == true) {
      this.type = "overall";
    }

    loadLeaderBoard();
    notifyListeners();
  }
}
