/*
* Created by Ahammed Hossain Shanto on 7/12/20
*/

import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/mock-response/MockResponse.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationVM with ChangeNotifier {
  List promotions = new List();
  List notifications = new List();
  bool promotionsLoaded = false;
  bool notificationsLoaded = false;

  NotificationVM() {
    loadNotifications();
    loadPromotions();
  }

  loadNotifications() async {
    notificationsLoaded = false;
    notifyListeners();

    //TODO remove the line below after connecting API
    await Future.delayed(Duration(seconds: 1));

    var response = MockResponse.getNotifications();
    var responseBody = json.decode(response);
    notifications = responseBody['notifications'];
    notificationsLoaded = true;
    notifyListeners();
  }

  loadPromotions() async {
    promotionsLoaded = false;
    notifyListeners();

//    //TODO remove the line below after connecting API
//    await Future.delayed(Duration(seconds: 1));
//    var response = MockResponse.getPromotions();
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String access_token = preferences.getString(ACCESS_TOKEN);

    var response = await http.get(
      Uri.encodeFull(UrlHelper.promotions()),
      headers: {
        "Authorization": 'Bearer $access_token',
        "Content-type": "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "x-api-key": API_KEY,
      },
    );
    //Logger.printWrapped("Promotions:"+response.body);
    var responseBody = json.decode(response.body);
    promotions = responseBody['promotions'];
    promotionsLoaded = true;
    notifyListeners();
  }
}
