/*
* Created by Ahammed Hossain Shanto
* on 7/1/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

class TopicSuggestionToNewUserVM with ChangeNotifier {
  BuildContext context;
  bool suggestionLoaded = false;
  List suggestions = new List();
  List<int> selectedSuggIds = new List();
  bool savingFavourite = false;

  TopicSuggestionToNewUserVM(this.context) {
    loadSuggestions();
  }

  loadSuggestions() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);

    if (access_token != null && access_token.isNotEmpty) {
      suggestionLoaded = false;
      notifyListeners();

      var response = await http.get(Uri.encodeFull(UrlHelper.suggestedCategories()), headers: {
        "Authorization": 'Bearer $access_token',
        "Content-type": "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "x-api-key": API_KEY,
      });

      suggestions = new List();
      var responseBody = json.decode(response.body);
      suggestions = responseBody['categories'];
      suggestionLoaded = true;
      notifyListeners();
    }
  }

  bool isSelected(int id) {
    for (int i = 0; i < selectedSuggIds.length; i++) {
      if (selectedSuggIds[i] == id) {
        return true;
      }
    }
    return false;
  }

  toggleSelection(int id) {
    for (int i = 0; i < selectedSuggIds.length; i++) {
      if (selectedSuggIds[i] == id) {
        selectedSuggIds.removeAt(i);
        notifyListeners();
        return;
      }
    }
    selectedSuggIds.add(id);
    notifyListeners();
  }

  saveFavourites() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String access_token = sharedPreferences.getString(ACCESS_TOKEN);
    if (access_token != null && access_token.toString().isNotEmpty) {
      savingFavourite = true;
      notifyListeners();
      var body = json.encode({
        "categories": _getFavouriteIdList(),
      });

      var response = await http.post(Uri.encodeFull(UrlHelper.followCategories()),
          headers: {
            "Authorization": 'Bearer ${access_token}',
            "Content-type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "x-api-key": API_KEY,
          },
          body: body);

      var responseBody = json.decode(response.body);
      //Logger.printWrapped(responseBody.toString());
      savingFavourite = false;
      notifyListeners();
      if (responseBody['success'] == true) {
        Navigator.pushReplacementNamed(context, UploadAvatarRoute);
      } else {
        Toast.show("Error occured. you can skip this step", context, duration: 2, gravity: 0);
      }
    }
  }

  _getFavouriteIdList() {
    List topicIds = new List();
    for (int i = 0; i < selectedSuggIds.length; i++) {
      topicIds.add({
        "id": selectedSuggIds[i],
      });
    }
    return topicIds;
  }
}
