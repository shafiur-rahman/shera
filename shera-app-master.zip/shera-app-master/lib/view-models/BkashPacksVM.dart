/*
* Created by Ahammed Hossain Shanto
* on 2/24/21
*/

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/models/BCSPackage.dart';
import 'package:quiz/models/TournamentPackage.dart';
import 'package:quiz/utils/Logger.dart';

class BkashPacksVM with ChangeNotifier {
  BuildContext context;
  bool latestTournamentsLoaded = false;
  bool bcsPacksLoaded = false;
  bool tournamentPacksLoaded = false;
  var latestTournaments;
  List<BCSPackage> bcsPackages = [];
  List<TournamentPackage> tournamentPackages = [];

  BkashPacksVM(this.context) {
    loadLatestTournaments();
    loadBcsPacks();
    loadTournamentPacks();
  }


  loadLatestTournaments() async {


    latestTournamentsLoaded = false;
    notifyListeners();

    var response = await http.get(Uri.encodeFull(UrlHelper.latestTournamentsBkash()), headers: {
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    Logger.dlog("", responseBody.toString());
    latestTournaments = responseBody;
    latestTournamentsLoaded = true;
    notifyListeners();
  }

  loadBcsPacks() async {

    bcsPacksLoaded = false;
    notifyListeners();

    var response = await http.get(UrlHelper.bcsPacks(), headers: {
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    BCSPackage.packageTitle = responseBody['name'].toString();
    setBcsPackList(responseBody['packages']);
    bcsPacksLoaded = true;
    notifyListeners();
  }

  setBcsPackList(List<dynamic> values) {
    bcsPackages.clear();
    values.forEach((element) {
      bcsPackages.add(BCSPackage.fromJson(element));
    });
  }

  loadTournamentPacks() async {

    tournamentPacksLoaded = false;
    notifyListeners();

    var response = await http.get(UrlHelper.tournamentPacks(), headers: {
      "Content-type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      "x-api-key": API_KEY,
    });
    var responseBody = json.decode(response.body);
    //Logger.printWrapped(responseBody.toString());
    TournamentPackage.packageTitle = responseBody['name'].toString();
    setTournamentPackList(responseBody['packages']);
    tournamentPacksLoaded = true;
    notifyListeners();
  }

  setTournamentPackList(List<dynamic> values) {
    tournamentPackages.clear();
    values.forEach((element) {
      tournamentPackages.add(TournamentPackage.fromJson(element));
    });
  }
}