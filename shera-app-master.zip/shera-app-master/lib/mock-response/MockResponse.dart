import 'dart:convert';
import 'dart:math';

class MockResponse {
  static String getUpdateResponse() {
    return json.encode({"success": false, "message": "A new and fresh update available", "priority": "high"});
  }

  static String getTokenResponse() {
    return json.encode({"success": true, "message": "Valid token"});
  }

  static String getSendOtp() {
    return json.encode({"success": true, "account_exists": true, "message": "OTP sent successful"});
  }

  static String getVerifyOtp(String pin) {
    if (pin == "1234") {
      return json.encode({"success": true, "message": "OTP matched", "account_exists": true, "user_id": 1234, "access_token": "qertuiosdfghjkrfghjkertyuifghj"});
    } else {
      return json.encode({"success": false, "message": "OTP not matched"});
    }
  }

  static String loginWithEmail(var body) {
    return json.encode({"success": true, "message": "Login Successful", "user_id": 1234, "access_token": "qertuiosdfghjkrfghjkertyuifghj"});
  }

  static String recoverPassword(var body) {
    return json.encode({
      "success": true,
      "message": "Check your email and follow necessary steps",
    });
  }

  static String getCreateUser() {
    return json.encode({"success": true, "message": "Account created successfully", "user_id": 123, "access_token": "abcdefghijklmnopqrstuvwxyz"});
  }

  static String getTopicSuggestion() {
    return json.encode({
      "title": "Suggested Topics",
      "topics": [
        {"topic_id": 1, "name": "Bangladesh", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 2, "name": "History", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 3, "name": "Movie", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 4, "name": "Books", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 5, "name": "Technology", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 6, "name": "Science", "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 7, "name": "General Knowledge", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 8, "name": "BCS", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 9, "name": "Sports", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 10, "name": "TV Series", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 11, "name": "World", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
        {"topic_id": 12, "name": "Business", "image_url": "topics/country.png", "weight": 0, "category_id": 2, "Follower_count": 4, "description": "Country"},
      ]
    });
  }

  static String saveFavouriteTopics(var ids) {
    return json.encode({"success": true, "message": "Topics added successfully"});
  }

  static String getProfile() {
    return json.encode({
      "id": 123,
      "name": "Ahammed Shanto",
      "phone": "1902612426",
      "country_code": "+880",
      "email": "abc@gmail.com",
      "image_url": "https://widgetwhats.com/app/uploads/2019/11/free-profile-photo-whatsapp-4-300x300.png",
      "level": "Fish 5",
      "level_progress": 75.0,
      "points": 2075,
      "next_level": "Fish 6",
      "wallet": {"gems": 10, "coins": 200},
      "win_status_available": true,
      "win": 70.5,
      "loss": 10,
      "draw": 19.5
    });
  }

  static String getUpdateProfile(var body) {
    //Logger.printWrapped(body.toString());
    return json.encode({
      "success": true,
      "message": "Profile updated successfully",
    });
  }

  static String getDailyTask() {
    return json.encode({"title": "Play 10 quiz and win 100 coins", "caption": "You played 3/10", "progress": 60.0, "icon": "/coins.png"});
  }

  static String getLatestTournaments() {
    return json.encode({
      "title": "Latest Tournaments",
      "tournaments": [
        {"id": 1, "name": "Cinema 101", "caption": "", "time_left": "2 hour 16 min", "prize": "Won 1 year netflix subscription", "prize_count": "how many people is going to win", "started": false, "ended": false, "start_time": "DateTime ISO8601 standard", "end_time": "DateTime ISO8601 standard"},
        {"id": 2, "name": "Cinema 102", "caption": "", "time_left": "6 days 2 hour", "prize": "Won 1 year netflix subscription", "prize_count": "how many people is going to win", "started": false, "ended": false, "start_time": "DateTime ISO8601 standard", "end_time": "DateTime ISO8601 standard"},
        {"id": 3, "name": "Cinema 103", "caption": "", "time_left": "2 hour 16 min", "prize": "Won 1 year netflix subscription", "prize_count": "how many people is going to win", "started": false, "ended": false, "start_time": "DateTime ISO8601 standard", "end_time": "DateTime ISO8601 standard"},
        {"id": 4, "name": "Cinema 104", "caption": "", "time_left": "6 days 2 hour", "prize": "Won 1 year netflix subscription", "prize_count": "how many people is going to win", "started": false, "ended": false, "start_time": "DateTime ISO8601 standard", "end_time": "DateTime ISO8601 standard"}
      ]
    });
  }

  static String getTopDeals() {
    return json.encode({
      "title": "Latest Tournaments",
      "deals": [
        {
          "bundle_id": 1,
          "deal_name": "PANINI",
          "image_url": "https://pngriver.com/wp-content/uploads/2018/04/Download-Coins-PNG-Pic.png",
          "amount": "2500",
          "price": "699",
        },
        {"bundle_id": 2, "deal_name": "PANINI", "image_url": "http://www.pngmart.com/files/3/Coins-PNG-Photos.png", "amount": "2500", "price": "599", "pp_coins": "250", "pp_price": "250"},
        {"bundle_id": 3, "deal_name": "PANINI", "image_url": "http://www.pngmart.com/files/3/Coins-PNG-Photos.png", "amount": "2500", "price": "499", "pp_coins": "250", "pp_price": "250"},
        {"bundle_id": 4, "deal_name": "PANINI", "image_url": "https://pngriver.com/wp-content/uploads/2018/04/Download-Coins-PNG-Pic.png", "amount": "2500", "price": "499", "pp_coins": "250", "pp_price": "250"},
        {"bundle_id": 4, "deal_name": "PANINI", "image_url": "http://www.pngmart.com/files/3/Coins-PNG-Photos.png", "amount": "2500", "price": "499", "pp_coins": "250", "pp_price": "250"},
        {"bundle_id": 4, "deal_name": "PANINI", "image_url": "https://img.icons8.com/nolan/64/film-reel.png", "amount": "2500", "price": "499", "pp_coins": "250", "pp_price": "250"},
      ]
    });
  }

  static String getTournamentDetails(var body) {
    return json.encode({
      "tournament": {"id": 123, "name": "Cinema Khor 101", "caption": "", "time_left": "2 hour 16 min", "prize": "Win 1 year netflix subscription", "prize_count": "5", "started": false, "ended": false, "start_time": "DateTime ISO8601 standard", "end_time": "DateTime ISO8601 standard", "subscribed": false, "subscription_fee": 5, "subscriber_count": 100, "description": "31th BCS"},
      "ranking": [
        {"user_id": 1, "name": "MD", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "friend/not_friend/pending/blocked/unavailable", "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 750, "position": 125, "self": false},
        {"user_id": 2, "name": "History", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg", "points": 850, "position": 126, "self": true},
        {"user_id": 3, "name": "Shila", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "position": 127, "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 800, "self": false}
      ]
    });
  }

  static String seeAll() {
    return json.encode({
      "page_count": 10,
      "ranking": [
        {"user_id": 1, "name": "MD", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "friend/not_friend/pending/blocked/unavailable", "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 750, "position": 125, "self": false},
        {"user_id": 2, "name": "History", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg", "points": 850, "position": 126, "self": true},
        {"user_id": 3, "name": "Shila", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "position": 127, "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 800, "self": false}
      ]
    });
  }

  static String getTopTopics() {
    return json.encode({
      "title": "Top Topics",
      "topics": [
        {"topic_id": 1, "name": "Technical", "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png", "weight": 0, "category_id": 2, "category_name": "Education", "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
        {"topic_id": 2, "name": "Movie", "image_url": "https://img.icons8.com/nolan/64/film-reel.png", "weight": 0, "category_id": 2, "category_name": "Education", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 3, "name": "Country", "image_url": "https://img.icons8.com/color/48/000000/bangladesh.png", "weight": 0, "category_id": 2, "category_name": "Education", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
      ]
    });
  }

  static String getTopTopicsAll() {
    return json.encode({
      "title": "Top Topics",
      "topics": [
        {"topic_id": 1, "name": "Technical", "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png", "weight": 0, "category_id": 2, "category_name": "Education", "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
        {"topic_id": 2, "name": "Movie", "image_url": "https://img.icons8.com/nolan/64/film-reel.png", "weight": 0, "category_id": 2, "category_name": "Education", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 3, "name": "Country", "image_url": "https://img.icons8.com/color/48/000000/bangladesh.png", "weight": 0, "category_id": 2, "category_name": "Education", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 4, "name": "Oscar Films", "image_url": "https://img.icons8.com/fluent/48/000000/medal.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 5, "name": "Celebrity", "image_url": "https://img.icons8.com/color/48/000000/sophia-loren.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
        {"topic_id": 6, "name": "General Knowledge", "image_url": "https://img.icons8.com/nolan/64/knowledge-sharing.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 7, "name": "General Knowledge", "image_url": "https://img.icons8.com/nolan/64/knowledge-sharing.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 8, "name": "Technical", "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
      ]
    });
  }

  static String getFavouriteTopics() {
    return json.encode({
      "title": "Favourite Topics",
      "topics": [
        {"topic_id": 1, "name": "Oscar Films", "image_url": "https://img.icons8.com/fluent/48/000000/medal.png", "weight": 0, "category_id": 2, "category_name": "Films", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 2, "name": "Celebrity", "image_url": "https://img.icons8.com/color/48/000000/sophia-loren.png", "weight": 0, "category_id": 2, "category_name": "Films", "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
        {"topic_id": 3, "name": "General Knowledge", "image_url": "https://img.icons8.com/nolan/64/knowledge-sharing.png", "weight": 0, "category_id": 2, "category_name": "Films", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
      ]
    });
  }

  static String getFavouriteTopicsAll() {
    return json.encode({
      "title": "Favourite Topics",
      "topics": [
        {"topic_id": 1, "name": "Oscar Films", "image_url": "https://img.icons8.com/fluent/48/000000/medal.png", "weight": 0, "category_id": 2, "category_name": "Films", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 2, "name": "Celebrity", "image_url": "https://img.icons8.com/color/48/000000/sophia-loren.png", "weight": 0, "category_id": 2, "category_name": "Films", "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
        {"topic_id": 3, "name": "General Knowledge", "image_url": "https://img.icons8.com/nolan/64/knowledge-sharing.png", "weight": 0, "category_id": 2, "category_name": "Education", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 4, "name": "Technical", "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
        {"topic_id": 5, "name": "Movie", "image_url": "https://img.icons8.com/nolan/64/film-reel.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 6, "name": "Country", "image_url": "https://img.icons8.com/color/48/000000/bangladesh.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 7, "name": "General Knowledge", "image_url": "https://img.icons8.com/nolan/64/knowledge-sharing.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 8, "name": "Technical", "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
      ]
    });
  }

  static String getTopicsOfCategory(var body) {
    //Logger.printWrapped(body.toString());
    return json.encode({
      "title": "Favourite Topics",
      "topics": [
        {"topic_id": 1, "name": "Oscar Films", "image_url": "https://img.icons8.com/fluent/48/000000/medal.png", "weight": 0, "category_id": 2, "category_name": "Films", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 2, "name": "Celebrity", "image_url": "https://img.icons8.com/color/48/000000/sophia-loren.png", "weight": 0, "category_id": 2, "category_name": "Films", "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
        {"topic_id": 3, "name": "General Knowledge", "image_url": "https://img.icons8.com/nolan/64/knowledge-sharing.png", "weight": 0, "category_id": 2, "category_name": "Education", "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 4, "name": "Technical", "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
        {"topic_id": 5, "name": "Movie", "image_url": "https://img.icons8.com/nolan/64/film-reel.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 6, "name": "Country", "image_url": "https://img.icons8.com/color/48/000000/bangladesh.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 7, "name": "General Knowledge", "image_url": "https://img.icons8.com/nolan/64/knowledge-sharing.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": true, "progress": 2.5, "description": "Country"},
        {"topic_id": 8, "name": "Technical", "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png", "weight": 0, "category_id": 2, "follower_count": 4, "following": false, "progress": 2.5, "description": "Country"},
      ]
    });
  }

  static String getInterestedCategories() {
    return json.encode({
      "title": "Your Interest",
      "categories": [
        {
          "category_id": 1,
          "name": "Play Technical Quiz",
          "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png",
          "weight": 0,
          "follower_count": 4,
          "following": true,
          "progress": 80.1,
        },
        {"category_id": 2, "name": "Play Chemistry Quiz", "image_url": "https://img.icons8.com/doodle/96/000000/test-tube--v1.png", "weight": 0, "follower_count": 4, "following": false, "progress": 30.2, "description": "Country"},
      ]
    });
  }

  static String getCategoriesPlayed() {
    return json.encode({
      "categories": [
        {"id": 1, "name": "Engineering", "image_url": "", "progress": 12.5, "weight": 0},
        {"id": 2, "name": "Technology", "image_url": "", "progress": 66.8, "weight": 0},
        {"id": 3, "name": "English", "image_url": "", "progress": 45, "weight": 0},
        {"id": 4, "name": "Bangla", "image_url": "", "progress": 100, "weight": 0}
      ]
    });
  }

  static String getAllCategories() {
    return json.encode({
      "categories": [
        {"id": 1, "name": "Engineering", "image_url": "https://img.icons8.com/plasticine/100/000000/broken-robot.png", "progress": 12.5, "follower_count": 4, "following": false, "weight": 0},
        {"id": 2, "name": "Technology", "image_url": "https://img.icons8.com/nolan/64/film-reel.png", "progress": 66.8, "follower_count": 4, "following": false, "weight": 0},
        {"id": 3, "name": "English", "image_url": "https://img.icons8.com/color/48/000000/bangladesh.png", "progress": 45, "follower_count": 4, "following": false, "weight": 0},
        {"id": 4, "name": "Bangla", "image_url": "https://img.icons8.com/nolan/64/film-reel.png", "progress": 100, "follower_count": 4, "following": false, "weight": 0}
      ]
    });
  }

  static String getToggleFavourite(var body) {
    //var bodyEncoded = json.encode(body.toString());
    var bodyDecoded = json.decode(json.decode(body.toString()));
    //Logger.printWrapped(bodyDecoded.toString());
    return json.encode({"success": true, "following": bodyDecoded['follow'], "message": "You are following this topic"});
  }

  static String getTopicDetails(var body) {
    var bodyDecoded = json.decode(body);
    return json.encode({
      "topic": {"id": 15, "name": "Oscar Films", "image_url": "https://img.icons8.com/fluent/48/000000/medal.png", "weight": 0, "category_id": 1, "category_name": "Movie", "follower_count": 225, "participant_count": 10, "description": "31th BCS"},
      "ranking": [
        {"user_id": 1, "name": "MD", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "friend/not_friend/pending/blocked/unavailable", "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 750, "position": 125, "self": false},
        {"user_id": 2, "name": "History", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg", "points": 850, "position": 126, "self": true},
        {"user_id": 3, "name": "Shila", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "position": 127, "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 800, "self": false}
      ],
      "progress": 73.5,
      "level": "Fish II",
      "next_level": "Fish III",
      "following": false,
      "rc": 0
    });
  }

  static String getSpinInfo() {
    return json.encode({
      "spin_available": true,
      "next_spin_left": "11 hr",
      "other_option": [
        {"id": 123, "title": "Spin again using 1 BDT"},
        {"id": 12, "title": "Spin again using 100 coins"},
        {"id": 13, "title": "Watch AD"}
      ]
    });
  }

  static String getSubmitSpin() {
    return json.encode({"result_index": Random().nextInt(8), "next_spin_left": "24 hr", "gift_type": 1, "amount": 20});
  }

  static String getSpinByAd() {
    return json.encode({
      "success": true,
      "message": "",
    });
  }

  static String getPurchaseHistory(var body) {
    var bodyContent = json.decode(body);
    if (bodyContent['type'] == "this_week") {
      return json.encode({
        "history": [
          {"id": 1, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Bundle of coins & gems", "caption": "3,500 Coins 35 Gems", "coins": 3500, "gems": 35, "type": "subscription", "subscribed": true, "price": 1.28},
          {"id": 2, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Lots of coins", "caption": "4,500 Coins", "coins": 4500, "gems": 0, "type": "coins", "subscribed": false, "price": 1.28}
        ]
      });
    } else if (bodyContent['type'] == "this_month") {
      return json.encode({
        "history": [
          {"id": 1, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Bundle of coins & gems", "caption": "3,500 Coins 35 Gems", "coins": 3500, "gems": 35, "type": "subscription", "subscribed": true, "price": 1.28},
          {"id": 2, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Lots of coins", "caption": "4,500 Coins", "coins": 4500, "gems": 0, "type": "coins", "subscribed": false, "price": 1.28},
          {"id": 3, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Bundle of coins & gems 2", "caption": "3,500 Coins 35 Gems", "coins": 3500, "gems": 35, "type": "subscription", "subscribed": true, "price": 1.28},
        ]
      });
    } else if (bodyContent['type'] == "this_year") {
      return json.encode({
        "history": [
          {"id": 1, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Bundle of coins & gems", "caption": "3,500 Coins 35 Gems", "coins": 3500, "gems": 35, "type": "subscription", "subscribed": true, "price": 1.28},
          {"id": 2, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Lots of coins", "caption": "4,500 Coins", "coins": 4500, "gems": 0, "type": "coins", "subscribed": false, "price": 1.28},
          {"id": 3, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Bundle of coins & gems 2", "caption": "3,500 Coins 35 Gems", "coins": 3500, "gems": 35, "type": "subscription", "subscribed": true, "price": 1.28},
          {"id": 4, "purchased_at": "15 OCT 2020, 08:41 PM", "title": "Lots of coins 2", "caption": "4,500 Coins", "coins": 4500, "gems": 0, "type": "coins", "subscribed": false, "price": 1.28}
        ]
      });
    } else {
      return "";
    }
  }

  static String getLeaderBoardHistory(var body) {
    var bodyContent = json.decode(body);
    if (bodyContent['type'] == "weekly") {
      return json.encode({
        "title": "Leader Board list",
        "List": [
          {"user_id": 1, "name": "MD", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "friend/not_friend/pending/blocked/unavailable", "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 100, "position": 125, "self": false},
          {"user_id": 2, "name": "History", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg", "points": 100, "position": 126, "self": true},
          {"user_id": 3, "name": "Shila", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "position": 127, "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 100, "self": false}
        ],
        "Top_list": [
          {
            "user_id": 1,
            "name": "Shorol",
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 1,
            "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
            "points": 100,
            "self": false,
          },
          {
            "user_id": 2,
            "name": "Saddam",
            "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg",
            "points": 100,
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 2,
            "self": false,
          },
          {
            "topic_id": 3,
            "name": "Billah",
            "image_url": "https://www.wallpaperflare.com/static/540/70/496/tom-hardy-man-actor-celebrity-wallpaper.jpg",
            "points": 100,
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 3,
            "self": false,
          },
        ]
      });
    } else if (bodyContent['type'] == "friends") {
      return json.encode({
        "title": "Leader Board list",
        "List": [
          {"user_id": 1, "name": "MD", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "friend/not_friend/pending/blocked/unavailable", "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 100, "position": 125, "self": false},
          {"user_id": 2, "name": "History", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg", "points": 100, "position": 126, "self": true},
          {"user_id": 3, "name": "Shila", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "position": 127, "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 100, "self": false}
        ],
        "Top_list": [
          {
            "user_id": 1,
            "name": "Shorol",
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 1,
            "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
            "points": 100,
            "self": false,
          },
          {
            "user_id": 2,
            "name": "Saddam",
            "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg",
            "points": 100,
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 2,
            "self": false,
          },
          {
            "topic_id": 3,
            "name": "Billah",
            "image_url": "https://www.wallpaperflare.com/static/540/70/496/tom-hardy-man-actor-celebrity-wallpaper.jpg",
            "points": 100,
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 3,
            "self": false,
          },
        ]
      });
    } else if (bodyContent['type'] == "overall") {
      return json.encode({
        "title": "Leader Board list",
        "List": [
          {"user_id": 1, "name": "MD", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "friend/not_friend/pending/blocked/unavailable", "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 100, "position": 125, "self": false},
          {"user_id": 2, "name": "History", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg", "points": 100, "position": 126, "self": true},
          {"user_id": 3, "name": "Shila", "level": "Fish I", "total_point": 7500, "tournament_played": 10, "tournament_win": 1, "topic_high_score": 15221, "friendship_status": "not_friend", "position": 127, "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", "points": 100, "self": false}
        ],
        "Top_list": [
          {
            "user_id": 1,
            "name": "Shorol",
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 1,
            "image_url": "https://images.unsplash.com/photo-1518806118471-f28b20a1d79d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
            "points": 100,
            "self": false,
          },
          {
            "user_id": 2,
            "name": "Saddam",
            "image_url": "https://i.pinimg.com/originals/2e/2f/ac/2e2fac9d4a392456e511345021592dd2.jpg",
            "points": 100,
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 2,
            "self": false,
          },
          {
            "topic_id": 3,
            "name": "Billah",
            "image_url": "https://www.wallpaperflare.com/static/540/70/496/tom-hardy-man-actor-celebrity-wallpaper.jpg",
            "points": 100,
            "level": "Fish I",
            "total_point": 7500,
            "tournament_played": 10,
            "tournament_win": 1,
            "topic_high_score": 15221,
            "friendship_status": "not_friend",
            "position": 3,
            "self": false,
          },
        ]
      });
    } else {
      return "";
    }
  }

  static String getNotifications() {
    return json.encode({
      "notifications": [
        {
          "id": 1,
          "title": "you have reach 200 Coins | by Watch Video",
          "caption": "starting soon",
          "body": "xxxxxx tournamet/topic has been started",
          "datetime": "15 june, 2020",
          "data": {"tournament_id": 111, "topic_id": 222}
        },
        {
          "id": 2,
          "title": "you have reach 200 Coins | by Watch Video",
          "caption": "starting soon - 22",
          "body": "tournamet/topic has been started",
          "datetime": "16 june, 2020",
          "data": {"tournament_id": 111, "topic_id": 222}
        },
        {
          "id": 1,
          "title": "you have reach 200 Coins | by Watch Video",
          "caption": "starting soon",
          "body": "xxxxxx tournamet/topic has been started",
          "datetime": "15 june, 2020",
          "data": {"tournament_id": 111, "topic_id": 222}
        },
        {
          "id": 2,
          "title": "you have reach 200 Coins | by Watch Video",
          "caption": "starting soon - 22",
          "body": "tournamet/topic has been started",
          "datetime": "16 june, 2020",
          "data": {"tournament_id": 111, "topic_id": 222}
        },
        {
          "id": 1,
          "title": "you have reach 200 Coins | by Watch Video",
          "caption": "starting soon",
          "body": "xxxxxx tournamet/topic has been started",
          "datetime": "15 june, 2020",
          "data": {"tournament_id": 111, "topic_id": 222}
        },
        {
          "id": 2,
          "title": "you have reach 200 Coins | by Watch Video",
          "caption": "starting soon - 22",
          "body": "tournamet/topic has been started",
          "datetime": "16 june, 2020",
          "data": {"tournament_id": 111, "topic_id": 222}
        },
      ]
    });
  }

  static String getPromotions() {
    return json.encode({
      "promotions": [
        {"id": 1, "title": "Notification from tournament/topic", "caption": "Refer your friends to QuizGiri App, both of you will get a bonus of 140 Coins", "body": "xxxxxx tournamet/topic has been started", "datetime": "15 june, 2020", "banner_url": "https://cdn.shortpixel.ai/client/q_glossy,ret_img,w_1200/https://blog.snappa.com/wp-content/uploads/2018/03/twitch-banner-size-2.jpg"},
        {"id": 2, "title": "Notification from tournament/topic", "caption": "Refer your friends to QuizGiri App, both of you will get a bonus of 140 Coins", "body": "xxxxxx tournamet/topic has been started", "datetime": "15 june, 2020", "banner_url": "https://s3.envato.com/files/130424404/970x250.jpg"},
        {"id": 3, "title": "Notification from tournament/topic", "caption": "Refer your friends to QuizGiri App, both of you will get a bonus of 140 Coins", "body": "xxxxxx tournamet/topic has been started", "datetime": "15 june, 2020", "banner_url": "https://placeit-assets0.s3-accelerate.amazonaws.com/custom-pages/make-a-twitch-banner2/Purple-Twitch-Banner-1024x324.png"}
      ]
    });
  }

  static String getGameStart(var body) {
    return json.encode({
      "wallet": {"coins": 250, "gems": 5},
      "game_id": "d6c5e425-186a-4ff5-92d6-d43e7d4454b6",
      "game_type": "topic/tournament",
      "retry_coin_amount": 99,
      "progress": 25,
      "progress_category": 10,
      "question": {
        "type": 1,
        "option_type": 1,
        "src_url": "https://quizgiri.xyz/video/abc.mp4",
        "timer": 2,
        "question_no": 1,
        "question_left": 6,
        "question_id": 142,
        "question_value": "Which of the following actor own OSCAR in 2019?",
        "options": [
          {"id": 1, "src_url": "", "value": "Gary Oldmand"},
          {"id": 2, "src_url": "", "value": "Joaquin phonix"},
          {"id": 3, "type": "1/2 according to text/image", "src_url": "", "value": "Casey Affleck"},
          {"id": 4, "src_url": "", "value": "Leonardo Dicaprio"}
        ]
      }
    });
  }

  static String getTournamentStart(var body) {
    return json.encode({
      "tournament_id": "d6c5e425-186a-4ff5-92d6-d43e7d4454b6",
      "game_type": "tournament",
      "play_duration": 10,
      "wallet": {"coins": 250, "gems": 5},
      "retry_coin_amount": 99,
      "progress": 25,
      "progress_category": 10,
      "question": {
        "type": 1,
        "option_type": 1,
        "src_url": "https://quizgiri.xyz/video/abc.mp4",
        "question_no": 1,
        "question_left": 6,
        "question_id": 142,
        "question_value": "Which of the following actor own OSCAR in 2019?",
        "options": [
          {"id": 1, "src_url": "", "value": "Gary Oldmand"},
          {"id": 2, "src_url": "", "value": "Joaquin phonix"},
          {"id": 3, "type": "1/2 according to text/image", "src_url": "", "value": "Casey Affleck"},
          {"id": 4, "src_url": "", "value": "Leonardo Dicaprio"}
        ]
      }
    });
  }

  static String getAnswerSubmitResult(var body) {
    //Logger.printWrapped(body.toString());

    int result = Random().nextInt(6);
    bool questionFinished = (Random().nextBool() && Random().nextBool() && Random().nextBool());
    double progress_topic = 36.0;

    if (result == 0) {
      bool correct = Random().nextBool();
      return json.encode({
        "is_correct": correct,
        "retry_coin_amount": 100,
        "correct_id": correct
            ? json.decode(body)['answer_id']
            : json.decode(body)['answer_id'] == 2
                ? 1
                : 2,
        "question_finished": questionFinished,
        "progress_topic": progress_topic,
        "progress_category": 10,
        "next_topic_id": 12,
        "next_topic_category": "Sports",
        "next_topic_title": "Cricket",
        "total_quiz": 30,
        "total_correct": 10,
        "level": "Fish I",
        "question": {
          "type": 1,
          "option_type": 1,
          "src_url": "https://quizgiri.xyz/video/abc.mp4",
          "timer": 10,
          "question_no": 12,
          "question_left": 6,
          "question_id": 142,
          "question_value": "(x-y, 3) = ( 0, x+2y) হলে (x,y) = কত ?",
          "options": [
            {"id": 1, "src_url": "", "value": "(1, 3)"},
            {"id": 2, "src_url": "", "value": "(-3, 1)"},
            {"id": 3, "src_url": "", "value": "(1,1)"},
            {"id": 4, "src_url": "", "value": "(-1,-1)"}
          ]
        }
      });
    } else if (result == 1) {
      bool correct = Random().nextBool();
      return json.encode({
        "is_correct": correct,
        "retry_coin_amount": 100,
        "correct_id": correct
            ? json.decode(body)['answer_id']
            : json.decode(body)['answer_id'] == 2
                ? 1
                : 2,
        "question_finished": questionFinished,
        "progress_topic": progress_topic,
        "next_topic_id": 12,
        "next_topic_category": "Sports",
        "next_topic_title": "Cricket",
        "total_quiz": 30,
        "total_correct": 10,
        "progress_category": 10,
        "level": "Fish I",
        "question": {
          "type": 1,
          "option_type": 1,
          "src_url": "https://see.news/wp-content/uploads/2020/05/Facebook-company.jpg",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "Who is the founder of Microsoft",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "Mark Zuckerberg"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "Steve Jobs"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "Dr. A.P.J. Abdul Kalam"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "Bill Gates"}
          ]
        }
      });
    } else if (result == 2) {
      bool correct = Random().nextBool();
      return json.encode({
        "is_correct": correct,
        "retry_coin_amount": 100,
        "correct_id": correct
            ? json.decode(body)['answer_id']
            : json.decode(body)['answer_id'] == 2
                ? 1
                : 2,
        "question_finished": questionFinished,
        "progress_topic": progress_topic,
        "progress_category": 10,
        "next_topic_id": 12,
        "next_topic_category": "Sports",
        "next_topic_title": "Cricket",
        "total_quiz": 30,
        "total_correct": 10,
        "level": "Fish I",
        "question": {
          "type": 1,
          "option_type": 2,
          "src_url": "https://see.news/wp-content/uploads/2020/05/Facebook-company.jpg",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "Who is the founder of Facebook",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "Mark Zuckerberg"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "Steve Jobs"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "Dr. A.P.J. Abdul Kalam"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "Bill Gates"}
          ]
        }
      });
    } else if (result == 3) {
      bool correct = Random().nextBool();
      return json.encode({
        "is_correct": correct,
        "retry_coin_amount": 100,
        "correct_id": correct
            ? json.decode(body)['answer_id']
            : json.decode(body)['answer_id'] == 2
                ? 1
                : 2,
        "question_finished": questionFinished,
        "progress_topic": progress_topic,
        "progress_category": 10,
        "level": "Fish I",
        "next_topic_id": 12,
        "next_topic_category": "Sports",
        "next_topic_title": "Cricket",
        "total_quiz": 30,
        "total_correct": 10,
        "question": {
          "type": 2,
          "option_type": 1,
          "src_url": "https://see.news/wp-content/uploads/2020/05/Facebook-company.jpg",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "Who is the founder of the company shown in image",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "Mark Zuckerberg"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "Steve Jobs"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "Dr. A.P.J. Abdul Kalam"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "Bill Gates"}
          ]
        }
      });
    } else if (result == 4) {
      bool correct = Random().nextBool();
      return json.encode({
        "is_correct": correct,
        "retry_coin_amount": 100,
        "correct_id": correct
            ? json.decode(body)['answer_id']
            : json.decode(body)['answer_id'] == 2
                ? 1
                : 2,
        "question_finished": questionFinished,
        "progress_topic": progress_topic,
        "progress_category": 10,
        "level": "Fish I",
        "next_topic_id": 12,
        "next_topic_category": "Sports",
        "next_topic_title": "Cricket",
        "total_quiz": 30,
        "total_correct": 10,
        "question": {
          "type": 4,
          "option_type": 1,
          "src_url": "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
          //"src_url" : "https://luan.xyz/files/audio/nasa_on_a_mission.mp3",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "What you have seen in the video",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "A Dog"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "A Cat"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "A Bee"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "A Butterfly"}
          ]
        }
      });
    } else if (result == 5) {
      bool correct = Random().nextBool();
      return json.encode({
        "is_correct": correct,
        "retry_coin_amount": 100,
        "correct_id": correct
            ? json.decode(body)['answer_id']
            : json.decode(body)['answer_id'] == 2
                ? 1
                : 2,
        "question_finished": questionFinished,
        "progress_topic": progress_topic,
        "progress_category": 10,
        "level": "Fish I",
        "next_topic_id": 12,
        "next_topic_category": "Sports",
        "next_topic_title": "Cricket",
        "total_quiz": 30,
        "total_correct": 10,
        "question": {
          "type": 3,
          "option_type": 1,
          "src_url": "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
          //"src_url" : "https://luan.xyz/files/audio/nasa_on_a_mission.mp3",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "What you have heard in the video",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "A Dog"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "A Cat"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "A Bee"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "A Butterfly"}
          ]
        }
      });
    } else {
      bool correct = Random().nextBool();
      return json.encode({
        "is_correct": correct,
        "retry_coin_amount": 100,
        "correct_id": correct
            ? json.decode(body)['answer_id']
            : json.decode(body)['answer_id'] == 2
                ? 1
                : 2,
        "question_finished": questionFinished,
        "progress_topic": progress_topic,
        "progress_category": 10,
        "level": "Fish I",
        "next_topic_id": 12,
        "next_topic_category": "Sports",
        "next_topic_title": "Cricket",
        "total_quiz": 30,
        "total_correct": 10,
        "question": {
          "type": 2,
          "option_type": 2,
          "src_url": "https://see.news/wp-content/uploads/2020/05/Facebook-company.jpg",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "Who is the founder of this Company",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "Mark Zuckerberg"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "Steve Jobs"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "Dr. A.P.J. Abdul Kalam"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "Bill Gates"}
          ]
        }
      });
    }
  }

  static String getTimeUp(var body) {
    //Logger.printWrapped(body.toString());

    int result = Random().nextInt(4);

    if (result == 0) {
      bool correct = Random().nextBool();
      return json.encode({
        "retry_coin_amount": 100,
        "question_finished": (Random().nextBool() && Random().nextBool() && Random().nextBool()),
        "progress": 25,
        "progress_category": 10,
        "level": "Fish I",
        "question": {
          "type": 1,
          "option_type": 1,
          "src_url": "https://quizgiri.xyz/video/abc.mp4",
          "timer": 10,
          "question_no": 12,
          "question_left": 6,
          "question_id": 142,
          "question_value": "(x-y, 3) = ( 0, x+2y) হলে (x,y) = কত ?",
          "options": [
            {"id": 1, "src_url": "", "value": "(1, 3)"},
            {"id": 2, "src_url": "", "value": "(-3, 1)"},
            {"id": 3, "src_url": "", "value": "(1,1)"},
            {"id": 4, "src_url": "", "value": "(-1,-1)"}
          ]
        }
      });
    } else if (result == 1) {
      bool correct = Random().nextBool();
      return json.encode({
        "retry_coin_amount": 100,
        "question_finished": (Random().nextBool() && Random().nextBool() && Random().nextBool()),
        "progress": 25,
        "progress_category": 10,
        "level": "Fish I",
        "question": {
          "type": 1,
          "option_type": 1,
          "src_url": "https://see.news/wp-content/uploads/2020/05/Facebook-company.jpg",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "Who is the founder of Microsoft",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "Mark Zuckerberg"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "Steve Jobs"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "Dr. A.P.J. Abdul Kalam"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "Bill Gates"}
          ]
        }
      });
    } else if (result == 2) {
      bool correct = Random().nextBool();
      return json.encode({
        "retry_coin_amount": 100,
        "question_finished": (Random().nextBool() && Random().nextBool() && Random().nextBool()),
        "progress": 25,
        "progress_category": 10,
        "level": "Fish I",
        "question": {
          "type": 1,
          "option_type": 2,
          "src_url": "https://see.news/wp-content/uploads/2020/05/Facebook-company.jpg",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "Who is the founder of Facebook",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "Mark Zuckerberg"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "Steve Jobs"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "Dr. A.P.J. Abdul Kalam"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "Bill Gates"}
          ]
        }
      });
    } else if (result == 3) {
      bool correct = Random().nextBool();
      return json.encode({
        "retry_coin_amount": 100,
        "question_finished": (Random().nextBool() && Random().nextBool() && Random().nextBool()),
        "progress": 25,
        "progress_category": 10,
        "level": "Fish I",
        "question": {
          "type": 2,
          "option_type": 1,
          "src_url": "https://see.news/wp-content/uploads/2020/05/Facebook-company.jpg",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "Who is the founder of the company shown in image",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "Mark Zuckerberg"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "Steve Jobs"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "Dr. A.P.J. Abdul Kalam"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "Bill Gates"}
          ]
        }
      });
    } else {
      bool correct = Random().nextBool();
      return json.encode({
        "retry_coin_amount": 100,
        "question_finished": (Random().nextBool() && Random().nextBool() && Random().nextBool()),
        "progress": 25,
        "progress_category": 10,
        "level": "Fish I",
        "question": {
          "type": 2,
          "option_type": 2,
          "src_url": "https://see.news/wp-content/uploads/2020/05/Facebook-company.jpg",
          "timer": 10,
          "question_no": 12,
          "question_left": 2,
          "question_id": 142,
          "question_value": "Who is the founder of this Company",
          "options": [
            {"id": 1, "src_url": "https://upload.wikimedia.org/wikipedia/commons/1/14/Mark_Zuckerberg_F8_2018_Keynote_%28cropped_2%29.jpg", "value": "Mark Zuckerberg"},
            {"id": 2, "src_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dc/Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg/1200px-Steve_Jobs_Headshot_2010-CROP_%28cropped_2%29.jpg", "value": "Steve Jobs"},
            {"id": 3, "src_url": "https://upload.wikimedia.org/wikipedia/commons/b/b0/A._P._J._Abdul_Kalam_in_2008.jpg", "value": "Dr. A.P.J. Abdul Kalam"},
            {"id": 4, "src_url": "https://m.economictimes.com/thumb/msid-63134251,width-1200,height-900,resizemode-4,imgsize-22881/bill-gates-says-us-will-have-another-financial-crisis-similar-to-2008.jpg", "value": "Bill Gates"}
          ]
        }
      });
    }
  }

  static String getSettings() {
    return json.encode({"daily_updates": false, "new_topics": false, "allow_friend_requests": true, "allow_challenges": false});
  }

  static String updateSettings(var body) {
    //Logger.printWrapped(json.decode(body).toString());
    return json.encode({
      "success": true,
      "message": "Settings updated successfully",
    });
  }

  static String retryUsingCoin(var body) {
    //Logger.printWrapped(json.decode(body).toString());
    return json.encode({
      "success": true,
      "message": "Enough coins not available",
    });
  }

  static String retryUsingAd(var body) {
    //Logger.printWrapped(json.decode(body).toString());
    return json.encode({
      "success": true,
      "message": "Enough coins not available",
    });
  }

  static String sendFriendRequest(int userId) {
    return json.encode({
      "success": true,
      "message": "Request sent",
    });
  }

  static String refreshFcmToken(var body) {
    return json.encode({
      "success": true,
      "message": "Token Refreshed",
    });
  }

  static String challengeResult() {
    return json.encode({
      "result": {
        "self": {"avatar": "https://www.beautycastnetwork.com/images/banner-profile_pic.jpg", "name": "Shafiur", "winner": true, "win_count": 1, "correct_answer": 18, "wrong_answer": 12, "played": true},
        "opponent": {"avatar": "https://www.fairtravel4u.org/wp-content/uploads/2018/06/sample-profile-pic.png", "name": "Shanto", "winner": false, "win_count": 0, "correct_answer": 16, "wrong_answer": 14, "played": true}
      },
    });
  }

  static String getInvitation() {
    return json.encode({"invite_code": "ABC123", "title": "Invite & Win", "description": "Invite a friend & get 2000 coins"});
  }

  static String getReferralBanner() {
    return json.encode({"image_url": "https://i.ibb.co/rvkSNNm/refer.jpg"});
  }
}
