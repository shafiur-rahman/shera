/*
* Created by Ahammed Hossain Shanto
* on 2/7/21
*/

import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/AppSessionSettings.dart';

class LocaleValues {
  static LocaleValues _instance;

  static LocaleValues get instance {
    if (_instance == null) {
      _instance = new LocaleValues();
    }
    return _instance;
  }

  Map<String, String> numberMap = {
    "1": "১",
    "2": "২",
    "3": "৩",
    "4": "৪",
    "5": "৫",
    "6": "৬",
    "7": "৭",
    "8": "৮",
    "9": "৯",
    "0": "০",
  };

  var strings = {
    LocaleKey.HEY: {"en": "Hey", "bn": "হেই"},
    LocaleKey.YOU_ARE_ON: {"en": "You are on", "bn": "আপনার বর্তমান অবস্থা"},
    LocaleKey.LEVEL: {"en": "Level", "bn": "লেভেল"},
    LocaleKey.SPIN_NOW: {"en": "Spin Now", "bn": "স্পিন করুন"},
    LocaleKey.SPIN_NOW_2: {"en": "Spin\nNow", "bn": "স্পিন\nকরুন"},
    LocaleKey.QUESTIONS: {"en": "Questions", "bn": "প্রশ্ন"},
    LocaleKey.MINUTES: {"en": "Minutes", "bn": "মিনিট"},
    LocaleKey.PLAY_FREE: {"en": "Play Free", "bn": "ফ্রি খেলুন"},
    LocaleKey.PLAY_USING: {"en": "Play using", "bn": "খেলুন"},
    LocaleKey.USING_COINS: {"en": "Coins", "bn": "কয়েন দিয়ে"},
    LocaleKey.LATEST_TOURNAMENTS: {"en": "Latest Tournaments", "bn": "বর্তমান টুর্নামেন্ট"},
    LocaleKey.LATEST_CHALLENGEROOM: {"en": "Latest Challenges", "bn": "চ্যালেঞ্জ রুম"},
    LocaleKey.SEE_ALL: {"en": "See all", "bn": "সবগুলো দেখুন"},
    LocaleKey.CATEGORIES: {"en": "Categories", "bn": "হোম"},
    LocaleKey.TOP_TOPICS: {"en": "Top Topics", "bn": "টপ টপিকস"},
    LocaleKey.YOUR_INTEREST: {"en": "Your Interest", "bn": "আপনার পছন্দ"},
    LocaleKey.YOU_HAVE_COMPLETED: {"en": "You have completed", "bn": "আপনি সম্পন্ন করেছেন"},
    LocaleKey.LEADERBOARD: {"en": "Leaderboard", "bn": "স্টোর"},
    LocaleKey.STORE: {"en": "Store", "bn": "চ্যালেঞ্জ"},
    LocaleKey.FRIENDS: {"en": "Friends", "bn": "ফ্রেন্ডস"},
    LocaleKey.REFER: {"en": "Refer", "bn": "রেফার"},
    LocaleKey.DAILY: {"en": "Daily", "bn": "দৈনিক"},
    LocaleKey.WEEKLY: {"en": "Weekly", "bn": "সাপ্তাহিক"},
    LocaleKey.MONTHLY: {"en": "Monthly", "bn": "মাসিক"},
    LocaleKey.REQUEST: {"en": "Request", "bn": "রিকোয়েস্ট"},
    LocaleKey.SENT_REQUEST: {"en": "Sent Request", "bn": "পাঠানো রিকোয়েস্ট"},
    LocaleKey.YOU_HAVE_NO_FRIENDS: {
      "en": "You have no friends yet",
      "bn": "আপনার এখনো কোন বন্ধু নেই"
    },
    LocaleKey.EMPTY_REQUEST: {"en": "Empty Request", "bn": "রিকোয়েস্ট নেই"},
    LocaleKey.YOU_CAN_ADD_FRIEND: {
      "en": "You can add friends as you wish",
      "bn": "আপনি চাইলে বন্ধু বানাতে পারেন"
    },
    LocaleKey.SEARCH_FRIEND: {"en": "Search Friends", "bn": "বন্ধু খুঁজুন"},
    LocaleKey.COINS: {"en": "Coins", "bn": "কয়েন"},
    LocaleKey.GEMS: {"en": "Gems", "bn": "জেম"},
    LocaleKey.YOUR_BALANCE: {"en": "Your Balance", "bn": "আপনার ব্যালেন্স"},
    LocaleKey.BUY_NOW: {"en": "Buy Now", "bn": "ক্রয় করুন"},
    LocaleKey.BDT: {"en": "BDT", "bn": "টাকা"},
    LocaleKey.TOP_DEALS: {"en": "Top Deals", "bn": "টপ ডিলস"},
    LocaleKey.POPULAR_PRODUCTS: {"en": "Popular Products", "bn": "পপুলার প্রোডাক্টস"},
    LocaleKey.RS: {"en": "RS", "bn": "RS"},
    LocaleKey.SEARCH_TOPICS: {"en": "Search Topics", "bn": "টপিক খুঁজুন"},
    LocaleKey.PROFILE: {"en": "Profile", "bn": "প্রোফাইল"},
    LocaleKey.NOTIFICATIONS: {"en": "Notifications", "bn": "নোটিফিকেশনস"},
    LocaleKey.SETTINGS: {"en": "Settings", "bn": "সেটিংস"},
    LocaleKey.CHALLENGES: {"en": "Challenges", "bn": "চ্যালেঞ্জেস"},
    LocaleKey.NO_HISTORY_AVAILABLE: {"en": "No history available", "bn": "হিস্টোরি নেই"},
    LocaleKey.PURCHASE_HISTORY: {"en": "Purchase History", "bn": "পারচেজ হিস্টরি"},
    LocaleKey.INVITE_FRIENDS: {"en": "Invite Friends", "bn": "ইনভাইট ফ্রেন্ডস"},
    LocaleKey.RATE_QUIZGIRI: {"en": "Rate QuizGiri", "bn": "রেট কুইজগিরি"},
    LocaleKey.CHALLENGE_WINNING_STATUS: {
      "en": "Challenge Winning Status",
      "bn": "চ্যালেঞ্জ জেতার পরিসংখ্যান"
    },
    LocaleKey.WIN: {"en": "Win", "bn": "বিজয়"},
    LocaleKey.DRAW: {"en": "Draw", "bn": "ড্র"},
    LocaleKey.LOSS: {"en": "Loss", "bn": "পরাজয়"},
    LocaleKey.BCS_TEST_RESULT: {"en": "BCS Test Results", "bn": "বিসিএস টেস্ট রেজাল্ট"},
    LocaleKey.TODAY: {"en": "Today", "bn": "আজ"},
    LocaleKey.THIS_WEEK: {"en": "This Week", "bn": "এই সপ্তাহে"},
    LocaleKey.THIS_MONTH: {"en": "This Month", "bn": "এই মাসে"},
    LocaleKey.MODEL_TEST_PARTICIPATED: {
      "en": "Model Test Participated",
      "bn": "মডেল টেস্ট দিয়েছেন"
    },
    LocaleKey.QUESTION_ANSWERED: {"en": "Question Answered", "bn": "প্রশ্ন খেলেছেন"},
    LocaleKey.MARK: {"en": "Mark", "bn": "মার্ক"},
    LocaleKey.CORRECT: {"en": "Correct", "bn": "সঠিক"},
    LocaleKey.WRONG: {"en": "Wrong", "bn": "ভুল"},
    LocaleKey.SKIPPED: {"en": "Skipped", "bn": "স্কিপড"},
    LocaleKey.CANCEL: {"en": "Cancel", "bn": "ক্যান্সেল"},
    LocaleKey.EDIT_PROFILE: {"en": "Edit Profile", "bn": "এডিট প্রোফাইল"},
    LocaleKey.FULL_NAME: {"en": "Full Name", "bn": "পুরোনাম"},
    LocaleKey.MOBILE: {"en": "Mobile", "bn": "মোবাইল"},
    LocaleKey.EMAIL: {"en": "Email", "bn": "ই-মেইল"},
    LocaleKey.SAVE: {"en": "Save", "bn": "সেভ"},
    LocaleKey.WEEKLY_TASK: {"en": "Weekly Task", "bn": "সাপ্তাহিক টাস্ক"},
    LocaleKey.DAY: {"en": "Day", "bn": "দিন"},
    LocaleKey.PLAY_NOW: {"en": "Play Now", "bn": "খেলা শুরু করুন"},
    LocaleKey.OUT_OF_COIN: {"en": "Out of Coin", "bn": "পর্যাপ্ত কয়েন নেই"},
    LocaleKey.STARTING_NOW: {"en": "Starting", "bn": "শুরু হচ্ছে"},
    LocaleKey.ALREADY_PLAYED: {"en": "Already Played", "bn": "খেলে ফেলেছেন"},
    LocaleKey.RECENT_BEST: {"en": "Recent Best", "bn": "সর্বোচ্চ স্কোরার"},
    LocaleKey.REPORT: {"en": "Report", "bn": "রিপোর্ট করুন"},
    LocaleKey.NEXT: {"en": "Next", "bn": "পরবর্তী"},
    LocaleKey.USE_COIN: {"en": "Use Coin", "bn": "ইউজ কয়েন"},
    LocaleKey.SEE_RESULT: {"en": "See Result", "bn": "রেজাল্ট দেখুন"},
    LocaleKey.WATCH_VIDEO: {"en": "Watch Video", "bn": "ভিডিও দেখুন"},
    LocaleKey.TI: {"en": "", "bn": " টি"},
    LocaleKey.YOU_HAVE_GIVEN: {"en": "You Have Given", "bn": "আপনি দিয়েছেন"},
    LocaleKey.CORRECT_ANS: {"en": "Correct Answer", "bn": "সঠিক উত্তর"},
    LocaleKey.TOTAL_QUESTION: {"en": "Total Question", "bn": "মোট প্রশ্ন"},
    LocaleKey.THANKS_FOR_PLAYING: {"en": "Thanks for Playing", "bn": "খেলার জন্য ধন্যবাদ"},
    LocaleKey.YOU_HAVE_COMPLETED_TODAYS_TASK: {
      "en": "You have completed today's task",
      "bn": "আপনি আজকের টাস্ক সম্পন্ন করেছেন"
    },
    LocaleKey.DONE: {"en": "Done", "bn": "শেষ করুন"},
    LocaleKey.TIME: {"en": "Time", "bn": "সময়"},
    LocaleKey.PENALTY: {"en": "Penalty", "bn": "পেনাল্টি"},
    LocaleKey.WRONG_QUESTION: {"en": "Wrong Question", "bn": "ভুল প্রশ্ন"},
    LocaleKey.WRONG_ANSWER: {"en": "Wrong Answer", "bn": "ভুল উত্তর"},
    LocaleKey.OTHERS: {"en": "Others", "bn": "অন্যান্য"},
    LocaleKey.SUBMIT: {"en": "Submit", "bn": "সাবমিট করুন"},
    LocaleKey.REPORTED: {"en": "Reported", "bn": "রিপোর্ট হয়েছে"},
    LocaleKey.SUBMITTED: {"en": "Submitted", "bn": "সাবমিট হয়েছে"},
    LocaleKey.PLEASE_CONFIRM: {"en": "Please Confirm", "bn": "কনফার্ম করুন"},
    LocaleKey.FOLLOW: {"en": "Follow", "bn": "ফলো করুন"},
    LocaleKey.FOLLOWING: {"en": "Following", "bn": "ফলোয়িং"},
    LocaleKey.FOLLOWER: {"en": "Follower", "bn": "ফলোয়ার"},
    LocaleKey.YOUR_LEVEL: {"en": "Your Level", "bn": "আপনার লেভেল"},
    LocaleKey.NEXT_LEVEL: {"en": "Next Level", "bn": "পরবর্তী লেভেল"},
    LocaleKey.PLAY: {"en": "Play", "bn": "খেলুন"},
    LocaleKey.EXPLORE: {"en": "Explore", "bn": "অন্য বিষয় খেলুন"},
    LocaleKey.CHOOSE_BET_AMOUNT: {"en": "Choose bet amount", "bn": "বাজীর পরিমাণ সিলেক্ট করুন"},
    LocaleKey.TYPE_OF_CHALLENGE: {"en": "Type of challenge", "bn": "চ্যালেঞ্জের ধরন"},
    LocaleKey.SINGLE_TOPIC: {"en": "Single topic", "bn": "একক বিষয়"},
    LocaleKey.GLOBAL: {"en": "Global", "bn": "গ্লোবাল"},
    LocaleKey.SELECT_TOPIC_CATEGORY: {
      "en": "Select topic category",
      "bn": "টপিকের ক্যাটাগরি সিলেক্ট করুন"
    },
    LocaleKey.SELECT_TOPIC: {"en": "Select topic", "bn": "টপিক সিলেক্ট করুন"},
    LocaleKey.SELECT_QUESTION_AMOUNT: {
      "en": "Select question amount",
      "bn": "প্রশ্নের সংখ্যা সিলেক্ট করুন"
    },
    LocaleKey.CONFIRM: {"en": "Confirm", "bn": "কনফার্ম করুন"},
    LocaleKey.CHALLENGE_NOW: {"en": "Challenge Now", "bn": "চ্যালেঞ্জ করুন"},
    LocaleKey.RESULT: {"en": "Result", "bn": "রেজাল্ট"},
    LocaleKey.ACCEPTED: {"en": "Accepted", "bn": "এক্সেপ্টেড"},
    LocaleKey.ACCEPT: {"en": "Accept", "bn": "এক্সেপ্ট"},
    LocaleKey.REJECTED: {"en": "Rejected", "bn": "রিজেক্টেড"},
    LocaleKey.REJECT: {"en": "Reject", "bn": "রিজেক্ট"},
    LocaleKey.CANCELLED: {"en": "Cancelled", "bn": "ক্যান্সেলড"},
    LocaleKey.PENDING: {"en": "Pending", "bn": "পেন্ডিং"},
    LocaleKey.NO_CHALLENGE: {"en": "You have no challenge yet", "bn": "কোন চ্যালেঞ্জ নেই"},
    LocaleKey.CHALLENGE: {"en": "Challenge", "bn": "চ্যালেঞ্জ"},
    LocaleKey.COMPLETED: {"en": "Completed", "bn": "সম্পন্ন"},
    LocaleKey.OPPONENT_PLAYED: {"en": "Opponent played", "bn": "প্রতিদ্বন্দ্বী খেলেছেন"},
    LocaleKey.OPPONENT_NOT_PLAYED: {"en": "Opponent hasn't played", "bn": "প্রতিদ্বন্দ্বী খেলেননি"},
    LocaleKey.PLAYED: {"en": "Played", "bn": "খেলেছেন"},
    LocaleKey.CONGRATULATION: {"en": "Congratulation", "bn": "অভিনন্দন"},
    LocaleKey.YOU_HAVE_SUCCESSFULLY_PURCHASED: {
      "en": "You have successfully purchased",
      "bn": "আপনি সফলভাবে ক্রয় করেছেন"
    },
    LocaleKey.NOW_YOU_CAN_PARTICIPATE_TOURNAMENT: {
      "en": "Now you can participate tournament",
      "bn": "আপনি এখন টুর্নামেন্টে অংশগ্রহণ করতে পারবেন"
    },
    LocaleKey.GO_HOME: {"en": "Go Home", "bn": "হোমে যান"},
    LocaleKey.YOU_WON: {"en": "You Won", "bn": "আপনি জিতেছেন"},
    LocaleKey.YOU_CAN_SPIN_ONLY_ONCE: {
      "en": "You can spin only one time in a day. But you can spin again by watching ad",
      "bn":
          "আপনি একদিনে একবার স্পিন করতে পারবেন । চাইলে ভিডিও দেখে আপনি একাধিকবার স্পিন করতে পারবেন"
    },
    LocaleKey.DAILY_SPIN: {"en": "Daily Spin", "bn": "দৈনিক স্পিন"},
    LocaleKey.YOUR_NEXT_SPIN: {
      "en": "Your next spin will be available in",
      "bn": "আপনার পরবর্তি স্পিনে বাকি আছে"
    },
    LocaleKey.SHARE: {"en": "Share", "bn": "শেয়ার করুন"},
    LocaleKey.NOTHING_FOUND: {"en": "Nothing found", "bn": "কিছু খুঁজে পাওয়া যাইনি"},
    LocaleKey.THIS_YEAR: {"en": "This Year", "bn": "এই বছরে"},
    LocaleKey.FILTER: {"en": "Filter", "bn": "ফিল্টার করুন"},
    LocaleKey.SEARCH_WITH_NAME_OR_EMAIL: {
      "en": "Search with name or email",
      "bn": "নাম অথবা ইমেইল দিয়ে খুঁজুন"
    },
    LocaleKey.PEOPLE_FROM_CONTACT: {
      "en": "Peoples from your contact",
      "bn": "আপনার কন্টাক্ট লিস্টের যারা আছেন"
    },
    LocaleKey.SELECT_FRIEND: {"en": "Select a Friend", "bn": "বন্ধু সিলেক্ট করুন"},
    LocaleKey.DAILY_UPDATE: {"en": "Daily Update", "bn": "দৈনিক আপডেট"},
    LocaleKey.NEW_TOPIC: {"en": "New Topic", "bn": "নতুন টপিক"},
    LocaleKey.NEW_TOURNAMENT: {"en": "New Tournament", "bn": "নতুন টুর্নামেন্ট"},
    LocaleKey.SOUND_EFFECT: {"en": "Sound Effect", "bn": "সাউন্ড ইফেক্ট"},
    LocaleKey.MUSIC: {"en": "Music", "bn": "মিউজিক"},
    LocaleKey.LOGOUT: {"en": "Logout", "bn": "লগ আউট"},
    LocaleKey.TOURNAMENT: {"en": "Tournament", "bn": "টুর্নামেন্ট"},
    LocaleKey.CHALLENGE_ROOM: {"en": "Challenge Room", "bn": "চ্যালেঞ্জ রুম"},
    LocaleKey.PARTICIPANTS_ARE_PLAYING: {
      "en": "Participants are playing",
      "bn": "অংশগ্রহনকারী খেলছেন"
    },
    LocaleKey.TIME_UP: {"en": "Time up", "bn": "সময় শেষ"},
    LocaleKey.SUBSCRIBE_NOW: {"en": "Subscribe Now", "bn": "সাবস্ক্রাইব করুন"},
    LocaleKey.UNSUBSCRIBE_NOW: {"en": "Unsubscribe Now", "bn": "বাতিল করুন"},
    LocaleKey.YOU_CANT_PLAY_MORE: {
      "en": "You can't play more",
      "bn": "আপনি সর্বাধিক সংখ্যকবার খেলে ফেলেছেন"
    },
    LocaleKey.PARTICIPATE_IN_OTHER_TOURNAMENTS: {
      "en": "Participate in other tournaments",
      "bn": "অন্যান্য টুর্নামেন্টে অংশগ্রহণ করুন"
    },
    LocaleKey.FIFTY_FIFTY: {"en": "50:50", "bn": "৫০ঃ৫০"},
    LocaleKey.GET_ANSWER: {"en": "Get Answer", "bn": "উত্তর জানুন"},
    LocaleKey.BKASH_AND_OTHERS: {"en": "bKash & Others", "bn": "বিকাশ ও অন্যান্য"},
    LocaleKey.TOTAL_POINTS: {"en": "Total Point", "bn": "মোট পয়েন্ট"},
    LocaleKey.HIGH_SCORE_IN_ANY_TOPIC: {
      "en": "Hign Score in Any Topic",
      "bn": "যেকোন টপিকে সর্বোচ্চ পয়েন্ট"
    },
    LocaleKey.TOURNAMENT_WIN: {"en": "Tournament Win", "bn": "টুর্নামেন্ট জিতেছেন"},
    LocaleKey.ADD_FRIEND: {"en": "Add Friend", "bn": "বন্ধু বানান"},
    LocaleKey.CANCEL_REQUEST: {"en": "Cancel Request", "bn": "রিকোয়েস্ট বাতিল করুন"},
    LocaleKey.ACCEPT_REQUEST: {"en": "Accept Request", "bn": "রিকোয়েস্ট এক্সেপ্ট করুন"},
    LocaleKey.REQUEST_SENT: {"en": "Request Sent", "bn": "রিকোয়েস্ট পাঠানো হয়েছে"},
    LocaleKey.UNAVAILABLE: {"en": "Unavailable", "bn": "এভেলেবল নেই"},
    LocaleKey.REMATCH: {"en": "Rematch", "bn": "আবার খেলুন"},
    LocaleKey.OKAY: {"en": "okay", "bn": "ওকে"},
    LocaleKey.USE_OF_COIN: {"en": "User of Coin", "bn": "কয়েনের ব্যাবহার"},
    LocaleKey.USE_OF_COIN_1: {
      "en":
          "1. While challenging your friend, you must have at least the bet amount of coins in your wallet",
      "bn": "1. আপনার বন্ধুকে চ্যালেঞ্জ করতে হলে আপনার ওয়ালেটে কমপক্ষে বাজির পরিমাণ কয়েন থাকতে হবে"
    },
    LocaleKey.USE_OF_COIN_2: {
      "en": "2. You can use your coins to retry a question both in General Quiz & Challenge",
      "bn":
          "2. জেনারেল কুইজ ও চ্যালেঞ্জ উভয় ক্ষেত্রেই পুনরায় প্রশ্নের উত্তর দেয়ার চেষ্টা করতে আপনি আপনার কয়েন ব্যবহার করতে পারবেন"
    },
    LocaleKey.USE_OF_COIN_3: {
      "en": "3. While playing tournament, you can use lifeline by spending coins",
      "bn": "3. টুর্নামেন্ট খেলার সময় আপনি কয়েন ব্যয় করে লাইফলাইন ব্যবহার করতে পারবেন"
    },
    LocaleKey.USE_OF_GEM: {"en": "Use of Gem", "bn": "জেম এর ব্যাবহার"},
    LocaleKey.USE_OF_GEM_1: {
      "en":
          "1. While playing tournament, you can get the correct answer of a question by spending gems",
      "bn": "1. টুর্নামেন্ট খেলার সময়, আপনি জেম ব্যয় করে যেকোনো প্রশ্নের সঠিক উত্তর পেতে পারবেন"
    },
    LocaleKey.SURE_TO_EXIT: {"en": "Are you sure to exit?", "bn": "আপনি কি বের হয়ে যেতে চান"},
    LocaleKey.YES: {"en": "Yes", "bn": "হ্যাঁ"},
    LocaleKey.NO: {"en": "No", "bn": "না"},
    LocaleKey.YOU_HAVE_NOT_SUBMITTED_ANSWERS: {
      "en": "You haven't submitted your answers",
      "bn": "আপনি উত্তর সাবমিট করেন নি"
    },
    LocaleKey.SURE_TO_QUIT: {"en": "Are you sure to quit?", "bn": "আপনি কি বের হয়ে যেতে চান?"},
    LocaleKey.YOU_HAVE_NOT_COMPLETED_THE_GAME: {
      "en": "You haven't completed the game",
      "bn": "আপনি খেলা শেষ করেন নি"
    },
    LocaleKey.TRY_AGAIN: {"en": "Try Again", "bn": "আবার খেলুন"},
    LocaleKey.NEXT_TOPIC: {"en": "Next Topic", "bn": "পরবর্তী টপিক"},
    LocaleKey.NOT_BAD: {"en": "Not Bad", "bn": "খারাপ না"},
    LocaleKey.BETTER_LUCK_NEXT_TIME: {
      "en": "Better Luck Next Time",
      "bn": "পরবর্তী বারের জন্য শুভকামনা"
    },
    LocaleKey.YOU_HAVE_PASSED: {
      "en": "You have passed this stage",
      "bn": "আপনি এই স্টেজে পাশ করেছেন"
    },
    LocaleKey.YOU_HAVE_FAILED: {
      "en": "You have failed this stage",
      "bn": "আপনি এই স্টেজে ফেল করেছেন"
    },
    LocaleKey.NO_IMPROVEMENT: {"en": "You have no improvement", "bn": "কোন সাফল্য নেই"},
    LocaleKey.PLEASE_NOTE: {"en": "Please Note", "bn": "খেয়াল করুন"},
    LocaleKey.TOTAL_CHANCE: {"en": "Total Chances", "bn": "মোট সুযোগ"},
    LocaleKey.CHANCE_PLAYED: {"en": "Chances Played", "bn": "সুযোগ শেষ"},
    LocaleKey.START: {"en": "Start", "bn": "শুরু করুন"},
    LocaleKey.ENTER_PASSCODE: {"en": "Enter Passcode", "bn": "পাসকোড প্রবেশ করান"},
    LocaleKey.VERIFY: {"en": "Verify", "bn": "ভেরিফাই করুন"},
    LocaleKey.PAY_TO_PLAY: {"en": "Pay to Play", "bn": "পেমেন্টের ধরন সিলেক্ট করুন"},
    LocaleKey.WILL_PUBLISH_RESULT_SOON: {
      "en": "We will publish the result soon",
      "bn": "শীঘ্রই রেজাল্ট প্রকাশ করা হবে"
    },
    LocaleKey.SORRY: {"en": "Sorry", "bn": "দুঃখিত"},
    LocaleKey.FEATURE_AVAILABLE_IN_APP: {
      "en": "This feature is not available in web",
      "bn": "এই ফিচারটি শুধুমাত্র মোবাইল অ্যাপে রয়েছে"
    },
    LocaleKey.DOWNLOAD_NOW: {"en": "Download Now", "bn": "ডাউনলোড করুন"},
    LocaleKey.WHY_DOWNLOAD_APP: {
      "en": "To enjoy more exciting features, get the app",
      "bn": "কুইজগিরির সকল আকর্ষনীয় ফিচার পাবেন কুইজগিরি অ্যাপে"
    },
    LocaleKey.ALREADY_PURCHASED_BUNDLE: {
      "en": "Already Purchased Bundle?",
      "bn": "টুর্নামেন্ট বান্ডেল কিনেছেন?"
    },
    LocaleKey.SIGN_IN_TO_PLAY: {
      "en": "Sign in to QuizGiri to play",
      "bn": "খেলার জন্য কুইজগিরিতে সাইন ইন করুন"
    },
    LocaleKey.SIGN_IN_NOW: {
      "en": "Sign In Now",
      "bn": "সাইন ইন করুন"
    },
    LocaleKey.ENTER_NAME: {
      "en": "Enter your name",
      "bn": "আপনার নাম লিখুন"
    },
    LocaleKey.ENTER_MOBILE: {
      "en": "11 digit mobile number",
      "bn": "১১ ডিজিটের মোবাইল নম্বর"
    },
    LocaleKey.CREATE_ACCOUNT_WITH_SAME_MOBILE: {
      "en": "[NOTICE: Please make sure you have or you are going to create QuizGiri account with this given number]",
      "bn": "[নোটিস: আপনি যেই মোবাইল নম্বরটি এখানে ব্যাবহার করছেন সেই নম্বর দিয়েই আপনাকে কুইজগিরিতে একাউন্ট থাকতে হবে অথবা একাউন্ট খুলতে হবে]"
    },
    LocaleKey.PROCEED: {
      "en": "Proceed",
      "bn": "এগিয়ে যান"
    },
    LocaleKey.PURCHASE_PACK: {
      "en": "Purchase Pack",
      "bn": "প্যাকেজ কিনুন"
    },
    LocaleKey.PAYMENT_METHOD: {
      "en": "Payment Methods",
      "bn": "পেমেন্টের ধরন"
    },
    LocaleKey.SELECT_PAYMENT_METHOD: {
      "en": "Select payment method",
      "bn": "পেমেন্টের ধরন নির্বাচন করুন"
    },
    LocaleKey.BCS_PACKAGES: {
      "en": "BCS Packages",
      "bn": "বিসিএস প্যাকেজ"
    },
    LocaleKey.TOURNAMENT_BUNDLES: {
      "en": "Tournament Bundles",
      "bn": "টুর্নামেন্ট বান্ডেল"
    },
    LocaleKey.SUBSCRIPTION: {
      "en": "subscription",
      "bn": "সাবস্ক্রিপশন"
    },
    LocaleKey.SUBSCRIBED: {
      "en": "Subscribed",
      "bn": "সাবস্ক্রাইবড"
    },
    LocaleKey.DUMMY: {
      "en": "dummy",
      "bn": "কৃত্রিম"
    },
  };

  String _getLocal() {
    String locale = "bn";
    if (AppSessionSettings.isNepaliUser()) {
      locale = "en";
    }
    return locale;
  }

  String getText(String key) {
    String result = "";
    try {
      result = strings[key][_getLocal()];
    } catch (_) {
      //
    }
    return result;
  }

  String getNumber(String value) {
    String result = value;
    try {
      if (_getLocal() != "en") {
        result = "";
        for (int i = 0; i < value.length; i++) {
          if (!_isDigit(value[i])) {
            result += value[i];
          } else {
            result += numberMap[value[i]];
          }
        }
      }
    } catch (_) {
      //
      result = value;
    }
    return result;
  }

  _isDigit(String value) {
    for (int i = 0; i < 10; i++) {
      if (value == i.toString()) {
        return true;
      }
    }
    return false;
  }
}
