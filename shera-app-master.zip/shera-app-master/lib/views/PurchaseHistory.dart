/*
* Created by Ahammed Hossain Shanto on 7/9/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/PurchaseHistoryVM.dart';

class PurchaseHistory extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return PurchaseHistoryVM();
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.PURCHASE_HISTORY.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Consumer<PurchaseHistoryVM>(
                builder: (context, snapshot, _) {
                  return _buildTournamentPackageList(context, snapshot);
                },
              ),
//            Container(
//              height: 20,
//              decoration: BoxDecoration(
//                color: Colors.white,
//                boxShadow: [
//                  BoxShadow(
//                      offset: Offset(0, 4),
//                      color: ColorsLocal.hexToColor("E1E1E1").withOpacity(0.5),
//                      spreadRadius: 0.4,
//                      blurRadius: 16
//                  )
//                ],
//              ),
//            ),
              Consumer<PurchaseHistoryVM>(builder: (context, snapshot, _) {
                return Container(
                  margin: EdgeInsets.fromLTRB(34, 24, 34, 10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Container(
                          child: Text(
                            LocaleKey.FILTER.toLocaleText(),
                            style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                      Container(
                        child: PopupMenuButton<String>(
                          itemBuilder: (context) {
                            return snapshot.ranges.map((value) {
                              return PopupMenuItem(
                                value: value['name'].toString(),
                                child: Text(
                                  value['name'].toString(),
                                  style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: snapshot.ranges[snapshot.selectedIndex]['type'] == value['type'] ? ColorsLocal.hexToColor("8435E8") : ColorsLocal.text_color, fontWeight: FontWeight.w500),
                                ),
                              );
                            }).toList();
                          },
                          tooltip: "Notification Filter",
                          elevation: 4,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Container(
                                child: Text(
                                  snapshot.ranges[snapshot.selectedIndex]['name'].toString(),
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 10,
                                    fontWeight: FontWeight.w500,
                                    color: ColorsLocal.hexToColor("8435E8"),
                                  ),
                                ),
                                margin: EdgeInsets.fromLTRB(0, 0, 4, 0),
                              ),
                              Icon(
                                Icons.keyboard_arrow_down,
                                size: 20,
                                color: ColorsLocal.hexToColor("8435E8"),
                              ),
                            ],
                          ),
                          onSelected: (str) {
                            snapshot.updateIndex(str);
                          },
                        ),
                      )
                    ],
                  ),
                );
              }),
              Consumer<PurchaseHistoryVM>(builder: (context, snapshot, _) {
                if (!snapshot.historyLoaded || (snapshot.history != null && snapshot.history.isNotEmpty)) {
                  return Container();
                } else {
                  return Container(
                    child: _buildEmptyWidget(),
                  );
                }
              }),
              Expanded(
                child: Container(
                    padding: EdgeInsets.fromLTRB(28, 0, 28, 16),
                    child: Consumer<PurchaseHistoryVM>(builder: (context, snapshot, _) {
                      return ListView(
                        children: _buildHistoryList(context, snapshot),
                      );
                    })),
              )
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildHistoryList(BuildContext context, PurchaseHistoryVM snapshot) {
    List<Widget> items = new List();

    if (!snapshot.historyLoaded) {
      items.addAll(List.generate(10, (index) {
        return Container(
          margin: EdgeInsets.fromLTRB(0, 4, 0, 4),
          child: MyShimmer.fromColors(
              child: Container(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 1,
                    color: Colors.grey[300],
                  ),
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 28,
                      width: 28,
                      padding: EdgeInsets.fromLTRB(4, 0, 4, 4),
                      decoration: BoxDecoration(border: Border.all(width: 1, color: Colors.grey[300]), shape: BoxShape.circle),
                      child: Image.asset("assets/images/ic_coins.png"),
                    ),
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.fromLTRB(8, 0, 8, 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              height: 16,
                              width: 50,
                              decoration: BoxDecoration(
                                color: Colors.grey[300],
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 4, 100, 0),
                              height: 12,
                              width: 100,
                              decoration: BoxDecoration(
                                color: Colors.grey[300],
                                borderRadius: BorderRadius.circular(8),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            height: 10,
                            width: 50,
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                            height: 16,
                            width: 100,
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(8),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              baseColor: Colors.grey[300],
              highlightColor: Colors.white),
        );
      }));
    } else if (snapshot.history != null && snapshot.history.isNotEmpty) {
      items.addAll(List.generate(snapshot.history.length, (index) {
        return Container(
          margin: EdgeInsets.fromLTRB(0, 4, 0, 4),
          child: Container(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
            decoration: BoxDecoration(
              border: Border.all(
                width: 1,
                color: ColorsLocal.hexToColor("F3F3F3"),
              ),
              color: Colors.white,
              borderRadius: BorderRadius.circular(7),
            ),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 28,
                      width: 28,
                      padding: EdgeInsets.fromLTRB(2, 0, 2, 6),
                      decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.hexToColor("F9F9F9")),
                      child: Image.asset("assets/images/ic_coins.png"),
                    ),
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.fromLTRB(8, 0, 8, 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              child: Text(
                                snapshot.history[index]['title'],
                                style: TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 14, color: ColorsLocal.text_color),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                              child: Text(
                                snapshot.history[index]['caption'],
                                style: TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 10, color: ColorsLocal.text_color.withOpacity(0.7)),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            child: Text(
                              snapshot.history[index]['purchased_at'].toString(),
                              style: TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w300, fontSize: 9, color: ColorsLocal.text_color.withOpacity(0.6)),
                            ),
                          ),
                          Container(
                              margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                              child: Text(
                                '${snapshot.history[index]['price'].toString().toLocaleNumber()} ${LocaleKey.BDT.toLocaleText()}',
                                style: TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 12, color: ColorsLocal.text_color_pink_2),
                              ))
                        ],
                      ),
                    ),
                  ],
                ),
                // (snapshot.history[index]['is_subscribed_tournament'] != null && snapshot.history[index]['is_subscribed_tournament'] == true) ?
                //     Align(
                //       alignment: Alignment.centerRight,
                //       child: Container(
                //         child: InkWell(
                //           onTap: () {
                //             // snapshot.cancelSubscription(snapshot.history[index]['id'].toString(), index).then((value) {
                //             //   if(value) {
                //             //     snapshot.loadHistory();
                //             //   }
                //             //   else {
                //             //     LocalAlert.showDialog(context, LocaleKey.SORRY.toLocaleText(), "Package un-subscription failed");
                //             //   }
                //             // });
                //           },
                //           child: Container(
                //             decoration: BoxDecoration(
                //               color: ColorsLocal.button_color_purple,
                //               borderRadius: BorderRadius.circular(4)
                //             ),
                //             padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
                //             child: snapshot.canceling && snapshot.currentIndex == index ?
                //                 Container(
                //                   height: 16,
                //                   width: 16,
                //                   child: CircularProgressIndicator(
                //                     strokeWidth: 2,
                //                     valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                //                   ),
                //                 ) :
                //             Text(
                //               LocaleKey.UNSUBSCRIBE_NOW.toLocaleText(),
                //               style: TextStyle(
                //                 fontFamily: "Poppins",
                //                 fontSize: 12,
                //                 color: Colors.white,
                //                 fontWeight: FontWeight.w400
                //               ),
                //             ),
                //           ),
                //         ),
                //       ),
                //     ) : Container()
              ],
            ),
          ),
        );
      }));
    }
    return items;
  }

  Widget _buildEmptyWidget() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Center(
          child: Image.asset(
            "assets/images/ic_coins.png",
            height: 100,
            width: 100,
          ),
        ),
        Text(
          LocaleKey.NOTHING_FOUND.toLocaleText(),
          style: TextStyle(color: ColorsLocal.hexToColor("262F56"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ],
    );
  }

  Widget _buildTournamentPackageList(BuildContext context, PurchaseHistoryVM snapshot) {
    if(!snapshot.tournamentPacksLoaded) {
      return Container(
        margin: EdgeInsets.only(left: 0, right: 0, top: 16, bottom: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              margin: EdgeInsets.only(left: 16, bottom: 12, right: 160),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.grey[300]
              ),
              height: 20,
            ),
            Container(
              height: 80,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: List.generate(3, (index) {
                    return MyShimmer.fromColors(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 10, 0),
                          width: 250,
                          height: 150,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.grey[300],
                          ),
                        ),
                        baseColor: Colors.grey[300],
                        highlightColor: Colors.white
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      );
    }
    else {
      return Container(
        margin: EdgeInsets.only(top: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              margin: EdgeInsets.only(left: 16, right: 16, bottom: 12),
              child: Text(
                LocaleKey.SUBSCRIPTION.toLocaleText(),
                style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 16,
                    color: ColorsLocal.text_color,
                    fontWeight: FontWeight.w600
                ),
              ),
            ),
            Container(
              //height: 112,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(snapshot.tournamentPackages.length, (index) {
                    return Container(
                      margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 12, 0),
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      width: 250,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.grey[200],
                                spreadRadius: 0.1,
                                blurRadius: 8
                            )
                          ]
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  child: Text(
                                    snapshot.tournamentPackages[index].title,
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 20,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                                Container(
                                  child: RaisedButton(
                                    elevation: 0,
                                    highlightElevation: 0,
                                    child: Text(
                                      //model['is_free'] ? LocaleKey.PLAY_FREE.toLocaleText() : '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_coin'].toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}',
                                      snapshot.canceling ? "প্রসেসিং...." :
                                      (snapshot.tournamentPackages[index].isAlreadyBought() ?
                                      LocaleKey.UNSUBSCRIBE_NOW.toLocaleText() :
                                      LocaleKey.UNSUBSCRIBE_NOW.toLocaleText()),
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 10,
                                          color: snapshot.tournamentPackages[index].isAlreadyBought() ?
                                          Colors.white
                                          : Colors.white, fontWeight: FontWeight.w600),
                                    ),
                                    color: snapshot.tournamentPackages[index].isAlreadyBought() ? ColorsLocal.button_color_purple : ColorsLocal.button_color_purple.withOpacity(.1),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                                    onPressed: () {
                                      if(snapshot.tournamentPackages[index].isAlreadyBought()) {
                                        snapshot.cancelSubscription(snapshot.tournamentPackages[index].id).then((value) {
                                          if(value) {
                                            snapshot.loadTournamentPacks();
                                          }
                                          else {
                                            LocalAlert.showDialog(context, LocaleKey.SORRY.toLocaleText(), "Package un-subscription failed");
                                          }
                                        });
                                      }
                                      else {
                                        // Navigator.pushNamed(context, PaymentMethodRoute, arguments: {
                                        //   'bundle_id': int.parse(snapshot.tournamentPackages[index].id)
                                        // }).then((value) {
                                        //   snapshot.loadTournamentPacks();
                                        // });
                                      }
                                    },
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      );
    }
  }

}
