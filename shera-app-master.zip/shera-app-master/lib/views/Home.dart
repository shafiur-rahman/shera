/*
* Created by Ahammed Hossain Shanto
* on 7/1/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:quiz/ViewModelFactory.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Pop_Ups/ExitPopup.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/HomeVM.dart';
import 'package:quiz/view-models/UtilsVM.dart';

import '../values/ColorsLocal.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays(SystemUiOverlay.values);
    UtilsVM utilsVM = ViewModelFactory.getUtilsVM(context);
    utilsVM.checkNoti();

    return RootBody(
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (_) {
              return HomeVM(context, ModalRoute.of(context).settings.arguments);
            },
          ),
          ChangeNotifierProvider.value(
            value: utilsVM,
          )
        ],
        child: Consumer<HomeVM>(builder: (context, snapshot, _) {
          return WillPopScope(
            onWillPop: () async {
              if (snapshot.navbarIndex != 2) {
                snapshot.navbarIndex = 2;
                snapshot.notify();
              } else {
                ExitPopup.showDialog(context);
              }
              return false;
            },
            child: Scaffold(
              extendBody: true,
              bottomNavigationBar: AppSessionSettings.isNepaliUser()
                  ? null
                  : Consumer2<HomeVM, UtilsVM>(builder: (context, snapshot, utilsVM, _) {
                      return BottomAppBar(
                        color: Colors.white,
                        elevation: 8,
                        child: Container(
                          height: 70,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: snapshot.getNavbarItems(utilsVM),
                          ),
                        ),
                        shape: CircularNotchedRectangle(),
                        clipBehavior: Clip.antiAlias,
                        notchMargin: 5.0,
                      );
                    }),
              body: Consumer<HomeVM>(
                builder: (context, snapshot, _) {
                  return snapshot.getFragmentToShow();
                },
              ),
            ),
          );
        }),
      ),
    );
  }
}
