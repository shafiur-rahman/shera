/*
* Created by Ahammed Hossain Shanto
* on 6/30/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/LoginWithMobileVM.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginWithMobile extends StatelessWidget {
  TextEditingController _textEditingController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return RootBody(
      needLogin: false,
      child: ChangeNotifierProvider(
        create: (_) {
          return LoginWithMobileVM(context);
        },
        child: Scaffold(
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 110,
                  width: 150,
                  margin: EdgeInsets.fromLTRB(36, 85, 36, 0),
                  child: Image.asset("assets/images/text_logo.png"),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 56, 36, 0),
                  child: Text(
                    "Enter your phone no",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 4, 36, 0),
                  child: Text(
                    "Use the phone number to register or login",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w300),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 24, 36, 36),
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 1,
                      color: ColorsLocal.hexToColor("EAEAEA"),
                    ),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Container(
                    child: Row(
                      children: [
                        Consumer<LoginWithMobileVM>(builder: (context, snapshot, _) {
                          return Container(
                            padding: EdgeInsets.fromLTRB(12, 16, 12, 16),
                            child: PopupMenuButton<dynamic>(
                              itemBuilder: (BuildContext context) {
                                return snapshot.countryWithCode.map((value) {
                                  return PopupMenuItem(
                                    value: value,
                                    child: Container(
                                      child: Text(
                                        '${value['name']} (${value['dial_code']})',
                                        style: TextStyle(fontFamily: 'Poppins', fontSize: 14, color: ColorsLocal.text_color.withOpacity(0.8), fontWeight: FontWeight.w600),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  );
                                }).toList();
                              },
                              elevation: 4,
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  //color: ColorsLocal.button_color_dark,
                                  // border: Border.all(
                                  //   width: 1,
                                  //   color: Colors.grey[300],
                                  // ),
                                ),
                                child: Wrap(
                                  children: [
                                    Container(
                                      child: Text(
                                        snapshot.selectedCountry['dial_code'].toString(),
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600,
                                          color: ColorsLocal.text_color_pink,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      margin: EdgeInsets.fromLTRB(0, 0, 4, 0),
                                    ),
                                    Container(
                                      child: Icon(
                                        Icons.keyboard_arrow_down,
                                        size: 24,
                                        color: ColorsLocal.text_color_pink,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              onSelected: (value) {
                                snapshot.updateCountrySelection(value);
                              },
                            ),
                          );
                        }),
                        Container(
                          height: 40,
                          width: 1,
                          color: Colors.grey[300],
                        ),
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(12, 0, 12, 0),
                            child: TextField(
                              controller: _textEditingController,
                              textAlign: TextAlign.start,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 20, color: ColorsLocal.text_color, letterSpacing: 1.5, fontWeight: FontWeight.w500),
                              maxLines: 1,
                              maxLength: 20,
                              autofocus: true,
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                              keyboardType: TextInputType.numberWithOptions(
                                signed: false,
                                decimal: false,
                              ),
                              decoration: InputDecoration(
                                hintText: "018xxxxxxxx",
                                border: InputBorder.none,
                                hintStyle: TextStyle(
                                  color: ColorsLocal.hexToColor("d4ddec"),
                                ),
                                counterText: "",
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Consumer<LoginWithMobileVM>(builder: (context, snapshot, _) {
                  return Container(
                    margin: EdgeInsets.fromLTRB(36, 0, 36, 36),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        snapshot.otpSending || snapshot.verifying
                            ? Container(
                                child: CupertinoActivityIndicator(),
                              )
                            : Container(),
                        Container(
                          child: Text(
                            snapshot.otpMessage,
                            style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 14,
                              color: ColorsLocal.text_color,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        snapshot.verifying
                            ? InkWell(
                                onTap: () {
                                  snapshot.setWaiting(false);
                                  Navigator.pushNamed(context, VerifyOtpRoute);
                                },
                                child: Container(
                                  child: Text(
                                    "Enter OTP manually",
                                    style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color_pink, fontWeight: FontWeight.w600, decoration: TextDecoration.underline),
                                    textAlign: TextAlign.center,
                                  ),
                                  padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
                                ),
                              )
                            : Container(),
                      ],
                    ),
                  );
                })
              ],
            ),
          ),
          floatingActionButton: Consumer<LoginWithMobileVM>(builder: (context, snapshot, _) {
            return FloatingActionButton(
              backgroundColor: ColorsLocal.button_color_pink,
              child: Icon(Icons.arrow_forward),
              onPressed: () {
                if (!snapshot.otpSending) {
                  if (snapshot.selectedCountry['dial_code'] == "+880" || AppSessionSettings.isNepaliUser()) {
                    if (_textEditingController.text.length != 11 && _textEditingController.text.length != 10) {
                      Logger.printWrapped(_textEditingController.text.toString());
                      snapshot.setMessage("Please enter valid mobile number");
                    } else {
                      if (!snapshot.otpSending) {
                        String mobile = _textEditingController.text;
                        if (!AppSessionSettings.isNepaliUser()) {
                          if (_textEditingController.text.length == 10) {
                            mobile = "0" + _textEditingController.text;
                          }
                        }
                        snapshot.sendOTP(mobile).then((flag) async {
                          if (flag) {
                            if (AppSessionSettings.isNepaliUser()) {
                              if (snapshot.sendOtpResponse != null) {
                                if (snapshot.sendOtpResponse['auto_verify'] == true && snapshot.sendOtpResponse['account_exists'] == true) {
                                  Logger.printWrapped("should launch home");
                                  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
                                  String accessToken = snapshot.sendOtpResponse['access_token'];
                                  String userId = snapshot.sendOtpResponse['user_id'].toString();
                                  sharedPreferences.setString(ACCESS_TOKEN, accessToken);
                                  sharedPreferences.setString(USER_ID, userId);
                                  while (Navigator.canPop(context)) {
                                    Navigator.pop(context);
                                  }
                                  Navigator.pushReplacementNamed(context, HomeRoute);
                                } else {
                                  while (Navigator.canPop(context)) {
                                    Navigator.pop(context);
                                  }
                                  Navigator.pushReplacementNamed(context, RegisterUserRoute);
                                }
                              }
                            } else {
                              Navigator.pushReplacementNamed(context, VerifyOtpRoute);
                            }
                          }
                        });
                      }
                    }
                  } else {
                    snapshot.sendOTPFirebase(_textEditingController.text);
                  }
                }
              },
            );
          }),
        ),
      ),
    );
  }
}
