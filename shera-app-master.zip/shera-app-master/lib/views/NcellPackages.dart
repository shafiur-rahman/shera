/*
* Created by Ahammed Hossain Shanto
* on 12/23/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/NcellPackagesVM.dart';

class NcellPackages extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var arguments = ModalRoute.of(context).settings.arguments;
    NcellPackagesVM ncellPackagesVM = new NcellPackagesVM(context, arguments);

    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return ncellPackagesVM;
        },
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(75),
            child: AppBar(
              elevation: 0,
              leading: Container(
                child: IconButton(
                  icon: Image.asset(
                    "assets/images/back_arrow.png",
                    height: 20,
                    width: 24,
                  ),
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
              title: Text(
                "Subscription Packages",
                style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          body: Consumer<NcellPackagesVM>(
            builder: (context, snapshot, _) {
              return _buildPackageList(context, snapshot);
            },
          ),
        ),
      ),
    );
  }

  Widget _buildPackageList(BuildContext context, NcellPackagesVM snapshot) {
    if (snapshot.packagesLoaded) {
      return Container(
        margin: EdgeInsets.fromLTRB(24, 8, 24, 8),
        child: ListView.builder(
            itemCount: snapshot.packages.length,
            itemBuilder: (BuildContext context, int index) {
              return Container(
                child: InkWell(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin: EdgeInsets.only(right: 16),
                          child: Image.asset(
                            "assets/images/ic_star_badge.png",
                            height: 50,
                            width: 50,
                          ),
                        ),
                        Expanded(
                          child: Container(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  child: Text(
                                    snapshot.packages[index]['name'].toString(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 16,
                                      color: ColorsLocal.text_color,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 8),
                                  child: Row(
                                    children: [
                                      Container(
                                        child: Text(
                                          "Charge: ",
                                          style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontSize: 14,
                                            color: ColorsLocal.text_color.withOpacity(0.6),
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                          child: Container(
                                        child: Text(
                                          snapshot.packages[index]['cost'].toString() + " Rupee",
                                          style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontSize: 14,
                                            color: ColorsLocal.text_color_purple,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ))
                                    ],
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 8),
                                  child: Row(
                                    children: [
                                      Container(
                                        child: Text(
                                          "Validity: ",
                                          style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontSize: 14,
                                            color: ColorsLocal.text_color.withOpacity(0.6),
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                          child: Container(
                                        child: Text(
                                          snapshot.packages[index]['validityInDays'].toString() + " Days",
                                          style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontSize: 14,
                                            color: ColorsLocal.text_color_purple,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ))
                                    ],
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 8),
                                  child: Container(
                                    child: Text(
                                      "*Rs. ${snapshot.packages[index]['perQuizCost'].toString()} will be charged from your balance after ${snapshot.packages[index]['freeQuesLimit'].toString()} questions",
                                      style: TextStyle(fontSize: 8, fontFamily: "Poppins", fontWeight: FontWeight.w600, color: ColorsLocal.text_color_pink_2),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        snapshot.isSubscribing && snapshot.selectedPackageId == snapshot.packages[index]['id'].toString()
                            ? CupertinoActivityIndicator()
                            : Container(
                                margin: EdgeInsets.only(left: 8),
                                child: Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.grey[300],
                                ),
                              )
                      ],
                    ),
                  ),
                  onTap: () {
                    if (!snapshot.isSubscribing) {
                      snapshot.subscribePackage(snapshot.packages[index]['id'].toString());
                    }
                  },
                ),
              );
            }),
      );
    } else {
      return Center(
        child: CupertinoActivityIndicator(),
      );
    }
  }
}
