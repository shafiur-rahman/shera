/*
* Created by Ahammed Hossain Shanto
* on 12/20/20
* * ReCreated by Shafiur
* on 01/07/2021
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_statusbarcolor/flutter_statusbarcolor.dart';
import 'package:provider/provider.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/ImageLoader.dart';
import 'package:quiz/view-components/Pop_Ups/QuitRoomJoinAlert.dart';
import 'package:quiz/view-models/ChallengePartnerSearchVM.dart';

class ChallengePartnerSearch extends StatefulWidget {
  @override
  _ChallengePartnerSearchState createState() => _ChallengePartnerSearchState();
}

class _ChallengePartnerSearchState extends State<ChallengePartnerSearch> {

  ChallengeRoomPartnerSearchVM challengePartnerSearchVM;


  @override
  void dispose() {
    // TODO: implement dispose
    FlutterStatusbarcolor.setStatusBarColor(Colors.white);
    //challengePartnerSearchVM.disconnectSocket();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {

    var arguments = json.decode(ModalRoute.of(context).settings.arguments);

    Color bgColor = Colors.blue[500];
    if(arguments != null && arguments['room_info'] != null) {
      bgColor = ColorsLocal.hexToColor(arguments['room_info']['primary_color'].toString());
    }

    FlutterStatusbarcolor.setStatusBarColor(bgColor);

    challengePartnerSearchVM = new ChallengeRoomPartnerSearchVM(context, arguments);

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (_) {
              return challengePartnerSearchVM;
            }
        )
      ],
      child: WillPopScope(
        onWillPop: () async {
          QuitRoomJoinAlert.show(context);
          return false;
        },
        child: Scaffold(
          backgroundColor: bgColor,
          body: SingleChildScrollView(
            child: Consumer<ChallengeRoomPartnerSearchVM>(
                builder: (context, snapshot, _) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          margin: EdgeInsets.only(top: 100),
                          child: ImageLoader.loadRect(
                            height: 100,
                            width: 100,
                            imageUrl: snapshot.roomInfo['image'].toString(),
                            showLoadingShimmer: false,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(24, 16, 24, 0),
                        child: Text(
                          snapshot.roomInfo['name'].toString(),
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 22,
                              color: Colors.white,
                              fontWeight: FontWeight.w700
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(24, 50, 24, 0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: 120,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    child: ImageLoader.loadCircular(
                                      imageUrl: snapshot.userInfo['avatar'].toString(),
                                      height: 100,
                                      width: 100,
                                    ),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        width: 3,
                                        color: ColorsLocal.hexToColor(snapshot.roomInfo['primary_color_dark'].toString()),
                                      ),
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(top: 8),
                                    child: Text(
                                      snapshot.userInfo['user_name'].toString(),
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontSize: 16,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 32),
                              child: Text(
                                "VS",
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 32,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700
                                ),
                              ),
                            ),
                            snapshot.isMatchFound ? Container(
                              width: 120,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    child: ImageLoader.loadCircular(

                                      imageUrl: snapshot.opponentInfo['avatar'].toString(),
                                    ),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                          width: 3,
                                          color: ColorsLocal.hexToColor(snapshot.roomInfo['primary_color_dark'].toString()),
                                        ),
                                        shape: BoxShape.circle
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(top: 8),
                                    child: Text(
                                      snapshot.opponentInfo['user_name'].toString(),
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontSize: 16,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                                ],
                              ),
                            ) :
                            Container(
                              width: 120,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                          width: 3,
                                          color: ColorsLocal.hexToColor(snapshot.roomInfo['primary_color_dark'].toString()),
                                        ),
                                        shape: BoxShape.circle
                                    ),
                                    child: Center(
                                      child: Container(
                                        height: 30,
                                        width: 30,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 3,
                                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                        ),
                                      ),
                                    ),
                                    height: 100,
                                    width: 100,
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(top: 8),
                                    child: Text(
                                      "Searching...",
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontSize: 16,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  );
                }
            ),
          ),
        ),
      ),
    );
  }
}
