/*
* Created by Ahammed Hossain Shanto on 7/8/20
*/


import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/helpers/banner-ad-loader.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Pop_Ups/AddFriendPU.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/TopicDetailsVM.dart';

// ignore: must_be_immutable
class TopicDetails extends StatelessWidget {
  var arguments;
  int topicId;
  String type = "";
  String categoryName = "";
  TopicDetailsVM topicDetailsVM;


  TopicDetails(this.arguments) {
    //arguments must contain topic_id, type, category_name
    topicId = int.parse(arguments['topic_id'].toString());
    type = arguments['type'].toString();
    categoryName = arguments['category_name'].toString();
    topicDetailsVM = new TopicDetailsVM(topicId);
  }

  Future<void> _onRefresh() async {
    topicDetailsVM.loadDetails();
    await Future.delayed(Duration(seconds: 1));
    return 'success';
  }

  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider.value(
        value: topicDetailsVM,
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            centerTitle: true,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Column(
              children: [
                Container(
                  child: Text(
                    type,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.hexToColor("FFB800"), fontWeight: FontWeight.w500),
                  ),
                ),
                Container(
                  child: Text(
                    categoryName,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
//            Container(
//              height: 20,
//              decoration: BoxDecoration(
//                color: Colors.white,
//                boxShadow: [
//                  BoxShadow(
//                      offset: Offset(0, 4),
//                      color: ColorsLocal.hexToColor("E1E1E1").withOpacity(0.5),
//                      spreadRadius: 0.4,
//                      blurRadius: 16
//                  )
//                ],
//              ),
//            ),
              Expanded(
                child: Container(
                  //color: Colors.red,
                  child: Consumer<TopicDetailsVM>(builder: (context, snapshot, _) {
                    return RefreshIndicator(
                      onRefresh: _onRefresh,
                      child: ListView.builder(
                        itemBuilder: (BuildContext context, int index) {
                          if (index == 0) {
                            return _buildStep1(context, snapshot);
                          } else if (index == 1) {
                            return _buildStep2(context, snapshot);
                          } else if (index == 2) {
                            return _buildStep3(context, snapshot);
                          } else {
                            return _buildPositions(context, snapshot, index - 3);
                          }
                        },
                        itemCount: _getItemCount(context, snapshot),
                      ),
                    );
                  }),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  int _getItemCount(BuildContext context, TopicDetailsVM snapshot) {
    int count = 0;

    if (snapshot.detailsLoaded) {
      count = 2;
      List rankList = snapshot.topicDetails['ranking'];
      if (rankList != null && rankList.isNotEmpty) {
        count += (rankList.length + 1);
      }
    } else {
      count = 6;
    }

    return count;
  }

  Widget _buildStep1(BuildContext context, TopicDetailsVM snapshot) {
    if (snapshot.detailsLoaded == false && snapshot.topicDetails == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: MyShimmer.fromColors(
            child: Container(
              padding: EdgeInsets.fromLTRB(36, 24, 36, 36),
              decoration: BoxDecoration(
                border: Border.all(
                  width: 1,
                  color: Colors.grey[300],
                ),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Column(
                children: [
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey[300]),
                  ),
                  Container(
                    height: 20,
                    width: 120,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 20,
                        margin: EdgeInsets.fromLTRB(0, 36, 150, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                      ),
                      Container(
                        height: 6,
                        margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                                height: 40,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                height: 40,
                                margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else if (snapshot.topicDetails['topic'] == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: MyShimmer.fromColors(
            child: Container(
              padding: EdgeInsets.fromLTRB(36, 24, 36, 36),
              decoration: BoxDecoration(
                border: Border.all(
                  width: 1,
                  color: Colors.grey[300],
                ),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Column(
                children: [
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey[300]),
                  ),
                  Container(
                    height: 20,
                    width: 120,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 20,
                        margin: EdgeInsets.fromLTRB(0, 36, 150, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                      ),
                      Container(
                        height: 6,
                        margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                                height: 40,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                height: 40,
                                margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: Container(
          padding: EdgeInsets.fromLTRB(36, 24, 36, 36),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(7),
          ),
          child: Column(
            children: [
              Container(
                  //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
//                        border: Border.all(
//                          width: 2,
//                          color: Colors.grey[300],
//                        ),
                    shape: BoxShape.circle,
                    color: Colors.blue[50],
                  ),
                  constraints: BoxConstraints.tightFor(height: 80, width: 80),
                  child: CachedNetworkImage(
                    imageUrl: snapshot.topicDetails['topic']['image_url'].toString(),
                    imageBuilder: (context, imageProvider) => Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        //borderRadius: BorderRadius.circular(4),
                        image: DecorationImage(
                          image: imageProvider,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                    placeholder: (context, url) => MyShimmer.fromColors(
                      child: Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          //borderRadius: BorderRadius.circular(8),
                          color: Colors.grey[300],
                        ),
                      ),
                      baseColor: Colors.grey[300],
                      highlightColor: Colors.white,
                    ),
                    errorWidget: (context, url, error) => Icon(Icons.error),
                  )),
              Container(
                margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                child: Text(
                  snapshot.topicDetails['topic']['name'].toString(),
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, fontFamily: "Poppins", color: ColorsLocal.text_color),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [

                  ///progress ****
                  // Container(
                  //   margin: EdgeInsets.fromLTRB(0, 36, 0, 0),
                  //   child: Row(
                  //     crossAxisAlignment: CrossAxisAlignment.center,
                  //     children: [
                  //       Expanded(
                  //         child: Container(
                  //           child: Text(
                  //             LocaleKey.YOU_HAVE_COMPLETED.toLocaleText(),
                  //             style: TextStyle(fontFamily: "Poppins", fontSize: 13, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  //           ),
                  //         ),
                  //       ),
                  //       Container(
                  //         child: Text(
                  //           '${double.parse((snapshot.topicDetails['progress'] * 100).toString()).toStringAsFixed(0).toLocaleNumber()}%',
                  //           style: TextStyle(fontFamily: "Poppins", fontSize: 13, color: ColorsLocal.getProgressColor(double.parse((snapshot.topicDetails['progress'] * 100).toString())), fontWeight: FontWeight.w600),
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  // ),
                  // Container(
                  //   margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                  //   child: LinearPercentIndicator(
                  //     width: MediaQuery.of(context).size.width.toCustomWidth() - (32 + 72),
                  //     lineHeight: 5.0,
                  //     backgroundColor: Colors.grey[200],
                  //     percent: double.parse((snapshot.topicDetails['progress']).toString()),
                  //     //progressColor: Colors.green,
                  //     padding: EdgeInsets.fromLTRB(2, 0, 2, 0),
                  //     linearGradient: LinearGradient(
                  //       colors: [ColorsLocal.getProgressColor(double.parse(snapshot.topicDetails['progress'].toString()) * 100), ColorsLocal.getProgressColor(double.parse(snapshot.topicDetails['progress'].toString()) * 100).withOpacity(0.1)],
                  //       stops: [0.7, 1.0],
                  //     ),
                  //     animation: true,
                  //   ),
                  // ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                            child: RaisedButton(
                              padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(7),
                              ),
                              elevation: 0,
                              highlightElevation: 0,
                              color: ColorsLocal.button_color_pink,
                              child: Center(
                                child: snapshot.starting
                                    ? Container(
                                        height: 24,
                                        width: 24,
                                        child: CircularProgressIndicator(
                                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : Text(
                                        snapshot.topicDetails['topic']['all_played'] ? LocaleKey.ALREADY_PLAYED.toLocaleText() : LocaleKey.PLAY.toLocaleText(),
                                        style: TextStyle(fontSize: 16, color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                      ),
                              ),
                              onPressed: snapshot.topicDetails['topic']['all_played']
                                  ? null
                                  : () {
                                      snapshot.startGame(type, categoryName).then((value) {
                                        if (value != null) {
                                          Navigator.pushNamed(context, GamePlayRoute, arguments: value).then((value) {
                                            snapshot.loadDetails();
                                          });
                                        } else {
                                          LocalAlert.showDialog(context, "Sorry", "Error Occurred. Please try again later");
                                        }
                                      });
                                    },
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                            child: RaisedButton(
                              padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(7),
                              ),
                              elevation: 0,
                              highlightElevation: 0,
                              color: snapshot.topicDetails['following'] ? ColorsLocal.button_color_purple.withOpacity(0.2) : ColorsLocal.button_color_purple,
                              child: Center(
                                child: snapshot.topicDetails['updating']
                                    ? Container(
                                        height: 24,
                                        width: 24,
                                        child: CircularProgressIndicator(
                                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : Text(
                                        snapshot.topicDetails['following'] ? LocaleKey.FOLLOWING.toLocaleText() : LocaleKey.FOLLOW.toLocaleText(),
                                        style: TextStyle(fontSize: 16, color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                      ),
                              ),
                              onPressed: () {
                                snapshot.toggleFavourite();
                              },
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              snapshot.detailsLoaded && snapshot.topicDetails['topic']['all_played']
                  ? Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 16),
                            child: Text(
                              snapshot.topicDetails['topic']['message'].toString(),
                              style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: Container(),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                child: RaisedButton(
                                  padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(7),
                                  ),
                                  elevation: 0,
                                  highlightElevation: 0,
                                  color: ColorsLocal.button_color_pink,
                                  child: Center(
                                    child: snapshot.starting
                                        ? Container(
                                            height: 24,
                                            width: 24,
                                            child: CircularProgressIndicator(
                                              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                              strokeWidth: 2,
                                            ),
                                          )
                                        : Text(
                                            LocaleKey.EXPLORE.toLocaleText(),
                                            style: TextStyle(fontSize: 14, color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                          ),
                                  ),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                    Navigator.pushNamed(context, CategoryListRoute);
                                  },
                                ),
                              ),
                              Expanded(
                                child: Container(),
                              ),
                            ],
                          ),
                        ],
                      ),
                    )
                  : Container(),
            ],
          ),
        ),
      );
    }
  }

  Widget _buildStep2(BuildContext context, TopicDetailsVM snapshot) {
    if (snapshot.detailsLoaded == false && snapshot.topicDetails == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: MyShimmer.fromColors(
            child: Container(
              height: 80,
              width: MediaQuery.of(context).size.width.toCustomWidth() - 32,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else if (snapshot.topicDetails['topic'] == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: MyShimmer.fromColors(
            child: Container(
              height: 80,
              width: MediaQuery.of(context).size.width.toCustomWidth() - 32,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      return Column(
        children: [
          Container(
              padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
              margin: EdgeInsets.fromLTRB(16, 12, 16, 0),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(7), color: Colors.white),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: Text(
                            snapshot.topicDetails['level'].toString(),
                            style: TextStyle(fontFamily: "Poppins", color: ColorsLocal.text_color_pink_2, fontWeight: FontWeight.w600, fontSize: 15),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                          child: Text(
                            LocaleKey.YOUR_LEVEL.toLocaleText(),
                            style: TextStyle(fontFamily: "Poppins", color: ColorsLocal.text_color, fontWeight: FontWeight.w400, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 36,
                    width: 0.5,
                    color: Colors.black.withOpacity(0.2),
                  ),
                  Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: Text(
                            snapshot.topicDetails['topic']['follower_count'].toString(),
                            style: TextStyle(fontFamily: "Poppins", color: ColorsLocal.hexToColor("8435E8"), fontWeight: FontWeight.w600, fontSize: 15),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                          child: Text(
                            LocaleKey.FOLLOWER.toLocaleText(),
                            style: TextStyle(fontFamily: "Poppins", color: ColorsLocal.text_color, fontWeight: FontWeight.w400, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 36,
                    width: 0.5,
                    color: Colors.black.withOpacity(0.2),
                  ),
                  Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: Text(
                            snapshot.topicDetails['next_level'].toString(),
                            style: TextStyle(fontFamily: "Poppins", color: ColorsLocal.hexToColor("FBAA19"), fontWeight: FontWeight.w600, fontSize: 15),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                          child: Text(
                            LocaleKey.NEXT_LEVEL.toLocaleText(),
                            style: TextStyle(fontFamily: "Poppins", color: ColorsLocal.text_color, fontWeight: FontWeight.w400, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              )),
        ],
      );
    }
  }

  Widget _buildStep3(BuildContext context, TopicDetailsVM snapshot) {
    if (snapshot.detailsLoaded == false && snapshot.topicDetails == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 20, 120, 18),
        child: MyShimmer.fromColors(
            child: Container(
              height: 20,
              width: MediaQuery.of(context).size.width.toCustomWidth() - 150,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else if (snapshot.topicDetails['topic'] == null || snapshot.topicDetails['ranking'] == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 20, 120, 18),
        child: MyShimmer.fromColors(
            child: Container(
              height: 20,
              width: MediaQuery.of(context).size.width.toCustomWidth() - 150,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      List rankList = snapshot.topicDetails['ranking'];
      return Container(
        margin: EdgeInsets.fromLTRB(20, 20, 20, 18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                child: Text(
                  LocaleKey.RECENT_BEST.toLocaleText(),
                  style: TextStyle(fontSize: 16, color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600),
                ),
              ),
            ),
            snapshot.topicDetails['topic']['participant_count'] >= SHORT_RANKLIST_COUNT
                ? Container(
                    child: RichText(
                      text: TextSpan(
                          text: LocaleKey.SEE_ALL.toLocaleText(),
                          style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.hexToColor("999999"), fontWeight: FontWeight.w600),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.pushNamed(context, ReccentBestAllRoute, arguments: {"topic_id": topicId});
                              //TODO show full list ****
                            }),
                    ),
                  )
                : Container()
          ],
        ),
      );
    }
  }

  Widget _buildPositions(BuildContext context, TopicDetailsVM snapshot, int index) {
    if (snapshot.detailsLoaded == false) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: MyShimmer.fromColors(
            child: Container(
              height: 50,
              width: MediaQuery.of(context).size.width.toCustomWidth(),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else if (snapshot.topicDetails['topic'] == null || snapshot.topicDetails['ranking'] == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: MyShimmer.fromColors(
            child: Container(
              height: 50,
              width: MediaQuery.of(context).size.width.toCustomWidth(),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      List rankList = snapshot.topicDetails['ranking'];

      return Container(
        margin: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(7),
          child: InkWell(
            borderRadius: BorderRadius.circular(7),
            child: Container(
              padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Badge(
                    elevation: 0,
                    padding: EdgeInsets.all(0),
                    badgeColor: Colors.transparent,
                    position: BadgePosition.bottomEnd(bottom: -8, end: -4),
                    animationDuration: Duration(milliseconds: 0),
                    animationType: BadgeAnimationType.slide,
                    badgeContent: Container(
                      margin: EdgeInsets.all(1.5),
                      padding: EdgeInsets.fromLTRB(6, 0, 6, 0),
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(width: 2, color: Colors.white),
                        color: ColorsLocal.hexToColor("8435E8"),
                      ),
                      child: Text(
                        (index + 1).toString().toLocaleNumber(),
                        style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 8),
                      ),
                    ),
                    child: Container(
                        //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
//                        border: Border.all(
//                          width: 2,
//                          color: Colors.grey[300],
//                        ),
                          shape: BoxShape.circle,
                        ),
                        constraints: BoxConstraints.tightFor(height: 34, width: 34),
                        child: CachedNetworkImage(
                          imageUrl: rankList[index]['image_url'].toString(),
                          imageBuilder: (context, imageProvider) => Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              //borderRadius: BorderRadius.circular(4),
                              image: DecorationImage(
                                image: imageProvider,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          placeholder: (context, url) => MyShimmer.fromColors(
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                //borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[300],
                              ),
                            ),
                            baseColor: Colors.grey[300],
                            highlightColor: Colors.white,
                          ),
                          errorWidget: (context, url, error) => Icon(Icons.error),
                        )),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(24, 0, 0, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            rankList[index]['name'].toString(),
                            style: TextStyle(fontFamily: "Poppins", fontSize: 13, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            '${LocaleKey.LEVEL.toLocaleText()} ${rankList[index]['level'].toString()}',
                            style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.text_color, fontWeight: FontWeight.w400),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
//                    decoration: BoxDecoration(
//                      borderRadius: BorderRadius.circular(10),
//                      border: Border.all(
//                        width: 1,
//                        color: ColorsLocal.text_color_pink_2
//                      )
//                    ),
                    padding: EdgeInsets.fromLTRB(15, 4, 15, 4),
                    child: Text(
                      rankList[index]['points'].toString().toLocaleNumber(),
                      style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color_pink_2, fontWeight: FontWeight.w600),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  )
                ],
              ),
            ),
            onTap: () {
              AddFriendPU.show(context, rankList[index]);
            },
          ),
        ),
      );
    }
  }
}
