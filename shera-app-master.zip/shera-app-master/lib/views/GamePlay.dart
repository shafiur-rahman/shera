/*
* Created by Ahammed Hossain Shanto on 7/13/20
*/

import 'dart:convert';
import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/AdmobHelper.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/controllers/SoundController.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/helpers/video-ad-loader.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/utils/FacebookLogger.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Pop_Ups/DownloadApp.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/view-components/Pop_Ups/QuizResultPU.dart';
import 'package:quiz/view-components/Pop_Ups/ReportPU.dart';
import 'package:quiz/view-components/Pop_Ups/WatchVideoPU.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/GamePlayVM.dart';
import 'package:quiz/view-models/TimerVM.dart';
import 'package:toast/toast.dart';
import 'package:video_player/video_player.dart';

class GamePlay extends StatefulWidget {
  @override
  _GamePlayState createState() => _GamePlayState();
}

class _GamePlayState extends State<GamePlay> {
  var arguments;
  double gridMinWidth = 120;
  TimerVM timerVM = new TimerVM();

  VideoPlayerController _videoPlayerController;


  @override
  void dispose() async {
    // TODO: implement dispose
    super.dispose();
    _videoPlayerController?.dispose();
    SoundController.pauseTimer();
    await timerVM?.stopTimer();
    timerVM.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    GamePlayVM gamePlayVM = new GamePlayVM(context, timerVM);
    arguments = ModalRoute.of(context).settings.arguments;
    gamePlayVM.wallet = arguments['wallet'];
    gamePlayVM.question = arguments['question'];
    gamePlayVM.otherDetails = arguments;
    timerVM.setDuration(int.parse(arguments['question']['timer'].toString()));
    if (arguments['question']['type'] == "text" || arguments['question']['type'] == "image") {
      //below to line is required to perform method after time finish*******
      gamePlayVM.setShowOptions(true);
      timerVM.setContext(context);
      timerVM.setGamePlayVM(gamePlayVM);
      timerVM.startTimer();
    }
    //Logger.printWrapped(arguments.toString());
    _setVideoPlayerController(context, gamePlayVM, timerVM);

    // calculating some value for facebook event logging ****
    gamePlayVM.init();

    return RootBody(
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider.value(value: timerVM),
          ChangeNotifierProvider.value(value: gamePlayVM),
        ],
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            centerTitle: true,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Column(
              children: [
                Container(
                  child: Text(
                    arguments['appbar_type'].toString(),
                    style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.hexToColor("FFB800"), fontWeight: FontWeight.w500),
                  ),
                ),
                Container(
                  child: Text(
                    arguments['appbar_name'].toString(),
                    style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            bottom: AppBarBottom.shadow(
                height: 50,
                child: Consumer<GamePlayVM>(builder: (context, snapshot, _) {
                  return Container(
                    margin: EdgeInsets.fromLTRB(40, 0, 40, 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: _buildQuestionNumbers(context, snapshot),
                    ),
                  );
                })),
          ),
          body: Consumer2<GamePlayVM, TimerVM>(builder: (context, gamePlayVm, timerVm, _) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(32, 24, 32, 12),
                  child: Material(
                    borderRadius: BorderRadius.circular(100),
                    clipBehavior: Clip.antiAlias,
                    child: Container(
                      width: MediaQuery.of(context).size.width.toCustomWidth() - 64,
                      height: 30,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(100), color: Colors.white, boxShadow: [BoxShadow(color: Colors.grey[200], spreadRadius: 0.5, blurRadius: 2)]),
                      child: Stack(
                        children: [
                          AnimatedContainer(
                            duration: Duration(milliseconds: timerVm.duration == timerVm.timeLeft ? 300 : 1000),
                            //300 ms to go to its stating position and 1000 ms for each steps
                            width: (MediaQuery.of(context).size.width.toCustomWidth() - 64),
                            margin: EdgeInsets.fromLTRB(0, 0, (MediaQuery.of(context).size.width.toCustomWidth() - 64) * (1 - timerVm.getTimerProgress()), 0),
                            height: 30,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: ColorsLocal.text_color_pink_2,
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            bottom: 0,
                            child: Container(
                              height: 32,
                              width: 32,
                              child: Icon(
                                Icons.timer,
                                color: gamePlayVM.isTimeUp ? Colors.grey[600] : Colors.white,
                                size: 22,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        gamePlayVM.question['type'] == "image"
                            ? Container(
                                margin: EdgeInsets.fromLTRB(28, 16, 28, 0),
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
//                        border: Border.all(
//                          width: 2,
//                          color: Colors.grey[300],
//                        ),
                                  shape: BoxShape.rectangle,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                constraints: BoxConstraints.tightFor(height: (MediaQuery.of(context).size.width.toCustomWidth() - 48) * (9 / 16), width: MediaQuery.of(context).size.width.toCustomWidth() - 48),
                                child: CachedNetworkImage(
                                  imageUrl: gamePlayVM.question['src_url'].toString(),
                                  imageBuilder: (context, imageProvider) => Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.rectangle,
                                      borderRadius: BorderRadius.circular(10),
                                      image: DecorationImage(
                                        image: imageProvider,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  placeholder: (context, url) => CupertinoActivityIndicator(),
                                  errorWidget: (context, url, error) => Icon(Icons.error),
                                ))
                            : Container(),
                        gamePlayVM.question['type'] == "audio"
                            ? Container(
                                width: MediaQuery.of(context).size.width.toCustomWidth() - 56,
                                margin: EdgeInsets.fromLTRB(28, 20, 28, 0),
                                padding: EdgeInsets.fromLTRB(14, 18, 14, 18),
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.white, boxShadow: [BoxShadow(color: Colors.grey[200], blurRadius: 8, spreadRadius: 8)]),
                                child: Row(
                                  children: [
                                    Container(
                                      height: 40,
                                      width: 40,
                                      decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey[300].withOpacity(0.5)),
                                      child: IconButton(
                                        icon: Icon(
                                          gamePlayVM.mediaPosition != null && gamePlayVM.mediaPosition == gamePlayVM.mediaDuration ? Icons.play_arrow : Icons.pause,
                                          size: 24,
                                          color: gamePlayVM.mediaPosition != null && gamePlayVM.mediaPosition == gamePlayVM.mediaDuration ? ColorsLocal.button_color_pink : Colors.grey[500],
                                        ),
                                        padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                                        onPressed: () async {
                                          if (!_videoPlayerController.value.isPlaying && !gamePlayVM.isTimeUp) {
                                            _videoPlayerController.seekTo(Duration(seconds: 0));
                                            _videoPlayerController.play();
                                          }
                                        },
                                      ),
                                    ),
                                    Container(
                                      height: 0,
                                      width: 0,
                                      child: VideoPlayer(
                                        _videoPlayerController != null ? _videoPlayerController : _setVideoPlayerController(context, gamePlayVM, timerVM),
                                      ),
                                    ),
                                    Expanded(
                                      child: Container(
                                        margin: EdgeInsets.fromLTRB(16, 0, 0, 0),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context).size.width.toCustomWidth() - 140,
                                              height: 2,
                                              decoration: BoxDecoration(
                                                color: Colors.grey[200],
                                              ),
                                              child: Row(
                                                children: [
                                                  AnimatedContainer(
                                                    height: 2,
                                                    duration: Duration(milliseconds: 1000),
                                                    width: gamePlayVM.mediaDuration != null ? ((MediaQuery.of(context).size.width.toCustomWidth() - 140) * (gamePlayVM.mediaPosition.inSeconds / gamePlayVM.mediaDuration.inSeconds)) : 0,
                                                    decoration: BoxDecoration(
                                                      color: ColorsLocal.button_color_pink,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                    child: gamePlayVM.mediaPosition != null
                                                        ? Container(
                                                            child: Text('00:${gamePlayVM.mediaPosition.inSeconds}'),
                                                          )
                                                        : Container(
                                                            child: Text("00:00"),
                                                          ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                    child: gamePlayVM.mediaDuration != null
                                                        ? Container(
                                                            child: Text('00:${gamePlayVM.mediaDuration.inSeconds}'),
                                                          )
                                                        : CupertinoActivityIndicator(),
                                                  ),
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : Container(),
                        gamePlayVM.question['type'] == "video"
                            ? Container(
                                width: MediaQuery.of(context).size.width.toCustomWidth() - 56,
                                height: (MediaQuery.of(context).size.width.toCustomWidth() - 56) * (9 / 16),
                                margin: EdgeInsets.fromLTRB(28, 20, 28, 0),
                                child: Material(
                                  clipBehavior: Clip.antiAlias,
                                  borderRadius: BorderRadius.circular(10),
                                  child: Stack(
                                    children: [
                                      gamePlayVM.mediaDuration == null
                                          ? Center(
                                              child: CupertinoActivityIndicator(),
                                            )
                                          : Container(height: 0, width: 0),
                                      Container(
                                        child: VideoPlayer(
                                          _videoPlayerController != null ? _videoPlayerController : _setVideoPlayerController(context, gamePlayVM, timerVM),
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        bottom: 0,
                                        top: 0,
                                        right: 0,
                                        child: gamePlayVM.mediaDuration != null && gamePlayVM.mediaDuration.inSeconds == gamePlayVM.mediaPosition.inSeconds
                                            ? Center(
                                                child: Container(
                                                  height: 56,
                                                  width: 56,
                                                  decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                                                  child: IconButton(
                                                    icon: Icon(
                                                      Icons.play_arrow,
                                                      size: 28,
                                                      color: ColorsLocal.button_color_pink,
                                                    ),
                                                    padding: EdgeInsets.fromLTRB(12, 12, 12, 12),
                                                    onPressed: () async {
                                                      if (!_videoPlayerController.value.isPlaying && !gamePlayVM.isTimeUp) {
                                                        _videoPlayerController.seekTo(Duration(seconds: 0));
                                                        _videoPlayerController.play();
                                                      }
                                                    },
                                                  ),
                                                ),
                                              )
                                            : Container(height: 0, width: 0),
                                      ),
                                      Positioned(
                                        left: 0,
                                        bottom: 0,
                                        right: 0,
                                        child: Container(
                                          width: MediaQuery.of(context).size.width.toCustomWidth() - 56,
                                          height: 2,
                                          decoration: BoxDecoration(
                                            color: Colors.grey[200],
                                          ),
                                          child: Row(
                                            children: [
                                              AnimatedContainer(
                                                height: 2,
                                                duration: Duration(milliseconds: 1000),
                                                width: gamePlayVM.mediaDuration != null ? ((MediaQuery.of(context).size.width.toCustomWidth() - 56) * (gamePlayVM.mediaPosition.inSeconds / gamePlayVM.mediaDuration.inSeconds)) : 0,
                                                decoration: BoxDecoration(
                                                  color: ColorsLocal.button_color_pink,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : Container(),
                        Container(
                          margin: EdgeInsets.fromLTRB(32, 22, 32, 0),
                          child: Wrap(
                            children: [
                              Text(
                                gamePlayVM.question['question_value'].toString(),
                                style: TextStyle(fontSize: 22, color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w700),
                                textAlign: TextAlign.start,
                              ),
                              Material(
                                  clipBehavior: Clip.antiAlias,
                                  color: ColorsLocal.hexToColor("FBAA19"),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(6.0),
                                  ),
                                  child: InkWell(
                                      onTap: () {
                                        ReportPU.showDialog(context, gamePlayVM.question["question_id"]);
                                      },
                                      child: Container(
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                                          child: Text(
                                            LocaleKey.REPORT.toLocaleText(),
                                            style: TextStyle(fontSize: 10, color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      )))
                            ],
                          ),
                        ),
                        gamePlayVM.showOptions ? _buildTextOptions(context, gamePlayVM, timerVM) : Container(),
                        gamePlayVM.showOptions ? _buildImageOptions(context, gamePlayVM, timerVM) : Container(),
                      ],
                    ),
                  ),
                ),
              ],
            );
          }),
          bottomNavigationBar: BottomAppBar(
            elevation: 10,
            child: Consumer2<GamePlayVM, TimerVM>(builder: (context, gamePlayVM, timerVM, _) {
              return Container(
                margin: EdgeInsets.fromLTRB(28, 0, 28, 0),
                height: gamePlayVM.isSubmitted || gamePlayVM.isTimeUp ? 72 : 0,
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    gamePlayVM.isCorrect
                        ? Container()
                        : Expanded(
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                              child: RaisedButton(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    side: BorderSide(
                                      width: 2,
                                      color: ColorsLocal.hexToColor("E6E6E6"),
                                    )),
                                color: Colors.white,
                                elevation: 0,
                                highlightElevation: 0,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
                                  child: Row(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(right: 8),
                                        child: Image.asset(
                                          "assets/images/ic_coin.png",
                                          height: 16,
                                          width: 16,
                                        ),
                                      ),
                                      Container(
                                        child: Text(
                                          LocaleKey.USE_COIN.toLocaleText(),
                                          style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color_pink, fontWeight: FontWeight.w500),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                onPressed: () {
                                  _videoPlayerController?.pause();
                                  _videoPlayerController = null;
                                  WatchVideoPU.show(
                                    context,
                                    gamePlayVM,
                                    gamePlayVM.wallet,
                                    retryCoinAmount: int.parse(gamePlayVM.otherDetails['retry_coin_amount'].toString()),
                                    onWatchVideoTap: () {
                                      if(PackageSupport.instance.isMobile()) {

                                        gamePlayVM.popupWorking = true;
                                        gamePlayVM.notify();

                                        new VideoAdLoader(
                                            onAdLoaded: (videoAdLoader) {
                                              gamePlayVM.popupWorking = false;
                                              gamePlayVM.notify();
                                              videoAdLoader.showAd();
                                            },
                                            onRewarded: (videoAdLoader) {
                                              gamePlayVM.adWatchDone = true;
                                              FacebookLogger.adWatchForRetry(type: "quiz");
                                              gamePlayVM.retryWithAd().then((value) {
                                                if (value) {
                                                  Navigator.of(context).pop();
                                                  gamePlayVM?.tryAgain();
                                                } else {
                                                  //Do nothing
                                                }
                                              });
                                            },
                                            onAdClosed: (videoAdLoader) {
                                              // Logger.printWrapped("quizgiri: ad closed");
                                              // if (!gamePlayVM.popupWorking && gamePlayVM.adWatchDone) {
                                              //   gamePlayVM.retryWithAd().then((value) {
                                              //     if (value) {
                                              //       Navigator.of(context).pop();
                                              //       gamePlayVM?.tryAgain();
                                              //     } else {
                                              //       //Do nothing
                                              //     }
                                              //   });
                                              // }
                                            },
                                            onAdLoadingFailed: (val) {
                                              Toast.show("No ads are available now. Try again later", context);
                                              gamePlayVM.popupWorking = false;
                                              gamePlayVM.notify();
                                              FacebookLogger.adLoadFailed();
                                            }
                                        ).init();

                                        /// previous admob implementation ***

                                        // MobileAdTargetingInfo targetingInfo = MobileAdTargetingInfo(
                                        //   keywords: <String>['quizgiri'],
                                        //   contentUrl: 'https://quizgiri.xyz',
                                        //   birthday: DateTime.now(),
                                        //   childDirected: false,
                                        //   designedForFamilies: false,
                                        //   gender: MobileAdGender.unknown,
                                        //   testDevices: <String>[], // Android emulators are considered test devices
                                        // );
                                        // gamePlayVM.popupWorking = true;
                                        // gamePlayVM.notify();
                                        // RewardedVideoAd.instance.load(adUnitId: AdmobHelper.getResumeGameUnitId(), targetingInfo: targetingInfo).then((value) {
                                        //   if (value) {
                                        //     RewardedVideoAd.instance.listener = (RewardedVideoAdEvent event, {String rewardType, int rewardAmount}) {
                                        //       if (event == RewardedVideoAdEvent.loaded) {
                                        //         gamePlayVM.popupWorking = false;
                                        //         gamePlayVM.notify();
                                        //         RewardedVideoAd.instance.show();
                                        //       }
                                        //       if (event == RewardedVideoAdEvent.rewarded) {
                                        //         gamePlayVM.adWatchDone = true;
                                        //         FacebookLogger.adWatchForRetry(type: "quiz");
                                        //       }
                                        //       if (event == RewardedVideoAdEvent.closed) {
                                        //         if (!gamePlayVM.popupWorking && gamePlayVM.adWatchDone) {
                                        //           gamePlayVM.retryWithAd().then((value) {
                                        //             if (value) {
                                        //               Navigator.of(context).pop();
                                        //               gamePlayVM?.tryAgain();
                                        //             } else {
                                        //               //Do nothing
                                        //             }
                                        //           });
                                        //         }
                                        //       }
                                        //       if (event == RewardedVideoAdEvent.failedToLoad) {
                                        //         Toast.show("Failed to load ad. Try again later", context);
                                        //         gamePlayVM.popupWorking = false;
                                        //         gamePlayVM.notify();
                                        //         FacebookLogger.adLoadFailed();
                                        //       }
                                        //     };
                                        //   }
                                        // });
                                      }
                                      else {
                                        DownloadApp.showDialog(context);
                                      }
                                    },
                                    onCoinUseTap: () {
                                      if (!gamePlayVM.popupWorking) {
                                        if (gamePlayVM.wallet['coins'] >= int.parse(gamePlayVM.otherDetails['retry_coin_amount'].toString())) {
                                          gamePlayVM.retryWithCoins().then((value) {
                                            if (value) {
                                              Navigator.of(context).pop();
                                              gamePlayVM?.tryAgain();
                                            } else {
                                              //Do nothing
                                            }
                                          });
                                        } else {
                                          LocalAlert.showDialog(context, "Oppss!!", "You don't have enough coins");
                                        }
                                      }
                                    },
                                  );
                                },
                              ),
                            ),
                          ),
                    gamePlayVM.isSubmitted || (gamePlayVM.isTimeUp && gamePlayVM.submitResponse != null)
                        ? Expanded(
                            child: Container(
                              margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                              child: RaisedButton(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                color: ColorsLocal.button_color_purple,
                                elevation: 0,
                                highlightElevation: 0,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
                                  child: Text(
                                    gamePlayVM.questionFinished ? LocaleKey.SEE_RESULT.toLocaleText() : LocaleKey.NEXT.toLocaleText(),
                                    style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.white, fontWeight: FontWeight.w500),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                onPressed: () {
                                  _videoPlayerController = null;
                                  if (gamePlayVM.questionFinished) {
                                    gamePlayVM.showInterstitial();
                                    QuizResultPU.show(context, double.parse(gamePlayVM.submitResponse['progress_topic'].toString()), int.parse(gamePlayVM.submitResponse['total_quiz'].toString()), gamePlayVM.submitResponse['total_correct'], gamePlayVM.submitResponse['level'].toString(), gamePlayVM.submitResponse['next_topic_id'], onCancel: () {
                                      Navigator.of(context).pop();
                                      Navigator.of(context).pop();
                                    }, onTryAgainTap: () {
                                      Navigator.of(context).pop();
                                      Navigator.of(context).pop();
                                    }, onNextTopicTap: () {
                                      Navigator.popUntil(context, (route) {
                                        if (route.settings.name == HomeRoute) {
                                          Navigator.pushNamed(context, TopicDetailsRoute, arguments: {'topic_id': gamePlayVM.submitResponse['next_topic_id'], 'type': gamePlayVM.submitResponse['next_topic_title'], 'category_name': gamePlayVM.submitResponse['next_topic_category']});
                                          return true;
                                        } else {
                                          return false;
                                        }
                                      });
                                    }, onChallenge: () {
                                      Navigator.pushNamed(context, SelectFriendRoute);
                                    });
                                  } else {
                                    gamePlayVM.nextQuiz();
                                  }
                                },
                              ),
                            ),
                          )
                        : Container()
                  ],
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildQuestionNumbers(BuildContext context, GamePlayVM snapshot) {
    List<Widget> items = new List();

    for (int i = snapshot.question['question_no']; i <= (int.parse(snapshot.question['question_no'].toString()) + min(4, int.parse(snapshot.question['questions_left'].toString()))); i++) {
      Logger.printWrapped("question number added");
      Widget item = new Container(
        child: Container(
          child: Text(
            i.toString().toLocaleNumber(),
            style: TextStyle(fontSize: 15, fontFamily: "Poppins", fontWeight: FontWeight.w600, color: i == int.parse(snapshot.question['question_no'].toString()) ? ColorsLocal.text_color_pink_2 : ColorsLocal.hexToColor("BAB8B8")),
          ),
        ),
      );

      items.add(item);
    }

    return items;
  }

  Widget _buildTextOptions(BuildContext context, GamePlayVM gamePlayVM, TimerVM timerVM) {
    if (gamePlayVM.question['option_type'] == "text") {
      List options = gamePlayVM.question['options'];
      return Container(
        padding: EdgeInsets.fromLTRB(32, 12, 32, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: List.generate(options.length, (index) {
            return Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              child: Container(
                margin: EdgeInsets.fromLTRB(0, 8, 0, 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(24, 20, 24, 20),
                    decoration: BoxDecoration(
                      //color: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index ? Colors.transparent : Colors.white.withOpacity(0.33),
                      gradient: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index && gamePlayVM.selectedIndex == index
                          ? LinearGradient(colors: [ColorsLocal.hexToColor("01A757"), ColorsLocal.hexToColor("0EC06B")], stops: [0.0, 1.0], begin: Alignment.bottomCenter, end: Alignment.topCenter)
                          : LinearGradient(
                              colors: [Colors.white.withOpacity(0.5), Colors.white.withOpacity(0.33)],
                              stops: [0.0, 1.0],
                            ),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        width: gamePlayVM.correctAnsIndex == index && gamePlayVM.selectedIndex == index ? 0 : 2,
                        color: gamePlayVM.selectedIndex == index && gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex != index
                            ? ColorsLocal.text_color_pink_2
                            : gamePlayVM.selectedIndex == index && gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex != index
                                ? Colors.transparent
                                : ColorsLocal.hexToColor("E6E6E6"),
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                            child: Text(
                              options[index]['value'].toString(),
                              style: TextStyle(fontFamily: "Poppins", color: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index && gamePlayVM.selectedIndex == index ? Colors.white : ColorsLocal.hexToColor("747474"), fontSize: 18, fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                        gamePlayVM.selectedIndex == index && !gamePlayVM.isSubmitted ? CupertinoActivityIndicator() : Container(width: 0, height: 0),
                      ],
                    ),
                  ),
                  onTap: () {
                    _videoPlayerController?.pause();
                    gamePlayVM.submitAnswer(index);
                  },
                ),
              ),
            );
          }),
        ),
      );
    } else {
      return Container();
    }
  }

  Widget _buildImageOptions(BuildContext context, GamePlayVM gamePlayVM, TimerVM timerVM) {
    if (gamePlayVM.question['option_type'] == "image") {
      List options = gamePlayVM.question['options'];
      return Container(
        padding: EdgeInsets.fromLTRB(32, 12, 32, 12),
        child: Wrap(
          runSpacing: 16,
          spacing: 16,
          children: List.generate(options.length, (index) {
            return Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              child: Container(
                child: InkWell(
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    decoration: BoxDecoration(
                      //color: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index ? Colors.transparent : Colors.white.withOpacity(0.33),
                      gradient: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index && gamePlayVM.selectedIndex == index
                          ? LinearGradient(colors: [ColorsLocal.hexToColor("01A757"), ColorsLocal.hexToColor("0EC06B")], stops: [0.0, 1.0], begin: Alignment.bottomCenter, end: Alignment.topCenter)
                          : LinearGradient(
                              colors: [Colors.white.withOpacity(0.5), Colors.white.withOpacity(0.33)],
                              stops: [0.0, 1.0],
                            ),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        width: gamePlayVM.correctAnsIndex == index ? 4 : 0,
                        color: gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex == index && gamePlayVM.selectedIndex == index ? ColorsLocal.hexToColor("00B359").withOpacity(0.66) : Colors.transparent,
                      ),
                    ),
                    height: _getGridWidth(context) - 8,
                    width: _getGridWidth(context) - 8,
                    child: Stack(
                      children: [
                        Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            constraints: BoxConstraints.tightFor(
                              height: _getGridWidth(context),
                              width: _getGridWidth(context),
                            ),
                            child: CachedNetworkImage(
                              imageUrl: gamePlayVM.question['options'][index]['src_url'].toString(),
                              imageBuilder: (context, imageProvider) => Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.rectangle,
                                  borderRadius: BorderRadius.circular(8),
                                  image: DecorationImage(
                                    image: imageProvider,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              placeholder: (context, url) => CupertinoActivityIndicator(),
                              errorWidget: (context, url, error) => Icon(Icons.error),
                            )),
                        Positioned(
                          left: 0,
                          right: 0,
                          top: 0,
                          bottom: 0,
                          child: gamePlayVM.selectedIndex == index && !gamePlayVM.isSubmitted
                              ? Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.6),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: CupertinoActivityIndicator())
                              : Container(width: 0, height: 0),
                        ),
                        Positioned(
                            left: 0,
                            right: 0,
                            top: 0,
                            bottom: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                color: gamePlayVM.selectedIndex == index && gamePlayVM.isSubmitted && gamePlayVM.correctAnsIndex != index ? ColorsLocal.hexToColor("FF2E75").withOpacity(0.66) : Colors.transparent,
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ))
                      ],
                    ),
                  ),
                  onTap: () {
                    _videoPlayerController?.pause();
                    gamePlayVM.submitAnswer(index);
                  },
                ),
              ),
            );
          }),
        ),
      );
    } else {
      return Container();
    }
  }

  int _getRowCount(BuildContext context) {
    double totalWidth = MediaQuery.of(context).size.width.toCustomWidth();
    double availableWidth = totalWidth - 56;

    int rowCount = availableWidth ~/ (gridMinWidth + 16);
    return rowCount;
  }

  double _getGridWidth(BuildContext context) {
    double totalWidth = MediaQuery.of(context).size.width.toCustomWidth();
    double availableWidth = totalWidth - 56;

    int rowCount = _getRowCount(context);
    double totalVerticalSpacing = (rowCount - 1) * 16.toDouble();
    double availableWidthWithoutSpacing = availableWidth - totalVerticalSpacing;
    //Logger.printWrapped((availableWidthWithoutSpacing/rowCount).toString());
    return availableWidthWithoutSpacing / rowCount;
  }

  VideoPlayerController _setVideoPlayerController(BuildContext context, GamePlayVM gamePlayVM, TimerVM timerVM) {
    if (gamePlayVM.question['type'] == "video" || gamePlayVM.question['type'] == "audio") {
      _videoPlayerController = VideoPlayerController.network(
        gamePlayVM.question['src_url'].toString(),
      )..initialize().then((_) {
          gamePlayVM.setMediaDuration(_videoPlayerController.value.duration);
          _videoPlayerController.play();
        });
      _videoPlayerController?.addListener(() {
        gamePlayVM.setMediaPosition(_videoPlayerController.value.position);
        if (_videoPlayerController.value.position == _videoPlayerController.value.duration) {
          if (!gamePlayVM.mediaPlayed) {
            gamePlayVM.setMediaStatus(true);
            gamePlayVM.setShowOptions(true);
            //Logger.printWrapped("Video ended");
            timerVM.startTimer();
          }
        }
      });
    }

    return _videoPlayerController;
  }
}
