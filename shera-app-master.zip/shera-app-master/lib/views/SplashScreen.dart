import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:launch_review/launch_review.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/constants/UrlHelper.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/SplashScreenVM.dart';
import 'package:url_launcher/url_launcher.dart';

class SplashScreen extends StatelessWidget {
  //final SplashScreenVM splashScreenVM = new SplashScreenVM();

  SplashScreen();

  init() {
    if (!kIsWeb) {
      SystemChrome.setEnabledSystemUIOverlays([]);

      /// previous admob implementation ***

      // FirebaseAdMob.instance.initialize(appId: AdmobHelper.getAppId());
    }
  }

  @override
  Widget build(BuildContext context) {
    //FirebaseAdMob.instance.initialize(appId: AdmobHelper.getAppId());
    //splashScreenVM.context = context;
    //splashScreenVM.startCheckingRequirements();

    //SystemChrome.setEnabledSystemUIOverlays(SystemUiOverlay.values);
    init();

    return RootBody(
      needLogin: false,
      child: ChangeNotifierProvider(
        create: (_) => SplashScreenVM(context),
        child: Scaffold(
          body: Stack(
            children: [
              Center(
                child: Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 200),
                  height: 140,
                  width: 200,
                  child: Image.asset("assets/images/text_logo.png"),
                ),
              ),
              Consumer<SplashScreenVM>(builder: (context, snapshot, _) {
                if (snapshot.isCheckingComplete) {
                  if (snapshot.readyToStart()) {
                    return Positioned(
                      left: 36,
                      right: 36,
                      bottom: 36,
                      child: Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              decoration: BoxDecoration(boxShadow: <BoxShadow>[
                                BoxShadow(
                                  color: Colors.pink.withOpacity(0.57),
                                  blurRadius: 4,
                                  offset: Offset(0, 4),
                                ),
                              ], borderRadius: BorderRadius.circular(10)),
                              child: RaisedButton(
                                color: ColorsLocal.button_color_pink,
                                padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Container(
                                  child: Text(
                                    "Get Started",
                                    style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 22),
                                  ),
                                ),
                                onPressed: () {
                                  Navigator.pushReplacementNamed(context, LoginWithMobileRoute);
                                },
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                              child: RichText(
                                textAlign: TextAlign.center,
                                text: TextSpan(text: "You are going to agree with the ", style: TextStyle(fontFamily: "Poppins", fontSize: 12, fontWeight: FontWeight.w400, color: Colors.grey[800]), children: <TextSpan>[
                                  TextSpan(
                                    text: "Terms & Conditions ",
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () async {
                                        if (await canLaunch(UrlHelper.termsAndConditions())) {
                                          await launch(UrlHelper.termsAndConditions());
                                        } else {
                                          throw 'Could not launch ${UrlHelper.termsAndConditions()}';
                                        }
                                      },
                                    style: TextStyle(fontFamily: "Poppins", fontSize: 12, fontWeight: FontWeight.w600, color: Colors.grey[900]),
                                  ),
                                  TextSpan(
                                    text: "& ",
                                  ),
                                  TextSpan(
                                    text: "Privacy Policy",
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () async {
                                        if (await canLaunch(UrlHelper.privacyPolicy())) {
                                          await launch(UrlHelper.privacyPolicy());
                                        } else {
                                          throw 'Could not launch ${UrlHelper.privacyPolicy()}';
                                        }
                                      },
                                    style: TextStyle(fontFamily: "Poppins", fontSize: 12, fontWeight: FontWeight.w600, color: Colors.grey[900]),
                                  ),
                                ]),
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  } else if (snapshot.readyToUpdate()) {
                    return Positioned(
                      left: 36,
                      right: 36,
                      bottom: 36,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            child: Text(
                              snapshot.updateMessage,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.grey[900], fontWeight: FontWeight.w400),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.pink.withOpacity(0.57),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                              ),
                            ], borderRadius: BorderRadius.circular(10)),
                            child: RaisedButton(
                              color: ColorsLocal.button_color_pink,
                              padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Container(
                                child: Text(
                                  "Update Now",
                                  style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18),
                                ),
                              ),
                              onPressed: () {
                                LaunchReview.launch(androidAppId: PACKAGE_NAME_ANDROID, iOSAppId: APP_STORE_ID);
                              },
                            ),
                            margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                          ),
                          !snapshot.isMajorUpdate
                              ? Container(
                                  decoration: BoxDecoration(),
                                  child: RaisedButton(
                                    color: Colors.transparent,
                                    padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Container(
                                      child: Text(
                                        "Skip",
                                        style: TextStyle(color: Colors.grey[800], fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 15),
                                      ),
                                    ),
                                    onPressed: () {
                                      if (snapshot.tokenOk == 1) {
                                        Navigator.pushReplacementNamed(context, HomeRoute);
                                      } else {
                                        Navigator.pushReplacementNamed(context, LoginWithMobileRoute);
                                      }
                                    },
                                    highlightElevation: 0,
                                  ),
                                  margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                )
                              : Container(),
                        ],
                      ),
                    );
                  } else if (!snapshot.connectedToInternet()) {
                    return Positioned(
                      left: 36,
                      right: 36,
                      bottom: 36,
                      child: Column(
                        children: [
                          Container(
                            child: Text(
                              "No internet connection. Please make sure the device is connected to the internet",
                              style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.red[700], fontWeight: FontWeight.w400),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.pink.withOpacity(0.57),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                              ),
                            ], borderRadius: BorderRadius.circular(10)),
                            child: RaisedButton(
                              color: ColorsLocal.button_color_pink,
                              padding: EdgeInsets.fromLTRB(32, 12, 32, 12),
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Container(
                                child: Text(
                                  "Retry",
                                  style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 18),
                                ),
                              ),
                              onPressed: () {
                                snapshot.reset();
                                snapshot.startCheckingRequirements();
                              },
                            ),
                            margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                          ),
                        ],
                      ),
                    );
                  } else {
                    return Container();
                  }
                } else {
                  return Positioned(
                    left: 32,
                    right: 32,
                    bottom: 100,
                    child: CupertinoActivityIndicator(),
                  );
                }
              })
            ],
          ),
        ),
      ),
    );
  }
}
