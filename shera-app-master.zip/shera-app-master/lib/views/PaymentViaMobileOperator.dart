/*
* Created by Ahammed Hossain Shanto
* on 10/13/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Pop_Ups/ConfimationPU.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/PaymentViaMobileOperatorVM.dart';

class PaymentViaMobileOperator extends StatelessWidget {
  var arguments;
  int bundle_id;
  String caption;
  double price;
  int tournamentId;
  int subscription_fee;
  PaymentViaMobileOperatorVM paymentViaMobileOperatorVM;

  PaymentViaMobileOperator(this.arguments) {
    bundle_id = arguments["bundle_id"];
    caption = arguments["caption"];
    price = arguments["price"];
    tournamentId = arguments["tournament_id"];
    subscription_fee = arguments["subscription_fee"];
  }

  @override
  Widget build(BuildContext context) {
    paymentViaMobileOperatorVM = new PaymentViaMobileOperatorVM(context);
    return RootBody(
      child: ChangeNotifierProvider.value(
        value: paymentViaMobileOperatorVM,
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(75),
            child: AppBar(
              elevation: 0,
              leading: Container(
                child: IconButton(
                  icon: Image.asset(
                    "assets/images/back_arrow.png",
                    height: 20,
                    width: 24,
                  ),
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
              title: Text(
                "Mobile Operators",
                style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          body: Consumer<PaymentViaMobileOperatorVM>(
            builder: (context, snapshot, _) {
              return Padding(padding: EdgeInsets.fromLTRB(0, 50, 0, 0), child: buildPaymentOptions(context, snapshot, bundle_id, tournamentId));
            },
          ),
        ),
      ),
    );
  }

  Widget buildPaymentOptions(BuildContext context, PaymentViaMobileOperatorVM snapshot, int bundle_id, int tournamentId) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
            margin: EdgeInsets.fromLTRB(30, 0, 0, 0),
            child: Text(
              "Select Your Mobile Operator",
              style: TextStyle(
                fontFamily: "Poppins",
                color: ColorsLocal.hexToColor("414141"),
                fontSize: 14,
              ),
            )),
        Container(
          margin: EdgeInsets.fromLTRB(30, 10, 30, 0),
          child: Material(
            elevation: .1,
            borderRadius: BorderRadius.circular(7),
            clipBehavior: Clip.antiAlias,
            color: Colors.white,
            child: InkWell(
              onTap: () {
                ConfirmationPU.showDialog(context, price, caption, bundle_id, tournamentId, subscription_fee, paymentViaMobileOperatorVM);
              },
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, 5, 20, 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey[100],
                        ),
                        constraints: BoxConstraints.tightFor(height: 64, width: 64),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Image.asset(
                            "assets/images/pm_robi.png",
                          ),
                        )),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.only(left: 16, right: 16),
                        child: Text(
                          "Robi",
                          style: TextStyle(
                            fontFamily: "Poppins",
                            color: ColorsLocal.hexToColor("000000"),
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                      color: ColorsLocal.hexToColor("686868"),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
        Container(
          margin: EdgeInsets.fromLTRB(30, 10, 30, 0),
          child: Material(
            elevation: .1,
            borderRadius: BorderRadius.circular(7),
            clipBehavior: Clip.antiAlias,
            color: Colors.white,
            child: InkWell(
              onTap: () {
                ConfirmationPU.showDialog(context, price, caption, bundle_id, tournamentId, subscription_fee, paymentViaMobileOperatorVM);
              },
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, 5, 20, 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey[100],
                        ),
                        constraints: BoxConstraints.tightFor(height: 64, width: 64),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Image.asset(
                            "assets/images/pm_airtel.png",
                          ),
                        )),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.only(left: 16, right: 16),
                        child: Text(
                          "Airtel",
                          style: TextStyle(
                            fontFamily: "Poppins",
                            color: ColorsLocal.hexToColor("000000"),
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                      color: ColorsLocal.hexToColor("686868"),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
