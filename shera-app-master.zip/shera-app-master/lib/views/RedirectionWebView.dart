/*
* Created by Ahammed Hossain Shanto
* on 10/12/20
*/

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:webview_flutter/webview_flutter.dart';

class RedirectionWebView extends StatelessWidget {
  Completer<WebViewController> _controller = Completer<WebViewController>();

  String launchUrl;

  RedirectionWebView() {
    if(kIsWeb) {
      if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
    }
  }

  @override
  Widget build(BuildContext context) {
    dynamic arguments = ModalRoute.of(context).settings.arguments;
    launchUrl = arguments['launch_url'];

    return RootBody(
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          centerTitle: false,
          leading: Container(
            child: IconButton(
              icon: Image.asset(
                "assets/images/back_arrow.png",
                height: 20,
                width: 24,
              ),
              padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ),
          title: Container(
            child: Text(
              "",
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
          ),
        ),
        body: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              top: 0,
              bottom: 0,
              child: WebView(
                initialUrl: launchUrl,
                javascriptMode: JavascriptMode.unrestricted,
                onPageFinished: (String url) {},
                onWebViewCreated: (WebViewController controller) {
                  _controller.complete(controller);
                },
                onPageStarted: (value) {
                  //Logger.printWrapped("pageStarted");
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
