/*
* Created by Ahammed Hossain Shanto on 7/19/20
*/

import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Pop_Ups/DownloadApp.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/EditProfileVM.dart';
import 'package:toast/toast.dart';

class EditProfile extends StatelessWidget {
  var profileDetails;
  TextEditingController _tcName, _tcEmail;

  EditProfile(this.profileDetails) {
    _tcName = new TextEditingController(text: profileDetails['name'] ?? "");
    _tcEmail = new TextEditingController(text: profileDetails['email'] ?? "");
  }

  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) => EditProfileVM(profileDetails),
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.EDIT_PROFILE.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Consumer<EditProfileVM>(
                  builder: (context, snapshot, _) {
                    return _buildProfile(context, snapshot);
                  },
                ),
                Consumer<EditProfileVM>(
                  builder: (context, snapshot, _) {
                    return _buildInputs(context, snapshot);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfile(BuildContext context, EditProfileVM snapshot) {
    return Container(
      margin: EdgeInsets.fromLTRB(36, 44, 36, 0),
      child: Column(
        children: [
          Badge(
            position: BadgePosition.bottomEnd(end: 0, bottom: 0),
            toAnimate: false,
            badgeColor: Colors.transparent,
            elevation: 0,
            badgeContent: Container(
              child: InkWell(
                borderRadius: BorderRadius.circular(100),
                child: Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.4),
                    border: Border.all(width: 2, color: Colors.white),
                  ),
                  child: Icon(
                    Icons.edit,
                    color: Colors.white,
                    size: 12,
                  ),
                ),
                onTap: () {
                  //TODO invoke image picker
                  if (PackageSupport.instance.isMobile()) {
                    snapshot.pickImage(context);
                  } else {
                    DownloadApp.showDialog(context);
                  }
                },
              ),
            ),
            child: snapshot.uploadingImage
                ? Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                        border: Border.all(
                          width: 4,
                          color: Colors.white,
                        ),
                        shape: BoxShape.circle),
                    child: Center(
                      child: CupertinoActivityIndicator(),
                    ),
                  )
                : Container(
                    //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        border: Border.all(
                          width: 4,
                          color: Colors.white,
                        ),
                        shape: BoxShape.circle),
                    constraints: BoxConstraints.tightFor(height: 100, width: 100),
                    child: CachedNetworkImage(
                      imageUrl: snapshot.profileDetails['image_url'].toString(),
                      imageBuilder: (context, imageProvider) => Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          //borderRadius: BorderRadius.circular(4),
                          image: DecorationImage(
                            image: imageProvider,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      placeholder: (context, url) => MyShimmer.fromColors(
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            //borderRadius: BorderRadius.circular(8),
                            color: Colors.grey[300],
                          ),
                        ),
                        baseColor: Colors.grey[300],
                        highlightColor: Colors.white,
                      ),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                    )),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
            child: Text(
              profileDetails['name'].toString(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 20, color: ColorsLocal.text_color_pink_2, fontWeight: FontWeight.w600),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputs(BuildContext context, EditProfileVM snapshot) {
    return Container(
      margin: EdgeInsets.fromLTRB(36, 36, 36, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            child: Text(
              LocaleKey.FULL_NAME.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w400),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
            padding: EdgeInsets.fromLTRB(24, 8, 24, 8),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                width: 1,
                color: ColorsLocal.hexToColor("E6E6E6"),
              ),
              borderRadius: BorderRadius.circular(15),
            ),
            child: TextField(
              controller: _tcName,
              textAlign: TextAlign.start,
              style: TextStyle(fontFamily: "Poppins", fontSize: 17, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
              maxLines: 1,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: "Your Name",
                border: InputBorder.none,
                hintStyle: TextStyle(
                  color: ColorsLocal.hexToColor("d4ddec"),
                ),
                counterText: "",
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 18, 0, 0),
            child: Text(
              LocaleKey.MOBILE.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w400),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
            padding: EdgeInsets.fromLTRB(24, 20, 24, 20),
            decoration: BoxDecoration(
              color: ColorsLocal.hexToColor("EDF0FA"),
              border: Border.all(
                width: 1,
                color: ColorsLocal.hexToColor("E6E7E8"),
              ),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Text(
              '${profileDetails['phone'].toString()}',
              style: TextStyle(fontFamily: "Poppins", fontSize: 17, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
              textAlign: TextAlign.start,
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 18, 0, 0),
            child: Text(
              LocaleKey.EMAIL.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w400),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
            padding: EdgeInsets.fromLTRB(24, 8, 24, 8),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                width: 1,
                color: ColorsLocal.hexToColor("E6E6E6"),
              ),
              borderRadius: BorderRadius.circular(15),
            ),
            child: TextField(
              controller: _tcEmail,
              textAlign: TextAlign.start,
              style: TextStyle(fontFamily: "Poppins", fontSize: 17, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
              maxLines: 1,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                hintText: "Hello@gmail.com",
                border: InputBorder.none,
                hintStyle: TextStyle(
                  color: ColorsLocal.hexToColor("d4ddec"),
                ),
                counterText: "",
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 96, 0, 36),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                    child: RaisedButton(
                      child: Container(
                        padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
                        child: Text(
                          LocaleKey.CANCEL.toLocaleText(),
                          style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: Colors.white, fontWeight: FontWeight.w500),
                        ),
                      ),
                      color: ColorsLocal.button_color_purple,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      elevation: 0,
                      highlightElevation: 0,
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                    child: RaisedButton(
                      child: Container(
                        padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
                        child: snapshot.infoUpdating
                            ? SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                ),
                              )
                            : Text(
                                LocaleKey.SAVE.toLocaleText(),
                                style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: Colors.white, fontWeight: FontWeight.w500),
                              ),
                      ),
                      color: ColorsLocal.button_color_pink,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      elevation: 0,
                      highlightElevation: 0,
                      onPressed: () {
                        if (_tcName.text.length != 0 && _tcEmail.text.length != 0) {
                          snapshot.profileDetails['name'] = _tcName.text.toString();
                          snapshot.profileDetails['email'] = _tcEmail.text.toString();
                          snapshot.updateInfo().then((flag) {
                            if (flag) {
                              Navigator.of(context).pop(true);
                            } else {
                              Toast.show("Error Occurred. Try later!", context);
                            }
                          });
                        } else {
                          Toast.show("Name & Email should not be empty", context);
                        }
                      },
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
