import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/models/RedirectToBrowser.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';

class DummyUI extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
        child: Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            decoration: BoxDecoration(color: Colors.white),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(32, 0, 32, 0),
                    child: Text(
                      "Do you want to explore QuizGiri?",
                      style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600, decoration: TextDecoration.none),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 32, 0, 0),
                    child: RaisedButton(
                        elevation: 0,
                        highlightElevation: 0,
                        child: Text(
                          "Visit Now",
                          style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                        ),
                        color: ColorsLocal.button_color_pink,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
                        onPressed: () async {
                          RedirectToBrowser.instance.launch(WEB_APP_URL, newTab: false);
                        }),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ));
  }
}
