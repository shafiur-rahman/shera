/*
* Created by Ahammed Hossain Shanto
* on 8/10/20
*/

import 'dart:convert';
import 'dart:math';

import 'package:dotted_border/dotted_border.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/InviteFriendsVM.dart';
import 'package:share/share.dart';

class InviteFriends extends StatelessWidget {
  TextEditingController _textEditingController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    if (ModalRoute.of(context).settings.arguments != null) {
      dynamic arguments = ModalRoute.of(context).settings.arguments;
      if (arguments['invite_code'] != null) {
        _textEditingController.text = arguments['invite_code'].toString();
      }
    }

    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return InviteFriendsVM();
        },
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.INVITE_FRIENDS.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Consumer<InviteFriendsVM>(builder: (context, snapshot, _) {
            return SingleChildScrollView(
              child: _buildBody(context, snapshot),
            );
          }),
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context, InviteFriendsVM snapshot) {
    if (ModalRoute.of(context).settings.arguments == null) {
      if (snapshot.invitationLoaded) {
        return Container(
          margin: EdgeInsets.fromLTRB(8, 0, 8, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Center(
                child: Container(
                  margin: EdgeInsets.fromLTRB(16, 32, 16, 16),
                  child: Image.asset(
                    'assets/images/invitation.png',
                    //height: 100,
                    width: min(MediaQuery.of(context).size.width.toCustomWidth() - 50, 200),
                    height: min(MediaQuery.of(context).size.width.toCustomWidth() - 50, 200),
                    fit: BoxFit.contain,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Text(
                  snapshot.invitationDetails['title'].toString(),
                  style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: Text(
                  snapshot.invitationDetails['caption'].toString(),
                  style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.9), fontWeight: FontWeight.w500),
                ),
              ),
              //***invitation code section****
              _buildCodeSection(context, snapshot),
              Container(
                margin: EdgeInsets.fromLTRB(16, 32, 16, 16),
                child: RaisedButton(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  padding: EdgeInsets.fromLTRB(16, 20, 16, 20),
                  color: ColorsLocal.button_color_purple,
                  elevation: 0,
                  highlightElevation: 1,
                  child: Text(
                    LocaleKey.SHARE.toLocaleText(),
                    style: TextStyle(
                      fontFamily: "medium",
                      color: Colors.white,
                      fontSize: 18,
                    ),
                  ),
                  onPressed: () async {
                    final DynamicLinkParameters parameters = DynamicLinkParameters(
                      uriPrefix: 'https://quizgiri.com.bd/invite',
                      link: Uri.parse('https://app.quizgiri.com.bd?invite_code=${snapshot.invitationDetails['code'].toString()}'),
                      androidParameters: AndroidParameters(
                        packageName: PACKAGE_NAME_ANDROID,
                        minimumVersion: 16,
                      ),
                      //TODO need to update the values ***
                      iosParameters: IosParameters(
                        bundleId: PACKAGE_NAME_IOS,
                        minimumVersion: '1.0.1',
                        appStoreId: APP_STORE_ID,
                      ),
//                      googleAnalyticsParameters: GoogleAnalyticsParameters(
//                        campaign: 'example-promo',
//                        medium: 'social',
//                        source: 'orkut',
//                      ),
//                      itunesConnectAnalyticsParameters: ItunesConnectAnalyticsParameters(
//                        providerToken: '123456',
//                        campaignToken: 'example-promo',
//                      ),
                      socialMetaTagParameters: SocialMetaTagParameters(
                        title: 'QuizGiri Invitation',
                        description: 'Join QuizGiri and play quiz with your friends',
                        imageUrl: Uri.parse("https://quizgiri.xyz/images/hero-1.png"),
                      ),
                    );

                    final ShortDynamicLink shortDynamicLink = await parameters.buildShortLink();
                    final Uri shortUrl = shortDynamicLink.shortUrl;
                    //Logger.printWrapped(shortUrl.toString());
                    Share.share(shortUrl.toString(), subject: "Invitation");
                  },
                ),
              )
            ],
          ),
        );
      } else {
        return Container(
          height: 200,
          child: Center(
            child: CupertinoActivityIndicator(),
          ),
        );
      }
    } else {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Center(
            child: Container(
              margin: EdgeInsets.fromLTRB(16, 32, 16, 16),
              child: Image.asset(
                'assets/images/invitation.png',
                //height: 100,
                width: min(MediaQuery.of(context).size.width.toCustomWidth() - 50, 200),
                height: min(MediaQuery.of(context).size.width.toCustomWidth() - 50, 200),
                fit: BoxFit.contain,
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(36, 56, 36, 0),
            child: Text(
              "Thank you for accepting the invitation",
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(36, 4, 36, 0),
            child: Text(
              "Apply your invitation code and win gifts",
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w300),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(36, 24, 36, 36),
            decoration: BoxDecoration(
              border: Border.all(
                width: 1,
                color: ColorsLocal.hexToColor("EAEAEA"),
              ),
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Container(
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.fromLTRB(12, 16, 12, 16),
                    child: Text(
                      "Code",
                      style: TextStyle(fontFamily: "Poppins", fontSize: 20, color: ColorsLocal.text_color_pink, fontWeight: FontWeight.w500),
                    ),
                  ),
                  Container(
                    height: 40,
                    width: 1,
                    color: Colors.grey[300],
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(12, 0, 12, 0),
                      child: TextField(
                        controller: _textEditingController,
                        textAlign: TextAlign.start,
                        style: TextStyle(fontFamily: "Poppins", fontSize: 20, color: ColorsLocal.text_color, letterSpacing: 1.5, fontWeight: FontWeight.w500),
                        maxLines: 1,
                        keyboardType: TextInputType.numberWithOptions(
                          signed: false,
                          decimal: false,
                        ),
                        decoration: InputDecoration(
                          hintText: "Your code",
                          border: InputBorder.none,
                          hintStyle: TextStyle(
                            color: ColorsLocal.hexToColor("d4ddec"),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Consumer<InviteFriendsVM>(builder: (context, snapshot, _) {
            return Container(
              margin: EdgeInsets.fromLTRB(36, 0, 24, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  snapshot.applying
                      ? Container(
                          child: CupertinoActivityIndicator(),
                        )
                      : Container(),
                  snapshot.applying
                      ? Container(
                          height: 0,
                          width: 0,
                        )
                      : Container(
                          child: Text(
                            snapshot.message,
                            style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 14,
                              color: ColorsLocal.text_color,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        )
                ],
              ),
            );
          }),
          Container(
            margin: EdgeInsets.fromLTRB(16, 16, 16, 16),
            child: RaisedButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              padding: EdgeInsets.fromLTRB(16, 20, 16, 20),
              color: ColorsLocal.button_color_purple,
              elevation: 0,
              highlightElevation: 1,
              child: Text(
                "Apply",
                style: TextStyle(fontFamily: "Poppins", color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
              ),
              onPressed: () async {
                snapshot.applyCode(_textEditingController.text.toString()).then((flag) {
                  if (flag) {
                    Navigator.pop(context);
                  }
                });
              },
            ),
          )
        ],
      );
    }
  }

  Widget _buildCodeSection(BuildContext context, InviteFriendsVM snapshot) {
    return Container(
      margin: EdgeInsets.fromLTRB(16, 32, 16, 0),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Container(
              margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
              child: DottedBorder(
                strokeWidth: 1.5,
                dashPattern: [6, 6],
                radius: Radius.circular(8),
                borderType: BorderType.RRect,
                padding: EdgeInsets.all(0),
                color: ColorsLocal.hexToColor("CBC9C9"),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.grey[100],
                  ),
                  padding: EdgeInsets.fromLTRB(22, 0, 22, 0),
                  height: 60,
                  child: Center(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          child: Icon(
                            Icons.local_offer,
                            size: 20,
                            color: ColorsLocal.hexToColor("BCBCBC"),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(16, 0, 0, 0),
                            child: Text(
                              snapshot.invitationDetails['code'].toString(),
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color.withOpacity(0.9), fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
//            InkWell(
//              child: DottedBorder(
//                strokeWidth: 1.5,
//                dashPattern: [6, 6],
//                radius: Radius.circular(8),
//                borderType: BorderType.RRect,
//                padding: EdgeInsets.all(0),
//                color: ColorsLocal.hexToColor("CBC9C9"),
//                child: Container(
//                  padding: EdgeInsets.fromLTRB(22, 0, 22, 0),
//                  margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
//                  decoration: BoxDecoration(
//                    borderRadius: BorderRadius.circular(8),
//                    color: Colors.grey[100],
//                  ),
//                  height: 60,
//                  child: Container(
//                    child: Center(
//                      child: Text(
//                        "Copy",
//                        style: TextStyle(
//                          fontFamily: "Poppins",
//                          fontSize: 15,
//                          color: ColorsLocal.text_color.withOpacity(0.9),
//                          fontWeight: FontWeight.w500
//                        ),
//                      ),
//                    ),
//                  ),
//                ),
//              ),
//              onTap: () {
//
//                Clipboard.setData(ClipboardData(text: snapshot.invitationDetails['invite_code'].toString()));
//                Toast.show("Code Copied to Clipboard", context, duration: 2);
//              },
//            ),
        ],
      ),
    );
  }
}
