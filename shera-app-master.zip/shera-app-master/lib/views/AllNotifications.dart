/*
* Created by Ahammed Hossain Shanto on 7/12/20
*/

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/NotificationVM.dart';

class AllNotification extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return NotificationVM();
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.NOTIFICATIONS.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
//            Container(
//              height: 20,
//              decoration: BoxDecoration(
//                color: Colors.white,
//                boxShadow: [
//                  BoxShadow(
//                      offset: Offset(0, 4),
//                      color: ColorsLocal.hexToColor("E1E1E1").withOpacity(0.5),
//                      spreadRadius: 0.4,
//                      blurRadius: 16
//                  )
//                ],
//              ),
//            ),
              Visibility(
                visible: false,
                child: Consumer<NotificationVM>(builder: (context, snapshot, _) {
                  return Container(
                      margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                      child: CarouselSlider(
                        //height: 200.0,
                        options: CarouselOptions(
                          aspectRatio: 16 / 8,
                          autoPlay: true,
                          enlargeCenterPage: false,
                          viewportFraction: 0.9,
                        ),
                        items: _buildPromotions(context, snapshot),
                      ));
                }),
              ),
              Expanded(
                child: Container(
                    padding: EdgeInsets.fromLTRB(28, 28, 28, 16),
                    child: Consumer<NotificationVM>(builder: (context, snapshot, _) {
                      return ListView(
                        children: _buildPromotions(context, snapshot),
                      );
                    })),
              )
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildPromotions(BuildContext context, NotificationVM snapshot) {
    List<Widget> items = new List();

    if (!snapshot.promotionsLoaded) {
      items.addAll(List.generate(3, (index) {
        return Container(
          margin: EdgeInsets.fromLTRB(8, 0, 8, 0),
          child: MyShimmer.fromColors(
              child: Container(
                width: MediaQuery.of(context).size.width.toCustomWidth() - 64,
                height: (MediaQuery.of(context).size.width.toCustomWidth() - 64) * (9 / 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width.toCustomWidth() - 64,
                      height: (MediaQuery.of(context).size.width.toCustomWidth() - 64) * (6 / 16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.grey[300],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(16, 16, 100, 0),
                      height: 20,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey[300],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(16, 8, 16, 0),
                      height: 20,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey[300],
                      ),
                    ),
                  ],
                ),
              ),
              baseColor: Colors.grey[300],
              highlightColor: Colors.white),
        );
      }));
    } else {
      {
        items.addAll(List.generate(snapshot.promotions == null ? 0 : snapshot.promotions.length, (index) {
          return snapshot.promotions[index]['banner_url'] == ""
              ? Container(
                  margin: EdgeInsets.fromLTRB(0, 4, 0, 4),
                  child: Container(
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 1,
                          color: ColorsLocal.hexToColor("F3F3F3"),
                        ),
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: Column(
                        //mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                                    child: Text(
                                      snapshot.promotions[index]['title'].toString(),
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.hexToColor("444444"), fontWeight: FontWeight.w600),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(4, 0, 0, 0),
                                  child: Text(
                                    snapshot.promotions[index]['datetime'].toString(),
                                    style: TextStyle(fontFamily: "Poppins", fontSize: 8, color: ColorsLocal.hexToColor("979797"), fontWeight: FontWeight.w400),
                                  ),
                                )
                              ],
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(8, 5, 0, 8),
                            child: Text(
                              snapshot.promotions[index]['body'].toString(),
                              style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.hexToColor("8D8D8D"), fontWeight: FontWeight.w500),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                            ),
                          ),
                        ],
                      )),
                )
              : Container(
                  margin: EdgeInsets.fromLTRB(0, 4, 0, 4),
                  child: PhysicalModel(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(7),
                    clipBehavior: Clip.antiAlias,
                    child: Container(
                      width: MediaQuery.of(context).size.width.toCustomWidth(),
                      // height: (MediaQuery.of(context).size.width.toCustomWidth()) * (9 / 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width.toCustomWidth(),
                            height: (((MediaQuery.of(context).size.width.toCustomWidth()) * (9 / 16)) * (5 / 9)),
                            child: CachedNetworkImage(
                              imageUrl: snapshot.promotions[index]['banner_url'].toString().toString(),
                              imageBuilder: (context, imageProvider) => Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.rectangle,
                                  borderRadius: BorderRadius.circular(0),
                                  image: DecorationImage(
                                    image: imageProvider,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              placeholder: (context, url) => MyShimmer.fromColors(
                                child: Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.rectangle,
                                    color: Colors.grey[300],
                                    borderRadius: BorderRadius.circular(0),
                                  ),
                                ),
                                baseColor: Colors.grey[300],
                                highlightColor: Colors.white,
                              ),
                              errorWidget: (context, url, error) => Icon(
                                Icons.error,
                                size: 32,
                                color: Colors.grey,
                              ),
                            ),
                          ),
                          Container(
                            height: (((MediaQuery.of(context).size.width.toCustomWidth()) * (9 / 16)) * (3 / 9)),
                            child: SingleChildScrollView(
                              child: Column(
                                //mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Container(
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Container(
                                            margin: EdgeInsets.fromLTRB(16, 0, 0, 0),
                                            child: Text(
                                              snapshot.promotions[index]['title'].toString(),
                                              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.hexToColor("444444"), fontWeight: FontWeight.w600),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(4, 0, 10, 0),
                                          child: Text(
                                            snapshot.promotions[index]['datetime'].toString(),
                                            style: TextStyle(fontFamily: "Poppins", fontSize: 8, color: ColorsLocal.hexToColor("979797"), fontWeight: FontWeight.w400),
                                          ),
                                        )
                                      ],
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                    ),
                                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(16, 5, 0, 8),
                                    child: Text(
                                      snapshot.promotions[index]['body'].toString(),
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.hexToColor("8D8D8D"), fontWeight: FontWeight.w500),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
        }));
      }
    }

    return items;
  }

  List<Widget> _buildNotifications(BuildContext context, NotificationVM snapshot) {
    List<Widget> items = new List();

    if (!snapshot.notificationsLoaded) {
      items.addAll(List.generate(10, (index) {
        return Container(
          margin: EdgeInsets.fromLTRB(0, 4, 0, 4),
          child: MyShimmer.fromColors(
              child: Container(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 1,
                    color: Colors.grey[300],
                  ),
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 28,
                      width: 28,
                      padding: EdgeInsets.fromLTRB(4, 4, 4, 2),
                      decoration: BoxDecoration(border: Border.all(width: 1, color: Colors.grey[300]), shape: BoxShape.circle),
                      child: Image.asset("assets/images/ic_trophy.png"),
                    ),
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.fromLTRB(8, 0, 8, 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              height: 16,
                              width: 50,
                              decoration: BoxDecoration(
                                color: Colors.grey[300],
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 4, 100, 0),
                              height: 12,
                              width: 100,
                              decoration: BoxDecoration(
                                color: Colors.grey[300],
                                borderRadius: BorderRadius.circular(8),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              baseColor: Colors.grey[300],
              highlightColor: Colors.white),
        );
      }));
    } else if (snapshot.notifications != null && snapshot.notifications.isNotEmpty) {
      items.addAll(List.generate(snapshot.notifications.length, (index) {
        return Container(
          margin: EdgeInsets.fromLTRB(0, 4, 0, 4),
          child: Container(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
            decoration: BoxDecoration(
              border: Border.all(
                width: 1,
                color: ColorsLocal.hexToColor("F3F3F3"),
              ),
              color: Colors.white,
              borderRadius: BorderRadius.circular(7),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 28,
                  width: 28,
                  padding: EdgeInsets.fromLTRB(4, 4, 4, 2),
                  decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.hexToColor("F9F9F9")),
                  child: Image.asset("assets/images/ic_trophy.png"),
                ),
                Expanded(
                  child: Container(
                    margin: EdgeInsets.fromLTRB(8, 0, 8, 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          child: Text(
                            snapshot.notifications[index]['title'],
                            style: TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 14, color: ColorsLocal.text_color),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                          child: Text(
                            snapshot.notifications[index]['datetime'].toString(),
                            style: TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 10, color: ColorsLocal.text_color.withOpacity(0.7)),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }));
    }

    return items;
  }

  Widget _buildEmptyWidget() {
    return Image.asset(
      "assets/images/ic_coins.png",
      height: 200,
      width: 200,
    );
  }
}
