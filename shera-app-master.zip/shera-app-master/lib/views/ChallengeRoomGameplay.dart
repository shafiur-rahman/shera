/*
* Created by Ahammed Hossain Shanto
* on 12/22/20
* * ReCreated by Shafiur
* on 01/07/2021
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_statusbarcolor/flutter_statusbarcolor.dart';
import 'package:provider/provider.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/ImageLoader.dart';
import 'package:quiz/view-components/Pop_Ups/QuitRoomJoinAlert.dart';
import 'package:quiz/view-models/ChallengeRoomGameplay.dart';
import 'package:quiz/view-models/TimerVM.dart';
import 'package:wakelock/wakelock.dart';
import 'package:quiz/extensions/string_extensions.dart';

class ChallengeRoomGameplay extends StatefulWidget {
  @override
  _ChallengeRoomGameplayState createState() => _ChallengeRoomGameplayState();
}

class _ChallengeRoomGameplayState extends State<ChallengeRoomGameplay> {

  @override
  void initState() {
    // TODO: implement initState
    Wakelock.enable();
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    FlutterStatusbarcolor.setStatusBarColor(Colors.white);
    timerVM?.stopTimer();
    Wakelock.disable();
    super.dispose();

  }


  TimerVM timerVM = new TimerVM();

  @override
  Widget build(BuildContext context) {

    var arguments = json.decode(ModalRoute.of(context).settings.arguments);
    timerVM.setContext(context);

    Color bgColor = Colors.blue[500];
    Color bgColorDark = Colors.blue[700];
    if(arguments != null && arguments['room_info'] != null) {
      bgColor = ColorsLocal.hexToColor(arguments['room_info']['primary_color'].toString());
      bgColorDark = ColorsLocal.hexToColor(arguments['room_info']['primary_color_dark'].toString());
    }

    FlutterStatusbarcolor.setStatusBarColor(bgColorDark);

    ChallengeRoomGameplayVM challengeRoomGameplayVM = new ChallengeRoomGameplayVM(context, arguments, timerVM);
    timerVM.setChallengeRoomGameplayVM(challengeRoomGameplayVM);

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (_) {
              return challengeRoomGameplayVM;
            }
        ),
        ChangeNotifierProvider(
          create: (_) {
            return timerVM;
          },
        )
      ],
      child: WillPopScope(
        onWillPop: () async {
          QuitRoomJoinAlert.show(context);
          return false;
        },
        child: Scaffold(
          appBar:AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  QuitRoomJoinAlert.show(context);
                  return false;
                },
              ),
            ),
            title: Text(
              LocaleKey.CHALLENGES.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Consumer<ChallengeRoomGameplayVM>(
              builder: (context, snapshot, _) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    _buildHeader(context, snapshot, bgColor, bgColorDark),
                    Expanded(
                        child: _buildQuestion(context, snapshot)
                    ),
                  ],
                );
              }
          ),
          bottomNavigationBar: Consumer2<ChallengeRoomGameplayVM, TimerVM>(
              builder: (context, snapshot, timerVm, _) {
                if(!snapshot.submitted && snapshot.waitingFor == null) {
                  return Container(
                    height: 56,
                    decoration: BoxDecoration(
                        color: Colors.white
                    ),
                    child: Container(
                      margin: EdgeInsets.fromLTRB(24, 12, 24, 12),
                      child: Material(
                        borderRadius: BorderRadius.circular(100),
                        clipBehavior: Clip.antiAlias,
                        child: Container(
                          width: MediaQuery
                              .of(context)
                              .size
                              .width - 24,
                          height: 30,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.grey[200],
                                    spreadRadius: 0.5,
                                    blurRadius: 2)
                              ]),
                          child: Stack(
                            children: [
                              AnimatedContainer(
                                duration: Duration(
                                    milliseconds: timerVm.duration ==
                                        timerVm.timeLeft
                                        ? 300
                                        : 1000),
                                //300 ms to go to its stating position and 1000 ms for each steps
                                width: (MediaQuery
                                    .of(context)
                                    .size
                                    .width - 48),
                                margin: EdgeInsets.fromLTRB(
                                    0,
                                    0,
                                    (MediaQuery
                                        .of(context)
                                        .size
                                        .width - 48) *
                                        (1 - timerVm.getTimerProgress()),
                                    0),
                                height: 30,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: ColorsLocal.text_color_pink_2,
                                ),
                              ),
                              Positioned(
                                left: 0,
                                top: 0,
                                bottom: 0,
                                child: Container(
                                  height: 32,
                                  width: 32,
                                  child: Icon(
                                    Icons.timer,
                                    color: Colors.white,
                                    size: 22,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }
                else {
                  if(snapshot.waitingFor == null) {
                    return Container(
                      color: Colors.white,
                      height: 56,
                      child: Center(
                        child: Text(
                          "Please wait(00:" + timerVM.timeLeft.toString() +
                              ")...",
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 16,
                              color: ColorsLocal.text_color,
                              fontWeight: FontWeight.w500
                          ),
                        ),
                      ),
                    );
                  }
                  else {
                    return Container(
                      color: Colors.white,
                      height: 56,
                      child: Center(
                        child: Wrap(
                          alignment: WrapAlignment.center,
                          children: [
                            Text(
                              "Waiting for opponent...",
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 16,
                                  color: ColorsLocal.text_color,
                                  fontWeight: FontWeight.w500
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 8),
                              child: CupertinoActivityIndicator(),
                            )
                          ],
                        ),
                      ),
                    );
                  }
                }
              }
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, ChallengeRoomGameplayVM snapshot, Color bgColor, Color bgColorDark) {
    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top+16, left: 24, right: 24, bottom: 12),
      decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [bgColor, bgColorDark],
              stops: [0.0, 0.5],
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter
          )
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            width: 80,
            child: Column(
              children: [
                Container(
                  height: 90,
                  width: 80,
                  child: Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                width: 2,
                                color: Colors.white
                            ),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.white,
                                  spreadRadius: 0.1,
                                  blurRadius: 8
                              )
                            ]
                        ),
                        child: Container(
                          height: 80,
                          width: 80,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  width: 8,
                                  //color: snapshot.userStatus['answer_status'] == -1 ? Colors.grey[300] : snapshot.userStatus['answer_status'] == 1 ? Colors.green :
                                  color: snapshot.isCorrect == -1 ? Colors.grey[300] : snapshot.isCorrect == 1 ? Colors.green :
                                  Colors.red
                              ),
                              shape: BoxShape.circle
                          ),
                          child: ImageLoader.loadCircular(
                              imageUrl: snapshot.userInfo['avatar'].toString()
                          ),
                        ),
                      ),
                      Positioned(
                          bottom: 0,
                          left: 1,
                          right: 1,
                          child: Align(
                            alignment: Alignment.center,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(4, 2, 8, 2),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                      width: 2,
                                      color: Colors.green
                                  ),
                                  color: Colors.white
                              ),
                              child: Wrap(
                                children: [
                                  Container(
                                    child: Icon(
                                      Icons.check_circle,
                                      size: 20,
                                      color: Colors.green,
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(left: 4),
                                    child: Text(
                                      //snapshot.userStatus['correct_count'].toString() + "/" + snapshot.userStatus['total_count'].toString(),
                                      snapshot.userTotalCorrect.toString() + "/" + snapshot.userTotalAnswered.toString(),
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 14,
                                          color: Colors.green,
                                          fontWeight: FontWeight.w600
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 4),
                  child: Text(
                    snapshot.userInfo['user_name'].toString(),
                    style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 12,
                        color: Colors.white,
                        fontWeight: FontWeight.w500
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
                )
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    width: 4,
                    color: bgColorDark
                ),
                boxShadow: [
                  BoxShadow(
                      color: Colors.white,
                      spreadRadius: 0.1,
                      blurRadius: 8
                  )
                ]
            ),
            width: 100,
            height: 100,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  child: Image.asset(
                    "assets/images/ic_trophy.png",
                    height: 40,
                    width: 40,
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 10, right: 10, top: 8),
                  padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: bgColorDark,
                  ),
                  child: Wrap(
                    children: [
                      Container(
                          child: Image.asset(
                            "assets/images/ic_coin.png",
                            height: 16,
                            width: 16,
                          )
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 8),
                        child: Text(
                          snapshot.roomInfo['prize'].toString(),
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 14,
                              color: Colors.white,
                              fontWeight: FontWeight.w600
                          ),
                        ),
                      )
                    ],
                    alignment: WrapAlignment.center,
                    crossAxisAlignment: WrapCrossAlignment.center,
                  ),
                )
              ],
            ),
          ),
          Container(
            width: 80,
            child: Column(
              children: [
                Container(
                  height: 90,
                  width: 80,
                  child: Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                width: 2,
                                color: Colors.white
                            ),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.white,
                                  spreadRadius: 0.1,
                                  blurRadius: 8
                              )
                            ]
                        ),
                        child: Container(
                          height: 80,
                          width: 80,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  width: 8,
                                  color: snapshot.isOpponentLastAnswerCorrect == -1 ? Colors.grey[300] : snapshot.isOpponentLastAnswerCorrect == 1 ? Colors.green :
                                  Colors.red
                              ),
                              shape: BoxShape.circle
                          ),
                          child: ImageLoader.loadCircular(
                              imageUrl: snapshot.opponentInfo['avatar'].toString()
                          ),
                        ),
                      ),
                      Positioned(
                          bottom: 0,
                          left: 1,
                          right: 1,
                          child: Align(
                            alignment: Alignment.center,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(4, 2, 8, 2),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                      width: 2,
                                      color: Colors.green
                                  ),
                                  color: Colors.white
                              ),
                              child: Wrap(
                                children: [
                                  Container(
                                    child: Icon(
                                      Icons.check_circle,
                                      size: 20,
                                      color: Colors.green,
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(left: 4),
                                    child: Text(
                                      //snapshot.opponentStatus['correct_count'].toString() + "/" + snapshot.opponentStatus['total_count'].toString(),
                                      snapshot.opponentTotalCorrect.toString() + "/" + snapshot.opponentTotalAnswered.toString(),
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 14,
                                          color: Colors.green,
                                          fontWeight: FontWeight.w600
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 4),
                  child: Text(
                    snapshot.opponentInfo['user_name'].toString(),
                    style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 12,
                        color: Colors.white,
                        fontWeight: FontWeight.w500
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildQuestion(BuildContext context, ChallengeRoomGameplayVM snapshot) {
    if(snapshot.question != null) {

      List options = snapshot.question['options'];

      return SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.fromLTRB(24, 24, 24, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              snapshot.question['topic'] != null && snapshot.question['topic'].toString().isNotEmpty ? Container(
                  margin: EdgeInsets.only(bottom: 0),
                  child: Text(
                    snapshot.question['topic']['name'].toString(),
                    style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 12,
                        color: ColorsLocal.text_color_purple,
                        fontWeight: FontWeight.w600
                    ),
                  )
              ) : Container(),
              Container(
                  margin: EdgeInsets.only(bottom: 8),
                  child: Text(
                    snapshot.question['question_value'].toString(),
                    style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 24,
                        color: ColorsLocal.text_color,
                        fontWeight: FontWeight.w600
                    ),
                  )
              ),
              Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: List.generate(options.length, (index) {
                    return Container(
                      margin: EdgeInsets.only(top: 8, bottom: 8),
                      child: InkWell(
                        onTap: () {
                          // if(!snapshot.submitting && !snapshot.submitted && !snapshot.isTimeUp) {
                          //   snapshot.submitAnswer(
                          //       options[index]['id'].toString());
                          // }

                          if(!snapshot.submitted){
                            print("Option select");
                            snapshot.selectOption(
                                options[index]['id']);
                          }
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              color: snapshot.answerGiven && snapshot.isCorrect == 1 && snapshot.selectedOptionId == options[index]['id']? Colors.green
                                  : snapshot.answerGiven && snapshot.isCorrect == 0 && snapshot.selectedOptionId == options[index]['id'] ? Colors.red :
                              Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  width: 2,
                                  color: Colors.grey[300]
                              )
                          ),
                          padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  options[index]['value'].toString(),
                                  style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 18,
                                      color: snapshot.answerGiven && snapshot.selectedOptionId == options[index]['id'] ? Colors.white
                                          : ColorsLocal.text_color,
                                      fontWeight: FontWeight.w600
                                  ),
                                ),
                              ),
                              snapshot.submitting && snapshot.selectedOptionId == options[index]['id'] ? CupertinoActivityIndicator() :
                              Container(),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ),
              Container(height: 24)
            ],
          ),
        ),
      );
    }
    else {
      return Center(
        child: CupertinoActivityIndicator(),
      );
    }
  }
}
