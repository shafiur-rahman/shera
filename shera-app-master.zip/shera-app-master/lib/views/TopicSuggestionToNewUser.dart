/*
* Created by Ahammed Hossain Shanto
* on 7/1/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/TopicSuggestionToNewUserVM.dart';
import 'package:toast/toast.dart';

class TopicSuggestionToNewUser extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return TopicSuggestionToNewUserVM(context);
        },
        child: Scaffold(
          body: Stack(
            children: [
              Positioned(
                left: 0,
                right: 0,
                bottom: 100,
                top: 0,
                child: Container(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(36, 72, 36, 0),
                          child: Text(
                            "Great!",
                            style: TextStyle(color: ColorsLocal.text_color_pink_2, fontFamily: "Poppins", fontSize: 40, fontWeight: FontWeight.w700),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(36, 0, 36, 0),
                          child: Text(
                            "Your is created successfully",
                            style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontSize: 24, fontWeight: FontWeight.w700),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(36, 12, 36, 0),
                          child: Text(
                            "Select your favourite topics",
                            style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontSize: 18, fontWeight: FontWeight.w400),
                          ),
                        ),
                        Consumer<TopicSuggestionToNewUserVM>(builder: (context, snapshot, _) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(36, 56, 36, 36),
                                child: Wrap(
                                  children: _buildSuggestedTopics(context, snapshot),
                                ),
                              ),
                            ],
                          );
                        }),
                        Consumer<TopicSuggestionToNewUserVM>(builder: (context, snapshot, _) {
                          return snapshot.savingFavourite
                              ? Container(
                                  margin: EdgeInsets.fromLTRB(36, 16, 36, 36),
                                  child: CupertinoActivityIndicator(),
                                )
                              : Container(
                                  margin: EdgeInsets.fromLTRB(36, 16, 36, 36),
                                );
                        }),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Container(
                  padding: EdgeInsets.fromLTRB(36, 0, 36, 0),
                  height: 100,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          child: RichText(
                            text: TextSpan(
                                text: "Skip",
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: ColorsLocal.text_color, fontFamily: "Poppins"),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    Navigator.pushReplacementNamed(context, HomeRoute);
                                  }),
                          ),
                        ),
                        Consumer<TopicSuggestionToNewUserVM>(builder: (context, snapshot, _) {
                          return Container(
                            child: FloatingActionButton(
                              child: Icon(
                                Icons.arrow_forward,
                              ),
                              onPressed: () {
                                if (snapshot.selectedSuggIds.isEmpty) {
                                  Toast.show("Please choose some topics", context);
                                } else {
                                  if (!snapshot.savingFavourite) {
                                    snapshot.saveFavourites();
                                  }
                                }
                              },
                            ),
                          );
                        })
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildSuggestedTopics(BuildContext context, TopicSuggestionToNewUserVM snapshot) {
    List<Widget> items = new List();
    if (snapshot.suggestionLoaded) {
      for (int i = 0; i < snapshot.suggestions.length; i++) {
        Widget item = Container(
            margin: EdgeInsets.fromLTRB(0, 0, 12, 12),
            child: InkWell(
              child: Container(
                decoration: BoxDecoration(
                    color: snapshot.isSelected(snapshot.suggestions[i]['category_id']) ? ColorsLocal.text_color_purple : Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      width: 1,
                      color: Colors.grey[300],
                    )),
                padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
                child: Text(
                  snapshot.suggestions[i]['name'],
                  style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: snapshot.isSelected(snapshot.suggestions[i]['category_id']) ? Colors.white : ColorsLocal.text_color,
                  ),
                ),
              ),
              onTap: () {
                snapshot.toggleSelection(snapshot.suggestions[i]['category_id']);
              },
            ));
        items.add(item);
      }
    } else {
      for (int i = 0; i < 10; i++) {
        Widget item = Container(
          child: MyShimmer.fromColors(
              child: Container(
                height: 32,
                width: 72 + ((i % 2) * 20).toDouble(),
                margin: EdgeInsets.fromLTRB(0, 0, 12, 12),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
              baseColor: Colors.grey[300],
              highlightColor: Colors.white),
        );
        items.add(item);
      }
    }
    return items;
  }
}
