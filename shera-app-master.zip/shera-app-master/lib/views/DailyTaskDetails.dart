/*
* Created by Ahammed Hossain Shanto on 7/8/20
*/

import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Pop_Ups/AddFriendPU.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/DailyTaskDetailsVM.dart';

class DailyTaskDetails extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return DailyTaskDetailsVM(context);
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            centerTitle: false,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Container(
              child: Text(
                LocaleKey.WEEKLY_TASK.toLocaleText(),
                style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
              ),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: Container(
                  //color: Colors.red,
                  child: Consumer<DailyTaskDetailsVM>(builder: (context, snapshot, _) {
                    return RefreshIndicator(
                      onRefresh: () async {
                        await snapshot.loadDetails();
                      },
                      child: ListView.builder(
                        itemBuilder: (BuildContext context, int index) {
                          if (index == 0) {
                            return _buildStep1(context, snapshot);
                          } else if (index == 1) {
                            return _buildStep2(context, snapshot);
                          } else {
                            return _buildPositions(context, snapshot, index - 2);
                          }
                        },
                        itemCount: _getItemCount(context, snapshot),
                      ),
                    );
                  }),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  int _getItemCount(BuildContext context, DailyTaskDetailsVM snapshot) {
    int count = 0;

    if (snapshot.detailsLoaded) {
      count = 1;
      List rankList = snapshot.details['ranking'];
      if (rankList != null && rankList.isNotEmpty) {
        count += (rankList.length + 1);
      }
    } else {
      count = 5;
    }

    return count;
  }

  Widget _buildStep1(BuildContext context, DailyTaskDetailsVM snapshot) {
    if (snapshot.detailsLoaded == false && snapshot.details == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: MyShimmer.fromColors(
            child: Container(
              padding: EdgeInsets.fromLTRB(36, 24, 36, 36),
              decoration: BoxDecoration(
                border: Border.all(
                  width: 1,
                  color: Colors.grey[300],
                ),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Column(
                children: [
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey[300]),
                  ),
                  Container(
                    height: 20,
                    width: 120,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 20,
                        margin: EdgeInsets.fromLTRB(0, 36, 150, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                      ),
                      Container(
                        height: 6,
                        margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                                height: 40,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                height: 40,
                                margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: PhysicalModel(
          clipBehavior: Clip.antiAlias,
          borderRadius: BorderRadius.circular(7),
          color: Colors.transparent,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(7),
                topRight: Radius.circular(7),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                  decoration: BoxDecoration(color: ColorsLocal.button_color_purple),
                  child: Column(
                    //crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                        child: Text(
                          snapshot.details['title'].toString(),
                          style: TextStyle(
                            fontSize: 25,
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontFamily: "poppins",
                          ),
                        ),
                      ),
                      // Container(
                      //   margin: EdgeInsets.fromLTRB(16, 8, 16, 0),
                      //   child: Text(
                      //     "DAY " + snapshot.details['day_running']
                      //         .toString(),
                      //     style: TextStyle(
                      //       fontSize: 25,
                      //       color: Colors.white,
                      //       fontWeight: FontWeight.w500,
                      //       fontFamily: "poppins",
                      //     ),
                      //   ),
                      // ),
                      Container(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
                          margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                          child: Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Container(
                                child: Image.asset(
                                  "assets/images/ic_trophy.png",
                                  height: 22,
                                  width: 22,
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                                child: Text(
                                  snapshot.details['prize'].toString(),
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    color: ColorsLocal.text_color_purple,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                        child: Text(
                          snapshot.details['caption'].toString(),
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontFamily: "poppins",
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.fromLTRB(0, 16, 0, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 60,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (BuildContext context, int index) {
                            return Container(
                              margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 8, 0),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    width: 2,
                                    color: snapshot.details['daily_status'][index]['is_today'] ? ColorsLocal.text_color_pink : Colors.grey[300],
                                  )),
                              height: 60,
                              width: 70,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  // Container(
                                  //   decoration: BoxDecoration(
                                  //     color: Colors.white,
                                  //     borderRadius: BorderRadius.circular(8),
                                  //     border: Border.all(
                                  //       width: 2,
                                  //       color: snapshot.details['daily_status'][index]['played'] ? ColorsLocal.hexToColor("F6891F") : Colors.grey[300]
                                  //     )
                                  //   ),
                                  //   margin: EdgeInsets.fromLTRB(4, 0, 4, 4),
                                  //   padding: EdgeInsets.fromLTRB(4, 2, 4, 2),
                                  //   child: Text(
                                  //     'Bonus +${snapshot.details['daily_status'][index]['bonus_point'].toString()}',
                                  //     style: TextStyle(
                                  //       fontFamily: "Poppins",
                                  //       fontSize: 8,
                                  //       fontWeight: FontWeight.w400,
                                  //       color: snapshot.details['daily_status'][index]['played'] ? ColorsLocal.hexToColor("F6891F") : Colors.grey[500],
                                  //     ),
                                  //     textAlign: TextAlign.center,
                                  //   ),
                                  // ),
                                  Container(
                                    child: Text(
                                      '${LocaleKey.DAY.toLocaleText()} ${snapshot.details['daily_status'][index]['day'].toString().toLocaleNumber()}',
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        color: snapshot.details['daily_status'][index]['is_today'] ? ColorsLocal.text_color_pink : Colors.grey[300],
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                                ],
                              ),
                            );
                          },
                          itemCount: snapshot.details['daily_status'] != null && snapshot.details['daily_status'].length != 0 ? snapshot.details['daily_status'].length : 0,
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.fromLTRB(16, 24, 16, 0),
                          child: RaisedButton(
                            color: !snapshot.details['today_played'] ? ColorsLocal.button_color_pink : Colors.grey[400],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            padding: EdgeInsets.fromLTRB(36, 12, 36, 12),
                            elevation: 0,
                            highlightElevation: 0,
                            child: Text(
                              snapshot.starting
                                  ? LocaleKey.STARTING_NOW.toLocaleText()
                                  : snapshot.details['today_played']
                                      ? LocaleKey.ALREADY_PLAYED.toLocaleText()
                                      : LocaleKey.PLAY_NOW.toLocaleText(),
                              style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: "Poppins", fontWeight: FontWeight.w600),
                            ),
                            onPressed: snapshot.details['today_played']
                                ? null
                                : () {
                                    if (!snapshot.starting) {
                                      snapshot.startGame().then((value) {
                                        if (value != null) {
                                          //navitate to next route********
                                          Navigator.pushNamed(context, DailyTaskPlayRoute, arguments: value).then((value) {
                                            snapshot.loadDetails();
                                          });
                                        } else {
                                          LocalAlert.showDialog(context, "Opps!!", "Something went wrong. Please try again later");
                                        }
                                      });
                                    }
                                  },
                          ))
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      );
    }
  }

  Widget _buildStep2(BuildContext context, DailyTaskDetailsVM snapshot) {
    if (snapshot.detailsLoaded == false && snapshot.details == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 20, 120, 18),
        child: MyShimmer.fromColors(
            child: Container(
              height: 20,
              width: MediaQuery.of(context).size.width.toCustomWidth() - 150,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      return Column(
        children: [
          Container(
            margin: EdgeInsets.fromLTRB(20, 20, 20, 18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Container(
                    child: Text(
                      LocaleKey.RECENT_BEST.toLocaleText(),
                      style: TextStyle(fontSize: 16, color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                snapshot.details['ranking'] != null && snapshot.details['ranking'].length >= SHORT_RANKLIST_COUNT
                    ? Container(
                        child: RichText(
                          text: TextSpan(
                              text: LocaleKey.SEE_ALL.toLocaleText(),
                              style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.hexToColor("999999"), fontWeight: FontWeight.w600),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  Navigator.pushNamed(context, ReccentBestAllRoute, arguments: {"type": "daily_task"});
                                }),
                        ),
                      )
                    : Container()
              ],
            ),
          ),
        ],
      );
    }
  }

  Widget _buildPositions(BuildContext context, DailyTaskDetailsVM snapshot, int index) {
    if (snapshot.detailsLoaded == false) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: MyShimmer.fromColors(
            child: Container(
              height: 50,
              width: MediaQuery.of(context).size.width.toCustomWidth(),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      List rankList = snapshot.details['ranking'];
      return Container(
        margin: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(7),
          child: InkWell(
            borderRadius: BorderRadius.circular(7),
            child: Container(
              padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Badge(
                    elevation: 0,
                    padding: EdgeInsets.all(0),
                    badgeColor: Colors.transparent,
                    position: BadgePosition.bottomEnd(bottom: -8, end: -4),
                    animationDuration: Duration(milliseconds: 0),
                    animationType: BadgeAnimationType.slide,
                    badgeContent: Container(
                      margin: EdgeInsets.all(1.5),
                      padding: EdgeInsets.fromLTRB(6, 0, 6, 0),
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(width: 2, color: Colors.white),
                        color: ColorsLocal.hexToColor("8435E8"),
                      ),
                      child: Text(
                        rankList[index]["position"].toString().toLocaleNumber(),
                        style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 8),
                      ),
                    ),
                    child: Container(
                        //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
//                        border: Border.all(
//                          width: 2,
//                          color: Colors.grey[300],
//                        ),
                          shape: BoxShape.circle,
                        ),
                        constraints: BoxConstraints.tightFor(height: 34, width: 34),
                        child: CachedNetworkImage(
                          imageUrl: rankList[index]['image_url'].toString(),
                          imageBuilder: (context, imageProvider) => Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              //borderRadius: BorderRadius.circular(4),
                              image: DecorationImage(
                                image: imageProvider,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          placeholder: (context, url) => MyShimmer.fromColors(
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                //borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[300],
                              ),
                            ),
                            baseColor: Colors.grey[300],
                            highlightColor: Colors.white,
                          ),
                          errorWidget: (context, url, error) => Icon(Icons.error),
                        )),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(24, 0, 16, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            rankList[index]['name'].toString(),
                            style: TextStyle(fontFamily: "Poppins", fontSize: 13, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            '${LocaleKey.LEVEL.toLocaleText()} ${rankList[index]['level'].toString().toLocaleNumber()}',
                            style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.text_color, fontWeight: FontWeight.w400),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
//                    decoration: BoxDecoration(
//                        borderRadius: BorderRadius.circular(10),
//                        border: Border.all(
//                            width: 1, color: ColorsLocal.text_color_pink_2)),
                    padding: EdgeInsets.fromLTRB(15, 4, 15, 4),
                    child: Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(
                          rankList[index]['points'].toString().toLocaleNumber(),
                          style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color_pink_2, fontWeight: FontWeight.w600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          ' +${rankList[index]['bonus_points'].toString().toLocaleNumber()}',
                          style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: Colors.green, fontWeight: FontWeight.w600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            onTap: () {
              AddFriendPU.show(context, rankList[index]);
            },
          ),
        ),
      );
    }
  }
}
