/*
* Created by Ahammed Hossain Shanto
* on 10/13/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/ImageLoader.dart';
import 'package:quiz/view-components/Pop_Ups/DownloadApp.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/UploadAvatarVM.dart';

class UploadAvatar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return UploadAvatarVM(context);
        },
        child: Scaffold(
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 110,
                  width: 150,
                  margin: EdgeInsets.fromLTRB(36, 85, 36, 0),
                  child: Image.asset("assets/images/text_logo.png"),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    height: 150,
                    width: 150,
                    margin: EdgeInsets.only(top: 36),
                    child: Consumer<UploadAvatarVM>(
                      builder: (context, snapshot, _) {
                        return snapshot.uploadingImage
                            ? Center(
                                child: CupertinoActivityIndicator(),
                              )
                            : InkWell(
                                borderRadius: BorderRadius.circular(1000),
                                child: Container(
                                  height: 150,
                                  width: 150,
                                  decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.2), offset: Offset(0, 5), spreadRadius: 0.1, blurRadius: 8)]),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        left: 4,
                                        right: 4,
                                        top: 4,
                                        bottom: 4,
                                        child: snapshot.profileDetails == null
                                            ? Container(
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      child: Center(
                                                        child: Container(
                                                          child: Icon(
                                                            Icons.person_outline,
                                                            size: 80,
                                                            color: ColorsLocal.button_color_pink,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      child: Container(
                                                        height: 32,
                                                        width: 32,
                                                        child: Center(
                                                          child: Icon(
                                                            Icons.file_upload,
                                                            color: ColorsLocal.button_color_purple,
                                                            size: 24,
                                                          ),
                                                        ),
                                                        decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey[200], border: Border.all(width: 2, color: Colors.white)),
                                                      ),
                                                      right: 32,
                                                      bottom: 32,
                                                    ),
                                                  ],
                                                ),
                                              )
                                            : Center(
                                                child: Container(
                                                  child: ImageLoader.loadCircular(
                                                    imageUrl: snapshot.profileDetails['image_url'].toString(),
                                                    height: 142,
                                                    width: 142,
                                                  ),
                                                ),
                                              ),
                                      )
                                    ],
                                  ),
                                ),
                                onTap: () {
                                  if (PackageSupport.instance.isMobile()) {
                                    snapshot.pickImage(context);
                                  } else {
                                    DownloadApp.showDialog(context);
                                  }
                                },
                              );
                      },
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 36, 36, 0),
                  child: Text(
                    "Upload Profile Picture",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 4, 36, 0),
                  child: Text(
                    "It will help your friends to find you",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w300),
                  ),
                ),
              ],
            ),
          ),
          floatingActionButton: Consumer<UploadAvatarVM>(
            builder: (context, snapshot, _) {
              return FloatingActionButton(
                backgroundColor: ColorsLocal.button_color_pink,
                child: Icon(
                  Icons.arrow_forward,
                ),
                onPressed: () {
                  while (Navigator.canPop(context)) {
                    Navigator.of(context).pop();
                  }
                  Navigator.pushReplacementNamed(context, HomeRoute);
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
