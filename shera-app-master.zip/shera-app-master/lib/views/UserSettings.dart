/*
* Created by Ahammed Hossain Shanto on 7/20/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/helpers/banner-ad-loader.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/UserSettingsVM.dart';
import 'package:seekbar/seekbar.dart';

class UserSettings extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) => UserSettingsVM(),
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.SETTINGS.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Consumer<UserSettingsVM>(
            builder: (context, snapshot, _) {
              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
                      margin: EdgeInsets.fromLTRB(36, 32, 36, 0),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            width: 0.2,
                            color: ColorsLocal.hexToColor("E6E6E6"),
                          )),
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(
                              child: Text(
                                LocaleKey.DAILY_UPDATE.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: ColorsLocal.hexToColor("686868"),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            child: Switch(
                              value: snapshot.settingsLoaded ? snapshot.settings['daily_updates'] : false,
                              activeColor: ColorsLocal.button_color_purple,
                              onChanged: (value) {
                                snapshot.settings['daily_updates'] = value;
                                snapshot.updateSettings();
                              },
                            ),
                          )
                        ],
                      ),
                    ),
//                  Container(
//                    padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
//                    margin: EdgeInsets.fromLTRB(36, 10, 36, 0),
//                    decoration: BoxDecoration(
//                        color: Colors.white,
//                        borderRadius: BorderRadius.circular(10),
//                        border: Border.all(
//                          width: 0.2,
//                          color: ColorsLocal.hexToColor("E6E6E6"),
//                        )
//                    ),
//                    child: Row(
//                      children: [
//                        Expanded(
//                          child: Container(
//                            child: Text(
//                              "Challenges",
//                              style: TextStyle(
//                                fontFamily: "Poppins",
//                                fontSize: 16,
//                                fontWeight: FontWeight.w600,
//                                color: ColorsLocal.hexToColor("686868"),
//                              ),
//                            ),
//                          ),
//                        ),
//                        Container(
//                          child: Switch(
//                            value: snapshot.settingsLoaded ? snapshot.settings['allow_challenges'] : false,
//                            activeColor: ColorsLocal.button_color_purple,
//                            onChanged: (value) {
//                              snapshot.settings['allow_challenges'] = value;
//                              snapshot.updateSettings();
//                            },
//                          ),
//                        )
//                      ],
//                    ),
//                  ),
                    Container(
                      padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
                      margin: EdgeInsets.fromLTRB(36, 10, 36, 0),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            width: 0.2,
                            color: ColorsLocal.hexToColor("E6E6E6"),
                          )),
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(
                              child: Text(
                                LocaleKey.NEW_TOPIC.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: ColorsLocal.hexToColor("686868"),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            child: Switch(
                              value: snapshot.settingsLoaded ? snapshot.settings['new_topics'] : false,
                              activeColor: ColorsLocal.button_color_purple,
                              onChanged: (value) {
                                snapshot.settings['new_topics'] = value;
                                snapshot.updateSettings();
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
                      margin: EdgeInsets.fromLTRB(36, 10, 36, 0),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            width: 0.2,
                            color: ColorsLocal.hexToColor("E6E6E6"),
                          )),
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(
                              child: Text(
                                LocaleKey.NEW_TOURNAMENT.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: ColorsLocal.hexToColor("686868"),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            child: Switch(
                              value: snapshot.settingsLoaded ? snapshot.settings['new_tournament'] : false,
                              activeColor: ColorsLocal.button_color_purple,
                              onChanged: (value) {
                                snapshot.settings['new_tournament'] = value;
                                snapshot.updateSettings();
                              },
                            ),
                          )
                        ],
                      ),
                    ),
//                  Container(
//                    padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
//                    margin: EdgeInsets.fromLTRB(36, 10, 36, 0),
//                    decoration: BoxDecoration(
//                        color: Colors.white,
//                        borderRadius: BorderRadius.circular(10),
//                        border: Border.all(
//                          width: 0.2,
//                          color: ColorsLocal.hexToColor("E6E6E6"),
//                        )
//                    ),
//                    child: Row(
//                      children: [
//                        Expanded(
//                          child: Container(
//                            child: Text(
//                              "Friend Request",
//                              style: TextStyle(
//                                fontFamily: "Poppins",
//                                fontSize: 16,
//                                fontWeight: FontWeight.w600,
//                                color: ColorsLocal.hexToColor("686868"),
//                              ),
//                            ),
//                          ),
//                        ),
//                        Container(
//                          child: Switch(
//                            value: snapshot.settingsLoaded ? snapshot.settings['allow_friend_requests'] : false,
//                            activeColor: ColorsLocal.button_color_purple,
//                            onChanged: (value) {
//                              snapshot.settings['allow_friend_requests'] = value;
//                              snapshot.updateSettings();
//                            },
//                          ),
//                        )
//                      ],
//                    ),
//                  ),
                    //Sounds *******
                    Container(
                      padding: EdgeInsets.fromLTRB(20, 12, 20, 12),
                      margin: EdgeInsets.fromLTRB(36, 10, 36, 0),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            width: 0.2,
                            color: ColorsLocal.hexToColor("E6E6E6"),
                          )),
                      child: Column(
                        children: [
                          Container(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    child: Text(
                                      LocaleKey.SOUND_EFFECT.toLocaleText(),
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        color: ColorsLocal.hexToColor("686868"),
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  child: Container(
                                      child: Icon(
                                    snapshot.soundEffectLevel == 0 ? Icons.volume_off : Icons.volume_up,
                                    color: ColorsLocal.hexToColor("7A7B79"),
                                  )),
                                  onTap: () {
                                    if (snapshot.soundEffectLevel == 0) {
                                      snapshot.updateSoundEffect(1.0);
                                    } else {
                                      snapshot.updateSoundEffect(0.0);
                                    }
                                  },
                                )
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                            child: SeekBar(
                              value: snapshot.soundEffectLevel,
                              progressColor: ColorsLocal.button_color_purple,
                              thumbColor: ColorsLocal.button_color_purple,
                              barColor: ColorsLocal.hexToColor("E2E2E2"),
                              progressWidth: 4,
                              thumbRadius: 7,
                              onProgressChanged: (value) {
                                snapshot.updateSoundEffect(value);
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(20, 12, 20, 12),
                      margin: EdgeInsets.fromLTRB(36, 10, 36, 0),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            width: 0.2,
                            color: ColorsLocal.hexToColor("E6E6E6"),
                          )),
                      child: Column(
                        children: [
                          Container(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    child: Text(
                                      LocaleKey.MUSIC.toLocaleText(),
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        color: ColorsLocal.hexToColor("686868"),
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  child: Container(
                                      child: Icon(
                                    snapshot.musicLevel == 0 ? Icons.volume_off : Icons.volume_up,
                                    color: ColorsLocal.hexToColor("7A7B79"),
                                  )),
                                  onTap: () {
                                    if (snapshot.musicLevel == 0) {
                                      snapshot.updateMusicLevel(1.0);
                                    } else {
                                      snapshot.updateMusicLevel(0.0);
                                    }
                                  },
                                )
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                            child: SeekBar(
                              value: snapshot.musicLevel,
                              progressColor: ColorsLocal.button_color_purple,
                              thumbColor: ColorsLocal.button_color_purple,
                              barColor: ColorsLocal.hexToColor("E2E2E2"),
                              progressWidth: 4,
                              thumbRadius: 7,
                              onProgressChanged: (value) {
                                snapshot.updateMusicLevel(value);
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                    //Logout ****
                    Container(
                      margin: EdgeInsets.fromLTRB(36, 10, 36, 36),
                      child: InkWell(
                        child: Container(
                          padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                width: 0.2,
                                color: ColorsLocal.hexToColor("E6E6E6"),
                              )),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Text(
                                    LocaleKey.LOGOUT.toLocaleText(),
                                    style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: ColorsLocal.hexToColor("686868"),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                  child: snapshot.loggingOut
                                      ? CupertinoActivityIndicator()
                                      : Container(
                                          child: Icon(
                                            Icons.exit_to_app,
                                            size: 24,
                                            color: ColorsLocal.text_color.withOpacity(0.7),
                                          ),
                                        ))
                            ],
                          ),
                        ),
                        onTap: () {
                          snapshot.logout().then((value) {
                            if (value) {
                              while (Navigator.canPop(context)) {
                                Navigator.pop(context);
                              }
                              Navigator.pushReplacementNamed(context, SplashScreenRoute);
                            }
                          });
                        },
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
