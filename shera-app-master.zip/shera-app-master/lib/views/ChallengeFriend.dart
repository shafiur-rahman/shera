/*
* Created by Ahammed Hossain Shanto on 8/6/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/ChallengeInfo.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/ChallengeFriendVM.dart';

class ChallengeFriend extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return ChallengeFriendVM(context);
        },
        child: Scaffold(
          body: Consumer<ChallengeFriendVM>(builder: (context, snapshot, _) {
            return SingleChildScrollView(
              child: Container(
                margin: EdgeInsets.fromLTRB(32, MediaQuery.of(context).padding.top, 32, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 20, 0, 0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(),
                          ),
                          Container(
                            child: InkWell(
                              child: Icon(
                                Icons.clear,
                                size: 32,
                              ),
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 30),
                      child: Text(
                        LocaleKey.CHOOSE_BET_AMOUNT.toLocaleText(),
                        style: TextStyle(
                          fontFamily: "Poppins",
                          fontSize: 14,
                          color: ColorsLocal.text_color,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 8),
                      child: Wrap(
                        children: List.generate(snapshot.bets.length, (index) {
                          return Container(
                            margin: EdgeInsets.fromLTRB(0, 10, 10, 0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(
                                width: 1,
                                color: ColorsLocal.hexToColor("E8E8E8"),
                              ),
                              color: ChallengeInfo.betAmount == snapshot.bets[index] ? ColorsLocal.button_color_pink : Colors.white,
                            ),
                            child: InkWell(
                              child: Container(
                                padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                                child: Wrap(
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  children: [
                                    Container(
                                      child: Image.asset(
                                        "assets/images/ic_coin.png",
                                        height: 24,
                                        width: 24,
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(8, 0, 8, 0),
                                      child: Text(
                                        snapshot.bets[index].toString().toLocaleNumber(),
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontFamily: "Poppins",
                                          color: ChallengeInfo.betAmount == snapshot.bets[index] ? Colors.white : ColorsLocal.text_color,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              onTap: () {
                                ChallengeInfo.betAmount = snapshot.bets[index];
                                snapshot.notify();
                              },
                            ),
                          );
                        }),
                      ),
                    ),
                    // Container(
                    //   margin: EdgeInsets.only(top: 20),
                    //   child: Text(
                    //     LocaleKey.TYPE_OF_CHALLENGE.toLocaleText(),
                    //     style: TextStyle(
                    //       fontFamily: "Poppins",
                    //       fontSize: 14,
                    //       color: ColorsLocal.text_color,
                    //       fontWeight: FontWeight.w500,
                    //     ),
                    //   ),
                    // ),
                    // Container(
                    //   margin: EdgeInsets.only(top: 12),
                    //   child: Row(
                    //     children: [
                    //       Expanded(
                    //         child: InkWell(
                    //           child: Container(
                    //             height: 60,
                    //             decoration: BoxDecoration(
                    //                 borderRadius: BorderRadius.only(topLeft: Radius.circular(15), bottomLeft: Radius.circular(15)),
                    //                 color: Colors.white,
                    //                 border: Border.all(
                    //                   width: 1,
                    //                   color: ColorsLocal.hexToColor("E8E8E8"),
                    //                 )),
                    //             child: Center(
                    //               child: Text(
                    //                 LocaleKey.SINGLE_TOPIC.toLocaleText(),
                    //                 style: TextStyle(
                    //                   fontFamily: "Poppins",
                    //                   fontSize: 18,
                    //                   fontWeight: FontWeight.w600,
                    //                   color: snapshot.singleTopic ? ColorsLocal.text_color_pink : ColorsLocal.text_color.withOpacity(0.4),
                    //                 ),
                    //                 maxLines: 1,
                    //                 overflow: TextOverflow.ellipsis,
                    //               ),
                    //             ),
                    //           ),
                    //           onTap: () {
                    //             snapshot.singleTopic = true;
                    //             snapshot.notify();
                    //           },
                    //         ),
                    //       ),
                    //       Expanded(
                    //         child: InkWell(
                    //           child: Container(
                    //             height: 60,
                    //             decoration: BoxDecoration(
                    //                 borderRadius: BorderRadius.only(topRight: Radius.circular(15), bottomRight: Radius.circular(15)),
                    //                 color: Colors.white,
                    //                 border: Border.all(
                    //                   width: 1,
                    //                   color: ColorsLocal.hexToColor("E8E8E8"),
                    //                 )),
                    //             child: Center(
                    //               child: Text(
                    //                 LocaleKey.GLOBAL.toLocaleText(),
                    //                 style: TextStyle(
                    //                   fontFamily: "Poppins",
                    //                   fontSize: 18,
                    //                   fontWeight: FontWeight.w600,
                    //                   color: !snapshot.singleTopic ? ColorsLocal.text_color_pink : ColorsLocal.text_color.withOpacity(0.4),
                    //                 ),
                    //                 maxLines: 1,
                    //                 overflow: TextOverflow.ellipsis,
                    //               ),
                    //             ),
                    //           ),
                    //           onTap: () {
                    //             snapshot.singleTopic = false;
                    //             snapshot.notify();
                    //           },
                    //         ),
                    //       ),
                    //     ],
                    //   ),
                    // ),
                    // snapshot.singleTopic
                    //     ? Container(
                    //         margin: EdgeInsets.only(top: 20),
                    //         child: Text(
                    //           LocaleKey.SELECT_TOPIC_CATEGORY.toLocaleText(),
                    //           style: TextStyle(
                    //             fontFamily: "Poppins",
                    //             fontSize: 14,
                    //             color: ColorsLocal.text_color,
                    //             fontWeight: FontWeight.w500,
                    //           ),
                    //         ),
                    //       )
                    //     : Container(height: 0, width: 0),
                    // snapshot.singleTopic
                    //     ? Container(
                    //         height: 60,
                    //         margin: EdgeInsets.only(top: 12),
                    //         decoration: BoxDecoration(
                    //             borderRadius: BorderRadius.circular(15),
                    //             color: Colors.white,
                    //             border: Border.all(
                    //               width: 1,
                    //               color: ColorsLocal.hexToColor("E8E8E8"),
                    //             )),
                    //         padding: EdgeInsets.fromLTRB(24, 0, 12, 0),
                    //         child: Center(
                    //           child: snapshot.categoriesLoaded
                    //               ? Container(
                    //                   child: PopupMenuButton<dynamic>(
                    //                     itemBuilder: (context) {
                    //                       return snapshot.categories.map((value) {
                    //                         return PopupMenuItem(
                    //                           value: value,
                    //                           child: Container(
                    //                             margin: EdgeInsets.only(top: 16),
                    //                             child: Text(
                    //                               value['name'].toString(),
                    //                               style: TextStyle(fontFamily: "Poppins", fontSize: 20, color: ColorsLocal.text_color.withOpacity(0.8), fontWeight: FontWeight.w500),
                    //                               maxLines: 1,
                    //                               overflow: TextOverflow.ellipsis,
                    //                             ),
                    //                           ),
                    //                         );
                    //                       }).toList();
                    //                     },
                    //                     elevation: 4,
                    //                     child: Row(
                    //                       mainAxisSize: MainAxisSize.min,
                    //                       children: <Widget>[
                    //                         Expanded(
                    //                           child: Container(
                    //                             child: Text(
                    //                               snapshot.getSelectedCategoryName(),
                    //                               style: TextStyle(
                    //                                 fontFamily: "Poppins",
                    //                                 fontSize: 20,
                    //                                 fontWeight: FontWeight.w500,
                    //                                 color: ColorsLocal.text_color.withOpacity(0.8),
                    //                               ),
                    //                               maxLines: 1,
                    //                               overflow: TextOverflow.ellipsis,
                    //                             ),
                    //                             margin: EdgeInsets.fromLTRB(0, 0, 4, 0),
                    //                           ),
                    //                         ),
                    //                         Icon(
                    //                           Icons.keyboard_arrow_down,
                    //                           size: 32,
                    //                           color: ColorsLocal.text_color.withOpacity(0.8),
                    //                         ),
                    //                       ],
                    //                     ),
                    //                     onSelected: (value) {
                    //                       snapshot.setCategoryId(value['id']);
                    //                     },
                    //                   ),
                    //                 )
                    //               : CupertinoActivityIndicator(),
                    //         ),
                    //       )
                    //     : Container(height: 0, width: 0),
                    // snapshot.singleTopic
                    //     ? Container(
                    //         margin: EdgeInsets.only(top: 20),
                    //         child: Text(
                    //           LocaleKey.SELECT_TOPIC.toLocaleText(),
                    //           style: TextStyle(
                    //             fontFamily: "Poppins",
                    //             fontSize: 14,
                    //             color: ColorsLocal.text_color,
                    //             fontWeight: FontWeight.w500,
                    //           ),
                    //         ),
                    //       )
                    //     : Container(height: 0, width: 0),
                    // snapshot.singleTopic
                    //     ? Container(
                    //         height: 60,
                    //         margin: EdgeInsets.only(top: 12),
                    //         decoration: BoxDecoration(
                    //             borderRadius: BorderRadius.circular(15),
                    //             color: Colors.white,
                    //             border: Border.all(
                    //               width: 1,
                    //               color: ColorsLocal.hexToColor("E8E8E8"),
                    //             )),
                    //         padding: EdgeInsets.fromLTRB(24, 0, 12, 0),
                    //         child: Center(
                    //           child: snapshot.topicsLoaded
                    //               ? Container(
                    //                   child: PopupMenuButton<dynamic>(
                    //                     itemBuilder: (context) {
                    //                       return snapshot.topics.map((value) {
                    //                         return PopupMenuItem(
                    //                           value: value,
                    //                           child: Container(
                    //                             margin: EdgeInsets.only(top: 16),
                    //                             child: Text(
                    //                               value['name'].toString(),
                    //                               style: TextStyle(fontFamily: "Poppins", fontSize: 20, color: ColorsLocal.text_color.withOpacity(0.8), fontWeight: FontWeight.w500),
                    //                               maxLines: 1,
                    //                               overflow: TextOverflow.ellipsis,
                    //                             ),
                    //                           ),
                    //                         );
                    //                       }).toList();
                    //                     },
                    //                     elevation: 4,
                    //                     child: Row(
                    //                       mainAxisSize: MainAxisSize.min,
                    //                       children: <Widget>[
                    //                         Expanded(
                    //                           child: Container(
                    //                             child: Text(
                    //                               snapshot.getSelectedTopicName(),
                    //                               style: TextStyle(
                    //                                 fontFamily: "Poppins",
                    //                                 fontSize: 20,
                    //                                 fontWeight: FontWeight.w500,
                    //                                 color: ColorsLocal.text_color.withOpacity(0.8),
                    //                               ),
                    //                               maxLines: 1,
                    //                               overflow: TextOverflow.ellipsis,
                    //                             ),
                    //                             margin: EdgeInsets.fromLTRB(0, 0, 4, 0),
                    //                           ),
                    //                         ),
                    //                         Icon(
                    //                           Icons.keyboard_arrow_down,
                    //                           size: 32,
                    //                           color: ColorsLocal.text_color.withOpacity(0.8),
                    //                         ),
                    //                       ],
                    //                     ),
                    //                     onSelected: (value) {
                    //                       snapshot.setTopicId(value['topic_id']);
                    //                     },
                    //                   ),
                    //                 )
                    //               : CupertinoActivityIndicator(),
                    //         ),
                    //       )
                    //     : Container(height: 0, width: 0),
                    Container(
                      margin: EdgeInsets.only(top: 20),
                      child: Text(
                        LocaleKey.SELECT_QUESTION_AMOUNT.toLocaleText(),
                        style: TextStyle(
                          fontFamily: "Poppins",
                          fontSize: 14,
                          color: ColorsLocal.text_color,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Container(
                      height: 60,
                      margin: EdgeInsets.only(top: 12, bottom: 32),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: Colors.white,
                          border: Border.all(
                            width: 1,
                            color: ColorsLocal.hexToColor("E8E8E8"),
                          )),
                      padding: EdgeInsets.fromLTRB(24, 0, 12, 0),
                      child: Center(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Text(
                                ChallengeInfo.questionCount.toString().toLocaleNumber(),
                                style: TextStyle(fontFamily: "Poppins", fontSize: 20, color: ColorsLocal.text_color.withOpacity(0.7), fontWeight: FontWeight.w500),
                              ),
                            ),
                            Container(
                              child: Wrap(
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                    child: InkWell(
                                      child: Container(
                                        padding: EdgeInsets.all(6),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.grey[300],
                                        ),
                                        child: Icon(
                                          Icons.remove,
                                          color: ColorsLocal.text_color,
                                          size: 16,
                                        ),
                                      ),
                                      onTap: () {
                                        if (ChallengeInfo.questionCount > snapshot.minQuestionAmount) {
                                          ChallengeInfo.questionCount -= 10;
                                          snapshot.notify();
                                        }
                                      },
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                    child: InkWell(
                                      child: Container(
                                        padding: EdgeInsets.all(6),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.grey[300],
                                        ),
                                        child: Icon(
                                          Icons.add,
                                          color: ColorsLocal.text_color,
                                          size: 16,
                                        ),
                                      ),
                                      onTap: () {
                                        if (ChallengeInfo.questionCount < snapshot.maxQuestionAmount) {
                                          ChallengeInfo.questionCount += 10;
                                          snapshot.notify();
                                        }
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
          bottomNavigationBar: Consumer<ChallengeFriendVM>(builder: (context, snapshot, _) {
            return ChallengeInfo.topicId == -1 && snapshot.singleTopic
                ? Container(height: 0, width: 0)
                : BottomAppBar(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        color: ColorsLocal.button_color_purple,
                        elevation: 0,
                        highlightElevation: 0,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
                          child: snapshot.challenging
                              ? Container(height: 24, width: 24, child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation<Color>(Colors.white)))
                              : Text(
                                  LocaleKey.CONFIRM.toLocaleText(),
                                  style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w500),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                        ),
                        onPressed: () {
                          snapshot.challengeFriend();
                        },
                      ),
                    ),
                  );
          }),
        ),
      ),
    );
  }
}
