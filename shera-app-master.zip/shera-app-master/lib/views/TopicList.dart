/*
* Created by Ahammed Hossain Shanto on 7/7/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/ViewModelFactory.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-components/Topics.dart';
import 'package:quiz/view-models/TopicListVM.dart';

class TopicList extends StatelessWidget {
  var arguments;
  bool backArrowEnable = true;
  String title = "Topics";
  String type = "favourite"; //could be {top, favourite, category}
  String header = "Topic";
  int categoryId = -1;
  TopicsListVM topicsListVM = ViewModelFactory.getTopicListVM();
  double minTileWidth = 120;

  TopicList(this.arguments) {
    //
  }

  Future<void> _onRefresh() async {
    if (type == "top") {
      await topicsListVM.loadAllTop();
    } else if (type == "favourite") {
      await topicsListVM.loadAllFavourite();
    } else if (type == "category") {
      await topicsListVM.loadAllTopicsFromCategory(categoryId);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (arguments != null) {
      if (arguments['page_title'] != null) {
        title = arguments['page_title'].toString();
      }
      if (arguments['type'] != null) {
        type = arguments['type'].toString();
      }
      if (arguments['back_arrow_enable'] != null) {
        backArrowEnable = arguments['back_arrow_enable'];
      }
      if (arguments['category_id'] != null) {
        categoryId = arguments['category_id'];
      }
    }

    //calling apis***
    if (type == "top") {
      header = "Top Topic";
      if (topicsListVM.type != type) {
        topicsListVM.loadAllTop();
      }
    } else if (type == "favourite") {
      header = "Favorite Topic";
      if (topicsListVM.type != type) {
        topicsListVM.loadAllFavourite();
      }
    } else if (type == "category") {
      header = "Topic";
      topicsListVM.loadAllTopicsFromCategory(categoryId);
    }

    return RootBody(
      child: ChangeNotifierProvider.value(
        value: topicsListVM,
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: backArrowEnable
                ? Container(
                    child: IconButton(
                      icon: Image.asset(
                        "assets/images/back_arrow.png",
                        height: 20,
                        width: 24,
                      ),
                      padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  )
                : null,
            title: Text(
              title,
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
//            Container(
//              height: 20,
//              decoration: BoxDecoration(
//                color: Colors.white,
//                boxShadow: [
//                  BoxShadow(
//                      offset: Offset(0, 4),
//                      color: ColorsLocal.hexToColor("E1E1E1").withOpacity(0.5),
//                      spreadRadius: 0.4,
//                      blurRadius: 16
//                  )
//                ],
//              ),
//            ),
              Expanded(
                child: Container(
                    padding: EdgeInsets.fromLTRB(28, 24, 28, 24),
                    child: Consumer<TopicsListVM>(builder: (context, snapshot, _) {
                      if (snapshot.topicsLoaded && (snapshot.topics == null || snapshot.topics.isEmpty)) {
                        return Center(
                          child: Text(
                            "No topics found",
                            style: TextStyle(fontFamily: "Poppins", fontSize: 15, color: ColorsLocal.text_color.withOpacity(0.6), fontWeight: FontWeight.w500),
                          ),
                        );
                      } else {
                        return RefreshIndicator(
                          onRefresh: _onRefresh,
                          child: GridView.count(
                            crossAxisCount: getRowCount(context),
                            crossAxisSpacing: getRowCount(context) == 0 ? 0 : 16,
                            mainAxisSpacing: 12,
                            children: _buildTopicList(context, snapshot),
                          ),
                        );
                      }
                    })),
              )
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildTopicList(BuildContext context, TopicsListVM snapshot) {
    List<Widget> items = new List();

    if (snapshot.topicsLoaded) {
      if (snapshot.topics != null && snapshot.topics.isNotEmpty) {
        int rowCount = getRowCount(context);
        double heightWidth = (MediaQuery.of(context).size.width.toCustomWidth() - 56 - (rowCount - 1) * 16) / rowCount;

        items.addAll(List.generate(snapshot.topics.length, (index) {
          return Topics.tile(heightWidth, heightWidth, index, snapshot.topics,
              implementFavButton: true,
              gapBetween: 0,
              initialGap: 0,
              iconLabelGap: heightWidth * .05,
              iconSize: heightWidth * .5,
              favIconSize: heightWidth * 0.12,
              textStyle: TextStyle(
                fontFamily: "Poppins",
                color: ColorsLocal.text_color,
                fontWeight: FontWeight.w500,
                fontSize: heightWidth * .1,
              ),
              favButtonPosition: heightWidth * .05, onTap: () {
            Navigator.pushNamed(context, TopicDetailsRoute, arguments: {'topic_id': snapshot.topics[index]['topic_id'], 'type': header, 'category_name': snapshot.topics[index]['category_name']});
          }, onFavTap: () {
            //TODO call toggle favourite method ******
            snapshot.toggleFavourite(index);
          });
        }));
      }
    } else {
      int count = getRowCount(context) * 4;
      items.addAll(List.generate(count, (index) {
        return Container(
          child: MyShimmer.fromColors(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(7),
                  color: Colors.grey[300],
                ),
              ),
              baseColor: Colors.grey[300],
              highlightColor: Colors.white),
        );
      }));
    }

    return items;
  }

  int getRowCount(BuildContext context) {
    double availableWidth = MediaQuery.of(context).size.width.toCustomWidth() - 56;

    int i = availableWidth ~/ minTileWidth;
    return i;
  }
}
