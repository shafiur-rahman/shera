/*
* Created by Ahammed Hossain Shanto
* on 7/6/20
*/

import 'dart:convert';
import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/helpers/banner-ad-loader.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Pop_Ups/CoinsGemsUsage.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/ProfileVM.dart';

class Profile extends StatelessWidget {
  final ProfileVM profileVM = new ProfileVM();


  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return profileVM;
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: IconButton(
              icon: Image.asset(
                "assets/images/back_arrow.png",
                width: 25,
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            title: Text(
              '${LocaleValues.instance.getText(LocaleKey.PROFILE)}',
              style: TextStyle(
                fontFamily: "Poppins",
                color: ColorsLocal.text_color,
                fontSize: 22,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          body: SingleChildScrollView(
            child: Consumer<ProfileVM>(builder: (context, snapshot, _) {
              return Stack(
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    child: Container(
                      height: 80,
                      width: MediaQuery.of(context).size.width.toCustomWidth(),
                      decoration: BoxDecoration(
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        _buildProfileHeader(context, snapshot),
                        AppSessionSettings.isNepaliUser() ? Container() : _buildWiningStatus(context, snapshot),
                        //_buildCategoriesPlayed(context, snapshot),
                        AppSessionSettings.isNepaliUser() ? Container() : _buildBcsModelHistory(context, snapshot),
                      ],
                    ),
                  )
                ],
              );
            }),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileHeader(BuildContext context, ProfileVM snapshot) {
    if (snapshot.profileLoaded) {
      return Container(
        margin: EdgeInsets.fromLTRB(8, 12, 8, 6),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            //color: ColorsLocal.hexToColor("8435E8"),
            gradient: LinearGradient(
              colors: [Colors.deepPurple, ColorsLocal.button_color_purple],
              stops: [0.0, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.grey[200],
                offset: Offset(0, 4),
                blurRadius: 4,
                spreadRadius: 4,
              )
            ]),
        padding: EdgeInsets.fromLTRB(16, 20, 16, 20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
                //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    border: Border.all(
                      width: 4,
                      color: Colors.white,
                    ),
                    shape: BoxShape.circle),
                constraints: BoxConstraints.tightFor(height: 48, width: 48),
                child: CachedNetworkImage(
                  imageUrl: snapshot.userDetails['image_url'].toString(),
                  imageBuilder: (context, imageProvider) => Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      //borderRadius: BorderRadius.circular(4),
                      image: DecorationImage(
                        image: imageProvider,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  placeholder: (context, url) => MyShimmer.fromColors(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        //borderRadius: BorderRadius.circular(8),
                        color: Colors.grey[300],
                      ),
                    ),
                    baseColor: Colors.grey[300],
                    highlightColor: Colors.white,
                  ),
                  errorWidget: (context, url, error) => Icon(Icons.error),
                )),
            Expanded(
              child: Container(
                margin: EdgeInsets.fromLTRB(16, 0, 0, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 16, 0),
                            child: Text(
                              snapshot.userDetails['name'].toString(),
                              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: Colors.white, fontWeight: FontWeight.w700),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                          child: InkWell(
                            child: Container(
                              padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(7),
                                color: Colors.white.withOpacity(0.1),
                              ),
                              child: Icon(
                                Icons.edit,
                                size: 16,
                                color: Colors.white,
                              ),
                            ),
                            onTap: () {
                              Navigator.pushNamed(context, EditProfileRoute, arguments: profileVM.userDetails).then((flag) {
                                snapshot.loadProfile();
                              });
                            },
                          ),
                        )
                      ],
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                      child: Wrap(
                        children: [
                          Container(
                            height: 28,
                            margin: EdgeInsets.fromLTRB(0, 5, 5, 0),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                color: Colors.white.withOpacity(0.15),
                                border: Border.all(
                                  width: 1,
                                  color: Colors.white.withOpacity(0.5),
                                )),
                            child: Wrap(
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                Container(
                                  child: CircularPercentIndicator(
                                    radius: 24,
                                    lineWidth: 2.0,
                                    animation: true,
                                    percent: snapshot.userDetails['level_progress'] / 100,
                                    center: new Text(
                                      '${double.parse(snapshot.userDetails['level_progress'].toString()).toStringAsFixed(0).toLocaleNumber()}%',
                                      style: new TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w500, fontSize: 9.0),
                                    ),
                                    circularStrokeCap: CircularStrokeCap.round,
                                    progressColor: ColorsLocal.getProgressColor(double.parse(snapshot.userDetails['level_progress'].toString())),
                                  ),
                                  margin: EdgeInsets.fromLTRB(1, 0, 0, 1),
                                  decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                  child: Text(
                                    '${LocaleKey.LEVEL.toLocaleText()} ${snapshot.userDetails['level'].toString().toLocaleNumber()}',
                                    style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              CoinsGemsUsage.showDialog(context);
                            },
                            child: Container(
                              height: 28,
                              margin: EdgeInsets.fromLTRB(0, 5, 5, 0),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  color: Colors.white.withOpacity(0.15),
                                  border: Border.all(
                                    width: 1,
                                    color: Colors.white.withOpacity(0.5),
                                  )),
                              child: Wrap(
                                crossAxisAlignment: WrapCrossAlignment.center,
                                children: [
                                  Container(
                                    child: Image.asset(
                                      "assets/images/ic_coin.png",
                                      height: 20,
                                      width: 20,
                                    ),
                                    padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                                    child: Text(
                                      '${snapshot.userDetails['wallet']['coins'].toString().toLocaleNumber()}',
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              CoinsGemsUsage.showDialog(context);
                            },
                            child: Container(
                              height: 28,
                              margin: EdgeInsets.fromLTRB(0, 5, 5, 0),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  color: Colors.white.withOpacity(0.15),
                                  border: Border.all(
                                    width: 1,
                                    color: Colors.white.withOpacity(0.5),
                                  )),
                              child: Wrap(
                                crossAxisAlignment: WrapCrossAlignment.center,
                                children: [
                                  Container(
                                    child: Image.asset(
                                      "assets/images/ic_gem.png",
                                      height: 20,
                                      width: 20,
                                    ),
                                    padding: EdgeInsets.fromLTRB(4, 4, 4, 4),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 4, 8, 4),
                                    child: Text(
                                      '${snapshot.userDetails['wallet']['gems'].toString().toLocaleNumber()}',
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      );
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(8, 12, 8, 0),
        child: MyShimmer.fromColors(
            child: Container(
              height: 150,
              width: MediaQuery.of(context).size.width.toCustomWidth() - 16,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    }
  }

  Widget _buildWiningStatus(BuildContext context, ProfileVM snapshot) {
    if (snapshot.profileLoaded) {
      if (snapshot.userDetails['win_status_available'] == true) {
        return Container(
          margin: EdgeInsets.fromLTRB(8, 6, 8, 6),
          child: Container(
            //height: 150,
            padding: EdgeInsets.all(24),
            width: MediaQuery.of(context).size.width.toCustomWidth() - 16,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(
                  width: 1,
                  color: Colors.grey[200],
                )),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  child: Text(
                    LocaleKey.CHALLENGE_WINNING_STATUS.toLocaleText(),
                    style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                        child: Column(
                          children: [
                            Container(
                              child: CircularPercentIndicator(
                                radius: (MediaQuery.of(context).size.width.toCustomWidth() - 100 - 24) / 3,
                                lineWidth: 6.0,
                                animation: true,
                                percent: double.parse(snapshot.userDetails['win'].toString()).abs() / 100,
                                backgroundColor: Colors.grey[200],
                                reverse: true,
                                center: new Text(
                                  '${double.parse(snapshot.userDetails['win'].toString()).toStringAsFixed(0).toLocaleNumber()}%',
                                  style: new TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w700, fontSize: 20, color: Colors.black.withOpacity(0.8)),
                                ),
                                circularStrokeCap: CircularStrokeCap.round,
                                progressColor: ColorsLocal.hexToColor("3BC985"),
                              ),
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              decoration: BoxDecoration(shape: BoxShape.circle),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                              child: Text(
                                LocaleKey.WIN.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  color: ColorsLocal.hexToColor("A8A8A8"),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                        child: Column(
                          children: [
                            Container(
                              child: CircularPercentIndicator(
                                radius: (MediaQuery.of(context).size.width.toCustomWidth() - 100 - 24) / 3,
                                lineWidth: 6.0,
                                animation: true,
                                percent: double.parse(snapshot.userDetails['draw'].toString()).abs() / 100,
                                backgroundColor: Colors.grey[200],
                                reverse: true,
                                center: new Text(
                                  '${double.parse(snapshot.userDetails['draw'].toString()).toStringAsFixed(0).toLocaleNumber()}%',
                                  style: new TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w700, fontSize: 20, color: Colors.black.withOpacity(0.8)),
                                ),
                                circularStrokeCap: CircularStrokeCap.round,
                                progressColor: ColorsLocal.hexToColor("FEA41F"),
                              ),
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              decoration: BoxDecoration(shape: BoxShape.circle),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                              child: Text(
                                LocaleKey.DRAW.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  color: ColorsLocal.hexToColor("A8A8A8"),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                        child: Column(
                          children: [
                            Container(
                              child: CircularPercentIndicator(
                                radius: (MediaQuery.of(context).size.width.toCustomWidth() - 100 - 24) / 3,
                                lineWidth: 6.0,
                                animation: true,
                                percent: double.parse(snapshot.userDetails['loss'].toString()).abs() / 100,
                                backgroundColor: Colors.grey[200],
                                reverse: true,
                                center: new Text(
                                  '${double.parse(snapshot.userDetails['loss'].toString()).toStringAsFixed(0).toLocaleNumber()}%',
                                  style: new TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w700, fontSize: 20, color: Colors.black.withOpacity(0.8)),
                                ),
                                circularStrokeCap: CircularStrokeCap.round,
                                progressColor: ColorsLocal.hexToColor("FF5E94"),
                              ),
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              decoration: BoxDecoration(shape: BoxShape.circle),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                              child: Text(
                                LocaleKey.LOSS.toLocaleText(),
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  color: ColorsLocal.hexToColor("A8A8A8"),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(8, 12, 8, 0),
        child: MyShimmer.fromColors(
            child: Container(
              //height: 150,
              padding: EdgeInsets.all(24),
              width: MediaQuery.of(context).size.width.toCustomWidth() - 16,
              decoration: BoxDecoration(
                //color: Colors.grey[300],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 20,
                    margin: EdgeInsets.fromLTRB(0, 0, 100, 0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      color: Colors.grey[300],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.grey[300],
                          ),
                          height: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                          width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                          margin: EdgeInsets.fromLTRB(4, 4, 4, 4),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.grey[300],
                          ),
                          height: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                          width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                          margin: EdgeInsets.fromLTRB(4, 4, 4, 4),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.grey[300],
                          ),
                          height: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                          width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 3,
                          margin: EdgeInsets.fromLTRB(4, 4, 4, 4),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    }
  }

  Widget _buildCategoriesPlayed(BuildContext context, ProfileVM snapshot) {
    if (snapshot.categoriesLoaded) {
      if (snapshot.categories != null && snapshot.categories.isNotEmpty) {
        return Container(
          margin: EdgeInsets.fromLTRB(8, 6, 8, 12),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                width: 1,
                color: Colors.grey[200],
              )),
          child: Container(
            padding: EdgeInsets.fromLTRB(20, 24, 20, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                    margin: EdgeInsets.fromLTRB(4, 0, 4, 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Container(
                            child: Text(
                              "Categories",
                              style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                        Visibility(
                          visible: false,
                          child: InkWell(
                            child: Container(
                              padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                              child: Text(
                                "See all",
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 10,
                                  color: Colors.grey[400],
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            onTap: () {},
                          ),
                        ),
                      ],
                    )),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: List.generate(min(snapshot.categories.length, 4), (index) {
                    return Container(
                      margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                      child: Material(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.transparent,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(24, 12, 24, 12),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                width: 1,
                                color: ColorsLocal.hexToColor("F0F0F0"),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Expanded(
                                        child: Container(
                                          child: Text(
                                            snapshot.categories[index]['name'].toString(),
                                            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: ColorsLocal.text_color, fontFamily: "Poppins"),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        child: Text(
                                          '${double.parse((snapshot.categories[index]['progress'] * 100).toString()).toStringAsFixed(0)}%',
                                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: ColorsLocal.getProgressColor(double.parse((snapshot.categories[index]['progress'] * 100).toString())), fontFamily: "Poppins"),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

//                          Container(
//                            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
//                            child: MyLinearProgressBar.progressBar(
//                                MediaQuery.of(context).size.width.toCustomWidth() - 108,
//                                double.parse(snapshot.categories[index]['progress'].toString()),
//                              height: 4.4,
//                            ),
//                          ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                                  child: LinearPercentIndicator(
                                    width: MediaQuery.of(context).size.width.toCustomWidth() - 108,
                                    lineHeight: 5.0,
                                    backgroundColor: Colors.grey[200],
                                    percent: double.parse(snapshot.categories[index]['progress'].toString()),
                                    padding: EdgeInsets.fromLTRB(2, 0, 2, 0),
                                    linearGradient: LinearGradient(
                                      colors: [ColorsLocal.getProgressColor(double.parse(snapshot.categories[index]['progress'].toString()) * 100), ColorsLocal.getProgressColor(double.parse(snapshot.categories[index]['progress'].toString()) * 100).withOpacity(0.1)],
                                      stops: [0.7, 1.0],
                                    ),
                                    animation: true,
                                  ),
                                )
                              ],
                            ),
                          ),
                          onTap: () {
                            var arguments = {};
                            arguments['type'] = "category";
                            arguments['page_title'] = snapshot.categories[index]['name'].toString();
                            arguments['category_id'] = snapshot.categories[index]['id'];
                            if (snapshot.categories[index]['has_subcategory'] != null && snapshot.categories[index]['has_subcategory'] == true) {
                              Navigator.pushNamed(context, SubcategoryListRoute, arguments: arguments);
                            } else {
                              Navigator.pushNamed(context, TopicListRoute, arguments: arguments);
                            }
                          },
                        ),
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(8, 6, 8, 12),
        child: MyShimmer.fromColors(
            child: Container(
              padding: EdgeInsets.fromLTRB(24, 24, 24, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 20,
                    margin: EdgeInsets.fromLTRB(0, 0, 150, 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey[300],
                    ),
                  ),
                  Container(
                    height: 48,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[300],
                    ),
                  ),
                  Container(
                    height: 48,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[300],
                    ),
                  ),
                  Container(
                    height: 48,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[300],
                    ),
                  ),
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    }
  }

  Widget _buildBcsModelHistory(BuildContext context, ProfileVM snapshot) {
    if (snapshot.bcsHistoryLoaded) {
      return Container(
        margin: EdgeInsets.fromLTRB(8, 6, 8, 6),
        child: Container(
          //height: 150,
          padding: EdgeInsets.all(24),
          width: MediaQuery.of(context).size.width.toCustomWidth() - 16,
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                width: 1,
                color: Colors.grey[200],
              )),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Container(
                      child: Text(
                        LocaleKey.BCS_TEST_RESULT.toLocaleText(),
                        style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(8, 2, 8, 2),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(4), border: Border.all(width: 1, color: ColorsLocal.text_color_purple)),
                    child: PopupMenuButton<dynamic>(
                      itemBuilder: (context) {
                        return snapshot.bcsFilter.map((filter) {
                          return PopupMenuItem(
                            value: filter,
                            child: Text(
                              filter['value'].toString(),
                              style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                            ),
                          );
                        }).toList();
                      },
                      tooltip: "Notification Filter",
                      elevation: 4,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Container(
                            child: Text(
                              snapshot.selectedBcsFilter['value'].toString(),
                              style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                color: ColorsLocal.text_color_purple,
                              ),
                            ),
                            margin: EdgeInsets.fromLTRB(0, 0, 4, 0),
                          ),
                          Icon(
                            Icons.keyboard_arrow_down,
                            size: 20,
                            color: ColorsLocal.text_color_purple,
                          ),
                        ],
                      ),
                      onSelected: (value) {
                        snapshot.updateBcsFilterSelection(value);
                      },
                    ),
                  )
                ],
              ),
              Container(
                margin: EdgeInsets.only(top: 16),
                height: 0.5,
                color: Colors.grey[300],
              ),
              Container(
                margin: EdgeInsets.only(top: 16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                        child: Text(
                      LocaleKey.MODEL_TEST_PARTICIPATED.toLocaleText(),
                      style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 15,
                        color: ColorsLocal.text_color,
                        fontWeight: FontWeight.w500,
                      ),
                    )),
                    Container(
                        child: Text(
                      snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['test_played'].toString().toLocaleNumber(),
                      style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 18,
                        color: ColorsLocal.text_color,
                        fontWeight: FontWeight.w800,
                      ),
                    ))
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                        child: Text(
                      LocaleKey.QUESTION_ANSWERED.toLocaleText(),
                      style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 15,
                        color: ColorsLocal.text_color,
                        fontWeight: FontWeight.w500,
                      ),
                    )),
                    Container(
                        child: Text(
                      snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['question_played'].toString().toLocaleNumber(),
                      style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 18,
                        color: ColorsLocal.text_color,
                        fontWeight: FontWeight.w800,
                      ),
                    ))
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 4,
                      child: Column(
                        children: [
                          Container(
                            child: CircularPercentIndicator(
                              radius: (MediaQuery.of(context).size.width.toCustomWidth() - 100 - 24) / 4,
                              lineWidth: 4.0,
                              animation: true,
                              percent: double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['mark'].toString()).abs(),
                              backgroundColor: Colors.grey[200],
                              reverse: true,
                              center: new Text(
                                '${(double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['mark'].toString()) * 100).toStringAsFixed(0).toLocaleNumber()}%',
                                style: new TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16, color: Colors.black.withOpacity(0.8)),
                              ),
                              circularStrokeCap: CircularStrokeCap.round,
                              progressColor: ColorsLocal.getProgressColor((double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['mark'].toString()) * 100)),
                            ),
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            decoration: BoxDecoration(shape: BoxShape.circle),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                            child: Text(
                              LocaleKey.MARK.toLocaleText(),
                              style: TextStyle(
                                fontFamily: "Poppins",
                                color: ColorsLocal.hexToColor("A8A8A8"),
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Container(
                      width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 4,
                      child: Column(
                        children: [
                          Container(
                            child: CircularPercentIndicator(
                              radius: (MediaQuery.of(context).size.width.toCustomWidth() - 100 - 24) / 4,
                              lineWidth: 4.0,
                              animation: true,
                              percent: double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['correct'].toString()).abs(),
                              backgroundColor: Colors.grey[200],
                              reverse: true,
                              center: new Text(
                                '${(double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['correct'].toString()) * 100).toStringAsFixed(0).toLocaleNumber()}%',
                                style: new TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16, color: Colors.black.withOpacity(0.8)),
                              ),
                              circularStrokeCap: CircularStrokeCap.round,
                              progressColor: ColorsLocal.getProgressColor((double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['correct'].toString()) * 100)),
                            ),
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            decoration: BoxDecoration(shape: BoxShape.circle),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                            child: Text(
                              LocaleKey.CORRECT.toLocaleText(),
                              style: TextStyle(
                                fontFamily: "Poppins",
                                color: ColorsLocal.hexToColor("A8A8A8"),
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Container(
                      width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 4,
                      child: Column(
                        children: [
                          Container(
                            child: CircularPercentIndicator(
                              radius: (MediaQuery.of(context).size.width.toCustomWidth() - 100 - 24) / 4,
                              lineWidth: 4.0,
                              animation: true,
                              percent: double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['wrong'].toString()).abs(),
                              backgroundColor: Colors.grey[200],
                              reverse: true,
                              center: new Text(
                                '${(double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['wrong'].toString()) * 100).toStringAsFixed(0).toLocaleNumber()}%',
                                style: new TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16, color: Colors.black.withOpacity(0.8)),
                              ),
                              circularStrokeCap: CircularStrokeCap.round,
                              progressColor: ColorsLocal.getProgressColor(100 - (double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['wrong'].toString()) * 100)),
                            ),
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            decoration: BoxDecoration(shape: BoxShape.circle),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                            child: Text(
                              LocaleKey.WRONG.toLocaleText(),
                              style: TextStyle(
                                fontFamily: "Poppins",
                                color: ColorsLocal.hexToColor("A8A8A8"),
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Container(
                      width: (MediaQuery.of(context).size.width.toCustomWidth() - 100) / 4,
                      child: Column(
                        children: [
                          Container(
                            child: CircularPercentIndicator(
                              radius: (MediaQuery.of(context).size.width.toCustomWidth() - 100 - 24) / 4,
                              lineWidth: 4.0,
                              animation: true,
                              percent: double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['skipped'].toString()).abs(),
                              backgroundColor: Colors.grey[200],
                              reverse: true,
                              center: new Text(
                                '${(double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['skipped'].toString()) * 100).toStringAsFixed(0).toLocaleNumber()}%',
                                style: new TextStyle(fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 16, color: Colors.black.withOpacity(0.8)),
                              ),
                              circularStrokeCap: CircularStrokeCap.round,
                              progressColor: ColorsLocal.getProgressColor(100 - (double.parse(snapshot.bcsHistory['${snapshot.selectedBcsFilter['key']}']['skipped'].toString()) * 100)),
                            ),
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            decoration: BoxDecoration(shape: BoxShape.circle),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                            child: Text(
                              LocaleKey.SKIPPED.toLocaleText(),
                              style: TextStyle(
                                fontFamily: "Poppins",
                                color: ColorsLocal.hexToColor("A8A8A8"),
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      );
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(8, 6, 8, 12),
        child: MyShimmer.fromColors(
            child: Container(
              padding: EdgeInsets.fromLTRB(24, 24, 24, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 20,
                    margin: EdgeInsets.fromLTRB(0, 0, 150, 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey[300],
                    ),
                  ),
                  Container(
                    height: 48,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[300],
                    ),
                  ),
                  Container(
                    height: 48,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[300],
                    ),
                  ),
                  Container(
                    height: 48,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey[300],
                    ),
                  ),
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    }
  }
}
