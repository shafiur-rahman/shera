/*
* Created by Ahammed Hossain Shanto
* on 2/24/21
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/BkashPurchasePackVM.dart';
import 'package:quiz/extensions/string_extensions.dart';

class BkashPurchasePack extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var arguments = ModalRoute.of(context).settings.arguments;
    return RootBody(
      needLogin: false,
      child: ChangeNotifierProvider(
        create: (_) {
          return BkashPurchasePackVM(context, arguments);
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.PURCHASE_PACK.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Consumer<BkashPurchasePackVM>(
            builder: (context, snapshot, _) {
              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        margin: EdgeInsets.only(top: 50),
                        child: Image.asset(
                          "assets/images/text_logo.png",
                          height: 100,
                        ),
                      ),
                    ),
                    //name
                    Container(
                      margin: EdgeInsets.fromLTRB(24, 32, 24, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                            child: Text(
                              LocaleKey.FULL_NAME.toLocaleText(),
                              style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 14,
                                color: ColorsLocal.text_color,
                                fontWeight: FontWeight.w400
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 4, 0, 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                              border: Border.all(
                                width: 1,
                                color: ColorsLocal.hexToColor("EAEAEA"),
                              ),
                            ),
                            padding: EdgeInsets.fromLTRB(24, 6, 24, 6),
                            child: TextField(
                              controller: snapshot.nameController,
                              textAlign: TextAlign.start,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, letterSpacing: 1.0, fontWeight: FontWeight.w500),
                              maxLines: 1,
                              decoration: InputDecoration(
                                  hintText: LocaleKey.ENTER_NAME.toLocaleText(),
                                  hintStyle: TextStyle(
                                    fontSize: 18,
                                    color: ColorsLocal.hexToColor("D4DDEC"),
                                  ),
                                  border: InputBorder.none),
                              onChanged: (value) {
                                if(value.isNotEmpty) {
                                  if(!snapshot.isNameOk) {
                                    snapshot.isNameOk = true;
                                    snapshot.notify();
                                  }
                                }
                                else {
                                  if(snapshot.isNameOk) {
                                    snapshot.isNameOk = false;
                                    snapshot.notify();
                                  }
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    //mobile
                    Container(
                      margin: EdgeInsets.fromLTRB(24, 4, 24, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                            child: Text(
                              LocaleKey.MOBILE.toLocaleText(),
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 14,
                                  color: ColorsLocal.text_color,
                                  fontWeight: FontWeight.w400
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 4, 0, 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                              border: Border.all(
                                width: 1,
                                color: ColorsLocal.hexToColor("EAEAEA"),
                              ),
                            ),
                            padding: EdgeInsets.fromLTRB(24, 6, 24, 6),
                            child: TextField(
                              controller: snapshot.mobileController,
                              textAlign: TextAlign.start,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, letterSpacing: 1.0, fontWeight: FontWeight.w500),
                              maxLines: 1,
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                              decoration: InputDecoration(
                                  hintText: LocaleKey.ENTER_MOBILE.toLocaleText(),
                                  hintStyle: TextStyle(
                                    fontSize: 18,
                                    color: ColorsLocal.hexToColor("D4DDEC"),
                                  ),
                                  border: InputBorder.none),
                              onChanged: (value) {
                                if(value.length == 11) {
                                  if(!snapshot.isMobileOk) {
                                    snapshot.isMobileOk = true;
                                    snapshot.notify();
                                  }
                                }
                                else {
                                  if(snapshot.isMobileOk) {
                                    snapshot.isMobileOk = false;
                                    snapshot.notify();
                                  }
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 16,
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(24, 0, 24, 0),
                      child: Text(
                        LocaleKey.CREATE_ACCOUNT_WITH_SAME_MOBILE.toLocaleText(),
                        style: TextStyle(
                          fontFamily: "Poppins",
                          fontSize: 15,
                          color: Colors.red,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    snapshot.processing ?
                        CupertinoActivityIndicator() :
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child: RaisedButton(
                          child: Text(
                            LocaleKey.PROCEED.toLocaleText(),
                            style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w600),
                          ),
                          color: ColorsLocal.button_color_pink,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: EdgeInsets.fromLTRB(24, 16, 24, 16),
                          onPressed: !snapshot.isOkToProceed() ? null : () {
                            snapshot.purchaseBundle();
                          },
                        ),
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
