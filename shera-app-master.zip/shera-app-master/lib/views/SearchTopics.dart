import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-components/Topics.dart';
import 'package:quiz/view-models/SearchTopicsVM.dart';

class SearchTopics extends StatelessWidget {
  final double minTileWidth = 120;

  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return SearchTopicsVM();
        },
        child: Consumer<SearchTopicsVM>(
          builder: (context, snapshot, _) {
            return Scaffold(
              appBar: AppBar(
                elevation: 0,
                leading: Container(
                  child: IconButton(
                    icon: Image.asset(
                      "assets/images/back_arrow.png",
                      height: 20,
                      width: 24,
                    ),
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ),
                title: Row(
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        child: TextField(
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: LocaleKey.SEARCH_TOPICS.toLocaleText(),
                            hintStyle: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 18,
                              color: Colors.grey[400],
                            ),
                          ),
                          autofocus: true,
                          style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                          onChanged: ((text) {
                            snapshot.requestSearch(text.toString());
                          }),
                        ),
                      ),
                    ),
                    Container(
                      height: 16,
                      width: 16,
//                    child: searchData.searching != true ? Container() :  CircularProgressIndicator(
//                      valueColor: new AlwaysStoppedAnimation<Color>(LocalColors.tarokaloy_logo),
//                      strokeWidth: 2,
//                    ),
                      child: snapshot.searching != true ? Container() : CupertinoActivityIndicator(),
                    )
                  ],
                ),
              ),
              body: _buildBody(context, snapshot),
            );
          },
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context, SearchTopicsVM snapshot) {
    if (snapshot.searchResults != null && snapshot.searchResults.isNotEmpty) {
      return _buildTopicGrid(context, snapshot);
    } else {
      return _emptySearch();
    }
  }

  Widget _emptySearch() {
    return Container(
      margin: EdgeInsets.fromLTRB(24, 100, 24, 100),
      height: 100,
      child: Center(
        child: Text(
          LocaleKey.NOTHING_FOUND.toLocaleText(),
          style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.7), fontWeight: FontWeight.w500),
        ),
      ),
    );
  }

  Widget _buildTopicGrid(BuildContext context, SearchTopicsVM snapshot) {
    return Container(
      padding: EdgeInsets.fromLTRB(28, 24, 28, 24),
      child: GridView.count(
        crossAxisCount: getRowCount(context),
        crossAxisSpacing: getRowCount(context) == 0 ? 0 : 16,
        mainAxisSpacing: 12,
        children: _buildTopicList(context, snapshot),
      ),
    );
  }

  List<Widget> _buildTopicList(BuildContext context, SearchTopicsVM snapshot) {
    List<Widget> items = new List();

    if (snapshot.searchResults != null && snapshot.searchResults.isNotEmpty) {
      int rowCount = getRowCount(context);
      double heightWidth = (MediaQuery.of(context).size.width.toCustomWidth() - 56 - (rowCount - 1) * 16) / rowCount;

      items.addAll(List.generate(snapshot.searchResults.length, (index) {
        return Topics.tile(heightWidth, heightWidth, index, snapshot.searchResults,
            implementFavButton: true,
            gapBetween: 0,
            initialGap: 0,
            iconLabelGap: heightWidth * .05,
            iconSize: heightWidth * .5,
            favIconSize: heightWidth * 0.12,
            textStyle: TextStyle(
              fontFamily: "Poppins",
              color: ColorsLocal.text_color,
              fontWeight: FontWeight.w500,
              fontSize: heightWidth * .1,
            ),
            favButtonPosition: heightWidth * .05, onTap: () {
          Navigator.pushNamed(context, TopicDetailsRoute, arguments: {'topic_id': snapshot.searchResults[index]['topic_id'], 'type': "Topic", 'category_name': snapshot.searchResults[index]['category_name']});
        }, onFavTap: () {
          //TODO call toggle favourite method ******
          snapshot.toggleFavourite(index);
        });
      }));
    }

    return items;
  }

  int getRowCount(BuildContext context) {
    double availableWidth = MediaQuery.of(context).size.width.toCustomWidth() - 56;

    int i = availableWidth ~/ minTileWidth;
    return i;
  }
}
