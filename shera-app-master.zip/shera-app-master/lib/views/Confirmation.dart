import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';

class Confirmation extends StatelessWidget {
  var arguments;
  String caption;
  bool tournament;
  bool store;

  Confirmation(this.arguments) {
    caption = arguments["caption"];
    tournament = arguments["tournament"];
    store = arguments["store"];
  }

  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Icon(
                Icons.check_circle,
                color: Colors.green,
                size: 100,
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Text(
              LocaleKey.CONGRATULATION.toLocaleText(),
              style: TextStyle(color: ColorsLocal.hexToColor("262F56"), fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 25),
            ),
            SizedBox(
              height: 0,
            ),
            Container(
                margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
                child: store == true
                    ? Text(
                        "${LocaleKey.YOU_HAVE_SUCCESSFULLY_PURCHASED.toLocaleText()} $caption",
                        style: TextStyle(color: ColorsLocal.hexToColor("262F56"), fontFamily: "Poppins", fontWeight: FontWeight.w300, fontSize: 15),
                      )
                    : tournament == true
                        ? Text(
                            LocaleKey.NOW_YOU_CAN_PARTICIPATE_TOURNAMENT.toLocaleText(),
                            style: TextStyle(color: ColorsLocal.hexToColor("262F56"), fontFamily: "Poppins", fontWeight: FontWeight.w300, fontSize: 15),
                          )
                        : null),
            Container(
              margin: EdgeInsets.only(top: 40),
              child: Material(
                color: ColorsLocal.hexToColor("843BE2"),
                clipBehavior: Clip.antiAlias,
                borderRadius: BorderRadius.circular(10),
                child: InkWell(
                  onTap: () {
                    while (Navigator.canPop(context)) {
                      Navigator.of(context).pop();
                    }
                    Navigator.pushReplacementNamed(context, HomeRoute);
                  },
                  child: Container(
                    width: 200,
                    height: 40,
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Center(
                        child: Text(
                          LocaleKey.GO_HOME.toLocaleText(),
                          style: TextStyle(
                            color: ColorsLocal.hexToColor("ffffff"),
                            fontFamily: "Poppins",
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
