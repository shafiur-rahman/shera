import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Pop_Ups/AddFriendPU.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/SearchFriendsVM.dart';

class SearchFriends extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return SearchFriendsVM(context);
        },
        child: Consumer<SearchFriendsVM>(
          builder: (context, snapshot, _) {
            return Scaffold(
              appBar: AppBar(
                elevation: 0,
                leading: Container(
                  child: IconButton(
                    icon: Image.asset(
                      "assets/images/back_arrow.png",
                      height: 20,
                      width: 24,
                    ),
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ),
                title: Row(
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        child: TextField(
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: LocaleKey.SEARCH_WITH_NAME_OR_EMAIL.toLocaleText(),
                            hintStyle: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 16,
                              color: Colors.grey[400],
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                          autofocus: true,
                          style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                          onChanged: ((text) {
                            snapshot.requestSearch(text.toString());
                          }),
                        ),
                      ),
                    ),
                    Container(
                      height: 16,
                      width: 16,
//                    child: searchData.searching != true ? Container() :  CircularProgressIndicator(
//                      valueColor: new AlwaysStoppedAnimation<Color>(LocalColors.tarokaloy_logo),
//                      strokeWidth: 2,
//                    ),
                      child: snapshot.searching != true ? Container() : CupertinoActivityIndicator(),
                    )
                  ],
                ),
              ),
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  snapshot.isFromContacts && snapshot.searchResults != null && snapshot.searchResults.length != 0
                      ? Container(
                          margin: EdgeInsets.fromLTRB(24, 24, 24, 12),
                          child: Text(
                            LocaleKey.PEOPLE_FROM_CONTACT.toLocaleText(),
                            style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color.withOpacity(0.9), fontWeight: FontWeight.w600),
                          ),
                        )
                      : Container(),
                  Expanded(child: _buildBody(context, snapshot)),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context, SearchFriendsVM snapshot) {
    if (snapshot.searchResults != null && snapshot.searchResults.isNotEmpty) {
      return _buildList(context, snapshot);
    } else {
      return _emptySearch();
    }
  }

  Widget _emptySearch() {
    return Container(
      margin: EdgeInsets.fromLTRB(24, 100, 24, 100),
      height: 100,
      child: Center(
        child: Text(
          LocaleKey.NOTHING_FOUND.toLocaleText(),
          style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color.withOpacity(0.7), fontWeight: FontWeight.w500),
        ),
      ),
    );
  }

  Widget _buildList(BuildContext context, SearchFriendsVM snapshot) {
    return Container(
      //padding: EdgeInsets.fromLTRB(28, 24, 28, 24),
      child: ListView.builder(
        //shrinkWrap: true,
        itemBuilder: (BuildContext context, int index) {
          bool last = snapshot.searchResults.length == (index + 1);
          return Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Container(
              margin: last ? EdgeInsets.fromLTRB(0, 0, 0, 16) : EdgeInsets.fromLTRB(0, 0, 0, 0),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(7), border: Border.all(color: ColorsLocal.hexToColor("EEEEEE"), width: 1)),
              child: Material(
                color: Colors.white,
                borderRadius: BorderRadius.circular(7),
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: () {
                    AddFriendPU.show(context, snapshot.searchResults[index]);
                  },
                  child: Container(
                    padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                    child: Row(
                      children: [
                        Container(
                            //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(shape: BoxShape.circle),
                            constraints: BoxConstraints.tightFor(height: 48, width: 48),
                            child: CachedNetworkImage(
                              imageUrl: snapshot.searchResults[index]["image_url"], //imageUrl: snapshot.userDetails['image_url'].toString(),
                              imageBuilder: (context, imageProvider) => Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  //borderRadius: BorderRadius.circular(4),
                                  image: DecorationImage(
                                    image: imageProvider,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              placeholder: (context, url) => MyShimmer.fromColors(
                                child: Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    //borderRadius: BorderRadius.circular(8),
                                    color: Colors.grey[300],
                                  ),
                                ),
                                baseColor: Colors.grey[300],
                                highlightColor: Colors.white,
                              ),
                              errorWidget: (context, url, error) => Icon(Icons.error),
                            )),
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.only(left: 24),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                  child: Text(
                                    snapshot.searchResults[index]['name'],
                                    style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 14),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                  child: Text(
                                    '${LocaleKey.LEVEL.toLocaleText()} ${snapshot.searchResults[index]['level'].toString().toLocaleNumber()}',
                                    style: TextStyle(color: ColorsLocal.text_color.withOpacity(1.0), fontFamily: "Poppins", fontWeight: FontWeight.w400, fontSize: 12),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
        itemCount: snapshot.searchResults.length,
      ),
    );
  }
}
