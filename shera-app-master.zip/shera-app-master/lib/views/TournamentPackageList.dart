/*
* Created by Ahammed Hossain Shanto
* on 3/8/21
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/TournamentBundleListVM.dart';
import 'package:quiz/extensions/string_extensions.dart';

class TournamentPackageList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      needLogin: true,
      child: ChangeNotifierProvider(
        create: (_) {
          return TournamentBundleListVM(context);
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.TOURNAMENT_BUNDLES.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Consumer<TournamentBundleListVM>(
            builder: (context, snapshot, _) {
              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SizedBox(height: 10,),
                    _buildPackageList(context, snapshot),
                    SizedBox(height: 10,),
                  ],
                ),
              );
            }
          ),
        ),
      ),
    );
  }


  Widget _buildPackageList(BuildContext context, TournamentBundleListVM snapshot) {
    if(!snapshot.tournamentPacksLoaded) {
      return Container(
        margin: EdgeInsets.only(left: 16, right: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: List.generate(3, (index) {
            return MyShimmer.fromColors(
                child: Container(
                  margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.grey[300],
                  ),
                ),
                baseColor: Colors.grey[300],
                highlightColor: Colors.white
            );
          }),
        ),
      );
    }
    else {
      return Container(
        margin: EdgeInsets.only(left: 16, right: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.start,
          children: List.generate(snapshot.tournamentPackages.length, (index) {
            return Container(
              margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
              padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.grey[200],
                        spreadRadius: 0.1,
                        blurRadius: 8
                    )
                  ]
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    child: Text(
                      snapshot.tournamentPackages[index].title,
                      style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 24,
                        color: ColorsLocal.text_color,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Container(
                    child: Text(
                      snapshot.tournamentPackages[index].caption,
                      style: TextStyle(
                          fontFamily: "Poppins",
                          fontSize: 15,
                          color: ColorsLocal.text_color.withOpacity(0.7),
                          fontWeight: FontWeight.w400
                      ),
                    ),
                  ),
                  Container(
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                            child: Text(
                              '${snapshot.tournamentPackages[index].price} ${LocaleKey.BDT.toLocaleText()}',
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 20,
                                  color: ColorsLocal.text_color_pink,
                                  fontWeight: FontWeight.w700
                              ),
                            ),
                          ),
                        ),
                        Container(
                          child: RaisedButton(
                            elevation: 0,
                            highlightElevation: 0,
                            child: Text(
                              //model['is_free'] ? LocaleKey.PLAY_FREE.toLocaleText() : '${LocaleKey.PLAY_USING.toLocaleText()} ${model['fee_coin'].toString().toLocaleNumber()} ${LocaleKey.USING_COINS.toLocaleText()}',
                              snapshot.canceling &&  snapshot.cancelId == snapshot.tournamentPackages[index].id ? "Processing..." : (snapshot.tournamentPackages[index].isAlreadyBought() ? LocaleKey.UNSUBSCRIBE_NOW.toLocaleText() : LocaleKey.SUBSCRIBE_NOW.toLocaleText()),
                              style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600),
                            ),
                            color: ColorsLocal.button_color_purple,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                            onPressed: () {
                              if(snapshot.tournamentPackages[index].isAlreadyBought()) {
                                snapshot.cancelSubscription(snapshot.tournamentPackages[index].id).then((value) {
                                  if(value) {
                                    snapshot.loadTournamentPacks();
                                  }
                                  else {
                                    LocalAlert.showDialog(context, LocaleKey.SORRY.toLocaleText(), "Package un-subscription failed");
                                  }
                                });
                              }
                              else {
                                Navigator.pushNamed(context, PaymentMethodRoute, arguments: {
                                  'bundle_id': int.parse(snapshot.tournamentPackages[index].id)
                                }).then((value) {
                                  snapshot.loadTournamentPacks();
                                });
                              }
                            },
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            );
          }),
        ),
      );
    }
  }
}
