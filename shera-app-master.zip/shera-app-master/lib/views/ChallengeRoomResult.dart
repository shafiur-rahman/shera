/*
* Created by Ahammed Hossain Shanto
* on 1/4/21
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_statusbarcolor/flutter_statusbarcolor.dart';
import 'package:provider/provider.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/ImageLoader.dart';
import 'package:quiz/view-models/ChallengeRoomResultVM.dart';

class ChallengeRoomResult extends StatefulWidget {
  @override
  _ChallengeRoomResultState createState() => _ChallengeRoomResultState();
}

class _ChallengeRoomResultState extends State<ChallengeRoomResult> {

  @override
  void dispose() {
    // TODO: implement dispose
    FlutterStatusbarcolor.setStatusBarColor(Colors.white);
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {

    var arguments = json.decode(ModalRoute.of(context).settings.arguments);
    Color bgColor = Colors.blue[500];
    if(arguments != null && arguments['room_info'] != null) {
      bgColor = ColorsLocal.hexToColor(arguments['room_info']['primary_color'].toString());
    }

    FlutterStatusbarcolor.setStatusBarColor(bgColor);

    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(
           value: ChallengeRoomResultVM(context, arguments),
        )
      ],
      child: Scaffold(
        backgroundColor: bgColor,
        body: SingleChildScrollView(
          child: Consumer<ChallengeRoomResultVM>(
              builder: (context, snapshot, _) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        margin: EdgeInsets.only(top: 80),
                        child: ImageLoader.loadRect(
                          height: 60,
                          width: 60,
                          imageUrl: snapshot.roomInfo['image'].toString(),
                          showLoadingShimmer: false,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(24, 16, 24, 0),
                      child: Text(
                        snapshot.roomInfo['name'].toString(),
                        style: TextStyle(
                            fontFamily: "Poppins",
                            fontSize: 18,
                            color: Colors.white,
                            fontWeight: FontWeight.w700
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    //!snapshot.resultInfo['players'][0]['is_winner'] && !snapshot.resultInfo['players'][1]['is_winner'] ?
                    snapshot.resultInfo['game_status'] == 'draw' ?
                    Container(
                      margin: EdgeInsets.fromLTRB(24, 16, 24, 0),
                      child: Text(
                        "Match Drawn",
                        style: TextStyle(
                            fontFamily: "Poppins",
                            fontSize: 22,
                            color: Colors.white,
                            fontWeight: FontWeight.w700
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ) : Container(),
                    Container(
                      margin: EdgeInsets.fromLTRB(24, 16, 24, 0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              snapshot.isUserWinner() ?
                              Container(
                                margin: EdgeInsets.only(bottom: 16),
                                child: Text(
                                  "WINNER",
                                  style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 24,
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700
                                  ),
                                ),
                              ) : Container(
                                margin: EdgeInsets.only(bottom: 16),
                                height: 38,
                              ),
                              Container(
                                width: 120,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      child: ImageLoader.loadCircular(
                                        imageUrl: snapshot.userInfo['avatar'].toString(),
                                        height: 80,
                                        width: 80,
                                      ),
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          width: 3,
                                          color: ColorsLocal.hexToColor(snapshot.roomInfo['primary_color_dark'].toString()),
                                        ),
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 8),
                                      child: Text(
                                        snapshot.userInfo['user_name'].toString(),
                                        style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 14,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              Container(
                                margin: EdgeInsets.only(top: 60),
                                child: Text(
                                  "VS",
                                  style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 18,
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        width: 2,
                                        color: ColorsLocal.hexToColor(snapshot.roomInfo['primary_color_dark']),
                                      )
                                    // boxShadow: [
                                    //   BoxShadow(
                                    //     color: Colors.white,
                                    //     spreadRadius: 1,
                                    //     blurRadius: 8
                                    //   )
                                    // ]
                                  ),
                                  margin: EdgeInsets.only(top: 4),
                                  child: Wrap(
                                    alignment: WrapAlignment.center,
                                    crossAxisAlignment: WrapCrossAlignment.center,
                                    children: [
                                      Container(
                                        child: Image.asset(
                                          "assets/images/ic_coin.png",
                                          height: 16,
                                        ),
                                        margin: EdgeInsets.only(right: 4),
                                      ),
                                      Container(
                                        child: Text(
                                          snapshot.roomInfo['prize'].toString(),
                                          style: TextStyle(
                                              fontFamily: "Poppins",
                                              fontSize: 16,
                                              color: bgColor,
                                              fontWeight: FontWeight.w600
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              snapshot.isOpponentWinner() ?
                              Container(
                                margin: EdgeInsets.only(bottom: 16),
                                child: Text(
                                  "WINNER",
                                  style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontSize: 24,
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700
                                  ),
                                ),
                              ) : Container(
                                margin: EdgeInsets.only(bottom: 16),
                                height: 38,
                              ),
                              Container(
                                width: 120,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      child: ImageLoader.loadCircular(
                                          imageUrl: snapshot.opponentInfo['avatar'].toString(),
                                          height: 80,
                                          width: 80
                                      ),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                            width: 3,
                                            color: ColorsLocal.hexToColor(snapshot.roomInfo['primary_color_dark'].toString()),
                                          ),
                                          shape: BoxShape.circle
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 8),
                                      child: Text(
                                        snapshot.opponentInfo['user_name'].toString(),
                                        style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 14,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 50),
                      child: Align(
                        alignment: Alignment.center,
                        child: RaisedButton(
                          color: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.fromLTRB(32, 12, 32, 12),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text(
                            "Done",
                            style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 18,
                                color: ColorsLocal.text_color,
                                fontWeight: FontWeight.w600
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                );
              }
          ),
        ),
      ),
    );
  }
}
