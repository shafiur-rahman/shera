/*
* Created by Ahammed Hossain Shanto on 8/6/20
*/

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/ChallengeInfo.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/Pop_Ups/ChallengeResultPU.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/ChallengesVM.dart';

class Challenges extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return ChallengesVM(context);
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.CHALLENGES.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Consumer<ChallengesVM>(
            builder: (context, snapshot, _) {
              if (snapshot.listLoaded && snapshot.challenges.isEmpty) {
                return Container(
                  child: Center(
                    child: Text(
                      LocaleKey.NO_CHALLENGE.toLocaleText(),
                      style: TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 15,
                        color: ColorsLocal.text_color.withOpacity(0.6),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                );
              } else {
                return RefreshIndicator(
                  onRefresh: () async {
                    await snapshot.loadChallenges();
                  },
                  child: Container(
                    margin: EdgeInsets.fromLTRB(0, 16, 0, 16),
                    child: ListView.builder(
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                          child: _buildChallenge(context, snapshot, index),
                        );
                      },
                      itemCount: _getItemCount(context, snapshot),
                    ),
                  ),
                );
              }
            },
          ),
          bottomNavigationBar: BottomAppBar(
            child: Container(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                color: ColorsLocal.button_color_purple,
                elevation: 0,
                highlightElevation: 0,
                child: Container(
                  padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
                  child: Text(
                    LocaleKey.CHALLENGE_NOW.toLocaleText(),
                    style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w500),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                onPressed: () {
                  Navigator.pushNamed(context, SelectFriendRoute);
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  int _getItemCount(BuildContext context, ChallengesVM snapshot) {
    int count = 5;
    if (snapshot.challenges != null && snapshot.challenges.isNotEmpty) {
      count = snapshot.challenges.length;
    }

    return count;
  }

  Widget _buildChallenge(BuildContext context, ChallengesVM snapshot, int index) {
    if (snapshot.listLoaded) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 5, 16, 5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7),
            border: Border.all(
              width: 1,
              color: ColorsLocal.hexToColor("F3F3F3"),
            ),
            color: Colors.white,
            boxShadow: [BoxShadow(color: ColorsLocal.hexToColor("C1C1C1").withOpacity(0.2), blurRadius: 20, spreadRadius: 1)]),
        child: Container(
          padding: EdgeInsets.fromLTRB(12, 16, 12, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: [
                  Container(
                      //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          border: Border.all(
                            width: 4,
                            color: Colors.white,
                          ),
                          shape: BoxShape.circle),
                      constraints: BoxConstraints.tightFor(height: 50, width: 50),
                      child: CachedNetworkImage(
                        imageUrl: snapshot.challenges[index]['opponent_avatar'].toString(),
                        imageBuilder: (context, imageProvider) => Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            //borderRadius: BorderRadius.circular(4),
                            image: DecorationImage(
                              image: imageProvider,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        placeholder: (context, url) => MyShimmer.fromColors(
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              //borderRadius: BorderRadius.circular(8),
                              color: Colors.grey[300],
                            ),
                          ),
                          baseColor: Colors.grey[300],
                          highlightColor: Colors.white,
                        ),
                        errorWidget: (context, url, error) => Icon(Icons.error),
                      )),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.only(left: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            child: Text(
                              snapshot.challenges[index]['opponent_name'].toString(),
                              style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 18,
                                color: ColorsLocal.text_color,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 5),
                            child: Text(
                              snapshot.getCaption(index),
                              style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 12,
                                color: ColorsLocal.text_color,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  snapshot.challenges[index]['challenger'] == "self" && snapshot.challenges[index]['status'] == "pending"
                      ? Container(
                          width: 70,
                          decoration: BoxDecoration(
                            color: Colors.grey[400],
                            borderRadius: BorderRadius.circular(100),
                          ),
                          padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                          child: Center(
                            child: Text(
                              LocaleKey.PENDING.toLocaleText(),
                              style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                            ),
                          ),
                        )
                      : snapshot.challenges[index]['challenger'] == "self" && snapshot.challenges[index]['status'] == "accepted"
                          ? InkWell(
                              child: Container(
                                width: 70,
                                decoration: BoxDecoration(
                                  color: ColorsLocal.hexToColor("00B960"),
                                  borderRadius: BorderRadius.circular(100),
                                ),
                                padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                child: Center(
                                  child: snapshot.challenges[index]['process_status'] != null && snapshot.challenges[index]['process_status'] == "starting"
                                      ? Container(
                                          height: 16,
                                          width: 16,
                                          child: CircularProgressIndicator(
                                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : Text(
                                          LocaleKey.PLAY.toLocaleText(),
                                          style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                                        ),
                                ),
                              ),
                              onTap: () {
                                snapshot.startChallenge(index).then((value) {
                                  if (value != null) {
                                    Navigator.pushNamed(context, ChallengePlayRoute, arguments: value).then((value) {
                                      if (value) {
                                        snapshot.loadChallenges();
                                      }
                                    });
                                  } else {
                                    LocalAlert.showDialog(context, "Sorry", "Error Occurred. Please try again later");
                                  }
                                });
                              },
                            )
                          : snapshot.challenges[index]['challenger'] == "opponent" && snapshot.challenges[index]['status'] == "pending"
                              ? Column(
                                  children: [
                                    InkWell(
                                      child: Container(
                                        width: 70,
                                        decoration: BoxDecoration(
                                          color: ColorsLocal.hexToColor("00B960"),
                                          borderRadius: BorderRadius.circular(100),
                                        ),
                                        padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                        child: Center(
                                          child: snapshot.challenges[index]['process_status'] != null && snapshot.challenges[index]['process_status'] == "accepting"
                                              ? Container(
                                                  height: 16,
                                                  width: 16,
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                                    strokeWidth: 2,
                                                  ),
                                                )
                                              : Text(
                                                  LocaleKey.ACCEPT.toLocaleText(),
                                                  style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                                                ),
                                        ),
                                      ),
                                      onTap: () {
                                        snapshot.acceptChallenge(index);
                                      },
                                    ),
                                    InkWell(
                                      child: Container(
                                        width: 70,
                                        margin: EdgeInsets.only(top: 8),
                                        decoration: BoxDecoration(
                                          color: ColorsLocal.hexToColor("FBAA19"),
                                          borderRadius: BorderRadius.circular(100),
                                        ),
                                        padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                        child: Center(
                                          child: snapshot.challenges[index]['process_status'] != null && snapshot.challenges[index]['process_status'] == "denying"
                                              ? Container(
                                                  height: 16,
                                                  width: 16,
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                                    strokeWidth: 2,
                                                  ),
                                                )
                                              : Text(
                                                  LocaleKey.CANCEL.toLocaleText(),
                                                  style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                                                ),
                                        ),
                                      ),
                                      onTap: () {
                                        snapshot.denyChallenge(index);
                                      },
                                    ),
                                  ],
                                )
                              : snapshot.challenges[index]['challenger'] == "opponent" && snapshot.challenges[index]['status'] == "accepted"
                                  ? InkWell(
                                      child: Container(
                                        width: 70,
                                        decoration: BoxDecoration(
                                          color: ColorsLocal.hexToColor("00B960"),
                                          borderRadius: BorderRadius.circular(100),
                                        ),
                                        padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                        child: Center(
                                          child: snapshot.challenges[index]['process_status'] != null && snapshot.challenges[index]['process_status'] == "starting"
                                              ? Container(
                                                  height: 16,
                                                  width: 16,
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                                    strokeWidth: 2,
                                                  ),
                                                )
                                              : Text(
                                                  LocaleKey.PLAY.toLocaleText(),
                                                  style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                                                ),
                                        ),
                                      ),
                                      onTap: () {
                                        snapshot.startChallenge(index).then((value) {
                                          if (value != null) {
                                            Navigator.pushNamed(context, ChallengePlayRoute, arguments: value).then((value) {
                                              if (value) {
                                                snapshot.loadChallenges();
                                              }
                                            });
                                          } else {
                                            LocalAlert.showDialog(context, "Sorry", "Error Occurred. Please try again later");
                                          }
                                        });
                                      },
                                    )
                                  : snapshot.challenges[index]['status'] == "played" && snapshot.challenges[index]['opponent_played']
                                      ? InkWell(
                                          child: Container(
                                            width: 70,
                                            decoration: BoxDecoration(
                                              color: ColorsLocal.hexToColor("00B960"),
                                              borderRadius: BorderRadius.circular(100),
                                            ),
                                            padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                            child: Center(
                                              child: snapshot.challenges[index]['process_status'] != null && snapshot.challenges[index]['process_status'] == "starting"
                                                  ? Container(
                                                      height: 16,
                                                      width: 16,
                                                      child: CircularProgressIndicator(
                                                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                                        strokeWidth: 2,
                                                      ),
                                                    )
                                                  : Text(
                                                      LocaleKey.PLAY.toLocaleText(),
                                                      style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                                                    ),
                                            ),
                                          ),
                                          onTap: () {
                                            snapshot.startChallenge(index).then((value) {
                                              if (value != null) {
                                                Navigator.pushNamed(context, ChallengePlayRoute, arguments: value).then((value) {
                                                  if (value) {
                                                    snapshot.loadChallenges();
                                                  }
                                                });
                                              } else {
                                                LocalAlert.showDialog(context, "Sorry", "Error Occurred. Please try again later");
                                              }
                                            });
                                          },
                                        )
                                      : snapshot.challenges[index]['status'] == "played"
                                          ? Container(
                                              width: 70,
                                              decoration: BoxDecoration(
                                                color: Colors.grey[400],
                                                borderRadius: BorderRadius.circular(100),
                                              ),
                                              padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                              child: Center(
                                                child: Text(
                                                  LocaleKey.PLAYED.toLocaleText(),
                                                  style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                                                ),
                                              ),
                                            )
                                          : snapshot.challenges[index]['status'] == "completed"
                                              ? InkWell(
                                                  child: Container(
                                                    width: 70,
                                                    decoration: BoxDecoration(
                                                      color: ColorsLocal.button_color_purple,
                                                      borderRadius: BorderRadius.circular(100),
                                                    ),
                                                    padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                                    child: Center(
                                                      child: Text(
                                                        LocaleKey.RESULT.toLocaleText(),
                                                        style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                                                      ),
                                                    ),
                                                  ),
                                                  onTap: () {
                                                    ChallengeResultPU.show(context, snapshot.challenges[index]['result'], onTapCancel: () {
                                                      Navigator.of(context).pop(false);
                                                    }, onTapRematch: () {
                                                      ChallengeInfo.friendUserId = int.parse(snapshot.challenges[index]['result']['opponent']['user_id'].toString());
                                                      Navigator.pushNamed(context, ChallengeFriendRoute);
                                                    });
                                                  },
                                                )
                                              : Container(),
                ],
              ),
              Container(
                margin: EdgeInsets.only(top: 8),
                height: 0.3,
                color: Colors.grey[400],
              ),
              Container(
                margin: EdgeInsets.only(top: 16),
                child: Wrap(
                  spacing: 4,
                  runSpacing: 4,
                  alignment: WrapAlignment.start,
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(32),
                        color: Colors.grey[200],
                      ),
                      padding: EdgeInsets.fromLTRB(4, 2, 8, 2),
                      child: Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: <Widget>[
                          Container(
                            child: Icon(
                              Icons.assignment,
                              size: 12,
                              color: ColorsLocal.text_color_purple,
                            ),
                            margin: EdgeInsets.only(right: 4),
                          ),
                          Text(
                            snapshot.challenges[index]['question_count'].toString().toLocaleNumber(),
                            style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 10,
                              color: ColorsLocal.text_color,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(32),
                        color: Colors.grey[200],
                      ),
                      padding: EdgeInsets.fromLTRB(4, 2, 8, 2),
                      child: Wrap(
                        children: <Widget>[
                          Container(
                            child: Image.asset("assets/images/ic_coin.png"),
                            height: 14,
                            width: 14,
                            margin: EdgeInsets.only(right: 4),
                          ),
                          Text(
                            snapshot.challenges[index]['bet_coins'].toString().toLocaleNumber(),
                            style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 10,
                              color: ColorsLocal.text_color,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(32),
                        color: Colors.grey[200],
                      ),
                      padding: EdgeInsets.fromLTRB(8, 2, 8, 2),
                      child: Text(
                        snapshot.challenges[index]['topic_name'].toString(),
                        style: TextStyle(
                          fontFamily: "Poppins",
                          fontSize: 10,
                          color: ColorsLocal.text_color,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(32),
                        color: Colors.grey[200],
                      ),
                      padding: EdgeInsets.fromLTRB(4, 2, 8, 2),
                      child: Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: <Widget>[
                          Container(
                            child: Icon(
                              Icons.access_time,
                              size: 12,
                              color: ColorsLocal.text_color_purple,
                            ),
                            margin: EdgeInsets.only(right: 4),
                          ),
                          Text(
                            Jiffy(DateTime.parse(snapshot.challenges[index]['date'].toString())).fromNow(),
                            style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 10,
                              color: ColorsLocal.text_color,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 5, 16, 5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7),
            border: Border.all(
              width: 1,
              color: ColorsLocal.hexToColor("F3F3F3"),
            ),
            color: Colors.white,
            boxShadow: [BoxShadow(color: ColorsLocal.hexToColor("C1C1C1").withOpacity(0.2), blurRadius: 20, spreadRadius: 1)]),
        child: MyShimmer.fromColors(
            child: Container(
              padding: EdgeInsets.fromLTRB(12, 16, 12, 16),
              child: Row(
                children: [
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(color: Colors.grey[300], shape: BoxShape.circle),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.only(left: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            height: 20,
                            margin: EdgeInsets.only(right: 100),
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          Container(
                            height: 18,
                            margin: EdgeInsets.only(top: 8),
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    }
  }
}
