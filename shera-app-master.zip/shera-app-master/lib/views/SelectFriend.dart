/*
* Created by Ahammed Hossain Shanto on 8/6/20
*/

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/ChallengeInfo.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/SelectFriendVM.dart';

class SelectFriend extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return SelectFriendVM();
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Text(
              LocaleKey.SELECT_FRIEND.toLocaleText(),
              style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Consumer<SelectFriendVM>(builder: (context, snapshot, _) {
            if (snapshot.friendsLoaded && snapshot.friends.isEmpty) {
              return Container(
                child: Center(
                  child: Text(
                    LocaleKey.NOTHING_FOUND.toLocaleText(),
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.grey[500],
                      fontFamily: "Poppins",
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              );
            } else {
              return Container(
                margin: EdgeInsets.fromLTRB(16, 16, 16, 16),
                child: ListView.builder(
                  itemBuilder: (BuildContext context, int index) {
                    return _buildFriend(context, snapshot, index);
                  },
                  itemCount: _getFriendsCount(context, snapshot),
                ),
              );
            }
          }),
          bottomNavigationBar: Consumer<SelectFriendVM>(builder: (context, snapshot, _) {
            return ChallengeInfo.friendUserId == -1
                ? Container(height: 0, width: 0)
                : BottomAppBar(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        color: ColorsLocal.button_color_purple,
                        elevation: 0,
                        highlightElevation: 0,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(8, 12, 8, 12),
                          child: Text(
                            "Next",
                            style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: Colors.white, fontWeight: FontWeight.w500),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        onPressed: () {
                          Navigator.pushNamed(context, ChallengeFriendRoute);
                        },
                      ),
                    ),
                  );
          }),
        ),
      ),
    );
  }

  int _getFriendsCount(BuildContext context, SelectFriendVM snapshot) {
    if (snapshot.friendsLoaded) {
      return snapshot.friends.length;
    } else {
      return 10;
    }
  }

  Widget _buildFriend(BuildContext context, SelectFriendVM snapshot, int index) {
    if (!snapshot.friendsLoaded) {
      return MyShimmer.fromColors(
        child: Container(
          margin: EdgeInsets.fromLTRB(0, 4, 0, 4),
          height: 56,
          width: MediaQuery.of(context).size.width.toCustomWidth() - 32,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7),
            color: Colors.grey[300],
          ),
        ),
        baseColor: Colors.grey[300],
        highlightColor: Colors.white,
      );
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(0, 4, 0, 4),
        width: MediaQuery.of(context).size.width.toCustomWidth() - 32,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7),
            color: snapshot.isSelected(index) ? ColorsLocal.button_color_purple : Colors.white,
            border: Border.all(
              width: 1,
              color: ColorsLocal.hexToColor("F3F3F3"),
            )),
        child: InkWell(
          child: Container(
            padding: EdgeInsets.fromLTRB(12, 12, 12, 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 16, 0),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        border: Border.all(
                          width: 2,
                          color: Colors.white,
                        ),
                        shape: BoxShape.circle),
                    constraints: BoxConstraints.tightFor(height: 40, width: 40),
                    child: CachedNetworkImage(
                      imageUrl: snapshot.friends[index]['image_url'].toString(),
                      imageBuilder: (context, imageProvider) => Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          //borderRadius: BorderRadius.circular(4),
                          image: DecorationImage(
                            image: imageProvider,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      placeholder: (context, url) => MyShimmer.fromColors(
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            //borderRadius: BorderRadius.circular(8),
                            color: Colors.grey[300],
                          ),
                        ),
                        baseColor: Colors.grey[300],
                        highlightColor: Colors.white,
                      ),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                    )),
                Expanded(
                  child: Text(
                    snapshot.friends[index]['name'].toString(),
                    style: TextStyle(
                      fontSize: 16,
                      color: snapshot.isSelected(index) ? Colors.white : ColorsLocal.text_color,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Poppins",
                    ),
                  ),
                )
              ],
            ),
          ),
          onTap: () {
            snapshot.selectFriend(index);
          },
        ),
      );
    }
  }
}
