/*
* Created by Ahammed Hossain Shanto
* on 12/2/20
*/

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Pop_Ups/BCSModelConfirmation.dart';
import 'package:quiz/view-components/Pop_Ups/QuitBcsModelPlayAlert.dart';
import 'package:quiz/view-components/Pop_Ups/ReportPU.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/BCSModelPlayVM.dart';
import 'package:quiz/view-models/MyTimerVM.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

class BCSModelPlay extends StatefulWidget {
  @override
  _BCSModelPlayState createState() => _BCSModelPlayState();
}

class _BCSModelPlayState extends State<BCSModelPlay> {
  var arguments;
  BCSModelPlayVM bcsModelPlayVM;
  MyTimerVM myTimerVM;

  @override
  void dispose() {
    // TODO: implement dispose
    myTimerVM.timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    arguments = ModalRoute.of(context).settings.arguments;

    bcsModelPlayVM = new BCSModelPlayVM(context, arguments);
    myTimerVM = new MyTimerVM(context, autoStart: true, totalTimeInSeconds: arguments['model']['duration'], onFinish: () {
      //Logger.printWrapped("time up");
      bcsModelPlayVM.submitAnswers();
    });

    return RootBody(
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) {
            return bcsModelPlayVM;
          }),
          ChangeNotifierProvider(create: (_) {
            return myTimerVM;
          }),
        ],
        child: Consumer<BCSModelPlayVM>(builder: (context, snapshot, _) {
          return WillPopScope(
            onWillPop: () async {
              if (snapshot.isSubmitted) {
                Navigator.pop(context);
              } else {
                QuitBcsModelPlayAlert.show(context);
              }
              return false;
            },
            child: Scaffold(
              appBar: PreferredSize(
                preferredSize: Size.fromHeight(70),
                child: AppBar(
                  elevation: 0,
                  title: Row(children: [
                    Expanded(
                      child: Text(
                        arguments['model']['title'].toString(),
                        style: TextStyle(color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 22),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Consumer<MyTimerVM>(builder: (context, snapshot, _) {
                      return Container(
                        child: CircularPercentIndicator(
                          radius: 56,
                          lineWidth: 4.0,
                          animation: false,
                          percent: snapshot.timeLeftPercentage(),
                          backgroundColor: Colors.grey[200],
                          reverse: true,
                          center: new Text(
                            snapshot.getRemainingTime().formattedString.toLocaleNumber(),
                            style: new TextStyle(
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.w700,
                              fontSize: 13,
                              color: ColorsLocal.hexToColor("00B960"),
                            ),
                          ),
                          circularStrokeCap: CircularStrokeCap.round,
                          progressColor: ColorsLocal.getProgressColor(snapshot.timeLeftPercentage() * 100),
                        ),
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        decoration: BoxDecoration(shape: BoxShape.circle),
                      );
                    })
                  ]),
                  iconTheme: new IconThemeData(color: Colors.black),
                  backgroundColor: Colors.white,
                ),
              ),
              body: Container(
                child: ScrollablePositionedList.builder(
                  itemCount: snapshot.questions.length,
                  itemBuilder: (context, index) {
                    List options = snapshot.questions[index]['option'];
                    return Container(
                        //color: Colors.white,
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Text(
                                  '${index + 1}. ${snapshot.questions[index]['value']}',
                                  style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 8),
                                child: InkWell(
                                  onTap: () {
                                    ReportPU.showDialog(context, snapshot.questions[index]['question_id']);
                                  },
                                  child: Icon(
                                    Icons.error_outline,
                                    color: Colors.grey[400],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 4),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: options.map((option) {
                              return InkWell(
                                onTap: () {
                                  snapshot.updateSelection(index, option['id'].toString());
                                },
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(24, 2, 16, 2),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(right: 16),
                                        child: Icon(
                                          snapshot.answers[index] == option['id'].toString() ? Icons.radio_button_checked : Icons.radio_button_off,
                                          size: 18,
                                          color: snapshot.answers[index] == option['id'].toString() ? ColorsLocal.text_color_purple : ColorsLocal.text_color.withOpacity(0.7),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          option['value'].toString(),
                                          style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 16),
                          height: 0.5,
                          color: Colors.grey[300].withOpacity(0.5),
                        )
                      ],
                    ));
                  },
                  itemScrollController: snapshot.itemScrollController,
                  itemPositionsListener: snapshot.itemPositionsListener,
                ),
              ),
              floatingActionButton: Consumer<BCSModelPlayVM>(builder: (context, snapshot, _) {
                return !snapshot.isSubmitted
                    ? FloatingActionButton(
                        backgroundColor: ColorsLocal.button_color_pink,
                        child: snapshot.isSubmitting
                            ? CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                              )
                            : Icon(
                                Icons.arrow_forward,
                                color: Colors.white,
                              ),
                        onPressed: () {
                          BCSModelConfirmation.showDialog(context, snapshot.questions.length, snapshot.getAnswerCount(), onTap: () {
                            Navigator.pop(context);
                            snapshot.submitAnswers();
                          });
                        },
                      )
                    : Container();
              }),
            ),
          );
        }),
      ),
    );
  }
}
