/*
* Created by Ahammed Hossain Shanto
* on 2/24/21
*/


import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/locale-helper/locale_values.dart';
import 'package:quiz/models/BCSPackage.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/models/RedirectToBrowser.dart';
import 'package:quiz/models/RootSize.dart';
import 'package:quiz/models/TournamentPackage.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/ImageLoader.dart';
import 'package:quiz/view-components/Pop_Ups/SignInToPlay.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-components/Tournaments.dart';
import 'package:quiz/view-models/BkashPacksVM.dart';
import 'package:toast/toast.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/extensions/double_extensions.dart';

class BkashPacks extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      needLogin: false,
      child: ChangeNotifierProvider(
        create: (_) {
          return BkashPacksVM(context);
        },
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.zero,
            child: Container(),
          ),
          body: Consumer<BkashPacksVM>(
            builder: (context, snapshot, _) {
              return Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    _buildHeader(context),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            //_buildTopBanner(context, snapshot),
                            _buildDownloadApp(context),
                            _buildBcsPackages(context, snapshot),
                            _buildLatestTournaments(context, snapshot),
                            _buildTournamentPackages(context, snapshot),
                            SizedBox(
                              height: 16,
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey[200],
            blurRadius: 4,
            spreadRadius: 0.1,
          )
        ]
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            child: Image.asset(
              "assets/images/text_logo.png",
              height: 40,
            )
          ),
          Expanded(child: Container()),
          InkWell(
            onTap: () {
              RedirectToBrowser.instance.launch("/", newTab: false);
            },
            child: Container(
              padding: EdgeInsets.all(8),
              child: Text(
                "Sign In to Play",
                style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color: ColorsLocal.text_color_pink,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }


  Widget _buildTopBanner(BuildContext context, BkashPacksVM snapshot) {
    return Container(
      color: Colors.grey[200],
      child: ImageLoader.loadRect(
          imageUrl: "https://scontent.fdac14-1.fna.fbcdn.net/v/t1.0-9/143745849_436242331146463_337933651379269160_o.jpg?_nc_cat=101&ccb=3&_nc_sid=dd9801&_nc_ohc=FLQJ39h3iwQAX9J4-Qf&_nc_ht=scontent.fdac14-1.fna&oh=18fe85477216c8b07221119741133dda&oe=605B55F4",
        height: max(200, RootSize.getInstance(context).size.height/4),
        fit: BoxFit.cover
      ),
    );
  }

  Widget _buildDownloadApp(BuildContext context) {
    if (PackageSupport.instance.isMobile()) {
      return Container();
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: Colors.white, boxShadow: [BoxShadow(spreadRadius: 0.1, blurRadius: 4, color: Colors.grey[300])]),
        child: Wrap(
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 8,
          runSpacing: 8,
          children: [
            Container(
              child: Text(
                LocaleKey.WHY_DOWNLOAD_APP.toLocaleText(),
                style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                textAlign: TextAlign.start,
              ),
            ),
            //SizedBox(width: 16),
            InkWell(
              child: Image.asset(
                "assets/images/ic_playstore.png",
                height: 40,
                width: 120,
                fit: BoxFit.fill,
              ),
              onTap: () {
                RedirectToBrowser.instance.launch(ANDROID_APP_URL, newTab: false);
              },
            ),
            //SizedBox(width: 8),
            InkWell(
              child: Image.asset(
                "assets/images/ic_appstore.png",
                height: 40,
                width: 120,
                fit: BoxFit.fill,
              ),
              onTap: () {
                RedirectToBrowser.instance.launch(IOS_APP_URL, newTab: false);
              },
            ),
          ],
        ),
      );
    }
  }

  Widget _buildLatestTournaments(BuildContext context, BkashPacksVM snapshot) {
    if (snapshot.latestTournamentsLoaded) {
      List tournaments = [];
      if (snapshot.latestTournaments != null) {
        tournaments = snapshot.latestTournaments['tournaments'];
      }

      if (tournaments != null && tournaments.isNotEmpty) {
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        '${LocaleValues.instance.getText(LocaleKey.LATEST_TOURNAMENTS)}',
                        style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                      ),
                    ),
//                    Container(
//                      child: RichText(
//                        text: TextSpan(
//                          text: "See all",
//                          style: TextStyle(
//                            fontFamily: "Poppins",
//                            fontSize: 10,
//                            color: ColorsLocal.hexToColor("757575"),
//                            fontWeight: FontWeight.w500
//                          ),
//                          recognizer: TapGestureRecognizer()..onTap = () {
//                            //TODO navigate to all tournaments screen ***
//                          }
//                        ),
//                      ),
//                    )
                  ],
                ),
              ),
              Container(
                height: 160,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tile(150, 300, index, tournaments, onTap: () {
                      SignInToPlay.showDialog(context);
                    });
                  },
                  itemCount: tournaments.length,
                ),
              )
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(16, 20, 160, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 160,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tileShimmer(150, 250, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  Widget _buildBcsPackages(BuildContext context, BkashPacksVM snapshot) {
    if (snapshot.bcsPacksLoaded) {

      if (snapshot.bcsPackages != null && snapshot.bcsPackages.isNotEmpty) {
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        BCSPackage.packageTitle.toString(),
                        style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                height: 140,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      onTap: () {
                        var arguments = {
                          'bundle_id': snapshot.bcsPackages[index].id
                        };
                        Navigator.pushNamed(context, BkashPurchasePackRoute, arguments: arguments);
                      },
                      child: Container(
                        height: 140,
                        width: 200,
                        margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 12, 0),
                        padding: EdgeInsets.fromLTRB(16, 12, 16, 0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey[200],
                              spreadRadius: 0.1,
                              blurRadius: 8
                            )
                          ]
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              child: Text(
                                snapshot.bcsPackages[index].title,
                                style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontSize: 22,
                                  color: ColorsLocal.text_color,
                                  fontWeight: FontWeight.w600
                                ),
                              ),
                            ),
                            Container(
                              child: Text(
                                snapshot.bcsPackages[index].caption,
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 16,
                                    color: ColorsLocal.text_color.withOpacity(0.6),
                                    fontWeight: FontWeight.w400,
                                  height: 1.3
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              height: 40,
                            ),
                            Container(
                              child: Text(
                                snapshot.bcsPackages[index].price.toLocaleNumber() + " " + LocaleKey.BDT.toLocaleText(),
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 20,
                                    color: ColorsLocal.text_color_pink_2,
                                    fontWeight: FontWeight.w700
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              margin: EdgeInsets.only(top: 6),
                            )
                          ],
                        ),
                      ),
                    );
                  },
                  itemCount: snapshot.bcsPackages.length,
                ),
              )
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(16, 20, 160, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 140,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tileShimmer(140, 200, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }

  Widget _buildTournamentPackages(BuildContext context, BkashPacksVM snapshot) {
    if (snapshot.tournamentPacksLoaded) {

      if (snapshot.tournamentPackages != null && snapshot.tournamentPackages.isNotEmpty) {
        return Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Text(
                        TournamentPackage.packageTitle.toString(),
                        style: TextStyle(fontFamily: "Poppins", fontSize: 16, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                      ),
                    ),
//                    Container(
//                      child: RichText(
//                        text: TextSpan(
//                          text: "See all",
//                          style: TextStyle(
//                            fontFamily: "Poppins",
//                            fontSize: 10,
//                            color: ColorsLocal.hexToColor("757575"),
//                            fontWeight: FontWeight.w500
//                          ),
//                          recognizer: TapGestureRecognizer()..onTap = () {
//                            //TODO navigate to all tournaments screen ***
//                          }
//                        ),
//                      ),
//                    )
                  ],
                ),
              ),
              Container(
                height: 140,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      child: Container(
                        height: 140,
                        width: 200,
                        margin: EdgeInsets.fromLTRB(index == 0 ? 16 : 0, 0, 12, 0),
                        padding: EdgeInsets.fromLTRB(16, 12, 16, 0),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey[200],
                                  spreadRadius: 0.1,
                                  blurRadius: 8
                              )
                            ]
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              child: Text(
                                snapshot.tournamentPackages[index].title,
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 22,
                                    color: ColorsLocal.text_color,
                                    fontWeight: FontWeight.w600
                                ),
                              ),
                            ),
                            Container(
                              child: Text(
                                snapshot.tournamentPackages[index].caption,
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 16,
                                    color: ColorsLocal.text_color.withOpacity(0.6),
                                    fontWeight: FontWeight.w400,
                                    height: 1.3
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              height: 40,
                            ),
                            Container(
                              child: Text(
                                snapshot.tournamentPackages[index].price.toLocaleNumber() + " " + LocaleKey.BDT.toLocaleText(),
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 20,
                                    color: ColorsLocal.text_color_pink_2,
                                    fontWeight: FontWeight.w700
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              margin: EdgeInsets.only(top: 6),
                            )
                          ],
                        ),
                      ),
                      onTap: () {
                        var arguments = {
                          'bundle_id': snapshot.tournamentPackages[index].id
                        };
                        Navigator.pushNamed(context, BkashPurchasePackRoute, arguments: arguments);
                      },
                    );
                  },
                  itemCount: snapshot.tournamentPackages.length,
                ),
              )
            ],
          ),
        );
      } else {
        return Container();
      }
    } else {
      return Container(
        child: MyShimmer.fromColors(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 20,
                margin: EdgeInsets.fromLTRB(16, 20, 160, 0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              Container(
                height: 140,
                margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Tournaments.tileShimmer(140, 200, index);
                  },
                  itemCount: 3,
                ),
              )
            ],
          ),
          baseColor: Colors.grey[300],
          highlightColor: Colors.white,
        ),
      );
    }
  }
}
