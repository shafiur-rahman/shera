/*
* Created by Ahammed Hossain Shanto on 7/8/20
*/

import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/AdmobHelper.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/helpers/video-ad-loader.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/utils/FacebookLogger.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/Pop_Ups/DownloadApp.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/DailySpinVM.dart';
import 'package:toast/toast.dart';

class DailySpin extends StatefulWidget {
  @override
  _DailySpinState createState() => _DailySpinState();
}

class _DailySpinState extends State<DailySpin> with SingleTickerProviderStateMixin {
  AnimationController _animationController;
  Animation _spinAnimation;

  DailySpinVM dailySpinVM = new DailySpinVM();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _animationController = AnimationController(vsync: this, duration: Duration(milliseconds: 5000));
    _spinAnimation = Tween(begin: 0.0, end: 0.0).animate(CurvedAnimation(curve: Curves.ease, parent: _animationController));
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider.value(
        value: dailySpinVM,
        child: Scaffold(
          body: SingleChildScrollView(
            child: Consumer<DailySpinVM>(builder: (context, snapshot, _) {
              return Container(
                margin: EdgeInsets.fromLTRB(16, 40 + MediaQuery.of(context).padding.top, 16, 40),
                height: 530,
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      right: 0,
                      top: 22.5,
                      bottom: 28,
                      child: Container(
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: ColorsLocal.hexToColor("5C13BA"), boxShadow: [
                          BoxShadow(
                            color: ColorsLocal.button_color_pink.withOpacity(0.4),
                            offset: Offset(0, 0),
                            spreadRadius: 8,
                            blurRadius: 50,
                          )
                        ]),
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 12, 0, 0),
                              width: MediaQuery.of(context).size.width.toCustomWidth() - 32 - 32,
                              height: _getWheelHeightWidth(context) + 36,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    right: 0,
                                    top: 0,
                                    child: snapshot.spinned
                                        ? Image.asset(
                                            "assets/images/wheel_background.png",
                                            width: _getWheelHeightWidth(context),
                                          )
                                        : Container(height: 0, width: 0),
                                  ),
                                  Positioned(
                                    left: 0,
                                    right: 0,
                                    top: 40,
//                                child: Image.asset(
//                                    "assets/images/wheel.png",
//                                  height: _getWheelHeightWidth(context),
//                                  width: _getWheelHeightWidth(context),
//                                )
                                    child: AnimatedBuilder(
                                      animation: _animationController,
                                      child: Image.asset(
                                        "assets/images/wheel.png",
                                        height: _getWheelHeightWidth(context),
                                        width: _getWheelHeightWidth(context),
                                      ),
                                      builder: (context, child) {
                                        return Transform.rotate(
                                          angle: _spinAnimation.value,
                                          origin: Offset(0.0, 0.0),
                                          child: child,
                                        );
                                      },
                                    ),
                                  ),
                                  Positioned(
                                      left: 0,
                                      right: 0,
                                      top: 40,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/images/ic_spike.png",
                                          height: _getWheelHeightWidth(context),
                                          width: _getWheelHeightWidth(context),
                                        ),
                                      )),
                                ],
                              ),
                            ),
                            snapshot.spinned
                                ? Container(
                                    margin: EdgeInsets.fromLTRB(16, 8, 16, 0),
                                    child: Wrap(
                                      crossAxisAlignment: WrapCrossAlignment.center,
                                      children: [
                                        Container(
                                          child: Text(
                                            LocaleKey.YOU_WON.toLocaleText(),
                                            style: TextStyle(fontFamily: "Poppins", fontSize: 26, color: Colors.white, fontWeight: FontWeight.w600),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(4, 0, 4, 0),
                                          child: Image.asset(
                                            snapshot.giftType == 1 ? "assets/images/ic_coin.png" : "assets/images/ic_gem.png",
                                            height: 24,
                                            width: 24,
                                          ),
                                        ),
                                        Container(
                                          child: Text(
                                            snapshot.amount.toString().toLocaleNumber(),
                                            style: TextStyle(fontFamily: "Poppins", fontSize: 26, color: Colors.white, fontWeight: FontWeight.w600),
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                : Container(height: 0, width: 0),
                            !snapshot.spinned && snapshot.spinAvailable
                                ? Container(
                                    margin: EdgeInsets.fromLTRB(16, snapshot.spinned ? 8 : 16, 16, 0),
                                    child: Text(
                                      LocaleKey.YOU_CAN_SPIN_ONLY_ONCE.toLocaleText(),
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: Colors.grey[100], fontWeight: FontWeight.w500),
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                                : !snapshot.spinAvailable && snapshot.infoLoaded
                                    ? Container(
                                        margin: EdgeInsets.fromLTRB(16, snapshot.spinned ? 8 : 32, 16, 0),
                                        child: Text(
                                          "${LocaleKey.YOUR_NEXT_SPIN.toLocaleText()} " + snapshot.nextSpin,
                                          style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: Colors.grey[100], fontWeight: FontWeight.w500),
                                          textAlign: TextAlign.center,
                                        ),
                                      )
                                    : Container(),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                              child: RaisedButton(
                                color: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                padding: EdgeInsets.fromLTRB(36, 12, 36, 12),
                                elevation: 0,
                                highlightElevation: 0,
                                child: Container(
                                  child: Column(
                                    children: [
                                      Container(
                                        child: snapshot.infoLoaded && !snapshot.spinAvailable && !snapshot.spinSubmitting
                                            ? Container(
                                                child: Text(
                                                  LocaleKey.WATCH_VIDEO.toLocaleText(),
                                                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: ColorsLocal.hexToColor("5C13BA"), fontFamily: "Poppins"),
                                                ),
                                              )
                                            : Container(
                                                height: 0,
                                                width: 0,
                                              ),
                                      ),
                                      Container(
                                        child: snapshot.infoLoaded && !snapshot.spinSubmitting && !snapshot.spinning
                                            ? Text(
                                                snapshot.spinAvailable ? LocaleKey.SPIN_NOW.toLocaleText() : LocaleKey.SPIN_NOW.toLocaleText(),
                                                style: TextStyle(color: ColorsLocal.button_color_pink, fontSize: 20, fontFamily: "Poppins", fontWeight: FontWeight.w600),
                                              )
                                            : CupertinoActivityIndicator(),
                                      )
                                    ],
                                  ),
                                ),
                                onPressed: !snapshot.infoLoaded || snapshot.spinning
                                    ? () {}
                                    : () {
                                        //TODO need some checking ******

                                        if (snapshot.spinAvailable) {
                                          snapshot.submitSpin().then((index) {
                                            double totalSection = 8;

                                            double totalRotation = ((20 * pi) + ((pi / (totalSection / 2)) * index)) +
                                                /*makes more realistic*/ (Random().nextInt(5) - 2) * (pi / (7 * (totalSection / 2)));

                                            int durationSec = Random().nextInt(5) + 5;

                                            _spinAnimation = Tween(begin: 0.0, end: totalRotation).animate(CurvedAnimation(curve: Curves.ease, parent: _animationController));
                                            _animationController.duration = Duration(seconds: durationSec);
                                            _animationController.reset();
                                            _animationController.forward();
                                            _animationController.addStatusListener((status) {
                                              if (status == AnimationStatus.completed) {
                                                // custom code here
                                                snapshot.updateResult();
                                              }
                                            });
                                          });
                                        } else {
                                          if (PackageSupport.instance.isMobile()) {
                                            //to disable button while loading ad **
                                            snapshot.spinSubmitting = true;
                                            snapshot.notify();

                                            new VideoAdLoader(
                                                onAdLoaded: (videoAdLoader) {
                                                  snapshot.spinSubmitting = false;
                                                  snapshot.notify();
                                                  videoAdLoader.showAd();
                                                },
                                                onRewarded: (videoAdLoader) {
                                                  snapshot.spinByAd();
                                                  FacebookLogger.adWatchForSpin();
                                                },
                                                onAdClosed: (videoAdLoader) {
                                                  //
                                                },
                                                onAdLoadingFailed: (val) {
                                                  Toast.show("No ads are available now. Try again later", context);
                                                  snapshot.spinSubmitting = false;
                                                  snapshot.notify();

                                                  //facebook app event *****
                                                  FacebookLogger.adLoadFailed();
                                                }
                                            ).init();

                                            /// previous admob implementation *********

                                            // MobileAdTargetingInfo targetingInfo = MobileAdTargetingInfo(
                                            //   keywords: <String>['quizgiri'],
                                            //   contentUrl: 'https://quizgiri.xyz',
                                            //   childDirected: false,
                                            //   testDevices: <String>[], // Android emulators are considered test devices
                                            // );
                                            //
                                            // RewardedVideoAd.instance.load(adUnitId: AdmobHelper.getResumeGameUnitId(), targetingInfo: targetingInfo).then((value) {
                                            //   if (value) {
                                            //     RewardedVideoAd.instance.listener = (RewardedVideoAdEvent event, {String rewardType, int rewardAmount}) {
                                            //       if (event == RewardedVideoAdEvent.loaded) {
                                            //         snapshot.spinSubmitting = false;
                                            //         snapshot.notify();
                                            //         RewardedVideoAd.instance.show();
                                            //       }
                                            //       if (event == RewardedVideoAdEvent.rewarded) {
                                            //         snapshot.spinByAd();
                                            //         FacebookLogger.adWatchForSpin();
                                            //       }
                                            //       if (event == RewardedVideoAdEvent.closed) {
                                            //         //do nothing
                                            //       }
                                            //       if (event == RewardedVideoAdEvent.failedToLoad) {
                                            //         Toast.show("Failed to load ad. Try again later", context);
                                            //         snapshot.spinSubmitting = false;
                                            //         snapshot.notify();
                                            //
                                            //         //facebook app event *****
                                            //         FacebookLogger.adLoadFailed();
                                            //       }
                                            //     };
                                            //   }
                                            // });
                                          } else {
                                            DownloadApp.showDialog(context);
                                          }
                                        }
                                      },
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 0,
                      left: 50,
                      right: 50,
                      child: Container(
                        height: 45,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: ColorsLocal.hexToColor("FF4081"),
                        ),
                        child: Center(
                          child: Text(
                            LocaleKey.DAILY_SPIN.toLocaleText(),
                            style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: Colors.white, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Container(
                          height: 56,
                          decoration: BoxDecoration(shape: BoxShape.circle, color: ColorsLocal.button_color_pink),
                          child: IconButton(
                            icon: Icon(
                              Icons.clear,
                              size: 24,
                              color: Colors.white,
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  double _getWheelHeightWidth(BuildContext context) {
    return min((MediaQuery.of(context).size.width.toCustomWidth() - 32 - 72), 220);
  }
}
