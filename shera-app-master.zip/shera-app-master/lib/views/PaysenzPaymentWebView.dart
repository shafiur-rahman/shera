/*
* Created by Ahammed Hossain Shanto
* on 10/12/20
*/

import 'dart:async';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/utils/PackageSupport.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/PaysenzPaymentVM.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:quiz/extensions/string_extensions.dart';

class PaysenzPaymentWebView extends StatelessWidget {
  Completer<WebViewController> _controller = Completer<WebViewController>();

  String paymentUrl;

  PaysenzPaymentWebView(this.paymentUrl) {
    if (PackageSupport.instance.isMobile()) {
      if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
    }
  }

  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider(
        create: (_) {
          return PaysenzPaymentVM(context);
        },
        child: Consumer<PaysenzPaymentVM>(builder: (context, snapshot, _) {
          return Scaffold(
            appBar: AppBar(
              elevation: 0,
              centerTitle: false,
              leading: Container(
                child: IconButton(
                  icon: Image.asset(
                    "assets/images/back_arrow.png",
                    height: 20,
                    width: 24,
                  ),
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
              title: Container(
                child: Text(
                  LocaleKey.PAYMENT_METHOD.toLocaleText(),
                  style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            body: Stack(
              children: [
                Positioned(
                  left: 0,
                  right: 0,
                  top: 0,
                  bottom: 0,
                  child: WebView(
                    initialUrl: paymentUrl,
                    javascriptMode: JavascriptMode.unrestricted,
                    onPageFinished: (String url) {
                      snapshot.updateLoadStatus(true);
                      Logger.printWrapped(url);
                      if (url.contains(WEB_HOME_URL)) {
                        Navigator.of(context).pop(url);
                      }
                    },
                    onWebViewCreated: (WebViewController controller) {
                      _controller.complete(controller);
                    },
                    onPageStarted: (value) {
                      //Logger.printWrapped("pageStarted");
                    },
                  ),
                ),
                Center(
                  child: snapshot.pageLoaded ? Container() : CupertinoActivityIndicator(),
                )
              ],
            ),
          );
        }),
      ),
    );
  }
}
