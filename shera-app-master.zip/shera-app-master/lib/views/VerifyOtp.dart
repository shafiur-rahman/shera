/*
* Created by Ahammed Hossain Shanto
* on 6/30/20
*/

import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/models/UserLoginRegistration.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/TimerVM.dart';
import 'package:quiz/view-models/VerifyOtpVM.dart';
import 'package:toast/toast.dart';

class VerifyOtp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RootBody(
      needLogin: false,
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (_) {
              return VerifyOtpVM(context);
            },
          ),
          ChangeNotifierProvider(
            create: (_) {
              return TimerVM(duration: OTP_RESEND_DURATION, autoStart: true, playSound: false);
            },
          )
        ],
        child: Scaffold(
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 110,
                  width: 150,
                  margin: EdgeInsets.fromLTRB(36, 85, 36, 0),
                  child: Image.asset("assets/images/text_logo.png"),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 56, 36, 0),
                  child: Text(
                    "Enter verification code",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 4, 36, 0),
                  child: Text(
                    "We have sent a verification code to your given mobile number",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w300),
                  ),
                ),
                Consumer2<VerifyOtpVM, TimerVM>(
                  builder: (context, snapshotOtp, snapshotTimer, _) {
                    return Container(
                      child: Column(
                        //crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            child: OTPTextField(
                              length: OTP_DIGIT_LENGTH,
                              width: MediaQuery.of(context).size.width.toCustomWidth() - 72,
                              fieldWidth: 40,
                              style: TextStyle(fontSize: 30, fontFamily: "Poppins", color: ColorsLocal.text_color_purple, fontWeight: FontWeight.w600),
                              textFieldAlignment: MainAxisAlignment.spaceEvenly,
                              fieldStyle: FieldStyle.underline,
                              onCompleted: (pin) {
                                snapshotOtp.setPin(pin.toString());
                              },
                              onChanged: (pin) {
                                snapshotOtp.setPin(pin.toString());
                              },
                            ),
                            margin: EdgeInsets.fromLTRB(36, 16, 36, 36),
                          ),
                          !snapshotTimer.finished
                              ? Container(
                                  child: Text(
                                    '0:${snapshotTimer.timeLeft}s',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontFamily: "Poppins",
                                      fontWeight: FontWeight.w500,
                                      color: ColorsLocal.text_color_purple,
                                    ),
                                  ),
                                  margin: EdgeInsets.fromLTRB(36, 0, 36, 0),
                                )
                              : Container(),
                          snapshotOtp.otpSending ? CupertinoActivityIndicator() : Container(),
                          snapshotOtp.verifying ? CupertinoActivityIndicator() : Container(),
                          Container(
                            child: RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(text: "Didn't get the code yet? ", style: TextStyle(fontFamily: "Poppins", fontSize: 15, fontWeight: FontWeight.w400, color: Colors.grey[800]), children: <TextSpan>[
                                TextSpan(
                                  text: "Resend",
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {
                                      if (snapshotTimer.finished && !snapshotOtp.otpSending) {
                                        if (UserLoginRegistration.isFirebase) {
                                          snapshotOtp.sendOTPFirebase().then((value) {
                                            if (value == 3) {
                                              snapshotTimer.startTimer(playSound: false);
                                            } else {
                                              Toast.show(snapshotOtp.otpMessage, context);
                                            }
                                          });
                                        } else {
                                          snapshotOtp.sendOTP('0${UserLoginRegistration.mobile}').then((flag) {
                                            if (flag) {
                                              snapshotTimer.startTimer(playSound: false);
                                            } else {
                                              Toast.show(snapshotOtp.otpMessage, context);
                                            }
                                          });
                                        }
                                      }
                                    },
                                  style: TextStyle(fontFamily: "Poppins", fontSize: 15, fontWeight: FontWeight.w600, color: snapshotTimer.finished ? ColorsLocal.text_color_pink : Colors.grey[500], decoration: TextDecoration.underline),
                                ),
                              ]),
                            ),
                            margin: EdgeInsets.fromLTRB(36, 4, 36, 0),
                          ),
                          snapshotTimer.finished
                              ? Container(
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      text: "Change the mobile number",
                                      style: TextStyle(fontFamily: "Poppins", fontSize: 15, fontWeight: FontWeight.w400, color: snapshotTimer.finished ? Colors.grey[800] : Colors.transparent, decoration: TextDecoration.underline),
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {
                                          if (snapshotTimer.finished) {
                                            Navigator.pushReplacementNamed(context, LoginWithMobileRoute);
                                          }
                                        },
                                    ),
                                  ),
                                  margin: EdgeInsets.fromLTRB(36, 24, 36, 0),
                                )
                              : Container(height: 0, width: 0),
                          snapshotTimer.finished && UserLoginRegistration.accountExists
                              ? Container(
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(text: "Or use email address for ", style: TextStyle(fontFamily: "Poppins", fontSize: 15, fontWeight: FontWeight.w400, color: Colors.grey[800]), children: <TextSpan>[
                                      TextSpan(
                                        text: "Login",
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () {
                                            Navigator.pushNamed(context, LoginWithEmailRoute);
                                          },
                                        style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                          color: snapshotTimer.finished ? ColorsLocal.text_color_pink : Colors.grey[500],
                                          //decoration: TextDecoration.underline
                                        ),
                                      ),
                                    ]),
                                  ),
                                  margin: EdgeInsets.fromLTRB(36, 24, 36, 36),
                                )
                              : Container(
                                  height: 0,
                                  width: 0,
                                ),
                        ],
                      ),
                    );
                  },
                )
              ],
            ),
          ),
          floatingActionButton: Consumer2<VerifyOtpVM, TimerVM>(
            builder: (context, snapshot, timerVM, _) {
              if (snapshot.pin.length != OTP_DIGIT_LENGTH) {
                return Container();
              } else {
                return FloatingActionButton(
                  backgroundColor: ColorsLocal.button_color_pink,
                  child: Icon(
                    Icons.arrow_forward,
                  ),
                  onPressed: () {
                    if (!snapshot.verifying) {
                      if (snapshot.pin.length == OTP_DIGIT_LENGTH) {
                        if (UserLoginRegistration.isFirebase) {
                          snapshot.verifyOtpFirebase(timerVM);
                        } else {
                          snapshot.verifyOtp(timerVM);
                        }
                      } else {
                        Toast.show('Please enter ${OTP_DIGIT_LENGTH} digit OTP correctly', context);
                      }
                    }
                  },
                );
              }
            },
          ),
        ),
      ),
    );
  }
}
