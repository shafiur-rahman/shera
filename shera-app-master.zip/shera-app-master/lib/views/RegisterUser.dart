/*
* Created by Ahammed Hossain Shanto
* on 6/30/20
*/

import 'package:email_validator/email_validator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/models/UserLoginRegistration.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/RegisterUserVM.dart';

class RegisterUser extends StatelessWidget {
  TextEditingController _textEditingControllerName = new TextEditingController();
  TextEditingController _textEditingControllerEmail = new TextEditingController();
  TextEditingController _textEditingControllerPassword = new TextEditingController();
  TextEditingController _textEditingControllerPassword2 = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return RootBody(
      needLogin: false,
      child: ChangeNotifierProvider(
        create: (_) {
          return RegisterUserVM(context);
        },
        child: Scaffold(
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 110,
                  width: 150,
                  margin: EdgeInsets.fromLTRB(36, 85, 36, 0),
                  child: Image.asset("assets/images/text_logo.png"),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 56, 36, 0),
                  child: Text(
                    "Create you account",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 4, 36, 0),
                  child: Text(
                    "this is for the first time only",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w300),
                  ),
                ),
                Consumer<RegisterUserVM>(
                  builder: (context, snapshot, _) {
                    return Container(
                      child: Column(
                        //crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(36, 24, 36, 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                              border: Border.all(
                                width: 1,
                                color: ColorsLocal.hexToColor("EAEAEA"),
                              ),
                            ),
                            padding: EdgeInsets.fromLTRB(24, 6, 24, 6),
                            child: TextField(
                              controller: _textEditingControllerName,
                              textAlign: TextAlign.start,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, letterSpacing: 1.0, fontWeight: FontWeight.w500),
                              maxLines: 1,
                              decoration: InputDecoration(
                                  hintText: "Your Name",
                                  hintStyle: TextStyle(
                                    fontSize: 18,
                                    color: ColorsLocal.hexToColor("D4DDEC"),
                                  ),
                                  border: InputBorder.none),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(36, 8, 36, 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                              border: Border.all(
                                width: 1,
                                color: ColorsLocal.hexToColor("EAEAEA"),
                              ),
                            ),
                            padding: EdgeInsets.fromLTRB(24, 6, 24, 6),
                            child: TextField(
                              controller: _textEditingControllerEmail,
                              textAlign: TextAlign.start,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, letterSpacing: 1.0, fontWeight: FontWeight.w500),
                              maxLines: 1,
                              decoration: InputDecoration(
                                  hintText: "Email Address",
                                  hintStyle: TextStyle(
                                    fontSize: 18,
                                    color: ColorsLocal.hexToColor("D4DDEC"),
                                  ),
                                  border: InputBorder.none),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(36, 8, 36, 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                              border: Border.all(
                                width: 1,
                                color: ColorsLocal.hexToColor("EAEAEA"),
                              ),
                            ),
                            padding: EdgeInsets.fromLTRB(24, 6, 24, 6),
                            child: TextField(
                              controller: _textEditingControllerPassword,
                              obscureText: true,
                              textAlign: TextAlign.start,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, letterSpacing: 1.0, fontWeight: FontWeight.w500),
                              maxLines: 1,
                              decoration: InputDecoration(
                                  hintText: "Password",
                                  hintStyle: TextStyle(
                                    fontSize: 18,
                                    color: ColorsLocal.hexToColor("D4DDEC"),
                                  ),
                                  border: InputBorder.none),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(36, 8, 36, 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.white,
                              border: Border.all(
                                width: 1,
                                color: ColorsLocal.hexToColor("EAEAEA"),
                              ),
                            ),
                            padding: EdgeInsets.fromLTRB(24, 6, 24, 6),
                            child: TextField(
                              controller: _textEditingControllerPassword2,
                              obscureText: true,
                              textAlign: TextAlign.start,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, letterSpacing: 1.0, fontWeight: FontWeight.w500),
                              maxLines: 1,
                              decoration: InputDecoration(
                                  hintText: "Confirm Password",
                                  hintStyle: TextStyle(
                                    fontSize: 18,
                                    color: ColorsLocal.hexToColor("D4DDEC"),
                                  ),
                                  border: InputBorder.none),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(36, 16, 36, 36),
                            child: Text(
                              snapshot.message,
                              style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color_pink_2, fontWeight: FontWeight.w500),
                            ),
                          ),
                          snapshot.creating
                              ? Container(
                                  margin: EdgeInsets.fromLTRB(36, 16, 36, 36),
                                  child: CupertinoActivityIndicator(),
                                )
                              : Container(
                                  margin: EdgeInsets.fromLTRB(36, 16, 36, 36),
                                ),
                        ],
                      ),
                    );
                  },
                )
              ],
            ),
          ),
          floatingActionButton: Consumer<RegisterUserVM>(
            builder: (context, snapshot, _) {
              return FloatingActionButton(
                backgroundColor: ColorsLocal.button_color_pink,
                child: Icon(
                  Icons.arrow_forward,
                ),
                onPressed: () {
                  if (_textEditingControllerName.text.toString().isEmpty) {
                    snapshot.message = "Please enter a name before continue";
                    snapshot.notify();
                  } else if (!EmailValidator.validate(_textEditingControllerEmail.text.toString().trim())) {
                    snapshot.message = "Please enter a valid email";
                    snapshot.notify();
                  } else if (_textEditingControllerPassword.text.toString().trim().length < 8) {
                    snapshot.message = "Please enter at least 8 digit password";
                    snapshot.notify();
                  } else if (_textEditingControllerPassword.text.toString().trim() != _textEditingControllerPassword2.text.toString().trim()) {
                    snapshot.message = "Password don't match";
                    snapshot.notify();
                  } else {
                    snapshot.message = "";
                    snapshot.notify();
                    UserLoginRegistration.name = _textEditingControllerName.text.toString().trim();
                    UserLoginRegistration.email = _textEditingControllerEmail.text.toString().trim();
                    UserLoginRegistration.password = _textEditingControllerPassword.text.toString().trim();
                    snapshot.createUser();
                  }
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
