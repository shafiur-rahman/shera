/*
* Created by Ahammed Hossain Shanto
* on 6/30/20
*/

import 'package:email_validator/email_validator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/models/UserLoginRegistration.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/LoginWithEmailVM.dart';

class LoginWithEmail extends StatelessWidget {
  TextEditingController _textEditingControllerEmail = new TextEditingController();
  TextEditingController _textEditingControllerPassword = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return RootBody(
      needLogin: false,
      child: ChangeNotifierProvider(
        create: (_) {
          return LoginWithEmailVM(context);
        },
        child: Scaffold(
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 110,
                  width: 150,
                  margin: EdgeInsets.fromLTRB(36, 85, 36, 0),
                  child: Image.asset("assets/images/text_logo.png"),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 56, 36, 0),
                  child: Text(
                    "You can login to QuizGiri using your Email & Password",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 4, 36, 0),
                  child: Text(
                    "Use the same email & password that was used for registration",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.text_color, fontWeight: FontWeight.w300),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 24, 36, 8),
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 1,
                      color: ColorsLocal.hexToColor("EAEAEA"),
                    ),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Container(
                    margin: EdgeInsets.fromLTRB(24, 8, 24, 8),
                    child: TextField(
                      controller: _textEditingControllerEmail,
                      textAlign: TextAlign.start,
                      style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, letterSpacing: 1.5, fontWeight: FontWeight.w500),
                      maxLines: 1,
                      decoration: InputDecoration(
                        hintText: "Email Address",
                        border: InputBorder.none,
                        hintStyle: TextStyle(
                          color: ColorsLocal.hexToColor("d4ddec"),
                        ),
                        counterText: "",
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(36, 8, 36, 36),
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 1,
                      color: ColorsLocal.hexToColor("EAEAEA"),
                    ),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Container(
                    margin: EdgeInsets.fromLTRB(24, 8, 24, 8),
                    child: TextField(
                      controller: _textEditingControllerPassword,
                      obscureText: true,
                      textAlign: TextAlign.start,
                      style: TextStyle(fontFamily: "Poppins", fontSize: 18, color: ColorsLocal.text_color, letterSpacing: 1.5, fontWeight: FontWeight.w500),
                      maxLines: 1,
                      decoration: InputDecoration(
                        hintText: "Password",
                        border: InputBorder.none,
                        hintStyle: TextStyle(
                          color: ColorsLocal.hexToColor("d4ddec"),
                        ),
                        counterText: "",
                      ),
                    ),
                  ),
                ),
                Consumer<LoginWithEmailVM>(builder: (context, snapshot, _) {
                  return Container(
                    margin: EdgeInsets.fromLTRB(36, 0, 36, 36),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        snapshot.processing
                            ? Container(
                                child: CupertinoActivityIndicator(),
                              )
                            : Container(),
                        !snapshot.processing
                            ? Container(
                                child: Text(
                                  snapshot.message,
                                  style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14,
                                    color: ColorsLocal.text_color_pink_2,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              )
                            : Container(height: 0, width: 0),
                        Container(
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(text: "Forget your password? ", style: TextStyle(fontFamily: "Poppins", fontSize: 15, fontWeight: FontWeight.w400, color: Colors.grey[800]), children: <TextSpan>[
                              TextSpan(
                                text: "Recover",
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    if (!EmailValidator.validate(_textEditingControllerEmail.text.toString().trim())) {
                                      snapshot.message = "Please enter a valid email";
                                      snapshot.notify();
                                    } else {
                                      if (!snapshot.processing) {
                                        UserLoginRegistration.email = _textEditingControllerEmail.text.toString().trim();
                                        snapshot.recoverPassword();
                                      }
                                    }
                                  },
                                style: TextStyle(fontFamily: "Poppins", fontSize: 15, fontWeight: FontWeight.w600, color: ColorsLocal.text_color_pink, decoration: TextDecoration.underline),
                              ),
                            ]),
                          ),
                          margin: EdgeInsets.fromLTRB(36, 24, 36, 36),
                        )
                      ],
                    ),
                  );
                }),
              ],
            ),
          ),
          floatingActionButton: Consumer<LoginWithEmailVM>(builder: (context, snapshot, _) {
            return FloatingActionButton(
              backgroundColor: ColorsLocal.button_color_pink,
              child: Icon(Icons.arrow_forward),
              onPressed: () {
                if (!EmailValidator.validate(_textEditingControllerEmail.text.toString().trim())) {
                  snapshot.message = "Please enter a valid email";
                  snapshot.notify();
                } else if (_textEditingControllerPassword.text.toString().trim().isEmpty) {
                  snapshot.message = "Please enter a password";
                  snapshot.notify();
                } else {
                  if (!snapshot.processing) {
                    UserLoginRegistration.email = _textEditingControllerEmail.text.toString().trim();
                    UserLoginRegistration.password = _textEditingControllerPassword.text.toString().trim();
                    snapshot.loginWithEmail();
                  }
                }
              },
            );
          }),
        ),
      ),
    );
  }
}
