/*
* Created by Ahammed Hossain Shanto on 7/8/20
*/

import 'dart:convert';

import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz/constants/ProjectConstants.dart';
import 'package:quiz/constants/RoutingConstants.dart';
import 'package:quiz/extensions/double_extensions.dart';
import 'package:quiz/extensions/string_extensions.dart';
import 'package:quiz/locale-helper/locale_key.dart';
import 'package:quiz/models/AppSessionSettings.dart';
import 'package:quiz/models/MyShimmer.dart';
import 'package:quiz/utils/Logger.dart';
import 'package:quiz/values/ColorsLocal.dart';
import 'package:quiz/view-components/AppBarBottom.dart';
import 'package:quiz/view-components/ImageLoader.dart';
import 'package:quiz/view-components/Pop_Ups/AddFriendPU.dart';
import 'package:quiz/view-components/Pop_Ups/LocalAlert.dart';
import 'package:quiz/view-components/Pop_Ups/TournamentInfo.dart';
import 'package:quiz/view-components/Pop_Ups/TournamentPasscode.dart';
import 'package:quiz/view-components/Pop_Ups/TournamentPaymentOption.dart';
import 'package:quiz/view-components/RootBody.dart';
import 'package:quiz/view-models/TournamentDetailsVM.dart';
import 'package:share/share.dart';

class TournamentDetails extends StatelessWidget {
  var arguments;
  int tournamentId;
  String type = "GG";
  String category = "ROBI DHAMAKA";
  TournamentDetailsVM tournamentDetailsVM;

  TournamentDetails(this.arguments) {
    //arguments must contain tournament 'id'
    tournamentId = int.parse(arguments['tournament_id'].toString());
    tournamentDetailsVM = new TournamentDetailsVM(tournamentId);
  }

  Future<void> _onRefresh() async {
    tournamentDetailsVM.loadDetails();
    await Future.delayed(Duration(seconds: 1));
    return 'success';
  }

  @override
  Widget build(BuildContext context) {
    return RootBody(
      child: ChangeNotifierProvider.value(
        value: tournamentDetailsVM,
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            centerTitle: false,
            leading: Container(
              child: IconButton(
                icon: Image.asset(
                  "assets/images/back_arrow.png",
                  height: 20,
                  width: 24,
                ),
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            title: Container(
              child: Text(
                LocaleKey.TOURNAMENT.toLocaleText(),
                style: TextStyle(fontFamily: "Poppins", fontSize: 22, color: ColorsLocal.text_color, fontWeight: FontWeight.w600),
              ),
            ),
            bottom: AppBarBottom.shadow(),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: Container(
                  //color: Colors.red,
                  child: Consumer<TournamentDetailsVM>(builder: (context, snapshot, _) {
                    return RefreshIndicator(
                      onRefresh: _onRefresh,
                      child: ListView.builder(
                        itemBuilder: (BuildContext context, int index) {
                          if (index == 0) {
                            return _buildStep1(context, snapshot);
                          } else if (index == 1) {
                            return _buildStep2(context, snapshot);
                          } else {
                            return _buildPositions(context, snapshot, index - 2);
                          }
                        },
                        itemCount: _getItemCount(context, snapshot),
                      ),
                    );
                  }),
                ),
              )
            ],
          ),
          bottomNavigationBar: Consumer<TournamentDetailsVM>(builder: (context, snapshot, _) {
            return BottomAppBar(
              child: Container(
                height: 40,
                margin: EdgeInsets.only(top: 16, bottom: 16, left: 36, right: 36),
                child: RaisedButton(
                  shape: RoundedRectangleBorder(
                    side: BorderSide(
                      width: 1,
                      color: ColorsLocal.text_color_purple,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  color: Colors.white,
                  elevation: 0,
                  highlightElevation: 0,
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
                    child: Center(
                      child: Text(
                        LocaleKey.INVITE_FRIENDS.toLocaleText(),
                        style: TextStyle(
                          fontFamily: "Poppins",
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: ColorsLocal.text_color_purple,
                        ),
                      ),
                    ),
                  ),
                  onPressed: () async {
                    final DynamicLinkParameters parameters = DynamicLinkParameters(
                      uriPrefix: 'https://quizgiri.com.bd/invite',
                      link: Uri.parse('https://app.quizgiri.com.bd?tournament_id=${snapshot.tournamentDetails['tournament']['id']}'),
                      androidParameters: AndroidParameters(
                        packageName: PACKAGE_NAME_ANDROID,
                        minimumVersion: 16,
                      ),
                      //TODO need to update the values ***
                      iosParameters: IosParameters(
                        bundleId: PACKAGE_NAME_IOS,
                        minimumVersion: '1.0.1',
                        appStoreId: APP_STORE_ID,
                      ),
                      socialMetaTagParameters: SocialMetaTagParameters(
                        title: 'QuizGiri Invitation',
                        description: 'Participate & win prize',
                        imageUrl: Uri.parse("https://quizgiri.xyz/images/hero-1.png"),
                      ),
                    );

                    final ShortDynamicLink shortDynamicLink = await parameters.buildShortLink();
                    final Uri shortUrl = shortDynamicLink.shortUrl;
                    //Logger.printWrapped(shortUrl.toString());
                    Share.share(shortUrl.toString(), subject: "Invitation");
                  },
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  int _getItemCount(BuildContext context, TournamentDetailsVM snapshot) {
    int count = 0;

    if (snapshot.detailsLoaded) {
      if (AppSessionSettings.isNepaliUser()) {
        count = 2;
      } else {
        count = 1;
      }
      List rankList = snapshot.tournamentDetails['ranking'];
      if (rankList != null && rankList.isNotEmpty) {
        count += (rankList.length + 1);
      }
    } else {
      count = 5;
    }

    return count;
  }

  Widget _buildStep1(BuildContext context, TournamentDetailsVM snapshot) {
    if (snapshot.detailsLoaded == false && snapshot.tournamentDetails == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
        child: MyShimmer.fromColors(
            child: Container(
              padding: EdgeInsets.fromLTRB(36, 24, 36, 36),
              decoration: BoxDecoration(
                border: Border.all(
                  width: 1,
                  color: Colors.grey[300],
                ),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Column(
                children: [
                  Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.grey[300]),
                  ),
                  Container(
                    height: 20,
                    width: 120,
                    margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 20,
                        margin: EdgeInsets.fromLTRB(0, 36, 150, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                      ),
                      Container(
                        height: 6,
                        margin: EdgeInsets.fromLTRB(0, 8, 0, 0),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.grey[300]),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 24, 0, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                                height: 40,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                height: 40,
                                margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[300],
                                ),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      return Column(
        children: [
          Container(
            margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: PhysicalModel(
              clipBehavior: Clip.antiAlias,
              borderRadius: BorderRadius.circular(7),
              color: Colors.transparent,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(7),
                    topRight: Radius.circular(7),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                      decoration: BoxDecoration(color: ColorsLocal.button_color_purple),
                      child: Column(
                        //crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            child: Row(
                              children: [
                                snapshot.tournamentDetails['tournament']['sponsor_icon'] != null && snapshot.tournamentDetails['tournament']['sponsor_icon'].toString().isNotEmpty
                                    ? Container(
                                        margin: EdgeInsets.only(top: 8),
                                        child: ImageLoader.loadRect(
                                          imageUrl: snapshot.tournamentDetails['tournament']['sponsor_icon'].toString(),
                                          width: 100,
                                          height: 40,
                                          fit: BoxFit.contain,
                                          showLoadingShimmer: false,
                                        ),
                                      )
                                    : Container(),
                                Expanded(
                                  child: Container(),
                                ),
                                Container(
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(5, 0, 0, 0),
                                    decoration: BoxDecoration(color: Colors.grey.withOpacity(0.4), borderRadius: BorderRadius.circular(24)),
                                    padding: EdgeInsets.fromLTRB(8, 4, 8, 4),
                                    child: Text(
                                      '${snapshot.tournamentDetails['tournament']['time_left'].toString()}',
                                      style: TextStyle(
                                        fontSize: 8,
                                        color: Colors.white.withOpacity(0.6),
                                        fontWeight: FontWeight.w500,
                                        fontFamily: "poppins",
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(16, 16, 16, 16),
                            child: Text(
                              snapshot.tournamentDetails['tournament']['name'].toString(),
                              style: TextStyle(
                                fontSize: 25,
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontFamily: "Poppins",
                              ),
                            ),
                          ),
                          Container(
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
                              margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                              child: Wrap(
                                crossAxisAlignment: WrapCrossAlignment.center,
                                children: [
                                  Container(
                                    child: Image.asset(
                                      "assets/images/ic_trophy.png",
                                      height: 22,
                                      width: 22,
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
                                    child: Text(
                                      snapshot.tournamentDetails['tournament']['prize'].toString(),
                                      style: TextStyle(
                                        fontFamily: "Poppins",
                                        color: ColorsLocal.text_color_purple,
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(16, 16, 16, 0),
                            child: Text(
                              '${snapshot.tournamentDetails['tournament']['subscriber_count'].toString().toLocaleNumber()}+ ${LocaleKey.PARTICIPANTS_ARE_PLAYING.toLocaleText()}',
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.white.withOpacity(0.4),
                                fontWeight: FontWeight.w500,
                                fontFamily: "Poppins",
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    snapshot.tournamentDetails['tournament']['has_quota']
                        ? Container(
                            margin: EdgeInsets.fromLTRB(36, 24, 36, 24),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    child: RaisedButton(
                                      elevation: 0,
                                      highlightElevation: 0,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(24, 12, 24, 12),
                                        child: snapshot.starting || snapshot.verifying
                                            ? Container(
                                                height: 24,
                                                width: 24,
                                                child: CircularProgressIndicator(
                                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                                  strokeWidth: 2,
                                                ),
                                              )
                                            : Text(
                                                snapshot.tournamentDetails['tournament']['ended']
                                                    ? LocaleKey.TIME_UP.toLocaleText()
                                                    : !snapshot.tournamentDetails['tournament']['has_quota']
                                                        ? LocaleKey.ALREADY_PLAYED.toLocaleText()
                                                        : !snapshot.tournamentDetails['tournament']['subscribed'] && snapshot.tournamentDetails['tournament']['has_quota'] && !snapshot.tournamentDetails['tournament']['ended']
                                                            ? snapshot.getButtonTitle()
                                                            : snapshot.tournamentDetails['tournament']['subscribed'] && snapshot.tournamentDetails['tournament']['has_quota'] && !snapshot.tournamentDetails['tournament']['ended']
                                                                ? LocaleKey.PLAY_NOW.toLocaleText()
                                                                : "",
                                                style: TextStyle(
                                                  fontFamily: "Poppins",
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 16,
                                                ),
                                                textAlign: TextAlign.center),
                                      ),
                                      color: ColorsLocal.button_color_pink,
                                      onPressed: snapshot.tournamentDetails['tournament']['ended'] || !snapshot.tournamentDetails['tournament']['has_quota']
                                          ? null
                                          : !snapshot.tournamentDetails['tournament']['subscribed'] && snapshot.tournamentDetails['tournament']['has_quota'] && !snapshot.tournamentDetails['tournament']['ended']
                                              ? () {
                                                  //call passcode popup here if private ***
                                                  if (snapshot.tournamentDetails['tournament']['is_private'] && !snapshot.isEligible) {
                                                    TournamentPasscode.show(context, snapshot, onButtonPressed: () {
                                                      snapshot.verifyPasscode(snapshot.passcode).then((value) {
                                                        if (value) {
                                                          snapshot.passcodeMessage = "";
                                                          Navigator.of(context).pop();
                                                          if (snapshot.tournamentDetails['tournament']['currency'].toString() == "money") {
                                                            Navigator.pushNamed(context, PaymentMethodRoute, arguments: {"tournament_id": tournamentId, "subscription_fee": snapshot.tournamentDetails['tournament']['subscription_fee']}).then((value) {
                                                              Logger.printWrapped("Loading details again");
                                                              snapshot.loadDetails();
                                                            });
                                                          } else {
                                                            //call payment option choose popup
                                                            TournamentPaymentOption.showDialog(
                                                              context,
                                                              onBDTPay: () {
                                                                Navigator.pop(context);
                                                                Navigator.pushNamed(context, PaymentMethodRoute, arguments: {"tournament_id": tournamentId, "subscription_fee": snapshot.tournamentDetails['tournament']['subscription_fee']}).then((value) {
                                                                  Logger.printWrapped("Loading details again");
                                                                  snapshot.loadDetails();
                                                                });
                                                              },
                                                              onCoinPay: () {
                                                                Navigator.pop(context);
                                                                snapshot.subscribeByCoins().then((value) {
                                                                  if (value) {
                                                                    snapshot.loadDetails();
                                                                  } else {
                                                                    LocalAlert.showDialog(context, "Opps!!", snapshot.coinPurchaseMessage);
                                                                  }
                                                                });
                                                              },
                                                              bdt_fee: snapshot.tournamentDetails['tournament']['subscription_fee'].toString(),
                                                              coin_fee: snapshot.tournamentDetails['tournament']['coin_fee'].toString(),
                                                              type: snapshot.tournamentDetails['tournament']['currency'].toString(),
                                                            );
                                                          }
                                                        }
                                                      });
                                                    });
                                                  }
                                                  else {
                                                    if (snapshot.tournamentDetails['tournament']['currency'] == "money") {
                                                      if (AppSessionSettings.isNepaliUser()) {
                                                        var arguments = {"type": type, "tournament_id": tournamentId};
                                                        Navigator.pushNamed(context, NcellPackagesRoute, arguments: arguments).then((value) {
                                                          snapshot.loadDetails();
                                                        });
                                                      }
                                                      else {
                                                        Navigator.pushNamed(context, PaymentMethodRoute, arguments: {"tournament_id": tournamentId, "subscription_fee": snapshot.tournamentDetails['tournament']['subscription_fee']}).then((value) {
                                                          Logger.printWrapped("Loading again");
                                                          snapshot.loadDetails();
                                                        });
                                                      }
                                                    } else {
                                                      //call payment option choose popup
                                                      TournamentPaymentOption.showDialog(
                                                        context,
                                                        onBDTPay: () {
                                                          Navigator.pop(context);
                                                          Navigator.pushNamed(context, PaymentMethodRoute, arguments: {"tournament_id": tournamentId, "subscription_fee": snapshot.tournamentDetails['tournament']['subscription_fee']}).then((value) {
                                                            snapshot.loadDetails();
                                                          });
                                                        },
                                                        onCoinPay: () {
                                                          Navigator.pop(context);
                                                          snapshot.subscribeByCoins().then((value) {
                                                            if (value) {
                                                              snapshot.loadDetails();
                                                            } else {
                                                              LocalAlert.showDialog(context, "Opps!!", snapshot.coinPurchaseMessage);
                                                            }
                                                          });
                                                        },
                                                        bdt_fee: snapshot.tournamentDetails['tournament']['subscription_fee'].toString(),
                                                        coin_fee: snapshot.tournamentDetails['tournament']['coin_fee'].toString(),
                                                        type: snapshot.tournamentDetails['tournament']['currency'].toString(),
                                                      );
                                                    }
                                                  }
                                                }
                                              : () {
                                                  //to prevent multiple clicks *****
                                                  if (!snapshot.starting) {
                                                    if (snapshot.tournamentDetails['tournament']['subscribed'] && snapshot.tournamentDetails['tournament']['has_quota'] && !snapshot.tournamentDetails['tournament']['ended']) {
                                                      if (snapshot.tournamentDetails['tournament']['is_private'] && !snapshot.isEligible) {
                                                        TournamentPasscode.show(context, snapshot, onButtonPressed: () {
                                                          snapshot.verifyPasscode(snapshot.passcode).then((value) {
                                                            if (value) {
                                                              snapshot.passcodeMessage = "";
                                                              Navigator.of(context).pop();
                                                              TournamentInfo.showDialog(context, snapshot.getDuration(), snapshot.tournamentDetails['tournament']['question_count'], snapshot.tournamentDetails['tournament']['chances'], snapshot.tournamentDetails['tournament']['played'], onTap: () {
                                                                //dismiss the dialog ***
                                                                Navigator.pop(context);
                                                                snapshot.startGame("Tournament", snapshot.tournamentDetails['tournament']['name'].toString()).then((value) {
                                                                  if (value != null) {
                                                                    Navigator.pushNamed(context, TournamentPlayRoute, arguments: value).then((value) {
                                                                      snapshot.loadDetails();
                                                                    });
                                                                  } else {
                                                                    LocalAlert.showDialog(context, "Sorry", "Error Occurred. Please try again later");
                                                                  }
                                                                });
                                                              });
                                                            }
                                                          });
                                                        });
                                                      } else {
                                                        //TODO:Nepali users
                                                        if (AppSessionSettings.isNepaliUser()) {
                                                          //Navigator.pop(context);
                                                          snapshot.startGame("Tournament", snapshot.tournamentDetails['tournament']['name'].toString()).then((value) {
                                                            if (value != null) {
                                                              Navigator.pushNamed(context, TournamentPlayRoute, arguments: value).then((value) {
                                                                snapshot.loadDetails();
                                                              });
                                                            } else {
                                                              LocalAlert.showDialog(context, "Sorry", "Error Occurred. Please try again later");
                                                            }
                                                          });
                                                        } else {
                                                          TournamentInfo.showDialog(context, snapshot.getDuration(), snapshot.tournamentDetails['tournament']['question_count'], snapshot.tournamentDetails['tournament']['chances'], snapshot.tournamentDetails['tournament']['played'], onTap: () {
                                                            //dismiss the dialog ***
                                                            Navigator.pop(context);
                                                            snapshot.startGame("Tournament", snapshot.tournamentDetails['tournament']['name'].toString()).then((value) {
                                                              if (value != null) {
                                                                Navigator.pushNamed(context, TournamentPlayRoute, arguments: value).then((value) {
                                                                  snapshot.loadDetails();
                                                                });
                                                              } else {
                                                                LocalAlert.showDialog(context, "Sorry", "Error Occurred. Please try again later");
                                                              }
                                                            });
                                                          });
                                                        }
                                                      }
                                                    }
                                                  }
                                                },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),

                    //Subscribed

                    snapshot.tournamentDetails['tournament']['has_quota'] && !snapshot.tournamentDetails['tournament']['ended'] && snapshot.tournamentDetails['tournament']['subscribed'] && AppSessionSettings.isNepaliUser()
                        ? Container(
                            margin: EdgeInsets.fromLTRB(36, 10, 36, 24),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    child: RaisedButton(
                                      elevation: 0,
                                      highlightElevation: 0,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(24, 12, 24, 12),
                                        child: snapshot.subscribing
                                            ? Container(
                                                height: 24,
                                                width: 24,
                                                child: CircularProgressIndicator(
                                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                                  strokeWidth: 2,
                                                ),
                                              )
                                            : Text(
                                                snapshot.tournamentDetails['tournament']['ended']
                                                    ? LocaleKey.TIME_UP
                                                    : !snapshot.tournamentDetails['tournament']['has_quota']
                                                        ? LocaleKey.ALREADY_PLAYED.toLocaleText()
                                                        : !snapshot.tournamentDetails['tournament']['subscribed'] && snapshot.tournamentDetails['tournament']['has_quota'] && !snapshot.tournamentDetails['tournament']['ended']
                                                            ? snapshot.getButtonTitle()
                                                            : snapshot.tournamentDetails['tournament']['subscribed'] && snapshot.tournamentDetails['tournament']['has_quota'] && !snapshot.tournamentDetails['tournament']['ended']
                                                                ? LocaleKey.UNSUBSCRIBE_NOW.toLocaleText()
                                                                : LocaleKey.SUBSCRIBE_NOW.toLocaleText(),
                                                style: TextStyle(
                                                  fontFamily: "Poppins",
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 16,
                                                ),
                                                textAlign: TextAlign.center),
                                      ),
                                      color: ColorsLocal.button_color_purple,
                                      onPressed: () {
                                        snapshot.callUnsubscribe();
                                        //to prevent multiple clicks *****
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),

                    !snapshot.tournamentDetails['tournament']['has_quota']
                        ? Container(
                            margin: EdgeInsets.fromLTRB(24, 24, 24, 24),
                            padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                            decoration: BoxDecoration(
                              color: ColorsLocal.button_color_pink.withOpacity(0.7),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Column(
                              children: [
                                Text(
                                  '${LocaleKey.YOU_CANT_PLAY_MORE.toLocaleText()}',
                                  style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.white, fontWeight: FontWeight.w700),
                                ),
                                Text(
                                  '${LocaleKey.PARTICIPATE_IN_OTHER_TOURNAMENTS.toLocaleText()}',
                                  style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: Colors.white, fontWeight: FontWeight.w400),
                                ),
                              ],
                            ),
                          )
                        : Container(),

                    snapshot.tournamentPacksLoaded ? Visibility(
                      visible: !AppSessionSettings.isNepaliUser(),
                      child: Container(
                        margin: EdgeInsets.only(bottom: 24),
                        height: 64,
                        child: ListView.builder(
                          itemCount: snapshot.tournamentPackages.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (BuildContext context, int index) {
                              return InkWell(
                                onTap: (){
                                  Navigator.pushNamed(context, PaymentMethodRoute, arguments: {
                                    'bundle_id': int.parse(snapshot.tournamentPackages[index].id)
                                  }).then((value) {
                                    snapshot.loadDetails();
                                  });
                                },
                                child: Container(
                                  width: 220,
                                  margin: EdgeInsets.fromLTRB(index == 0 ? 36 : 0, 0, 12, 0),
                                  padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
                                  decoration: BoxDecoration(
                                    //color: Colors.grey[100],
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      width: 1,
                                      color: Colors.grey[200]
                                    )
                                  ),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.stretch,
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    snapshot.tournamentPackages[index].title,
                                                    style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontSize: 14,
                                                      color: ColorsLocal.text_color,
                                                      fontWeight: FontWeight.w600
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  '${snapshot.tournamentPackages[index].price} ${LocaleKey.BDT.toLocaleText()}',
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontSize: 14,
                                                      color: ColorsLocal.text_color_pink,
                                                      fontWeight: FontWeight.w600
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Text(
                                              snapshot.tournamentPackages[index].caption,
                                              style: TextStyle(
                                                  fontFamily: "Poppins",
                                                  fontSize: 12,
                                                  color: ColorsLocal.text_color.withOpacity(0.7),
                                                  fontWeight: FontWeight.w400
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            )
                                          ]
                                        ),
                                      ),
                                      SizedBox(
                                        width: 16,
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.white,
                                            border: Border.all(
                                                width: 0.5,
                                                color: Colors.grey[200]
                                            ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.grey[300],
                                              spreadRadius: 0.1,
                                              blurRadius: 4
                                            )
                                          ]
                                        ),
                                        padding: EdgeInsets.all(4),
                                        child: Icon(
                                          Icons.arrow_forward,
                                          size: 20,
                                          color: Colors.grey[600],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              );
                            }
                        ),
                      ),
                    ) : Container(),
                  ],
                ),
              ),
            ),
          ),
          Visibility(
            visible: false,
            child: Container(
              margin: EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Image.asset(
                "assets/images/promo_banner.png",
              ),
            ),
          ),
        ],
      );
    }
  }

  Widget _buildStep2(BuildContext context, TournamentDetailsVM snapshot) {
    if (snapshot.detailsLoaded == false && snapshot.tournamentDetails == null) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 20, 120, 18),
        child: MyShimmer.fromColors(
            child: Container(
              height: 20,
              width: MediaQuery.of(context).size.width.toCustomWidth() - 150,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      return Container(
        margin: EdgeInsets.fromLTRB(20, 20, 20, 18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    child: Text(
                      LocaleKey.RECENT_BEST.toLocaleText(),
                      style: TextStyle(fontSize: 16, color: ColorsLocal.text_color, fontFamily: "Poppins", fontWeight: FontWeight.w600),
                    ),
                  ),
                  AppSessionSettings.isNepaliUser() && snapshot.tournamentDetails['tournament']['score'] != null
                      ? Container(
                          margin: EdgeInsets.only(top: 8),
                          child: Row(
                            children: [
                              Container(
                                child: Text(
                                  "Your Score: ",
                                  style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color, fontWeight: FontWeight.w400),
                                ),
                              ),
                              Container(
                                child: Text(
                                  snapshot.tournamentDetails['tournament']['score'].toString(),
                                  style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: Colors.green[500], fontWeight: FontWeight.w600),
                                ),
                              ),
                            ],
                          ),
                        )
                      : Container()
                ],
              ),
            ),
            snapshot.tournamentDetails['tournament']['participant_count'] >= SHORT_RANKLIST_COUNT
                ? Container(
                    child: RichText(
                      text: TextSpan(
                          text: LocaleKey.SEE_ALL.toLocaleText(),
                          style: TextStyle(fontFamily: "Poppins", fontSize: 12, color: ColorsLocal.hexToColor("999999"), fontWeight: FontWeight.w600),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.pushNamed(context, ReccentBestAllRoute, arguments: {"tournament_id": tournamentId});
                              //TODO show full list ****
                            }),
                    ),
                  )
                : Container()
          ],
        ),
      );
    }
  }

  Widget _buildPositions(BuildContext context, TournamentDetailsVM snapshot, int index) {
    if (snapshot.detailsLoaded == false) {
      return Container(
        margin: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: MyShimmer.fromColors(
            child: Container(
              height: 50,
              width: MediaQuery.of(context).size.width.toCustomWidth(),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(7),
              ),
            ),
            baseColor: Colors.grey[300],
            highlightColor: Colors.white),
      );
    } else {
      List rankList = snapshot.tournamentDetails['ranking'];
      return Container(
        margin: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(7),
          child: InkWell(
            borderRadius: BorderRadius.circular(7),
            child: Container(
              padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Badge(
                    elevation: 0,
                    padding: EdgeInsets.all(0),
                    badgeColor: Colors.transparent,
                    position: BadgePosition.bottomEnd(bottom: -8, end: -4),
                    animationDuration: Duration(milliseconds: 0),
                    animationType: BadgeAnimationType.slide,
                    badgeContent: Container(
                      margin: EdgeInsets.all(1.5),
                      padding: EdgeInsets.fromLTRB(6, 0, 6, 0),
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(width: 2, color: Colors.white),
                        color: ColorsLocal.hexToColor("8435E8"),
                      ),
                      child: Text(
                        rankList[index]["position"].toString().toLocaleNumber(),
                        style: TextStyle(color: Colors.white, fontFamily: "Poppins", fontWeight: FontWeight.w600, fontSize: 8),
                      ),
                    ),
                    child: Container(
                        //margin: EdgeInsets.fromLTRB(8, 8, 4, 8),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
//                        border: Border.all(
//                          width: 2,
//                          color: Colors.grey[300],
//                        ),
                          shape: BoxShape.circle,
                        ),
                        constraints: BoxConstraints.tightFor(height: 34, width: 34),
                        child: CachedNetworkImage(
                          imageUrl: rankList[index]['image_url'].toString(),
                          imageBuilder: (context, imageProvider) => Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              //borderRadius: BorderRadius.circular(4),
                              image: DecorationImage(
                                image: imageProvider,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          placeholder: (context, url) => MyShimmer.fromColors(
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                //borderRadius: BorderRadius.circular(8),
                                color: Colors.grey[300],
                              ),
                            ),
                            baseColor: Colors.grey[300],
                            highlightColor: Colors.white,
                          ),
                          errorWidget: (context, url, error) => Icon(Icons.error),
                        )),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(24, 0, 16, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            rankList[index]['name'].toString(),
                            style: TextStyle(fontFamily: "Poppins", fontSize: 13, color: ColorsLocal.text_color, fontWeight: FontWeight.w500),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            '${LocaleKey.LEVEL.toLocaleText()} ${rankList[index]['level'].toString().toLocaleNumber()}',
                            style: TextStyle(fontFamily: "Poppins", fontSize: 10, color: ColorsLocal.text_color, fontWeight: FontWeight.w400),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
//                    decoration: BoxDecoration(
//                        borderRadius: BorderRadius.circular(10),
//                        border: Border.all(
//                            width: 1, color: ColorsLocal.text_color_pink_2)),
                    padding: EdgeInsets.fromLTRB(15, 4, 15, 4),
                    child: Text(
                      rankList[index]['points'].toString().toLocaleNumber(),
                      style: TextStyle(fontFamily: "Poppins", fontSize: 14, color: ColorsLocal.text_color_pink_2, fontWeight: FontWeight.w600),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  )
                ],
              ),
            ),
            onTap: () {
              AddFriendPU.show(context, rankList[index]);
            },
          ),
        ),
      );
    }
  }
}
